function removeAjaxIndicator() {

  $(document).bind('ajaxSend', function(event, xhr, settings) {
    if ($('.ajax-loading').length === 0 && settings.contentType != 'application/octet-stream') {
    $('#ajax-indicator').hide();   
    }
  });
  $(document).bind('ajaxStop', function() {
    $('#ajax-indicator').hide(); 
  });
}


$(document).ready(function(){

  // convert static text in arabic language
  window.t=function(key) {
    const locale=$('html').attr('lang')||'en';

    const translations = window.I18n.translations;
    // Try to find the translation in the selected locale, then fallback to English
    if (translations[locale] && translations[locale][key]) {
      return translations[locale][key];
    } else if (translations['en'] && translations['en'][key]) {
      console.warn(`Missing translation for key: "${key}" in locale: "${locale}". Falling back to English.`);
      return translations['en'][key];  // Fallback to English if not found in the selected locale
    } else {
      console.warn(`Missing translation for key: "${key}" in both Arabic and English.`);
      return key;  // If the key is not found in either language, return the key itself
    }
  }


  document.getElementById('search').blur(); // Blur the search bar

  var perpage=20;
  var pagenum=1;
  var total_pages;
  var project_perpage=20;
  var project_pagenum=1;
  var project_total_pages;
  let  ganttData =[];
  var allProjects=[];
  var allIssues=[];

  // //  initialize gantt element 
  // var element = document.getElementById("gantt_here"); 
  // var gantt = new ztGantt(element);

    // global variables
    var element = document.getElementById("gantt_here");
    window.gantt = new ztGantt(element);

  removeAjaxIndicator();


  gantt.options.taskOpacity = 0.6;
  gantt.options.taskProgress=true;
  gantt.options.addTaskOnDrag = false;
  gantt.options.weekends = ["Sat", "Sun"];
  // gantt.options.addLinks = true;

  gantt.options.addLinks =(task) => {
 if(task.parent===0 || task.subtask.length>0)
      {
        return false;
      }
      return true;
  }
  // gantt.options.collapse = false;
  gantt.options.scale_height = 30;   
  gantt.options.row_height = 30;
  gantt.options.minColWidth = 50;
  gantt.options.date_format="%Y-%m-%dT%H:%i:%s.000Z";
  gantt.options.exportApi = "https://zt-gantt.zehntech.net";    

  gantt.options.showBaseline = project !=null? enabled_modules:false;   

  gantt.options.taskColor = (task)=> { 
  
    if (task.parent == 0) { 
      return false; 
    } 
    return true; 
  }; 


  const dropdown = $("#detail"); 
  if (dropdown_selected_option) {
    dropdown.val(dropdown_selected_option);
    if(dropdown_selected_option==="expand")
    {
     gantt.options.collapse =false;
    }
    else{
      gantt.options.collapse = true;
    }
   
  }

  var gantt_data=[];
// Fix bug/73630
var textFilter = `<div zt-gantt-ignore='true' class='searchEl'>${t('label_name')} <span tabindex='0' onclick='addIssue()' onkeypress='if (event.key === \"Enter\") addIssue()' class='button_issue_gantt'>Add Issue</span></div>`;

  // var filter=`<div onclick="showColumns()" class="plus_icon"></div>`

    // Gantt columns start
    gantt.options.columns = [ 
        {name: "text",
          width: 350, 
          min_width: 230, 
          max_width: 450, 
          tree: true, 
          // label:"text",
          label:textFilter, 
          resize: true, 
          template: (task) => {  return `<span>${ task.text }</span>`;}, 
        }, 
        {
          name: "add",
          width: 40,
          label: `${t('label_edit')}`,
          min_width: 40,
          max_width: 40,
          align: "center",
          tree: false,
          resize: true,
          template: (task) => {
            const taskId = task.id;
            const params = window.location.search;
            const parameters = new URLSearchParams(params);
            const project_id = parameters.get('project_id');
            // Check if project_id is present
            if (project_id) {
              return `<span tabindex="0" class="add-task-icon" data-task-id="${taskId}"></span>`;
            } 
            else {
              if(task.parent!=0){
                return `<span tabindex="0" class="add-task-icon" data-task-id="${taskId}"></span>`;
              } 
              else {
                return '';
              }
            }
          }
        }
      ]; 
      // gantt config column end
 
       // code to close customize div 
        document.addEventListener('click', function(event) {
          const columnDiv = document.getElementById('column');
          const exportDiv=document.getElementById("export")
        if(columnDiv){

          if (!columnDiv.contains(event.target) && 
              !event.target.classList.contains('filter_div') && 
              !event.target.classList.contains("filter") &&
              !event.target.classList.contains("icon-setting-gantt")) {
              columnDiv.style.display = 'none';
          }
          if(event.target.classList.contains("filter_div")||
            event.target.classList.contains("filter")||
            event.target.classList.contains("icon-setting-gantt")){
            columnDiv.style.display = 'block';
          }

        }
        if(exportDiv){

          if(!exportDiv.contains(event.target) 
             && !event.target.classList.contains('export-data') &&
            !event.target.classList.contains("export-img")){
            exportDiv.style.display = 'none'; 
          }
          if(event.target.classList.contains("export-data")
          ||event.target.classList.contains("export-img")){
            exportDiv.style.display = 'block'; 
          }
        }
        });

        document.addEventListener('keypress', function(event) {
          if(event.key ==='Enter'){
          const columnDiv = document.getElementById('column');
          if (!columnDiv.contains(event.target) && !event.target.classList.contains('filter_div')&& !event.target.classList.contains("filter")&&!event.target.classList.contains("icon-setting-gantt")) {
            columnDiv.style.display = 'none';
          }
         if(event.target.classList.contains("filter_div")||event.target.classList.contains("filter")||event.target.classList.contains("icon-setting-gantt")){
            columnDiv.style.display = 'block';
          }
        }
        });
        // code to close customize div end 
     
          getFilters();
  
        function getFilters(){
          $.ajax({
            url:project!=null?`${url}/get/filter/data?project_id=${project}`:`${url}/get/filter/data`,
            method:'GET',
            async:true,
            beforeSend: function(){

               $('.circle-loader').show();
             },
            success:function(res)
            {
               if(res.data&&res.data.length!=0)
               {
                res.data.map((i)=>{
                  if(i.project_id===project)
                  {
                    showcustomizedOptions(i, projectID);
                  }
                  else{
                    if(i.project_id==null)
                    {
                      showcustomizedOptions(i, projectID);
                    }
                  }
                })
               }
            },
            error:function(err)
            {

            }
          })
        }
        
  // cusotmize column option code and show them start
      function getUrlParameter(name) {
          name = name.replace(/[\[]/, '\\[').replace(/[\]]/, '\\]');
          var regex = new RegExp('[\\?&]' + name + '=([^&#]*)');
          var results = regex.exec(location.search);
          return results === null ? '' : decodeURIComponent(results[1].replace(/\+/g, ' '));
      }
      let projectID = getUrlParameter('project_id');
      window.toggleColumn=function(e){
       const checkbox=e.target;
       const columnName=checkbox.value;
       const isChecked=checkbox.checked;
      if (isChecked) {
          let columnOrder = JSON.parse(localStorage.getItem('columnOrder')) || {};
          if (!columnOrder[projectID]) {
              columnOrder[projectID] = [];
          }
          if (!columnOrder[projectID].includes(columnName)) {
              columnOrder[projectID].push(columnName);
          }
          localStorage.setItem('columnOrder', JSON.stringify(columnOrder));
      } else {
          let columnOrder = JSON.parse(localStorage.getItem('columnOrder')) || {};
          if (columnOrder[projectID]) {
              columnOrder[projectID] = columnOrder[projectID].filter(col => col !== columnName);
              localStorage.setItem('columnOrder', JSON.stringify(columnOrder));
          }
      }

       $.ajax({
        url:`${url}/update_task_options?key=${api_key}`,
        method: 'POST',
        data: { [columnName]: isChecked ,
               project_id:project?project:null},
                
        success: function(response) {
        },
        error: function(error) {
          console.error(error);
        }
      });
    
        if(e.target.checked&&e.target.value=="assignee")
        {
          var isAssigneeExists =  gantt.options.columns.some(function(obj) {
            return obj.name === 'assigned_to';
          });
          if (!isAssigneeExists) {{
            gantt.options.columns.push({name: "assigned_to",
            width: 130, 
            min_width: 100, 
            max_width: 200, 
            align: "center", 
            tree: false,
            label: t('label_assignee'), 
            resize: true, 
            template: (task) => { 
              if(task.parent!=0)
              {
                return `<span>${ task.assigned_to !=null?task.assigned_to:"Not Assigneed" }</span>`; 
              }
              else{
                return " ";
              }
            }}
            )
            gantt.render();
          }
         }
        }
         if(!e.target.checked&&e.target.value=="assignee"){
          // Find the index of the object with name="assignee"
            var indexToRemove = gantt.options.columns.findIndex(function(obj) {
              return obj.name === 'assigned_to';
            });
            
            if (indexToRemove !== -1) {
              // Remove the column from the array using splice
              gantt.options.columns.splice(indexToRemove, 1);
              gantt.render();
            }
        }
        if(e.target.checked&&e.target.value=="progress")
        {
          var isProgressExists =  gantt.options.columns.some(function(obj) {
            return obj.name === 'progress';
          });
          if(!isProgressExists)
          {
          gantt.options.columns.push(
          {name: "progress",
            width: 80, 
            min_width: 80, 
            max_width: 150,
              tree: false, 
              align: "center", 
              label: t('label_progress'), 
              resize: true, 
              template: (task) => { 
               return `<span>${task.progress}%</span>`; 
               }
            }
          )
          gantt.render();
          }
        }
         if(!e.target.checked&&e.target.value=="progress"){
           // Find the index of the object with name="progress"
           var indexToRemove = gantt.options.columns.findIndex(function(obj) {
            return obj.name === 'progress';
          });
          if (indexToRemove !== -1) {
            // Remove the column from the array using splice
            gantt.options.columns.splice(indexToRemove, 1);
            gantt.render();
          }
        }
        if(e.target.checked&&e.target.value=="estimated_hour")
          {
            var isEstimationExists =  gantt.options.columns.some(function(obj) {
              return obj.name === 'estimated_hours';
            });
            if(!isEstimationExists)
            {
            gantt.options.columns.push(
              {name: "estimated_hours",
                width: 80, 
                min_width: 80, 
                max_width: 150,
                  tree: false, 
                  align: "center", 
                  label: t('label_estimation'), 
                  resize: true, 
                  template: (task) => {
                    
                      return `<span>${task.estimated_hours !=null?task.estimated_hours:0}h</span>`; 
                   }
                }
              )
              gantt.render(); 
            }  
          }
           if(!e.target.checked&&e.target.value=="estimated_hour")
          {
                // Find the index of the object with name="estimated hours
           var indexToRemove = gantt.options.columns.findIndex(function(obj) {
            return obj.name === 'estimated_hours';
          });
          if (indexToRemove !== -1) {
            // Remove the column from the array using splice
            gantt.options.columns.splice(indexToRemove, 1);
            gantt.render();
          }
          }

          if(e.target.checked&&e.target.value=="task")
          {
            // template for  issue tickets
            gantt.templates.grid_file = (task) => {
              var issue_id;
              if (task.parent != 0) {
                var tracker_name = task.hasOwnProperty("tracker") ? task.tracker.name : " ";
                issue_id =task.id.includes("i") ? task.id.replace("i","") : task.id;
                return `<div class='gantt_tree_icon gantt_file  ${tracker_name}'><a  target="_blank" class="link-issue ${tracker_name}" href='${url}/issues/${issue_id}'>#${issue_id}</a></div>`;
              }
            };
            gantt.render();
          }
          if(!e.target.checked&&e.target.value=="task")
          {
             // template for  issue tickets
              gantt.templates.grid_file = (task) => {
                return ``;
            };
            gantt.render();
          }

      } 
      function showcustomizedOptions(i,projectID) {
        const columnOrder = JSON.parse(localStorage.getItem('columnOrder')) || {};
        const projectColumnOrder = columnOrder[projectID] || [];
        // Iterate through the column order and display columns accordingly
        projectColumnOrder.forEach(columnName => {
            switch (columnName) {
                case 'assignee':
                    document.getElementsByClassName('assignee')[0].checked = i.assignee;
                    if (i.assignee) {
                        var isAssigneeExists = gantt.options.columns.some(function(obj) {
                            return obj.name === 'assigned_to';
                        });
                        if (!isAssigneeExists) {
                            gantt.options.columns.push({
                                name: "assigned_to",
                                width: 130,
                                min_width: 100,
                                max_width: 200,
                                align: "center",
                                tree: false,
                                label: t('label_assignee'),
                                resize: true,
                                template: (task) => {
                                    if (task.parent != 0) {
                                        // return `<span>${task.assigned_to != null ? task.assigned_to :" ${t('label_delete_issue_confirmation')}" }</span>`;
                                        // var lang = $("html").attr("lang");
                                        // return `<span>${task.assigned_to != null ? task.assigned_to : (lang === "ar" ? "غير معين" : "Not Assigned")}</span>`;
                                        return `<span>${task.assigned_to != null ? task.assigned_to : t('label_not_assigned')}</span>`;


                                    } else {
                                        return " ";
                                    }
                                }
                            });
                            gantt.render();
                        }
                    }
                    break;
                case 'progress':
                    document.getElementsByClassName('progress')[0].checked = i.progress;
                    if (i.progress) {
                        var isProgressExists = gantt.options.columns.some(function(obj) {
                            return obj.name === 'progress';
                        });
                        if (!isProgressExists) {
                            gantt.options.columns.push({
                                name: "progress",
                                width: 80,
                                min_width: 80,
                                max_width: 150,
                                tree: false,
                                align: "center",
                                label: t('label_progress'),
                                resize: true,
                                template: (task) => {
                                    return `<span>${task.progress}%</span>`;
                                }
                            });
                            gantt.render();
                        }
                    }
                    break;
                case 'estimated_hour':
                    document.getElementsByClassName('estimated_hour')[0].checked = i.estimated_hour;
                    if (i.estimated_hour) {
                        var isEstimationExists = gantt.options.columns.some(function(obj) {
                            return obj.name === 'estimated_hours';
                        });
                        if (!isEstimationExists) {
                            gantt.options.columns.push({
                                name: "estimated_hours",
                                width: 80,
                                min_width: 80,
                                max_width: 150,
                                tree: false,
                                align: "center",
                                label: t('label_estimation'),
                                resize: true,
                                template: (task) => {
                                    return `<span>${task.estimated_hours != null ? task.estimated_hours : 0}h</span>`;
                                }
                            });
                            gantt.render();
                        }
                    }
                    break;
                case 'task':
                    document.getElementsByClassName('zt-task')[0].checked = i.task;
                    if (i.task) {
                        gantt.templates.grid_file = (task) => {
                            var issue_id;
                            if (task.parent != 0) {
                                var tracker_name = task.hasOwnProperty("tracker") ? task.tracker.name : " ";
                                issue_id = task.id.includes("i") ? task.id.replace("i", "") : task.id;
                                return `<div class='gantt_tree_icon gantt_file  ${tracker_name}'><a  target="_blank" class="link-issue ${tracker_name}" href='${url}/issues/${issue_id}'>#${issue_id}</a></div>`;
                            }
                        };
                        gantt.render();
                    }
                    break;
                default:
                    break;
            }
        });
      }
  // customize gantt column end and show them
       
   // Zt gantt week start end function
    function weekStartAndEnd(t) {
      const e = t.getDay();
      let a, n;
      0 === e
        ? ((a = gantt.add(t, -6, "day")), (n = t))
        : ((a = gantt.add(t, -1 * e + 1, "day")),
          (n = gantt.add(t, 7 - e, "day")));
      return {
        startDate: a,
        endDate: n,
        weekNum: gantt.formatDateToString("%W", t),
      };
    }
     
     // Zt gantt start end function end 
    //  gantt.options.scales= [ 
    //         { 
    //             unit: "week", 
    //             step: 1,
    //             format: (t) =>{
    //               const { startDate: a, endDate: n, weekNum: i } = weekStartAndEnd(t);
    //               return ` ${gantt.formatDateToString(
    //                 "%j %M",
    //                 a
    //               )} - ${gantt.formatDateToString(
    //                 "%j %M",
    //                 n
    //               )}, ${a.getFullYear()}`;
    //             }
    //         },
    //         { 
    //             // unit: "day",step: 1, format:(t)=>{
    //             //   return `${gantt.formatDateToString("%d", t)}<br/><span class='day_scale'>${gantt.formatDateToString("%D",t)}</span>`
    //             // }
    //             unit: "day",step: 1,  format:(t)=>{
    //               return `${gantt.formatDateToString("%d", t)}`
    //             }
    //         }, 
    //     ]; 
   
        
        //ZT Gantt header class to show background color on  right scale 
          gantt.templates.scale_cell_class = (date, scale, scaleIndex) => {
            if(scaleIndex==1)
            {
                return "my-scale-class index1"
            }
            else
            {
                return "my-scale-class index2"
            }
          
          }
          //ZT Gantt header class left side start 
           gantt.templates.grid_header_class = (columns,i) => {
            return "my-header-class test"
          }
          

         
     
     
          gantt.templates.taskbar_text = function (start, end, task) {
            // var actual_start_pos = gantt.posFromDate(start);
            // var actual_end_pos = gantt.posFromDate(end);
            // var actual_width = actual_end_pos - actual_start_pos;
        
            // var html = "";
        
            // // Draw the actual task bar
            // if (task.parent == 0) {
            //     if (task.progress == 0 || task.type == "milestone") {
            //         html += task.text;
            //     } else if (task.duration < 3) {
            //         html += task.progress + '%';
            //     } else {
            //         html +=`<div style="display:flex; flex-direction:row;">
            //                 <div style="display:flex; width:${task.progress}%; justify-content:center;">${task.progress}%</div>
            //                 <div class="task_text" style="display:block; width:${100-task.progress}%; justify-content:center;">${task.text}</div>
            //               </div>`;
            //     }
            // } else {
            //     html += `<div style="display:flex; flex-direction:row;">
            //     <div style="display:flex; width:${task.progress}%; justify-content:center;">${task.progress}%</div>
            //     <div class="task_text" style="display:block; width:${100-task.progress}%; justify-content:center;">${task.text}</div>
            //    </div>`;
            // }
        
            // // Draw the baseline task bar if baseline dates are present
         
            // if (task.baseline_start_date && task.baseline_due_date) {
            //   console.log(task.baseline_start_date ,task.baseline_due_date,"html...");
            //     var baseline_start_pos = gantt.posFromDate(storedStart);
            //     var baseline_end_pos = gantt.posFromDate(storedEnd);
            //     var baseline_width = baseline_end_pos - baseline_start_pos;
            //     console.log(baseline_start_pos,"sta...");
            //     const taskLeft =gantt.posFromDate(start);
            //     let currentDate = new Date(start);
            //     const endData=new Date(end)
            //     while(currentDate.valueOf() <= endData.valueOf()){

            //       let cellStart = currentDate;
            //       // cellStart=cellStart.setHours(0)
            //       const cellEnd = gantt.add(currentDate,1,"day");
            //       // get relative position of each column inside the task
            //       const cellLeft = gantt.posFromDate(cellStart) - taskLeft;
            //       const cellRight = gantt.posFromDate(cellEnd) - taskLeft;
            //       const cellWidth = cellRight - cellLeft;
            //       console.log(cellLeft,cellWidth,"cell left cellwidht...");
            //       html += `<div  class='parent-bar-style' style='position:absolute;left:
            //          ${cellLeft}px;width:${cellWidth}px;'> <span class='span-parent'>  </span></div>`;
            //       currentDate = cellEnd;
            //     }
        
            //     // html += `
            //     //      <div class="gantt_baseline_bar" >
            //     //         <div class="baseline_task_bar" style="
            //     //         left: ${baseline_start_pos}px;
            //     //         width: ${baseline_width}px;
            //     //         height: 50%;
            //     //         top: 50%;
            //     //         background-color: #d3d3d3;
            //     //         position: absolute;
            //     //         z-index: 1;
            //     //         opacity: 0.5;"></div>
            //     //     </div>
            //     // `;
            // }
          
        
            // return html;

            if(task.progress==0||task.type=="milestone")
              {
                return task.text;
              }
              else if(task.duration<3)
              {
                return task.progress+'%';
              }
              else{
                  return `<div style="display:flex; flex-direction:row;">
                  <div style="display:flex; width:${task.progress}%; justify-content:center;">${task.progress}%</div>
                  <div class="task_text" style="display:block; width:${100-task.progress}%; justify-content:center;">${task.text}</div>
                 </div>`
              }
        }
        
          gantt.templates.task_row_class = (start, end, task) => {
            return "timeline_row_class"
          }
          gantt.templates.grid_row_class = (start, end, task) => {
            if(task.parent==0)
            {
              return "grid_row_class_parent"
            }
            else{
              return "grid_row_class"
            }
           
            }
            gantt.templates.task_class = (start, end, task) => {
              if(task.parent==0)
              {
                return "zt_task_parent"
              }
               else{
                return task.baseline_start_date && task.baseline_due_date ? "zt_task has-baseline" : "zt_task";
              
               }
             
            }
          // other options code
          // full screen function 
          window.showFullscreen=function(){
            // $("#menu-gantt").addClass("onfullscreen");
            gantt.requestFullScreen();
            }
            // full screen code end 

            
      

            gantt.attachEvent("onCollapse", function (){
              // any custom logic here
              $("#menu-gantt").css("display","block"); 
              $("#gantt_here").css('position','relative');
              $("#wrapper").removeClass('zt-gantt-fullScreen-wrapper');
              $("#menu-gantt").removeClass("onfullscreen");
            });
          
            gantt.attachEvent("onExpand", function (){
              $("#menu-gantt").addClass("onfullscreen");
             $("#wrapper").addClass('zt-gantt-fullScreen-wrapper');
              // any custom logic here
              $("#menu-gantt").css("display","none");
              $("#gantt_here").removeClass('panel_open');
              $("#gantt_here").removeClass('panel_close');
              $("#gantt_here").css('position','absolute');
            });
          

          // Expand all and Collapse all functionality 
          $('#detail').change(function() {
            const selectedOption = $(this).val();
            // Expand all and Collapse all functionality 
             if(selectedOption=="expand")
            {
              gantt.expandAll();
            }
            else{
              gantt.collapseAll();
            }
            $.post("/update_preference", { selected_option: selectedOption , project_id: project }, function(data) {
            if (data.success) {
              // Successfully updated preference
            }
          });
       
        }); 
        // zoom level code start
        gantt.options.zoomLevel = "day";
        gantt.options.zoomConfig = {
          levels: [
          {
          name: "day",
          scale_height: 27,
          min_col_width:30,
          scales: [
            { 
              unit: "week", 
              step: 1,
              format: (t) =>{
                const { startDate: a, endDate: n, weekNum: i } = weekStartAndEnd(t);
                return ` ${gantt.formatDateToString(
                  "%j %M",
                  a
                )} - ${gantt.formatDateToString(
                  "%j %M",
                  n
                )}, ${a.getFullYear()}`;
              }
          },
          { 
              unit: "day",step: 1,  format:(t)=>{
                return `${gantt.formatDateToString("%j", t)}`
              }
          }],
          },
          {
          name: "week",
          scale_height: 27,
          min_col_width:30,
          scales: [
          { unit: "month", format: "%F, %Y" },
          {
          unit: "week",
          step: 1,
          format: function (date) {
          var dateToStr = gantt.formatDateToString("%d %M");
          var endDate = gantt.add(date, 6, "day");
          var weekNum = gantt.formatDateToString("%W",date);
          return (
          "WK" +
          weekNum 
          // +
          // ", " +
          // gantt.formatDateToString("%d %M",date) +
          // " - " +
          // gantt.formatDateToString("%d %M",endDate)
          );
          },
          },
    
          ],
          },
          {
          name: "month",
          scale_height: 27,
          min_col_width:100,
          scales: [
            { unit: "year", step: 1, format: "%Y" },
          { unit: "month", format: "%F, %Y" },
          ],
          },
          // {
          //   name: "quarter",
          //   scale_height: 27,
          //   min_col_width: 90,
          //   scales: [
          //     { unit: "year", step: 1, format: "%Y" },
          //     { unit: "quarter", step: 1, format: "Q%q" },
          //     { unit: "month", format: "%M" },
          //   ],
          // },
          {
          name: "year",
          scale_height: 50,
          min_col_width: 30,
          scales: [{ unit: "year", step: 1, format: "%Y" },
       
        ],
          },
          {
            name: "hour",
            scale_height: 27,
            min_col_width: 550,
            scales: [
              { unit: "day", step: 1, format: "%d %M" },
              { unit: "hour", step: 1, format: "%H" },
            ],
          },
          ],
          };
          // zoom level code end


          window.zoomConfig=function (e){
            // console.log(e,"change")
            gantt.options.zoomLevel = e.target.value;
           gantt.zoomInit(); 
          }
          
          window.weekView=function(e){
            if(e.target.value=="fullweek")
            {
              gantt.options.fullWeek=true; 
              gantt.render();
            }
            else{
              gantt.options.fullWeek=false; 
              gantt.render();
            }
         
              
          }
         
           function showGanttLoader(){
            const ztLoader = document.createElement("span");
            const ztLoaderDrop = document.createElement("div");
      
            ztLoader.id = "zt-gantt-loader";
            ztLoader.classList.add("zt-gantt-loader");
            ztLoaderDrop.classList.add("zt-gantt-loader-drop");
            
            document.body.append(ztLoaderDrop, ztLoader);
           }

           function hideGanttLoader(){
            const ztLoader = document.querySelector("#zt-gantt-loader");
            const ztLoaderDrop = document.querySelector(".zt-gantt-loader-drop");
      
            if (ztLoader) {
              ztLoader.remove();
            }
      
            if (ztLoaderDrop) {
              ztLoaderDrop.remove();
            }
           }

          // Export Gantt chart to pdf format
          window.export_data= function(){
            let contextMenu=document.getElementById("export");
            if(contextMenu)
            {
              contextMenu.style.display="none";
            }
            showGanttLoader();
           
            let ganttElement = document.getElementById("gantt_here");
            let sidebar = document.getElementById("zt-gantt-grid-left-data");
            let timeline =  document.getElementById("zt-gantt-right-cell");
            let isVerScroll = document.querySelector("#zt-gantt-ver-scroll-cell");
            let isHorScroll = document.querySelector("#zt-gantt-hor-scroll-cell");
            if (isVerScroll) {
              isVerScroll.style.display="none";
            }
            if (isHorScroll) {
              isHorScroll.style.display="none";
            }
            let verScrollWidth = isVerScroll ? isVerScroll.offsetWidth : 0
            let totalWidth= sidebar.offsetWidth + timeline.scrollWidth+verScrollWidth
         

            let totalHeight = sidebar.scrollHeight;
            let originalWidth = ganttElement.style.width;
            let originalHeight = ganttElement.style.height;
            let scaleFactor=0.41;
        
            ganttElement.style.width = `${totalWidth}px`;
            ganttElement.style.height = `${totalHeight}px`;
        
            // Use html2canvas to capture the entire Gantt chart
            html2canvas(ganttElement, {
                width: totalWidth,
                height: totalHeight,
                scale: 2, // Increase scale for better quality
                scrollX: 0, // Prevents horizontal scrolling during capture
                scrollY: 0  // Prevents vertical scrolling during capture
            }).then(canvas => {
                // Restore the original width and height of the Gantt container
                ganttElement.style.width = originalWidth;
                ganttElement.style.height = originalHeight;

                if (isVerScroll) {
                  // isVerScroll.classList.add("d-none");
                  isVerScroll.style.display="block";
                }
                if (isHorScroll) {
                  // isHorScroll.classList.add("d-none");
                  isHorScroll.style.display="block";
                }

                hideGanttLoader();

                if(contextMenu)
                {
                  contextMenu.style.display="none";
                }
                let imgData = canvas.toDataURL("image/png");
        
                // Create a new jsPDF instance with custom dimensions
                const { jsPDF } = window.jspdf;
                let pdf = new jsPDF({
                    orientation: totalWidth > totalHeight ? 'landscape' : 'portrait',
                    unit: 'px',
                    format: [totalWidth*scaleFactor, totalHeight*scaleFactor] // Custom dimensions based on content
                });
        
                // Add the image to the PDF
                pdf.addImage(imgData, 'PNG', 0, 0, totalWidth*scaleFactor, totalHeight*scaleFactor);
              
                // Save the PDF
                pdf.save("Gantt.pdf");
            }).catch(function(error) {
                console.error("Error generating PDF:", error);
               });
          
        }
        window.export_png=function(){
          let contextMenu=document.getElementById("export");
          if(contextMenu)
          {
            contextMenu.style.display="none";
          }
          showGanttLoader();
          let ganttElement = document.getElementById("gantt_here");
          let sidebar = document.getElementById("zt-gantt-grid-left-data");
          let timeline =  document.getElementById("zt-gantt-right-cell");
          let isVerScroll = document.querySelector("#zt-gantt-ver-scroll-cell");
          let isHorScroll = document.querySelector("#zt-gantt-hor-scroll-cell");
          if (isVerScroll) {
            isVerScroll.style.display="none";
          }
          if (isHorScroll) {
            isHorScroll.style.display="none";
          }
          let verScrollWidth = isVerScroll ? isVerScroll.offsetWidth : 0
          let totalWidth= sidebar.offsetWidth + timeline.scrollWidth+verScrollWidth
       

          let totalHeight = sidebar.scrollHeight;
          let originalWidth = ganttElement.style.width;
          let originalHeight = ganttElement.style.height;
      
          ganttElement.style.width = `${totalWidth}px`;
          ganttElement.style.height = `${totalHeight}px`;
      
          // Use html2canvas to capture the entire Gantt chart
          html2canvas(ganttElement, {
              width: totalWidth,
              height: totalHeight,
              scale: 2, // Increase scale for better quality
              scrollX: 0, // Prevents horizontal scrolling during capture
              scrollY: 0  // Prevents vertical scrolling during capture
          }).then(canvas => {
              // Restore the original width and height of the Gantt container
              ganttElement.style.width = originalWidth;
              ganttElement.style.height = originalHeight;

              if (isVerScroll) {
                // isVerScroll.classList.add("d-none");
                isVerScroll.style.display="block";
              }
              if (isHorScroll) {
                // isHorScroll.classList.add("d-none");
                isHorScroll.style.display="block";
              }
              hideGanttLoader();
              if(contextMenu)
              {
                contextMenu.style.display="block";
              }
              let imgData = canvas.toDataURL("image/png");
                // Create a link element
                   let link = document.createElement('a');
                   link.href = imgData;
                   link.download = 'Gantt.png'; // Set the name of the image file
   
                   // Append the link to the body and trigger the download
                   document.body.appendChild(link);
                   link.click();
                   document.body.removeChild(link);
          }).catch(function(error) {
              console.error("Error generating PDF:", error);
             });
        }
        window.export_excel=function(name = "Gantt"){
          let csv = "";
           let columns = gantt.options.columns.filter(col=>col.name !=="add");
           let ganttData=gantt.options.data;
          // Generate header row
          // Modify columns where name is "text" and change label to "Name"
            columns = columns.map(col => {
              if (col.name === "text") {
                col.label = "Name";  // Change label to "Name"
              }
              return col;  // Return modified column
            });
          let headerRow = columns.map(col => col.label).join(",") + "\n";
          csv += headerRow;

          // Convert Gantt data to CSV format
          csv += convertToCSV(ganttData,columns);
      
          // Recursive function to convert data to CSV
          function convertToCSV(array, columns) {
            let csvData = "";
        
            array.forEach(item => {
              let rowData = columns.map(col => {
            
                  let value;
            
                  // Handling specific fields with default values
                  switch (col.name) {
                    case "assigned_to":
                      value = item[col.name] || "Not Assigned";  // Show "Not Assigned" if undefined or null
                      break;
                    case "estimated_hours":
                      value = item[col.name] !== undefined && item[col.name] !== null ? item[col.name]+"h" : "0h";  // Show 0 if undefined or null
                      break;
                    case "progress":
                      value = item[col.name] !== undefined && item[col.name] !== null ? item[col.name] + "%" : "0%";  // Show 0% if undefined or null
                      break;
                    default:
                      value = item[col.name] || "";  // Default empty string for other undefined/null values
                  }
                  return String(value).replace(/,/g, " ");
            });
        
              csvData += rowData.join(",") + "\n";
        
              // If the item has children (subtasks), recursively add them
              if (item.children && item.children.length > 0) {
                csvData += convertToCSV(item.children, columns);
              }
            });
        
            return csvData;
          }
        
          // Create a download link
          let link = document.createElement("a");
          link.setAttribute(
            "href",
            "data:text/csv;charset=utf-8," + encodeURIComponent(csv)
          );
          link.setAttribute("download", `${name}.csv`);
        
          // Programmatically trigger the download
          link.click();
        }

      // Add today Marker
      $("#today").change(function(e){
        // console.log(e.target.checked,"e")
        if(e.target.checked)
        {
          gantt.addTodayFlag();
        
          localStorage.setItem('gantt_today_flag', true);
        }
        else{
          gantt.removeTodayFlag();
          localStorage.setItem('gantt_today_flag', false);
        }

      })

      // search task in gantt library function 
      window.searchTask=function(e) {
        let isFilter = e.target.value.trim() !== "";
        gantt.filterTask((task) => {
          if (task.parent === 0) {
            return task.text.toLowerCase().includes(e.target.value.toLowerCase())||task.id==e.target.value;
          } else {
            return task.text.toLowerCase().includes(e.target.value.toLowerCase())||task.issue_id==e.target.value;
          }
        }, isFilter,true);
      }
      // zt gantt tolltip formatiing
      gantt.templates.tooltip_text = function (start, end, task) {
        if(task.parent===0)
        {
          return `<b>${project==null? t('label_project_tooltip'): t('label_release_tooltip')}</b>
          ${task.text}
          <br/><b>${t('label_start_date_tooltip')}</b>
          ${isNaN(new Date (start))?"dd-mm-yy":gantt.formatDateToString("%d-%m-%y  %h:%i %A",start)}
          <br/><b>${t('label_end_date_tooltip')}</b>
          ${isNaN(new Date(end))?"dd-mm-yy":gantt.formatDateToString("%d-%m-%y  %h:%i %A", end)}<br/>
          <b>${t('label_duration_tooltip')}</b> ${task.duration} ${
          task.duration > 1 ? "Days" : "Day"}`;
        }
        else{
          return `<b>${t('label_task_tooltip')}</b>
          ${task.text}
          <br/><b>${t('label_start_date_tooltip')}</b>
          ${isNaN(new Date (start))?"dd-mm-yy":gantt.formatDateToString("%d-%m-%y  %h:%i %A",start)}
          <br/><b>${t('label_end_date_tooltip')}</b>
          ${isNaN(new Date(end))?"dd-mm-yy":gantt.formatDateToString("%d-%m-%y  %h:%i %A", end)}<br/>
          <b>${t('label_duration_tooltip')}</b> ${task.duration} ${
        task.duration > 1 ? "Days" : "Day"} <br/>
          <b>${t('label_estimation_tooltip')}</b> ${task.estimated_hours!=null?task.estimated_hours+"h":"0h"}<br/>
          <b>${t('label_assignee_tooltip')}</b> ${task.assigned_to!=null?task.assigned_to:"Anonymous"}`;
        }

     
      };

   

      // Gantt events
      // gantt.attachEvent("onTaskToggle",(event)=>{
      //   console.log(event,"event");
      //   if(event.isTaskOpened)
      //   {
      //     console.log("yes pen")
      //     gantt.options.collapse=false;
      //     toggleOpen=true;
      //   }
      // })
    
  
      // when user drag the progress of task
      gantt.attachEvent("onAfterProgressDrag", (event) => {
         let issue_id=parseInt(event.task.issue_id);
         let content={
          "done_ratio":event.task.progress          ,
        }
        $.ajax({
          type: "PUT",
          url: `${url}/issues/${issue_id}.json?key=${api_key}`,
          dataType: "json",
          contentType: "application/json",
          async: false,
          data: JSON.stringify({
            issue: content,
          }),
          success: function (result, status, xhr) {
               // Update progress in the Gantt column
               gantt.updateTaskData(event.task);
              //  gantt.updateTaskData(event.task.parent);
               let childs=gantt.getTask(event.task.parent).children;
            
               const sum=childs.reduce((sum,task)=>{
                 return sum = sum + task.progress
               },0)

               if(childs.length!=0)
               {
                 let progress=sum/childs.length;
                 let task=gantt.getTask(event.task.parent);
                 task.progress=parseInt(progress)
                //  console.log(task,"task")
                 gantt.updateTaskData(task)
                 gantt.render();
               }
          },
          error: function (xhr, status, error) {
              if(xhr.status == 422){
            let content = JSON.parse(xhr.responseText).errors;
            content.map((i)=>{
              if(i===t('label_due_date_must_be_greater_than_start_date'))
              {
                toastr["error"](t('label_start_date_greater_than_due_date'));
              }
              else{
                toastr["error"](i);
              }
          })
        }
        else if(xhr.status == 403)
        {
            toastr["error"](t('label_no_permissions'));
        } 
          },
        });
    
        });
        window.ClosedeleteModal=function(id){
          $(".div-modal").hide();
          $(`#link${id}`).css("display","none");
          disableTabindex();
        }
        window.closeTask=function(id){
          $(`#task${id}`).css("display","none");
          $(".update_issue").css("zIndex","10001");
          modelTabindex();
        }
           // delete link API
          window.DeleteLink=function(id){
            $.ajax({
              url: `${url}/relations/${id}.json?key=${api_key}`,
              method: "DELETE",
              success: function (response) {
                gantt.deleteLink(id);
                $(".div-modal").hide();
                $(`#link${id}`).css("display","none");
                toastr["success"](t('label_link_deleted_successfully'));
                
               },
              error: function (xhr, status, error) {
              },
            });
            disableTabindex();
          }

          window.deleteTask=function(id)
          {
        
            $.ajax({
              url: `${url}/issues/${id}.json?key=${api_key}`,
              method: "DELETE",
              success: function (response) {
                gantt.deleteTask("i"+id);
                //  cb(start,end);
                 cb(moment(storedStart ? storedStart : start), moment(storedEnd  ? storedEnd : end));
                //  gantt.openTask("i"+id);
                $(".div-modal").hide();
                $(".update_issue").hide();
                $(`#task${id}`).css("display","none");
                toastr["success"](t('label_issue_deleted_successfully'));
               },
              error: function (xhr, status, error) {
              },
            });
            modelTabindex();
          }
          
          window.modelTabindex = function () {
            if ($(".link-delete").is(':visible')) {
                $(":tabbable").attr("tabindex", -1);
                $(".link-delete [tabindex='-1']").attr('tabindex', 0);
                $("html").css("overflow", "hidden");
            } else {
                $("[tabindex='-1']").attr("tabindex", 0);
                $("html").css("overflow-y", "auto");
            }
          }


          window.deleteIssue=function(){
            let id=$("#deleteIssue").attr("value");
            let subtask=0;
            gantt.eachTask((task)=>{
              if(id==parseInt(task.issue_id))
              {
                subtask=task.subtask&&task.subtask.length!=0?task.subtask.length:0;
              }
            })
            $(".div-modal").show();
            $(".update_issue").css("zIndex","1040");

          
            if($(`#task${id}`).length===0)
                {
                  if(subtask!=0)
                  {
                    $("body").append(`<div id="task${id}" class="link-delete">
                    <div style="display:flex; justify-content:center;" class="delete-para">${t('label_delete_issue_confirmation')} ${subtask} subtask(s)</div>
                    <div style="display:flex; justify-content:center; margin-top:30px;">

                    <div id="btn-plan" onclick="closeTask(${id})" style="display:flex; margin-right:15px;   cursor:pointer">
                    <button  id="cancel-btn" style="cursor:pointer">${t('label_cancel')}</button>
                   </div>
                    <div onclick="deleteTask(${id})" type="button" style="display:flex;  cursor:pointer">
                    <button class="delete-issue"   style="cursor:pointer">${t('label_delete')}</button>
                   </div>
               
               
                        </div>
                    </div>`);
                 }
                  else{
                    $("body").append(`<div id="task${id}" class="link-delete">
                    <div style="display:flex; justify-content:center;" class="delete-para">${t('label_delete_issue_confirmation')}</div>
                    <div style="display:flex; justify-content:center; margin-top:30px;">
                    <div id="btn-plan" onclick="closeTask(${id})" style="display:flex;  margin-right:15px; cursor:pointer">
                    <button  id="cancel-btn" style="cursor:pointer">${t('label_cancel')}</button>
                   </div>
                    <div onclick="deleteTask(${id})" type="button" style="display:flex;   cursor:pointer">
                    <button class="delete-issue"  style="cursor:pointer">${t('label_delete')}</button>
                    </div>
             
                    
                  </div>
                  </div>`);
                  }
            
                }
                else{
                 $(`#task${id}`).css("display","block"); 
               } 
               modelTabindex();   
          }

        // on link double click 
        gantt.attachEvent("onLinkDblClick", (event) => {
          let id=event.link.id
           $(".div-modal").show();
           if($(`#link${id}`).length===0)
               {
                $("body").append(`<div id="link${id}" class="link-delete">
                                 <div style="display:flex; justify-content:center;" class="delete-para">${t('label_delete_link_confirmation')}</div>
                                 <div style="display:flex; justify-content:center; margin-top:30px;">
                                  <div id="btn-plan" onclick="ClosedeleteModal(${id})" style="display:flex;  margin-right:15px; cursor:pointer">
                                    <button  id="cancel-btn" style="cursor:pointer" >${t('label_cancel')}</button>
                                   </div>
                                 <div onclick="DeleteLink(${id})" type="button" style="display:flex;  cursor:pointer">
                                   <button id="save-btn"  style="cursor:pointer">${t('label_delete')}</button>
                                </div>
                        </div>
                </div>`);
               }
               else{
                $(`#link${id}`).css("display","block");
               }

               disableTabindex();
        });









        
        //  fires when new link is added
        gantt.attachEvent("onLinkAdd", (event) => {
          // console.log("onLinkAdd: ", event);
          const typeMapping = {
            "1": "start_to_start",
            "3":"start_to_finish",
            "2":"finish_to_finish",
            "0": "finish_to_start"
          };
          let relation_type;
          if (typeMapping.hasOwnProperty(event.link.type)) {
            relation_type = typeMapping[event.link.type];
          }
          let issue_id=parseInt(event.link.source.substring(1))

          let content={
            issue_to_id:parseInt(event.link.target.substring(1)),
            relation_type:relation_type 
          }
          $.ajax({
            type: "POST",
            url: `${url}/issues/${issue_id}/relations.json?key=${api_key}`,
            dataType: "json",
            contentType: "application/json",
            async: false,
            data: JSON.stringify({
              relation: content,
            }),
            success: function (result, status, xhr) {
                //  cb(start, end);
                 cb(moment(storedStart ? storedStart : start), moment(storedEnd  ? storedEnd : end));
                 gantt.options.collapse=false;
                 gantt.render();
              
            },
            error: function (xhr, status, error) {
               let link=false;
                if(xhr.status == 422){
              let content = JSON.parse(xhr.responseText).errors;
              content.map((i)=>{
                if(i===t('label_due_date_must_be_greater_than_start_date'))
                {
                  toastr["error"](t('label_start_date_greater_than_due_date'));
                }
                else{
                  toastr["error"](i);
                  if(i==="Related issue has already been taken")
                  {
                      gantt.deleteLink(event.link.id);
                  }
                }
    
      
            })
           }
           else if(xhr.status == 403)
            {
              toastr["error"](t('label_no_permissions'));
            } 
            },
          });
          return true;
          });

          gantt.attachEvent("onColorChange", (event) => {
            // console.log("onColorChange: ", event);
            let issue_id=event.task.issue_id;
            let content={
              issue_id:issue_id,
              color:event.taskColor
            }
        
            $.ajax({
              type: "PUT",
              url: `${url}/gantt/issues.json?key=${api_key}`,
              dataType: "json",
              contentType: "application/json",
              async: false,
              data: JSON.stringify(content),
              success: function (result, status, xhr) {
              },
              error: function (xhr, status, error) {
                 if(xhr.status == 403)
                  {
                      toastr["error"](t('label_no_permissions'));
                  } 
              },
            });
            });
            

          function changeFormat(date) {
            var today = new Date(date);
            var dd = String(today.getDate()).padStart(2, "0");
            var mm = String(today.getMonth() + 1).padStart(2, "0"); //January is 0!
            var yyyy = today.getFullYear();
            return  today = yyyy + "-" + mm + "-" + dd;
          }
          function DateFormatDMY(date) {
            var today = new Date(date);
            var dd = String(today.getDate()).padStart(2, "0");
            var mm = String(today.getMonth() + 1).padStart(2, "0"); //January is 0!
            var yyyy = today.getFullYear();
            return  today = dd + "-" + mm + "-" + yyyy;
          }
          
          // task drag template to restrict parent task to be moved , resize and drag and drop 
          gantt.templates.task_drag = (mode, task) => {
            if (task.parent == 0 || (task.children && task.children.length > 0)) {
            return false;
            }
            return true;
            };
           
          // on before task drag to add restrications
          gantt.attachEvent("onBeforeTaskDrag", (event) => {
            // console.log("onBeforeTaskDrag: ", event);
            if (event.task.children.length !== 0) {
              return false;
            } else {
              return true;
            }
          });
   
          // gantt.attachEvent("addTaskOnDrag", (event) => {
          //   // console.log("addTaskOnDrag: ", event.task);
          //      let parent=event.task.parent;
          //     //  console.log(parent,"parent");
          //      let parent_task=gantt.getTask(parent)
          //     //  console.log(parent_task,"parent task");
          //      if(!Number.isInteger(parent)&&parent.includes("i"))
          //      {
          //       if(parent_task.parent.includes("i"))
          //       {
          //         // console.log(parent_task,"parent task",gantt.getTask(parent_task.parent))
          //         fixed_version_id=gantt.getTask(parent_task.parent).fixed_version_id
          //         // fixed_version_id=parent_task.parent.replace("i","")
          //       }
          //       else{
          //         fixed_version_id=parent_task.parent
          //       }
              
          //      }
          //      else{
          //       fixed_version_id=event.task.parent
          //      }
          //     const params =window.location.search
          //     const parameters = new URLSearchParams(params);
          //     const  project_id = parameters.get('project_id');
          //     let content={
          //       project_id: project_id,
          //       tracker_id:4,
          //       author_id:login_user_id,
          //       start_date:changeFormat(event.task.startDate),
          //       due_date:changeFormat(event.task.endDate),
          //       gantt_start_date:new Date(event.task.startDate),
          //       gantt_due_date:new Date(event.task.endDate),
          //       subject: "Task Added",
          //       fixed_version_id:fixed_version_id,
                
          //     }
          //     if(!Number.isInteger(parent)&&parent.includes("i"))
          //     {
          //       content.parent_id=event.task.parent.replace("i"," ")
          //     }
        
          //     $.ajax({
          //       type: "POST",
          //       url: `${url}/create/issue.json?key=${api_key} `,
          //       contentType: "application/json",
          //       dataType: "json",
          //       async:false,
          //       data: JSON.stringify({
          //         issue_params: content,
          //       }),
          //       success: function (result, status, xhr) {
          //         // console.log(result,"result")
          //         // if( event.task.parent.includes("i"))
          //           gantt.addTask({
          //           id: "i"+result.issue_id,
          //           start_date: new Date(event.task.startDate),
          //           end_date: new Date(event.task.endDate),
          //           parent: !Number.isInteger(parent)&&parent.includes("i")? parent_task.parent: event.task.parent,
          //           text: "Task Added",
          //         });
          //         // console.log(gantt.getTask("i"+result.issue_id),"tasl")
          //         gantt.render();
          //         cb(moment(storedStart ? storedStart : start), moment(storedEnd  ? storedEnd : end));
          //       },
          //       error: function (xhr, status, error) {
          //             if(xhr.status == 422){
          //                 let content = JSON.parse(xhr.responseText).errors;
          //                 // console.log(content,"content")
          //                 content.map((i)=>{
          //                 toastr["error"](i);
          //           })
          //           }
          //           else if(xhr.status == 403)
          //           {
          //             toastr["error"](t('label_no_permissions'));
          //             } 
          //       },
          //     });
    
         
          
          // });

    // onAfter task drag event to update start date and end date
      gantt.attachEvent("onAfterTaskDrag", (event) => {
          let task1 =event.task; 
          // console.log(task1,new Date(task1.end_date),new Date(task1.start_date),"end date","start date")
          let issue_id=task1.parent!=0?task1.id.replace("i",""):task1.id;
          let start_date=changeFormat(task1.start_date);
          let due_date=changeFormat(task1.end_date);
          let gantt_start_date=new Date(task1.start_date);
          let gantt_due_date=new Date(task1.end_date);
      

          let content={
              "start_date":start_date,
              "due_date": due_date,
              "gantt_start_date":gantt_start_date,
              "gantt_due_date":gantt_due_date,
              "issue_id":issue_id
            }
            var baselineSelects = document.querySelectorAll('.baseline_select');
            var baseline_id;
            if(baselineSelects)
            {
            // Loop through each select element and get its selected value
            baselineSelects.forEach(select => {
               baseline_id = select.value;
            });
          }
       
          if(project)
          {
           if(enabled_modules)
              {
                if(baseline_id)
                {
                content.baseline_id=parseInt(baseline_id);
                }
              }
            }

              const params =window.location.search
              const parameters = new URLSearchParams(params);
              const filter=parameters.get('utf8');
         if(event.mode=='resize')
         {
           $.ajax({
                  type: "PUT",
                  url: `${url}/update/dates.json?key=${api_key}`,
                  dataType: "json",
                  contentType: "application/json",
                  async: false,
                  data: JSON.stringify({
                    issue_params: content,
                  }),
                  success: function (result, status, xhr) {
                    // console.log(task1,"task1")
                    let isMilestone = /\(milestone\)/i.test(task1.text);
      
                    var Issue = {  
                      id:task1.id, 
                      start_date:new Date(task1.start_date),
                      end_date:new Date(task1.end_date),
                      due_date:new Date(task1.end_date),
                      type:isMilestone&&task1.duration==1?"milestone":"task"
                    }
                   
                    gantt.updateTaskData(Issue);
                    //  projectGanttAPI(params,perpage,pagenum,filter,parseInt(baseline_id));
                    cb(moment(storedStart ? storedStart : start), moment(storedEnd  ? storedEnd : end));
                    // console.log(task1,new Date(task1.end_date),new Date(task1.start_date),"end date","start date before render")
                    gantt.render();
                    gantt.openTask("i"+issue_id);
                    gantt.autoScheduling(); 
                    // console.log(gantt.getTask(task1.id),"task");
                    toastr["success"](t('label_issue_updated_successfully'));
                  },
                  error: function (xhr, status, error) {
                   if(xhr.status == 422){
                    let content = JSON.parse(xhr.responseText).errors;
                     content.map((i)=>{
                      if(i===t('label_due_date_must_be_greater_than_start_date'))
                      {
                        toastr["error"](t('label_start_date_greater_than_due_date'));
                      }
                      else if(i===t('label_assignee_invalid'))
                      {
                        toastr["error"](t('label_user_not_member'));
                      }
                      else{
                        toastr["error"](i);
                      }
                  })
                 }
                 else if(xhr.status == 403)
                 {
                    toastr["error"](t('label_no_permissions'));
                 } 
               },
             });
             }
              if(event.mode=='move')
              {
                let fixed_version_id;
          
                if(task1.parent_id==null)
                {
                  fixed_version_id=event.task.parent
                }
             
                content={
                  "start_date":start_date,
                  "due_date": due_date,
                  "gantt_start_date":gantt_start_date,
                  "gantt_due_date":gantt_due_date,
                  "issue_id":issue_id,
                  // "fixed_version_id":fixed_version_id
                }
                if(project==null)
                {
                   content.project_id=event.task.parent;
                }
                else{
                   content.fixed_version_id=fixed_version_id
                }
                if(project)
                  {
                if(enabled_modules)
                  {
                    if(baseline_id)
                      {
                       content.baseline_id=parseInt(baseline_id);
                      }
                }
              }
                $.ajax({
                  type: "PUT",
                  url: `${url}/update/dates.json?key=${api_key}`,
                  dataType: "json",
                  contentType: "application/json",
                  async: false,
                  data: JSON.stringify({
                    issue_params: content,
                  }),
                  success: function (result, status, xhr) {
                    // cb(start,end)
                    cb(moment(storedStart ? storedStart : start), moment(storedEnd  ? storedEnd : end));
                    gantt.openTask("i"+issue_id);
                    // var Issue = {
                    //   id:task1.id, 
                    //   start_date:changeFormat(task1.start_date),
                    //   end_date: changeFormat(task1.end_date),
                    //   due_date:changeFormat(task1.end_date),
                    //   parent:fixed_version_id
                    // }
                    // gantt.updateTaskData(Issue);
                    if(task1.parent_id==null)
                    {
                      toastr["success"](t('label_issue_updated_successfully'));
                    }
                   
                    // gantt.render();
                  },
                  error: function (xhr, status, error) {
                  if(xhr.status == 422){
                    let content = JSON.parse(xhr.responseText).errors;
                    content.map((i)=>{
                      if(i===t('label_due_date_must_be_greater_than_start_date'))
                      {
                        toastr["error"](t('label_start_date_greater_than_due_date'));
                      }
                      else{
                        toastr["error"](i);
                      }
                  })
                }
                else if(xhr.status == 403)
                {
                    toastr["error"](t('label_no_permissions'));
                } 
               },
             })
           }
         });
        
        //  on after task drag event end
        
        // restrict the user to update progress if user is parent
        gantt.attachEvent("onBeforeProgressDrag", (event) => {
          // console.log("onBeforeProgressDrag: ", event);
          if(event.task.parent === 0||event.task.children.length!=0){
            return false;
          }else{
            return true;
          }
      
        });

          // restrict the user to add link from parent to child or child to parent
          gantt.attachEvent("onBeforeLinkAdd", (event) => {
            let source=gantt.getTask(event.sourceId);
            let target=gantt.getTask(event.targetId);
  
            if(source&&source.parent==0 || target&&target.parent==0 ||source.parent!=target.parent ){
              if(source.parent!=target.parent)
              {
                toastr["error"](t('label_related_issue_does_not_belong'));
              }
              return false;
            }else{
              return true;
            }
        
          });

  
      
         
   const start = moment().startOf('month');
   const end =  moment().endOf('month');


    var storedStart = localStorage.getItem("start");
    var storedEnd = localStorage.getItem("end");

      // if global gantt is enabled
      if(project==null)
      {
        storedStart=localStorage.getItem("gantt_start_global");
        storedEnd = localStorage.getItem("gantt_end_global");
      }
      else{
        storedStart = localStorage.getItem("start");
        storedEnd = localStorage.getItem("end");
      }

       
      // Particular project gantt API 
      function projectGanttAPI(params,perpage,pagenum,filter,baselineId)
      {

      $.ajax({
        type: "GET",
        url: filter ? `${url}/gantt/data.json?key=${api_key}&${params}`:`${url}/gantt/data.json?key=${api_key}`,
        dataType: 'json',
        async:true,
        beforeSend: function(){
          $('.circle-loader').show();
        },
        data:filter?{
          start_date: storedStart ? storedStart :start.format('YYYY-MM-DD'),
          due_date: storedEnd? storedEnd :end.format('YYYY-MM-DD'),
          per_page:perpage,
          page:pagenum,
          baseline_id:baselineId
        }:{
          start_date: storedStart ? storedStart :start.format('YYYY-MM-DD'),
          due_date: storedEnd? storedEnd :end.format('YYYY-MM-DD'),
          project_id:project,
          per_page:perpage,
          page:pagenum,
          baseline_id:baselineId
        },
        success: function (result, status, xhr) {
    

          $('.circle-loader').toggleClass('load-complete');
          $('.checkmark').toggle();
          setTimeout(() => {
            $(".unknown-div").css("display","none");
            $('.circle-loader').hide();
            }, 500);
            $('#nodata').css('display', 'none');
  
            if(result.allIssues.length!=0)
              {
                allIssues=result.allIssues;
              }
           
            if(result.data.length==0)
              {
                   $("#menu-gantt").css("display","none");
                   $("#gantt_here").css("display","none");
                   $(".export-data").css("display","none");
                   if(!$(".nodata")[0])
                   {
              
                    $(".gantt_here_div").before(`<p  style="margin-top:30px; margin-left:13px;" class="nodata">${t('label_no_data_to_display')}</p>`);
                   }
              }
              else{
                $(".nodata").remove();
                $("#menu-gantt").css("display","block");
                $("#gantt_here").css("display","block");
                $(".export-data").css("display","block");
                if(result.hasOwnProperty("pagination"))
                {
                total_pages=result.pagination.total_pages;
                }


                resource_data=result
                gantt_data=resource_data.data
                resource_data.data.map((i)=>{
                  i.start_date=i.gantt_start_date
                  i.end_date=i.gantt_due_date
     
                  if(i.parent_id!=null)
                  {
                    i.parent="i"+i.parent_id
                  }
                   i.issue_id=i.parent==0? i.id : i.id.replace("i","")  
                   if(i.parent==0)
                  {
                    // code to calculate progress of parent       
                     Sum=i.issues.reduce((sum,issue)=>{
                      if(issue.parent_id==null)
                      {
                        return  sum+issue.done_ratio
                      }
                      return  sum
                     },0)
                     const filteredArray = i.issues.filter(obj => obj.parent_id==null);
                     length=filteredArray.length
                     i.progress=length!=0 ?Math.round(Sum/length) :0
             
                    // calculate estimation of parent task 
                     estimation_sum=i.issues.reduce((sum,issue)=>{
                      return sum= sum+issue.estimated_hours
                     },0)
                     i.estimated_hours=Number.isInteger(estimation_sum)? estimation_sum : estimation_sum.toFixed(2) 
                  
                    //  calculation end 
                  }
                  else{
                    i.taskColor=i.color
                  let isMilestone = /\(milestone\)/i.test(i.text);
                  if(isMilestone&&i.s_date===i.due_date)
                  {
                    i.type="milestone";
                  }
                  }
                })

                 gantt.clearAll();
                 const typeMapping = {
                  "start_to_start": 1,
                  "start_to_finish": 3,
                  "finish_to_finish": 2,
                  "finish_to_start": 0
                };
                 resource_data.links.map((l)=>{
                  if (typeMapping.hasOwnProperty(l.type)) {
                    l.type = typeMapping[l.type];
                  }
                 })
               
                  gantt.options.data = resource_data.data;
                  gantt.options.links =resource_data.links
                  // console.log(gantt.options.data,"optionsdata...");

            
                  var ganttTodayFlag= JSON.parse(localStorage.getItem('gantt_today_flag'));
                  document.getElementById('today').checked = ganttTodayFlag !== null ? ganttTodayFlag : true;
                  if (ganttTodayFlag != false) {
                    gantt.options.todayMarker=true;
                  } else {
                    gantt.options.todayMarker=false;
                  }

                  gantt.render(element); 
                  gantt.autoScheduling(); 
                  gantt.updateBody();
                 
              }
        },
        error: function (xhr, status, error) {
           
          $('.circle-loader').toggleClass('load-complete');
          $('.checkmark').toggle();
          setTimeout(() => {
            $(".unknown-div").css("display","none");
            $('.circle-loader').hide();
            }, 500);
            if(xhr.status==403)
            {
              if(!$(".nodata")[0])
              {
                $(".gantt_here_div").before(`<p  style="margin-top:30px; margin-left:13px;" class="nodata">${t('label_no_data_to_display')}</p>`);
              }
            }
            else {
              var errorResponse = JSON.parse(xhr.responseText);
              if (errorResponse.errors && errorResponse.errors.length > 0) {
                var errorHtml = '<ul>';
                errorResponse.errors.forEach(function(errorMessage) {
                    errorHtml += '<li>' + errorMessage + '</li>';
                });
                errorHtml += '</ul>';
                $('#errorExplanation').html(errorHtml);
                  $('.filter-modal,.div-modal').css('display', 'block');
                  $('#query_form_with_buttons').css('display', 'block');
                  disableTabindex();
                  $('#errorExplanation').css('display', 'block');
              }
              else if (errorResponse.error) {
                var errorMessage = errorResponse.error;
                $('#nodata').text(errorMessage);
                $('#nodata').css('display', 'block');
                $('#gantt_here').css('display', 'none')
                $(".gantt_here_div").css("display","none");
              }
              else{
                $('#nodata').css('display', 'none');
              }
            }
        }
     });
    }


  // show the baseline on checkbox enable
  $('#baseline-input').on('change', function() {
          // Get whether the checkbox is checked
          const isChecked = $(this).is(':checked');
          const params = window.location.search;
          const parameters = new URLSearchParams(params);
          const filter = parameters.get('utf8');
          const perpage = 20;
          const pagenum = 1;
          
          const baselineValue = $('.baseline_select').val();
          const baselineId = isChecked ? baselineValue : null; 
          // Call the API to update the Gantt chart UI
          projectGanttAPI(params, perpage, pagenum, filter, baselineId);
  });


let gantt_baseline=JSON.parse(localStorage.getItem(`gantt_baseline_${project}`));
if(project!=null)
{
if(enabled_modules)
{
if(gantt_baseline)
{
    $(".baseline-div").css("display","flex");
    $(".baseline-div-smallscreen").css("display","flex");
    $("#baseline-input")[0].checked=true;
   getBaselinedata();
}
else{
    $(".baseline-div").css("display","none");
    $(".baseline-div-smallscreen").css("display","none");
     $("#baseline-input")[0].checked=false;
}
}
else{
  localStorage.removeItem(`gantt_baseline_${project}`);
}
}

    //date range picker code start
    function cb(start, end) {

    $("#effective_date_update").attr("min", start.format('YYYY-MM-DD'));
    $("#effective_date_update").attr("max", end.format('YYYY-MM-DD'));

    $("#start_date").attr("min",start.format('YYYY-MM-DD'));
    $("#start_date").attr("max",end.format('YYYY-MM-DD'));


    $("#due_date").attr("min", start.format('YYYY-MM-DD'));
    $("#due_date").attr("max", end.format('YYYY-MM-DD'));

      // console.log(start, start.format('YYYY-MM-DD'),"start")
         start_range=start.format('YYYY-MM-DD');
        due_range=end.format('YYYY-MM-DD');
    

        // if global gantt is enabled
        if(project==null)
        {
          localStorage.setItem("gantt_start_global", start_range);
          localStorage.setItem("gantt_end_global", due_range);
        }
        else{

          localStorage.setItem("start", start_range);
          localStorage.setItem("end", due_range);
        }
      

     

           // if global gantt is enabled
          if(project==null)
          {
            storedStart=localStorage.getItem("gantt_start_global");
            storedEnd = localStorage.getItem("gantt_end_global");
          }
          else{
            storedStart = localStorage.getItem("start");
            storedEnd = localStorage.getItem("end");
          }

         gantt.options.startDate = storedStart ? storedStart :start.format('YYYY-MM-DD');
         gantt.options.endDate = storedEnd? storedEnd :end.format('YYYY-MM-DD');


      // show start and end date in date picker span tag
      $('#reportrange span').html(start.format('D MMM YY') + ' - ' + end.format('D MMM YY'));

      const params =window.location.search
      const parameters = new URLSearchParams(params);
      const filter=parameters.get('utf8');
      const project_id = parameters.get('project_id');
  
      pagenum=1;

      if(project_id)
      {
        if(selected_baseline_id>0)
        {
      
          projectGanttAPI(params,perpage,pagenum,filter,selected_baseline_id);
          // gantt.addBaseline();
        }
        else{
          projectGanttAPI(params,perpage,pagenum,filter,selected_baseline_id);
        }
    }
    else{
      project_pagenum=1;
          $.ajax({
            type: "GET",
            url:filter ?  `${url}/project/view.json?key=${api_key}&${params}`:`${url}/project/view.json?key=${api_key}`,
            dataType: 'json',
            async:true,
            beforeSend: function(){
              $('.circle-loader').show();
            },
            data:{
              start_date: storedStart ? storedStart :start.format('YYYY-MM-DD'),
              due_date: storedEnd? storedEnd :end.format('YYYY-MM-DD'),
              project_perpage:  project_perpage,
               project_pagenum: project_pagenum
            },
            success: function (result, status, xhr) {
        
    
              $('.circle-loader').toggleClass('load-complete');
              $('.checkmark').toggle();
              setTimeout(() => {
                $(".unknown-div").css("display","none");
                $('.circle-loader').hide();
                }, 500);
                $('#nodata').css('display', 'none');
                if(result.allProjects.length!=0)
                {
                  allProjects=result.allProjects;
                }
               
                if(result.data.length==0)
                  {
                       $("#menu-gantt").css("display","none");
                       $("#gantt_here").css("display","none");
                       if(!$(".nodata")[0])
                       {
                        $(".gantt_here_div").before(`<p  style="margin-top:30px; margin-left:13px;" class="nodata">${t('label_no_data_to_display')}</p>`);
                       }
                  }
                  else{
                    $(".nodata").remove();
                    $("#menu-gantt").css("display","block");
                    $("#gantt_here").css("display","block");
                    if(result.hasOwnProperty("pagination"))
                    {
                     project_total_pages=result.pagination.total_pages;
                    }
    
                    resource_data=result
                    gantt_data=resource_data.data
                    resource_data.data.map((i)=>{
                      i.start_date=i.gantt_start_date
                      i.end_date=i.gantt_due_date
                      if(i.parent_id!=null)
                      {
                        i.parent="i"+i.parent_id
                      }
                       i.issue_id=i.parent==0? i.id : i.id.replace("i","")  
                       if(i.parent==0)
                      {
                        // code to calculate progress of parent       
                         Sum=i.issues.reduce((sum,issue)=>{
                          if(issue.parent_id==null)
                          {
                            return  sum+issue.done_ratio
                          }
                          return  sum
                         },0)
                         const filteredArray = i.issues.filter(obj => obj.parent_id==null);
                         length=filteredArray.length
                         i.progress=length!=0 ?Math.round(Sum/length) :0
                 
                        // calculate estimation of parent task 
                         estimation_sum=i.issues.reduce((sum,issue)=>{
                          return sum= sum+issue.estimated_hours
                         },0)
                         i.estimated_hours=Number.isInteger(estimation_sum)? estimation_sum : estimation_sum.toFixed(2) 
                      
                        //  calculation end 
                      }
                      else{
                        i.taskColor=i.color
                      let isMilestone = /\(milestone\)/i.test(i.text);
                      if(isMilestone&&i.s_date===i.due_date)
                      {
                        i.type="milestone";
                      }
                      }
                    })
    
                     gantt.clearAll();
                     const typeMapping = {
                      "start_to_start": 1,
                      "start_to_finish": 3,
                      "finish_to_finish": 2,
                      "finish_to_start": 0
                    };
                     resource_data.links.map((l)=>{
                      if (typeMapping.hasOwnProperty(l.type)) {
                        l.type = typeMapping[l.type];
                      }
                     })

                      gantt.options.data = resource_data.data;
                      gantt.options.links =resource_data.links;

                      var ganttTodayFlag= JSON.parse(localStorage.getItem('gantt_today_flag'));
                        document.getElementById('today').checked = ganttTodayFlag !== null ? ganttTodayFlag : true;
                        if (ganttTodayFlag != false) {
                          gantt.options.todayMarker=true;
                        } else {
                          gantt.options.todayMarker=false;
                        }

                      gantt.render(element); 
                      gantt.autoScheduling(); 
                      gantt.updateBody();
                      
                  }
            },
            error: function (xhr, status, error) {
               
              $('.circle-loader').toggleClass('load-complete');
              $('.checkmark').toggle();
              setTimeout(() => {
                $(".unknown-div").css("display","none");
                $('.circle-loader').hide();
                }, 500);
                if(xhr.status==403)
                {
                  if(!$(".nodata")[0])
                  {
                    $(".gantt_here_div").before(`<p  style="margin-top:30px; margin-left:13px;" class="nodata">${t('label_no_data_to_display')}</p>`);
                  }
                }
                else {
                  var errorResponse = JSON.parse(xhr.responseText);
                  if (errorResponse.errors && errorResponse.errors.length > 0) {
                    var errorHtml = '<ul>';
                    errorResponse.errors.forEach(function(errorMessage) {
                        errorHtml += '<li>' + errorMessage + '</li>';
                    });
                    errorHtml += '</ul>';
                    $('#errorExplanation').html(errorHtml);
                      $('.filter-modal,.div-modal').css('display', 'block');
                      $('#query_form_with_buttons').css('display', 'block');
                      disableTabindex();
                      $('#errorExplanation').css('display', 'block');
                  }
                  else if (errorResponse.error) {
                    var errorMessage = errorResponse.error;
                    $('#nodata').text(errorMessage);
                    $('#nodata').css('display', 'block');
                    $('#gantt_here').css('display', 'none')
                    $(".gantt_here_div").css("display","none");
                  }
                  else{
                    $('#nodata').css('display', 'none');
                  }
                }
            }
         });
    }


    }

    
  
    $('#reportrange').daterangepicker({
      startDate: storedStart ? moment(storedStart) : start,
      endDate:storedEnd ? moment(storedEnd) : end,
      ranges: { 
        [t('label_today')]: [moment(), moment()], 
        [t('label_yesterday')]: [moment().subtract(1, 'days'), moment().subtract(1, 'days')],  
        [t('label_current_week')]: [moment().clone().isoWeekday(1), moment().clone().isoWeekday(7)], 
        [t('label_last_7_days')]: [moment().subtract(6, 'days'), moment()], 
        [t('label_last_30_days')]: [moment().subtract(29, 'days'), moment()], 
         [t('label_this_month')]: [moment().startOf('month'), moment().endOf('month')], 
         [t('label_last_month')]: [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')], 
         [t('label_next_month')]: [moment().add(1, 'month').startOf('month'), moment().add(1, 'month').endOf('month')]      
      },       
      locale: {    
              customRangeLabel: t('label_custom_range'),
              applyLabel: t('label_apply'),
              cancelLabel: t('label_cancel')
            }
    }, cb);

    cb(moment(storedStart ? storedStart : start), moment(storedEnd  ? storedEnd : end));

    $("[data-range-key='Custom Range']").click(function() {
      $(this).addClass("active");
      $("[data-range-key='Today']").removeClass("active");
      $("[data-range-key='Current Week']").removeClass("active");
      $("[data-range-key='Next Month']").removeClass("active");
      $("[data-range-key='This Month']").removeClass("active");
      $("[data-range-key='Last Month']").removeClass("active");
      $("[data-range-key='Last 30 Days']").removeClass("active");
      $("[data-range-key='Last 7 Days']").removeClass("active");
      $("[data-range-key='Yesterday']").removeClass("active");

      //Do Acction
    });


    var ganttTodayFlag= JSON.parse(localStorage.getItem('gantt_today_flag'));
    document.getElementById('today').checked = ganttTodayFlag !== null ? ganttTodayFlag : true;
    if (ganttTodayFlag != false) {
      gantt.options.todayMarker=true;
    } else {
      gantt.options.todayMarker=false;
    }

  // date range picker code end 
    window.getProjectTrackers=function(project_name){
      $.ajax({
        type: "GET",
        url: `${url}/projects/${project_name}.json?include=trackers&key=${api_key}`,
        dataType: "json",
        contentType: "application/json",
        async: false,
        success: function (result, status, xhr) {
             // Update progress in the Gantt column
             $("#trackers").html(" ");
            //  $("#trackers").append(`<option  value="0" >Please Select</option>`);
            if(result.project.trackers.length!=0){
              result.project.trackers.map((i)=>{
                $("#trackers").append(`<option  value=${i.id} >${i.name}</option>`)
            })
            }
        },
        error: function (xhr, status, error) {
          $("#trackers").html(" ");
        },
      });
     }
     function getProjectMembers(project_name)
     {

      $.ajax({
        type: "GET",
        url: `${url}/gantt_members.json?key=${api_key}`,
        dataType: "json",
        contentType: "application/json",
        async: false,
        data:{
          "project_name":project_name
        },
        success: function (result, status, xhr) {
             // Update progress in the Gantt column
             $("#dynamic_select_assignee").html(" ");
             $("#dynamic_select_assignee").append(`<option  value="0" >${t('label_please_select')}</option>`);
            if(result.length!=0){
              result.map((i)=>{
                $("#dynamic_select_assignee").append(`<option  value=${i.id} >${i.name}</option>`)
            })
            }
        },
        error: function (xhr, status, error) {
          $("#dynamic_select_assignee").html(" ");
        },
      });
     }

     function getProjectRelease(release_id){
      // console.log(gantt_data,"gantt")
      const params =window.location.search
      const parameters = new URLSearchParams(params);
      const  project_id = parameters.get('project_id');

      var filteredData = gantt_data.filter(function(obj) {
        return obj.parent === 0;
      });
      $("#dynamic_select_assignee").html(" ");
      $("#dynamic_select_release").html(" ");

      if(project==null)
      {

        $("#dynamic_select_assignee").append(`<option selected  value="0" >${t('label_please_select')}</option>`)
      }
      if(project_id)
        {
      if( filteredData.length!=0){
            filteredData.map((i)=>{
             
          // $("#dynamic_select_assignee").append(`<option  value=${i.id} >${i.text}</option>`)
          if(i.id==release_id)
          {
            $("#dynamic_select_release").append(`<option  selected value=${i.id} >${i.text}</option>`)
            $("#dynamic_select_assignee").append(`<option  selected value=${i.id} >${i.text}</option>`)
          }
          else{
            $("#dynamic_select_release").append(`<option  value=${i.id} >${i.text}</option>`)
              $("#dynamic_select_assignee").append(`<option  value=${i.id} >${i.text}</option>`)
          }
      })
       }
      }
      else{
        if(allProjects.length!=0){
          allProjects.map((i)=>{
           
        // $("#dynamic_select_assignee").append(`<option  value=${i.id} >${i.text}</option>`)
        if(i.id==release_id)
        {
          $("#dynamic_select_release").append(`<option  selected value=${i.id} >${i.name}</option>`)
          $("#dynamic_select_assignee").append(`<option  selected value=${i.id} >${i.name}</option>`)
        }
        else{
          $("#dynamic_select_release").append(`<option  value=${i.id} >${i.name}</option>`)
            $("#dynamic_select_assignee").append(`<option  value=${i.id} >${i.name}</option>`)
        }
    })
     }
      }
     }
     
    // add issue function
    window.addIssue=function(){
  
      $(".div-modal").css("display","block");
      $('.issue-create').css("display","block");
      $("#trackers").html(" ");
      $(".flex-col").css("margin-bottom","14px");
      $("#issue-div").css("display","none");
      $("#track-div").css("display","none");
      $("#subject-issue").val("")
      $("#d_date").val("")
      $("#s_date").val(" "); 
      $("#d_date").removeAttr("min max");
      $("#s_date").removeAttr("min max");

      $("#i-estimate").css("display","none");
      $("#assignee-div").css("display","none");
      $("#estimated_h").val("0h");

      $("#start-error-div").css("display","none");
      $("#due-error-div").css("display","none");
      $("#issue-create-error-div").css("display","none");
      const params =window.location.search
      const parameters = new URLSearchParams(params);
      const  project_id = parameters.get('project_id');
      if(project_id)
      {
        getProjectTrackers(project_id);
        
      }
      // else{
      //   getProjectMembers(project_id)
      // }
      getProjectRelease();
    
      disableTabindex();
  
    }

    gantt.attachEvent("onTaskDblClick", (event) => {
       let task=event.task
      let taskId=parseInt(event.task.issue_id);
      $('#deleteIssue').attr("value",taskId);
      gantt.hideLightbox();
      if(event.task.parent!=0)
      {
        $(".div-modal").show();
        $(".update_issue").show();
        disableTabindex();
        let e_time=task.estimated_hours==null ? "0h" : task.estimated_hours +"h";
        $("#start-error-div-update").css("display","none");
        $("#due-error-div-update").css("display","none");
        $("#estimated-error-div").css("display","none");
        $("#subject-update").css("display","none");
        $("#subject-issue-update").val(task.text);
        $("#btn-plan").attr("value",task.issue_id);
        $("#start_date").val(changeFormat(task.start_date));
        $("#due_date").val(changeFormat(task.end_date));
        $(".text-area-res").val("");
        let textarea = document.getElementsByClassName(".text-area-res");
        textarea.placeholder = `${t('label_please_select')}`;
        $("#estimated_hour").val(e_time);
        task.description==null ? textarea: $(".text-area-res").val(task.description);
        getProjectRelease(task.parent);
        $(".update_issue").css("zIndex","10001");
        $("#btn-plan .button-save").prop("disabled", true).css("cursor","not-allowed");

        //  for global Gantt
        // $("#subject-issue-update-global").val(task.text);
        // $("#start_date_global").val(changeFormat(task.start_date));
        // $("#due_date_global").val(changeFormat(task.end_date));
        // $("#estimated_hour_global").val(e_time);
 
      }
      else {
        if(project!=null)
        {  
          $(".div-modal").show();
        $(".version-update").show();
        $("#save_version").attr("value",task.id);
        $("#version_name_update").val(task.text);
        $("#version_description_update").val(task.description);
        $("#version_div_update").css("display","none");
        $("#effective_div_update").css("display","none");
        $("#effective_date_update").val(task.effective_date);
        $("#save_version .button-plan").prop("disabled", true).css("cursor","not-allowed");
        disableTabindex();
        }
    
       


      }
     })



// Attach a click event to the plus icon using jQuery
$(document).on("click", ".add-task-icon", function(event) {
  event.stopPropagation();
  let taskId = $(this).data("task-id");
  let task = gantt.getTask(taskId);
    openModalForTask(task);
});

$(document).on("keydown", ".add-task-icon", function(event) {
  if (event.which === 13 || event.keyCode === 13) { 
    event.preventDefault();
    event.stopPropagation();
    let taskId = $(this).data("task-id");
    openModalForTask(taskId);
  }
});


function openModalForTask(task) {
  gantt.hideLightbox();
  if (task.parent !== 0) {
    $('#deleteIssue').attr("value", task.issue_id);
    $(".div-modal").show();
    $(".update_issue").show();
    disableTabindex();
    let e_time = task.estimated_hours == null ? "0h" : task.estimated_hours + "h";
    let des = task.description == null ? "Description" : task.description;
    $("#start-error-div-update").css("display", "none");
    $("#due-error-div-update").css("display", "none");
    $("#estimated-error-div").css("display", "none");
    $("#subject-update").css("display", "none");
    $("#subject-issue-update").val(task.text);
    $("#btn-plan").attr("value", task.issue_id);
    $("#start_date").val(changeFormat(task.start_date));
    $("#due_date").val(changeFormat(task.end_date));
    $(".text-area-res").val("");
    let textarea = document.getElementsByClassName("text-area-res");
    textarea.placeholder = "Description";
    $("#estimated_hour").val(e_time);
    task.description == null ? textarea : $(".text-area-res").val(task.description);
    getProjectRelease(task.parent);
    $(".update_issue").css("zIndex", "10001");
    $("#btn-plan .button-save").prop("disabled", true).css("cursor", "not-allowed");
  } 
  else {
    if(project!=null)
    {  
        $(".div-modal").show();
        $(".version-update").show();
        $("#save_version").attr("value", task.id);
        $("#version_name_update").val(task.text);
        $("#version_description_update").val(task.description);
        $("#version_div_update").css("display", "none");
        $("#effective_div_update").css("display", "none");
        $("#effective_date_update").val(task.effective_date);
        $("#save_version .button-plan").prop("disabled", true).css("cursor", "not-allowed");
        disableTabindex();
    }

  }
}
    // enable Update Release popup save buttion 
    $("#version_name_update, #version_description_update").on("input", function() {
      $("#save_version .button-plan").prop("disabled", false).css("cursor", "pointer");
      });

  // enable Update Issue popup save buttion 
  $("#subject-issue-update, .text-area-res, #dynamic_select_release, #start_date, #due_date, #estimated_hour").on("input", function() {
      $("#btn-plan .button-save").prop("disabled", false).css("cursor", "pointer");
      });

    

    window.closeDialogPlan=function(){
      $('.div-modal').hide();
      $(".issue-create").hide();
      $(".update_issue").hide();
      $(".version-create").hide();
      $(".version-update").hide();
      let baselineDiv=document.getElementsByClassName("create_baseline");
      let DeleteBaselineDiv=document.getElementsByClassName("deleteBaseline");
      if (DeleteBaselineDiv.length > 0)
      {
        DeleteBaselineDiv[0].style.display="none";
      }
      if(baselineDiv.length > 0)
      {
        baselineDiv[0].style.display="none";
      }
      disableTabindex();
    }
    window.changeTabIssue=function(ev){
      if(ev[0].checked)
    {
      $("#due_date_i").css("display","flex");
    }
    else{
       $("#due_date_i").css("display","none");
    }
    
    }
    window.changeTab=function(ev){
      if(ev[0].checked)
    {
      $("#to").css("display","flex");
    }
    else{
      $("#to").css("display","none");
    }
    
    }
    // validate data function
    function validateFormData(){
       var reg = /^\d+(\.\d+)?h?$/;
       var ierrors={};
       var ierrors={};
       
      // if(project==null)
      // {  
      //   $("#dynamic_select_assignee").val("0");
      // }
        if($("#estimated_h").val().length==0||$("#estimated_h").val()=="0h")
       {
            $("#i-estimate").css("display","flex");
            $("#i-esti").html(t('label_field_is_required'));
           ierrors.estimated_h=t('label_field_is_required');
       }
       else if ($("#estimated_h").val()=="0")
       {
          $("#i-estimate").css("display","flex");
          $("#i-esti").html(t('label_value_must_be_larger'));
           ierrors.estimated_h=t('label_value_must_be_larger');
       }
       else if(!(reg.test($("#estimated_h").val())))
       {
          $("#i-estimate").css("display","flex");
             $("#i-esti").html(t('label_value_must_be_number'));
            ierrors.estimated_h=t('label_value_must_be_number');
       }
        else if($("#estimated_h").val().indexOf(".") !== -1)
       {
           var pattern = /^\d{0,2}(\.\d{0,2})?h?$/;
          if (!(pattern.test($("#estimated_h").val())))
          {
              $("#i-estimate").css("display","flex");
             $("#i-esti").html(t('label_value_should_be_format'));
            ierrors.estimated_h=t('label_value_should_be_format');
          }
       else{
       $("#i-estimate").css("display","none");
       }
       }
     else{
           if ($("#estimated_h").val().length > 3)
          {      
            $("#i-estimate").css("display","flex");
           $("#i-esti").html(t('label_only_3_digits_allowed'));
            ierrors.estimated_h=t('label_only_3_digits_allowed');
          }
       else{
          $("#i-estimate").css("display","none");
       }
       }
      //  subject field not black  validation
       if($("#subject-issue").val().length==0)
       {
            $("#issue-div").css("display","flex");
            $("#sub-issue").html(t('label_field_is_required'));
           ierrors.subject=t('label_field_is_required');
       }
       else if($("#subject-issue").val().length > 255)
       {
         $("#issue-div").css("display","flex");
         $("#sub-issue").html(t('label_only_255_characters_allowed'));
         ierrors.subject=t('label_only_255_characters_allowed');
       }
       else{
           $("#issue-div").css("display","none");
       }
        // subject field not blank validation end 
        // assignee field not blank validation
   
       if($("#dynamic_select_assignee").val()!=="0")
       {
           $(".assignee-select-div").css("margin-bottom","14px");
           $("#assignee-div").css("display","none");
       }
       else{
      
          $(".assignee-select-div").css("margin-bottom","0px");
          $("#assignee-div").css("display","flex");
          $("#i-assignee").html(t('label_field_is_required'));
          ierrors.assignee=t('label_field_required');
       }

      //tracker not valid 
      if($("#trackers").val()!=="0")
       {
           $("#track-div").css("display","none");
       }
       else{
          $("#track-div").css("display","flex");
          $("#i-track").html(t('label_field_is_required'));
          ierrors.tracker=t('label_field_required');
       }
       if($("#d_date").val().length==0)
       {
         $("#due-error-div").css("display","flex");
         $("#due-error").html(t('label_field_is_required'));
         ierrors.due_date=t('label_field_is_required');
       }
       else{
         $("#due-error-div").css("display","none");
       }


       if($("#s_date").val().length==0)
       {
         $("#start-error-div").css("display","flex");
         $("#start-error").html(t('label_field_is_required'));
         ierrors.start_date=t('label_field_is_required');
       }
       else{        
         $("#start-error-div").css("display","none");
       }

       if (!$("#s_date").val().length==0 && !$("#d_date").val().length==0) {

        if ($("#s_date").val() < storedStart || $("#s_date").val() > storedEnd) {
          $("#issue-create-error-div").css("display","flex");
          $("#issue-create-error").html(t('label_date_must_be_between')+ DateFormatDMY(storedStart) + " and " + DateFormatDMY(storedEnd) + "." );  
          ierrors.start_date=t('label_date_is_not_between_range_required');
        } else if($("#d_date").val() < storedStart || $("#d_date").val() > storedEnd){
          $("#issue-create-error-div").css("display","flex");
          $("#issue-create-error").html(t('label_date_must_be_between')+ DateFormatDMY(storedStart) + " and " + DateFormatDMY(storedEnd) + "." );  
          ierrors.end_date=t('label_date_is_not_between_range');
        } else if ($("#s_date").val() > $("#d_date").val() ) {
          $("#issue-create-error-div").css("display","flex");
          $("#issue-create-error").html(t('label_due_date_must_be_greater_than_start_date') );  
          ierrors.end_date=t('label_due_date_must_be_greater_than_start_date');
        } else{
          $("#issue-create-error-div").css("display","none");
        } 
       }


     
       if(Object.keys(ierrors).length)
       {
         return count=false;
       }
       else{
         return count=true;
       }
     }

     function storeBaselineDataAPI(){
      var issues=[];

    
      // gantt.originalData.forEach(element => {
      //   if(element.parent!=0)
      //   {
      //      issues.push({
      //       "issue_id": parseInt(element.issue_id),
      //       "baseline_start_date":element.gantt_start_date,
      //       "baseline_due_date":element.gantt_due_date,
      //       "project_id":parseInt(project),
      //       "baseline_id":selected_baseline_id
      //      })
      //   }
        
      // });

      allIssues.forEach(element => {
           issues.push({
            "issue_id": element.id,
            "baseline_start_date":element.gantt_start_date,
            "baseline_due_date":element.gantt_due_date,
            "project_id":parseInt(project),
            "baseline_id":selected_baseline_id
           })
      });
  
      // AJAX call to send data
      $.ajax({
        url: `${url}/store/baseline/data.json?key=${api_key}`, // Update the endpoint to your actual route
        type: 'POST',
        contentType: 'application/json',
        data: JSON.stringify({
          issues: issues
        }),
        success: function(response) {
        },
        error: function(xhr, status, error) {
          console.log('Error:', error);
        }
      });
    
     }
     window.saveBaseline=function(){
      let errorDiv=document.getElementsByClassName("error-div");
       if(errorDiv)
       {
         errorDiv[0].style.display="none";
         }
        let baselinename=document.getElementById("baseline_name");
        if(baselinename)
        baselinename=baselinename.value
          if (baselinename.trim() === "") {
              showError(t('label_field_is_required'));
              return;  // Stop execution, do not make API call
          }
      
          if (baselinename.length > 52) {
              showError(t('label_name_cannot_exceed_52_characters'));
              return;  // Stop execution, do not make API call
          }
          
          const params =window.location.search
          const parameters = new URLSearchParams(params);
          const filter=parameters.get('utf8');
           perpage=20;
           pagenum=1;
      
          $.ajax({
                    type:"POST",
                    url:`${url}/save/baseline.json?key=${api_key}`,
                    dataType: "json",
                    contentType: "application/json",
                    async: false,
                    data: JSON.stringify({
                    name: baselinename,
                    project_id: project
                      }),
                    success: function (result, status, xhr) {
                  
                        let baselineDiv=document.getElementsByClassName("create_baseline");
                        let backgroundDiv=document.getElementsByClassName("div-modal");
      
                        if(baselineDiv || backgroundDiv)
                        {
                          baselineDiv[0].style.display="none";
                          backgroundDiv[0].style.display="none";
                        }
                        getBaselinedata();
                        storeBaselineDataAPI();
                        setTimeout(()=>{
                          projectGanttAPI(params,perpage,pagenum,filter,selected_baseline_id);
                        },1000)
                     

                    },
                    error: function (xhr, status, error) {
                     if(xhr.status == 422){
                     
                      let content = JSON.parse(xhr.responseText);
                      // console.log(JSON.parse(xhr.responseText),"contet...");
                      if(JSON.parse(xhr.responseText).name)
                      {
                        let message=JSON.parse(xhr.responseText).name;
                        if(message[0]="has already been taken")
                        {
                          showError(t('label_name_has_already_been_taken'))
                        }
                          
                      } 
                      else if(JSON.parse(xhr.responseText).errors)
                      {
                       if (content.name) {
                           showError(content.name)
                          // toastr["error"](content.name);
                        }
                        if (content.project_id) {
                          showError(content.project_id)
                          // toastr["error"](content.project_id);
                        }
                      }
                      }
                      else if(xhr.status == 403)
                      {
                          toastr["error"](t('label_no_permissions'));
                      } 
                    },
              });
      
              function showError(message) {
              let baselineDiv = document.getElementsByClassName("create_baseline");
              let backgroundDiv = document.getElementsByClassName("div-modal");
      
              if (baselineDiv || backgroundDiv) {
                  baselineDiv[0].style.display = "block";
                  backgroundDiv[0].style.display = "block";
              }
      
              let errorDiv = document.getElementsByClassName("error-div");
              if (errorDiv) {
                  errorDiv[0].style.display = "block";
                  errorDiv[0].innerHTML = message;
              }
          }
        
      }
    //  validate function end 


    // window.deleteBaseline=function()
    // {
    //   const params =window.location.search
    //   const parameters = new URLSearchParams(params);
    //   const filter=parameters.get('utf8');
    //   perpage=20;
    //   pagenum=1;

    //   var baselineSelects = document.getElementById('baseline_select');
    //   var baselineSelectSmall = document.getElementById('smallscreen_baseline_select');

    //         var baseline_id;
    //         if(baselineSelects || baselineSelectSmall)
    //         {
    //         // Loop through each select element and get its selected value
    //         [baselineSelectSmall, baselineSelects].forEach(select => {
    //           baseline_id = select.value;
    //         });
    //       }
    //       console.log("Baseline ID: ", baseline_id);
    //       if(enabled_modules)
    //           {
    //             if(baseline_id)
    //             {
    //               baseline_id=parseInt(baseline_id);
    //             }
    //           }
    //  if (baseline_id) {
    
    //     $.ajax({
    //       url: `${url}/delete/baseline.json?key=${api_key}`,
    //       method: 'DELETE',
    //       data: JSON.stringify({
    //         project_id: project, // Ensure this is correctly set
    //         baseline_id: baseline_id
    //       }),
    //       contentType: 'application/json',
    //       dataType: 'json',
    //       success: function(res) {
    //             $('.div-modal').hide();
    //             getBaselinedata();
    //             // selected_baseline_id=0;
    //             if(selected_baseline_id>0)
    //             {
    //               projectGanttAPI(params,perpage,pagenum,filter,selected_baseline_id);
    //             }
    //             else{
    //               projectGanttAPI(params,perpage,pagenum,filter);
    //             }
           
    //             let DeleteBaselineDiv=document.getElementsByClassName("deleteBaseline");
    //             if (DeleteBaselineDiv)
    //             {
    //               DeleteBaselineDiv[0].style.display="none";
    //             }
            
    //         // Optionally, refresh the UI or handle the response
    //       },
    //       error: function(err) {
    //         console.error(err, "Failed to delete baseline.");
    //       }
    //     });
    //   }
    
    
    // }


    window.deleteBaseline = function() {
      const params = window.location.search;
      const parameters = new URLSearchParams(params);
      const filter = parameters.get('utf8');
      const perpage = 20;
      const pagenum = 1;
      let baseline_id = null;
  
      // Check if small screen baseline select is visible
      var smallScreenSelect = document.getElementById('smallscreen_baseline_select');
      var largeScreenSelect = document.getElementById('baseline_select');
  
      if (smallScreenSelect && getComputedStyle(smallScreenSelect).display !== 'none') {
          baseline_id = smallScreenSelect.value;       
      } 
      else if (largeScreenSelect && getComputedStyle(largeScreenSelect).display !== 'none') {
          baseline_id = largeScreenSelect.value;
      }
  
      if (baseline_id && enabled_modules) {
          baseline_id = parseInt(baseline_id); 
  
          // Proceed with deletion if a valid baseline_id is found
          $.ajax({
              url: `${url}/delete/baseline.json?key=${api_key}`,
              method: 'DELETE',
              data: JSON.stringify({
                  project_id: project,  
                  baseline_id: baseline_id
              }),
              contentType: 'application/json',
              dataType: 'json',
              success: function(res) {
                  $('.div-modal').hide();
                  getBaselinedata();
  
                  // Update Gantt chart
                  if (selected_baseline_id > 0) {
                      projectGanttAPI(params, perpage, pagenum, filter, selected_baseline_id);
                  } else {
                      projectGanttAPI(params, perpage, pagenum, filter);
                  }
  
                  // Hide the delete baseline div (common element)
                  let deleteBaselineDiv = document.getElementsByClassName("deleteBaseline");
                  if (deleteBaselineDiv && deleteBaselineDiv[0]) {
                      deleteBaselineDiv[0].style.display = "none";
                  }
              },
              error: function(err) {
                  console.error("Failed to delete baseline:", err);
              }
          });
      } else {
          console.log("No baseline selected or enabled_modules is not set.");
      }
    }
  
    window.storeBaseline=function(select){

      const params =window.location.search
      const parameters = new URLSearchParams(params);
      const filter=parameters.get('utf8');
      let value= select.value;
      perpage=20;
      pagenum=1;
        $.ajax({
          url: `${url}/save/selected/baseline.json?key=${api_key}`,
          method: 'POST',
          data: JSON.stringify({
            project_id: project,
            baseline_id: value
          }),
          contentType: 'application/json',
          dataType: 'json',
          success: function(res) {
            // projectGanttAPI(params,perpage,pagenum,filter,selectedBaselineId);
            projectGanttAPI(params,perpage,pagenum,filter,value);
     
          },
          error: function(err) {
            console.error(err, "error....");
          }
        });
      }

    // call issue POST API
    window.createIssue=function(){

      const params =window.location.search
      const parameters = new URLSearchParams(params);
      const  project_id = parameters.get('project_id');
      let tracker_id=$("#trackers").val();
      let text=$("#subject-issue").val();
      let start_date=$("#s_date").val();
      let due_date=$("#d_date").val();
      let fixed_version_id=parseInt($("#dynamic_select_assignee").val());
      var estimated_hours=$("#estimated_h").val();

      if(estimated_hours.includes("h"))
     {
       estimated_hours=$("#estimated_h").val().replace("h","");
     }
     else{
      estimated_hours=$("#estimated_h").val()
     }
     if(estimated_hours% 1 !== 0)
     {
       estimated_hours= parseFloat($("#estimated_h").val()).toFixed(2);      
     }

      let content={
        project_id: project_id? project_id: parseInt($("#dynamic_select_assignee").val()),
        tracker_id:parseInt(tracker_id),
        start_date:start_date,
        due_date:due_date,
        subject: text,
        // fixed_version_id:fixed_version_id,
        estimated_hours:estimated_hours
      }

      if (project_id)
      {
        content.fixed_version_id=fixed_version_id;
      }
      if(validateFormData())
      {
      $.ajax({
        type: "POST",
        url: self.url + "/issues.json?key=" + api_key + " ",
        contentType: "application/json",
        dataType: "json",
        async:false,
        data: JSON.stringify({
          issue: content,
        }),
        success: function (result, status, xhr) {
          $('.div-modal').hide();
          $(".issue-create").hide();
          // cb(start, end);
           toastr["success"](t('label_issue_created_successfully'));
           let id="i"+result.issue.id;
          cb(moment(storedStart ? storedStart : start), moment(storedEnd  ? storedEnd : end));
          gantt.openTask(id);
          
        },
        error: function (xhr, status, error) {
               if(xhr.status == 422){
                  let content = JSON.parse(xhr.responseText).errors;
                   content.map((i)=>{
                   toastr["error"](i);
             })
             }
             else if(xhr.status == 403)
             {
               toastr["error"](t('label_no_permissions'));
              } 
        },
        });
        disableTabindex();
    }
    }

 
      // validation function on task update
        function validateData(){
          var reg  =/^\d+(\.\d+)?h?$/;
          var errors={};
          if($("#estimated_hour").val().length==0||$("#estimated_hour").val()=="0h")
          {
          
            $("#estimated-error-div").css("display","flex");
            $("#estimated-error").html(t('label_field_is_required'));
            errors.estimated_hour=t('label_field_is_required');
          }
          else if ($("#estimated_hour").val()=="0")
          {
            $("#estimated-error-div").css("display","flex");
            $("#estimated-error").html(t('label_value_must_be_larger'));
            errors.estimated_hour=t('label_value_must_be_larger');
          }
            else if(!(reg.test($("#estimated_hour").val())))
          {
            $("#estimated-error-div").css("display","flex");
            $("#estimated-error").html(t('label_value_must_be_number'));
            errors.estimated_hour=t('label_value_must_be_number');
          }
          else if($("#estimated_hour").val().indexOf(".") !== -1)
          {
            let pattern = /^\d{0,2}(\.\d{0,2})?h?$/;
            if (!(pattern.test($("#estimated_hour").val())))
            {   
              $("#estimated-error-div").css("display","flex");
              $("#estimated-error").html(t('label_value_should_be_format'));
              errors.estimated_hour=t('label_value_should_be_format');
            }
           else{
               $("#estimated-error-div").css("display","none");
            }
          }
        else{
              if ($("#estimated_hour").val().length > 3)
            {
              $("#estimated-error-div").css("display","flex");
              $("#estimated-error").html(t('label_only_3_digits_allowed'));
              errors.estimated_hour=t('label_only_3_digits_allowed');
            }
          else{
            $("#estimated-error-div").css("display","none");
          }
          }
          if($("#due_date").val().length==0)
          {
            $("#due-error-div-update").css("display","flex");
            $("#due-error-update").html(t('label_field_is_required'));
            errors.due_date=t('label_field_is_required');
          }
          else{
            $("#due-error-div-update").css("display","none");
          }
          if($("#start_date").val().length==0)
          {
            $("#start-error-div-update").css("display","flex");
            $("#start-error-update").html(t('label_field_is_required'));
            errors.start_date=t('label_field_is_required');
          }
          else{
            $("#start-error-div-update").css("display","none");
          }
              //  subject field not black  validation
              if($("#subject-issue-update").val().length==0)
              {
                    $("#subject-update").css("display","flex");
                    $("#error-update").html(t('label_field_is_required'));
                  ierrors.subject=t('label_field_is_required');
              }
              else if($("#subject-issue-update").val().length > 255)
              {
                $("#subject-update").css("display","flex");
                $("#error-update").html(t('label_only_255_characters_allowed'));
                ierrors.subject=t('label_only_255_characters_allowed');
              }
              else{
                  $("#issue-div").css("display","none");
              }

          if(Object.keys(errors).length)
          {
            return count=false;
          }
          else{
            return count=true;
          }
          
        }
// validation function end 
  //  on click of save button update issue code start
    // function to  call PUT API on save button click 
    window.updateTask=function(){
      var issue_id=$("#btn-plan").attr("value");
      var estimate_time=$("#estimated_hour").val()

      var classesToPreserve = 'zt-gantt-row-item zt-gantt-child-row zt-gantt-child-1 grid_row_class zt-gantt-d-flex';
      // var checkbox = document.getElementById("watchers-input");
  
      if(estimate_time.includes("h"))
      {
         estimate_time=$("#estimated_hour").val().replace("h","");
      }
      else{
         estimate_time=$("#estimated_hour").val()
      }
      if($("#estimated_hour").val()% 1 !== 0)
      {
         estimate_time= parseFloat($("#estimated_hour").val()).toFixed(2);      
      }
      
    

      let content={
        "description":$(".text-area-res").val(),
        "start_date":$("#start_date").val(),
        "due_date":$("#due_date").val(),
        "estimated_hours":estimate_time,
        "subject":$("#subject-issue-update").val(), 
        // "baseline_id":23
      }
      if(project==null)
      {
       content.project_id=parseInt($("#dynamic_select_release").val());
      }
      else{
        content.fixed_version_id=parseInt($("#dynamic_select_release").val());
      }


        // Get all select elements with the class 'baseline_select'
        const baselineSelects = document.querySelectorAll('.baseline_select');
        var baseline_id;
        if(baselineSelects)
        {
        // Loop through each select element and get its selected value
        baselineSelects.forEach(select => {
           baseline_id = select.value;
        });
      }
      
     if(project)
     {
       if(enabled_modules)
       {
        if(baseline_id)
          {
           content.baseline_id=parseInt(baseline_id);
         }
      
       }
      }
        if(validateData())
        {
   
        $.ajax({
            type: "PUT",
            url: `${url}/issues/${issue_id}.json?key=${api_key}`,
            dataType: "json",
            contentType: "application/json",
            async: false,
            data: JSON.stringify({
              issue: content,
            }),
            success: function (result, status, xhr) {
              $('.div-modal').hide();
              $(".update_issue").hide();
              toastr["success"](t('label_issue_created_successfully'));
               // Preserve the classes
                $(element).removeClass().addClass(classesToPreserve);
              // cb(start,end);
          
              cb(moment(storedStart ? storedStart : start), moment(storedEnd  ? storedEnd : end));
                gantt.openTask("i"+issue_id);
               },
            error: function (xhr, status, error) {
            if(xhr.status == 422){
               let content = JSON.parse(xhr.responseText).errors;
              content.map((i)=>{
                if(i===t('label_due_date_must_be_greater_than_start_date'))
                {
                  toastr["error"](t('label_start_date_greater_than_due_date'));
                }
                else if(i===t('label_assignee_invalid'))
                {
                  toastr["error"](t('label_user_not_member'));
                }
                else{
                  toastr["error"](i);
                }
               })
              }
               else if(xhr.status == 403)
               {
                   toastr["error"](t('label_no_permissions'));
               } 
            },
          });
        }
    }
    // function on update task click end 
   function validateRelease(){
    let errors={};
    //  release field not black  validation
  
    if($("#version_name").val()===" "||$("#version_name").val().length==0)
    {
        $("#version_div").css("display","flex");
        $("#version_error").html(t('label_field_is_required'));
        errors.version=t('label_field_is_required');
    }
    else if($("#version_name").val().length > 255)
    {
      $("#version_div").css("display","flex");
      $("#version_error").html(t('label_only_255_characters_allowed'));
      errors.version=t('label_only_255_characters_allowed');
    }
    else{
        $("#version_div").css("display","none");
    }
    if($("#effective_date").val().length==0)
    {
      $("#effective_div").css("display","flex");
      $("#effective_error").html(t('label_field_is_required'));
      errors.effective_date=t('label_field_is_required');

    } else if ($("#effective_date").val() < storedStart || $("#effective_date").val() > storedEnd) {
      $("#version-create-error-div").css("display","flex");
      $("#version-create-error").html(t('label_date_must_be_between')+ DateFormatDMY(storedStart) + " and " + DateFormatDMY(storedEnd) + "." );  
      errors.effective_date=t('label_date_is_not_between_range_required');
      $("#effective_div").css("display","none");
    } 

    else{
      $("#version-create-error-div").css("display","none");
    }
    if(Object.keys(errors).length)
    {
      return count=false;
    }
    else{
      return count=true;
    }
   }

  
    //  add version function 
    window.addRelease=function(){
      $(".div-modal").show();
      $(".version-create").show();
      $("#version_div").hide();
      $("#effective_div").hide();
      $("#version-create-error-div").hide();
      $("#version_name").val(" ");
      $("#effective_date").val(" ");
      $("#effective_date").removeAttr("min max");
      $("#version_description").val(" ");
      $("#version_description").attr("placeholder","Description");
      disableTabindex();
     
    }

    // release create function start
    window.createRelease=function(){
      const params =window.location.search
      const parameters = new URLSearchParams(params);
      const  project_id = parameters.get('project_id');
      let content={
        name: $("#version_name").val(),
        description:$("#version_description").val(),
        project_id:project_id,
        effective_date:$("#effective_date").val()
      }
      if(validateRelease())
      {
      $.ajax({
        type: "POST",
        url: `${url}/projects/${project_id}/versions.json?key=${api_key}`,
        contentType: "application/json",
        dataType: "json",
        async:false,
        data: JSON.stringify({
          version: content,
        }),
        success: function (result, status, xhr) {
          $('.div-modal').hide();
          $(".version-create").hide();
          // cb(start, end);
   
          cb(moment(storedStart ? storedStart : start), moment(storedEnd  ? storedEnd : end));
          toastr["success"](t('label_release_created_successfully'));
        },
        error: function (xhr, status, error) {
               if(xhr.status == 422){
                  let content = JSON.parse(xhr.responseText).errors;
                   content.map((i)=>{
                   toastr["error"](i);
             })
             }
             else if(xhr.status == 403)
             {
               toastr["error"](t('label_no_permissions'));
              } 
        },
      });
    }
    }
    // release create function end

    // update release validation start
    function validateupdateRelease(){
      let errors={};
      //  release field not black  validation
      if($("#version_name_update").val().trim().length === 0)
      {
          $("#version_div_update").css("display","flex");
          $("#version_error_update").html(t('label_field_is_required'));
          errors.version=t('label_field_is_required');
      }
      else if($("#version_name_update").val().length > 255)
      {
        $("#version_div_update").css("display","flex");
        $("#version_error_update").html(t('label_only_255_characters_allowed'));
        errors.version=t('label_only_255_characters_allowed');
      }
      else{
          $("#version_div_update").css("display","none");
      }
      if($("#effective_date_update").val().length==0)
      {
        $("#effective_div_update").css("display","flex");
        $("#effective_error_update").html(t('label_field_is_required'));
        errors.effective_date=t('label_field_is_required');
      }
      else{
        $("#effective_div_update").css("display","none");
      }
      if(Object.keys(errors).length)
      {
        return count=false;
      }
      else{
        return count=true;
      }
     }
    //  update release validation end


    // update release function
    window.updateRelease=function(){
      const params =window.location.search
      const parameters = new URLSearchParams(params);
      const  project_id = parameters.get('project_id');
      let version_id= $("#save_version").attr("value");
      let content={
        name: $("#version_name_update").val(),
        description:$("#version_description_update").val(),
        project_id:project_id,
        effective_date:$("#effective_date_update").val()
      }
      if(validateupdateRelease())
      {
      $.ajax({
        type: "PUT",
        url: `${url}/versions/${version_id}.json?key=${api_key}`,
        contentType: "application/json",
        dataType: "json",
        async:false,
        data: JSON.stringify({
          version: content,
        }),
        success: function (result, status, xhr) {
          $('.div-modal').hide();
          $(".version-update").hide();
          disableTabindex();
          // cb(start, end);
          cb(moment(storedStart ? storedStart : start), moment(storedEnd  ? storedEnd : end));
          toastr["success"](t('label_release_updated_successfully'));
          gantt.openTask(version_id);
        },
        error: function (xhr, status, error) {
               if(xhr.status == 422){
                  let content = JSON.parse(xhr.responseText).errors;
                   content.map((i)=>{
                   toastr["error"](i);
             })
             }
             else if(xhr.status == 403)
             {
               toastr["error"](t('label_no_permissions'));
              } 
        },
      });
    }
    }
    // update release function end


                 // Helper function to merge arrays while ensuring the common parent object is present only once
                 function mergeArraysWithoutDuplicateParent(arr1, arr2) {
                  const commonParent = findCommonParent(arr1, arr2);

                  // Filter out the common parent from the second array
                  const filteredArr2 = arr2.filter(obj => obj.parent !== 0 || obj.id !== commonParent.id);

                  // Merge arrays
                  const mergedArray = [...arr1, ...filteredArr2];

                  return mergedArray;
                }

                // Helper function to find the common parent object with parent equal to 0
                function findCommonParent(data1, data2) {
                  return data1.find(obj1 => obj1.parent === 0 && data2.some(obj2 => obj2.parent === 0 && obj2.id === obj1.id));
                }
                                

     // ZT gantt event on scroll of gantt vertical scroll bar 
     gantt.attachEvent("onScroll", (event) => {
      let element1= $(".zt-gantt-ver-scroll");
      var scrollElement = element1;
      var scrollTop = scrollElement.scrollTop();
      var scrollHeight = scrollElement.prop("scrollHeight");
      var clientHeight = scrollElement.prop("clientHeight");
      if(scrollTop + clientHeight >= scrollHeight) {
    
                 
                      const params =window.location.search
                      const parameters = new URLSearchParams(params);
                      const filter=parameters.get('utf8');
                      const project_id = parameters.get('project_id');
                     if(project_id)
                     {
                      if(total_pages!=pagenum)
                        {
                             pagenum++;
                 
                      $.ajax({
                        type: "GET",
                        url: filter ? `${url}/gantt/data.json?key=${api_key}&${params}`:`${url}/gantt/data.json?key=${api_key}`,
                        dataType: 'json',
                        async:false,
                        beforeSend: function(){
                          $('.circle-loader').show();
                        },
                        data:filter?{
                          start_date: storedStart ? storedStart :start.format('YYYY-MM-DD'),
                          due_date: storedEnd? storedEnd :end.format('YYYY-MM-DD'),
                          per_page:perpage,
                          page:pagenum,
                          baseline_id:selected_baseline_id?selected_baseline_id :null
                        }:{
                          start_date: storedStart ? storedStart :start.format('YYYY-MM-DD'),
                          due_date: storedEnd? storedEnd :end.format('YYYY-MM-DD'),
                          project_id:project,
                          per_page:perpage,
                          page:pagenum,
                          baseline_id:selected_baseline_id?selected_baseline_id :null
                        },
                        success: function (result, status, xhr) {
                    
                 
                          $('.circle-loader').toggleClass('load-complete');
                          $('.checkmark').toggle();
                          setTimeout(() => {
                            $(".unknown-div").css("display","none");
                            $('.circle-loader').hide();
                            }, 500);
                            $('#nodata').css('display', 'none');
                          
                            if(result.data.length==0)
                              {
                                  $("#menu-gantt").css("display","none");
                                  $("#gantt_here").css("display","none");
                                  $(".export-data").css("display","none");
                                  if(!$(".nodata")[0])
                                  {
                                    $(".gantt_here_div").before(`<p  style="margin-top:30px; margin-left:13px;" class="nodata">${t('label_no_data_to_display')}</p>`);
                                  }
                              }
                              else{
                                $(".nodata").remove();
                                $("#menu-gantt").css("display","block");
                                $("#gantt_here").css("display","block");
                                $(".export-data").css("display","block");
                                gantt.clearAll();
                                gantt_data=result.data;
                                result.data.map((i)=>{
                                  i.start_date=i.gantt_start_date
                                  i.end_date=i.gantt_due_date
                                  if(i.parent_id!=null)
                                  {
                                    i.parent="i"+i.parent_id
                                  }
                                  i.issue_id=i.parent==0? i.id : i.id.replace("i","")  
                                  if(i.parent==0)
                                  {
                                    // code to calculate progress of parent       
                                    Sum=i.issues.reduce((sum,issue)=>{
                                      if(issue.parent_id==null)
                                      {
                                        return  sum+issue.done_ratio
                                      }
                                      return  sum
                                    },0)
                                    const filteredArray = i.issues.filter(obj => obj.parent_id==null);
                                    length=filteredArray.length
                                    i.progress=length!=0 ?Math.round(Sum/length) :0
                            
                                    // calculate estimation of parent task 
                                    estimation_sum=i.issues.reduce((sum,issue)=>{
                                      return sum= sum+issue.estimated_hours
                                    },0)
                                    i.estimated_hours=Number.isInteger(estimation_sum)? estimation_sum : estimation_sum.toFixed(2) 
                                  
                                    //  calculation end 
                                  }
                                  else{
                                    i.taskColor=i.color
                                    // Check if the subject contains "milestone" in parentheses
                                  let isMilestone = /\(milestone\)/i.test(i.text);
                                  if(isMilestone&&i.s_date===i.due_date)
                                  {
                                    i.type="milestone";
                                  }
                                  }
                                })
                                const typeMapping = {
                                  "start_to_start": 1,
                                  "start_to_finish": 3,
                                  "finish_to_finish": 2,
                                  "finish_to_start": 0
                                };
                                resource_data.links.map((l)=>{
                                  if (typeMapping.hasOwnProperty(l.type)) {
                                    l.type = typeMapping[l.type];
                                  }
                                })
                                  gantt.parse(result.data)
                                  gantt.options.links =resource_data.links
                                  var ganttTodayFlag= JSON.parse(localStorage.getItem('gantt_today_flag'));
                                  document.getElementById('today').checked = ganttTodayFlag !== null ? ganttTodayFlag : true;
                                  if (ganttTodayFlag != false) {
                                    gantt.options.todayMarker=true;
                                  } else {
                                    gantt.options.todayMarker=false;
                                  }
                                  gantt.render(); 
                                  gantt.autoScheduling(); 
                              }
                        },
                        error: function (xhr, status, error) {
                          
                          $('.circle-loader').toggleClass('load-complete');
                          $('.checkmark').toggle();
                          setTimeout(() => {
                            $(".unknown-div").css("display","none");
                            $('.circle-loader').hide();
                            }, 500);
                            if(xhr.status==403)
                            {
                              if(!$(".nodata")[0])
                              {
                                $(".gantt_here_div").before(`<p  style="margin-top:30px; margin-left:13px;" class="nodata">${t('label_no_data_to_display')}</p>`);
                              }
                            }
                            else {
              
                              var errorResponse = JSON.parse(xhr.responseText);
                              if (errorResponse.errors && errorResponse.errors.length > 0) {
                                var errorHtml = '<ul>';
                                errorResponse.errors.forEach(function(errorMessage) {
                                    errorHtml += '<li>' + errorMessage + '</li>';
                                });
                                errorHtml += '</ul>';
                                $('#errorExplanation').html(errorHtml);
                                  console.error(errorResponse.errors[0]);
                                  $('.filter-modal,.div-modal').css('display', 'block');
                                  $('#query_form_with_buttons').css('display', 'block');
                                  disableTabindex();
                                  $('#errorExplanation').css('display', 'block');
                              }
                              else if (errorResponse.error) { // Check for specific error message format
                                var errorMessage = errorResponse.error;
                                $('#nodata').text(errorMessage);
                                $('#nodata').css('display', 'block');
                                $(".gantt_here_div").css("display","none");
                              }
                            }
                        }
                    });
                  }
                  }
                
                  else{
          
                    if(project_total_pages!=project_pagenum)
                      {
                        project_pagenum++;
                    $.ajax({
                      type: "GET",
                      url:filter ?  `${url}/project/view.json?key=${api_key}&${params}`:`${url}/project/view.json?key=${api_key}`,
                      dataType: 'json',
                      async:true,
                      beforeSend:function(){
                        $('.circle-loader').show();
                      },
                      data:{
                        start_date: storedStart ? storedStart :start.format('YYYY-MM-DD'),
                        due_date: storedEnd? storedEnd :end.format('YYYY-MM-DD'),
                        project_perpage:  project_perpage,
                        project_pagenum: project_pagenum
                      },
                      success: function (result, status, xhr) {
                  
                        $('.circle-loader').toggleClass('load-complete');
                        $('.checkmark').toggle();
                        setTimeout(() => {
                          $(".unknown-div").css("display","none");
                          $('.circle-loader').hide();
                          }, 500);
                          $('#nodata').css('display', 'none');
                          if(result.allProjects.length!=0)
                            {
                              allProjects=result.allProjects;
                            }
                          if(result.data.length==0)
                            {
                                 $("#menu-gantt").css("display","none");
                                 $("#gantt_here").css("display","none");
                                 if(!$(".nodata")[0])
                                 {
                                  $(".gantt_here_div").before(`<p  style="margin-top:30px; margin-left:13px;" class="nodata">${t('label_no_data_to_display')}</p>`);
                                 }
                            }
                            else{
                              $(".nodata").remove();
                              $("#menu-gantt").css("display","block");
                              $("#gantt_here").css("display","block");
                              if(result.hasOwnProperty("pagination"))
                              {
                              total_pages=result.pagination.total_pages;
                              }
                              gantt.clearAll();
                 
                              gantt_data=  result.data
                              result.data.map((i)=>{
                                i.start_date=i.gantt_start_date
                                i.end_date=i.gantt_due_date
                                if(i.parent_id!=null)
                                {
                                  i.parent="i"+i.parent_id
                                }
                                 i.issue_id=i.parent==0? i.id : i.id.replace("i","")  
                                 if(i.parent==0)
                                {
                                  // code to calculate progress of parent       
                                   Sum=i.issues.reduce((sum,issue)=>{
                                    if(issue.parent_id==null)
                                    {
                                      return  sum+issue.done_ratio
                                    }
                                    return  sum
                                   },0)
                                   const filteredArray = i.issues.filter(obj => obj.parent_id==null);
                                   length=filteredArray.length
                                   i.progress=length!=0 ?Math.round(Sum/length) :0
                           
                                  // calculate estimation of parent task 
                                   estimation_sum=i.issues.reduce((sum,issue)=>{
                                    return sum= sum+issue.estimated_hours
                                   },0)
                                   i.estimated_hours=Number.isInteger(estimation_sum)? estimation_sum : estimation_sum.toFixed(2) 
                                
                                  //  calculation end 
                                }
                                else{
                                  i.taskColor=i.color
                                let isMilestone = /\(milestone\)/i.test(i.text);
                                if(isMilestone&&i.s_date===i.due_date)
                                {
                                  i.type="milestone";
                                }
                                }
                              })
              
                           
                               const typeMapping = {
                                "start_to_start": 1,
                                "start_to_finish": 3,
                                "finish_to_finish": 2,
                                "finish_to_start": 0
                              };
                               resource_data.links.map((l)=>{
                                if (typeMapping.hasOwnProperty(l.type)) {
                                  l.type = typeMapping[l.type];
                                }
                               })
          
                                gantt.parse(result.data)
                                gantt.options.links =resource_data.links;
                                var ganttTodayFlag= JSON.parse(localStorage.getItem('gantt_today_flag'));
                                document.getElementById('today').checked = ganttTodayFlag !== null ? ganttTodayFlag : true;
                                if (ganttTodayFlag != false) {
                                  gantt.options.todayMarker=true;
                                } else {
                                  gantt.options.todayMarker=false;
                                }
                                gantt.render();  
                                gantt.autoScheduling(); 
                            }
                      },
                      error: function (xhr, status, error) {
                         
                        $('.circle-loader').toggleClass('load-complete');
                        $('.checkmark').toggle();
                        setTimeout(() => {
                          $(".unknown-div").css("display","none");
                          $('.circle-loader').hide();
                          }, 500);
                          if(xhr.status==403)
                          {
                            if(!$(".nodata")[0])
                            {
                              $(".gantt_here_div").before(`<p  style="margin-top:30px; margin-left:13px;" class="nodata">${t('label_no_data_to_display')}</p>`);
                            }
                          }
                          else {
                            var errorResponse = JSON.parse(xhr.responseText);
                            if (errorResponse.errors && errorResponse.errors.length > 0) {
                              var errorHtml = '<ul>';
                              errorResponse.errors.forEach(function(errorMessage) {
                                  errorHtml += '<li>' + errorMessage + '</li>';
                              });
                              errorHtml += '</ul>';
                              $('#errorExplanation').html(errorHtml);
                                $('.filter-modal,.div-modal').css('display', 'block');
                                $('#query_form_with_buttons').css('display', 'block');
                                disableTabindex();
                                $('#errorExplanation').css('display', 'block');
                            }
                            else if (errorResponse.error) {
                              var errorMessage = errorResponse.error;
                              $('#nodata').text(errorMessage);
                              $('#nodata').css('display', 'block');
                              $('#gantt_here').css('display', 'none')
                              $(".gantt_here_div").css("display","none");
                            }
                            else{
                              $('#nodata').css('display', 'none');
                            }
                          }
                      }
                   });
                  }
                  }
                
              }
            })
            // zt gantt scroll bar end 
                  
               
            function disableTabindex() {
              if ($(".version-create, .version-update, .issue-create, .update_issue, .link-delete , .filter-modal").is(':visible')) {
              $(":tabbable").attr("tabindex", -1);
              $(".version-create [tabindex='-1']").attr('tabindex', 0);
              $(".version-update [tabindex='-1']").attr('tabindex', 0);
              $(".issue-create [tabindex='-1']").attr('tabindex', 0);
              $(".update_issue [tabindex='-1']").attr('tabindex', 0);
              $(".link-delete [tabindex='-1']").attr('tabindex', 0);
              $(".filter-modal [tabindex='-1']").attr('tabindex', 0);
              $("html").css("overflow-y", "hidden");
              
            }
            else{
              $("[tabindex='-1']").attr("tabindex", 0);
              $("html").css("overflow-y", "scroll");
             
            }
            } 

            function delay(callback, ms) {
              var timer = 0;
              return function() {
                var context = this, args = arguments;
                clearTimeout(timer);
                timer = setTimeout(function () {
                  callback.apply(context, args);
                }, ms || 0);
              };
            }
               // search unassigned issue function
                $('#Search').keyup(delay(function (e) {
                  var valThis=this.value;
                if(valThis.length!=0)
                {
                $('.spinner-gantt').show();
                $.ajax({
                  type: "GET",
                  url: `${url}/search/issues/without/version.json?key=${api_key}`,
                  dataType: 'json',
                  async:false,
                  contentType: "application/json",
                  data: {
                    issue: valThis.trim(),
                    project_id:project
                  },
                  success: function (result, status, xhr) {
                    setTimeout(()=>{
                        $('.spinner-gantt').hide();
                      },200)
                      $("#sidePanel-gantt").html( " ");

                      if (Array.isArray(result) && result.length != 0)
                      {
                         localStorage.setItem("unassigned_issue",JSON.stringify(result))
                         result.map((i)=>{
                          i.due_date=i.due_date !=null ? i.due_date : i.s_date
                  $(".dynamic-issue-gantt").append(`<div     id=${i.id} draggable="true" ondragstart="drag(event)" class="issues-div-gantt" style="display:flex; flex-direction:column; ">
                  <div  style="display:flex;"> 
                      <a  href='${url}/issues/${i.id}'class="ticket ${i.tracker.name}">#${i.id} </a><span  class="i-sub">${i.text}</span>
                    </div>
                    <div class="project-div"  style="display:flex; justify-content:space-between;"> 
                        <div style="display:flex">
                          <span class="project-name">${i.project_name}</span>
                            </div>

                        <div style="display:flex">
                          <span  class="e-hour" >${i.estimated_hours==null? 0+"h" : i.estimated_hours+"h"}</span>
                            </div>
                    </div>
                </div>`)
                })
                      }
                      else{
                        $(".dynamic-issue-gantt").append(`<div class="error-search"><span > ${t('label_no_matching_issue_found')}</span></div>`)
                      }
                  },
                  error: function (xhr, status, error) {
                  setTimeout(()=>{
                        $('.spinner-gantt').hide();
                      },200)
                  }

                  });
                }
                else{
                  let Issueswithoutversion=JSON.parse(localStorage.getItem("issueswithoutversion"));
                  $("#sidePanel-gantt").html( " ");
                  if(Issueswithoutversion.length!=0){
                    Issueswithoutversion.map((i)=>{
                          i.due_date=i.due_date !=null ? i.due_date : i.s_date
                  $(".dynamic-issue-gantt").append(`<div  id=${i.id} draggable="true" ondragstart="drag(event)" class="issues-div-gantt" style="display:flex; flex-direction:column; ">
                  <div  style="display:flex;"> 
                      <a  href='${url}/issues/${i.id}'class="ticket ${i.tracker.name}">#${i.id} </a><span  class="i-sub">${i.text}</span>
                    </div>
                    <div class="project-div"  style="display:flex; justify-content:space-between;"> 
                        <div style="display:flex">
                          <span class="project-name">${i.project_name}</span>
                            </div>

                        <div style="display:flex">
                          <span  class="e-hour" >${i.estimated_hours==null? 0+"h" : i.estimated_hours+"h"}</span>
                            </div>
                    </div>
                </div>`)
                })
                    }
                    else{
                      $(".dynamic-issue-gantt").append(`<div class="error-search"><span > ${t('label_no_issue_found')}</span></div>`)
                    }
                }
           },500));

// function to drag issues from right panel to drop on gantt
var originalParent = null; 
var draggedItem = null;
var previousSibling = null;
var draggItem=null;
// add a variable to check card id drop or not 
let cardDropped=false;

// drag and drop code for issues
const elem=document.querySelectorAll('.gantt_div');

elem.forEach(box => {
 box.addEventListener('dragenter', dragEnter)
 box.addEventListener('dragover', dragOver);
 box.addEventListener('dragleave', dragLeave);
 box.addEventListener('drop', drop);

});

window.drag=function(ev)
{  
if(ev.target.className.match("issues-div-gantt"))
{
var issueobj={};
let unassigned_issue=JSON.parse(localStorage.getItem("issueswithoutversion"));
unassigned_issue.map((list)=>{
        if(list.id==ev.target.id)
        {
          issueobj=list;
        }
})
ev.dataTransfer.setData('text/html',JSON.stringify(issueobj));
draggedItem = ev.target;

originalParent =  ev.target.parentElement;
previousSibling =  Array.from(originalParent.children).indexOf(draggedItem); 
setTimeout(() => {
  ev.target.classList.add('hide');
}, 100);

ev.target.addEventListener('dragend', function() {
  if (draggedItem) {
    originalParent.insertBefore(draggedItem, originalParent.children[previousSibling]);
    draggedItem.classList.remove('hide');
    // Reset variables
    draggedItem = null;
    originalParent = null;
    previousSibling = null;
  }
});
}  
  // Add dragend event listener

}

function dragEnter(e) {
e.preventDefault();
if(e.target.classList.contains("zt-gantt-task-cell"))
{
   e.target.classList.add('drag-over');
}
}

function dragOver(e) {
e.preventDefault();
if(e.target.classList.contains("zt-gantt-task-cell"))
{
  e.target.classList.add('drag-over');
}
}

function dragLeave(e) {
if(e.target.classList.contains("zt-gantt-task-cell"))
{
e.target.classList.remove('drag-over');
}
}



function drop(e) {
  e.preventDefault();
  const id = e.dataTransfer.getData('text/html');
  var task=JSON.parse(id)
  const draggable = document.getElementById(task.id);
  draggItem=draggable;
  if(e.target.classList.contains("zt-gantt-task-cell"))
  {
  e.target.classList.remove('drag-over');
  var task_id="i"+task.id;
  var cell_date=e.target.getAttribute("zt-gantt-cell-date");
  var ID=e.target.getAttribute("zt-gantt-task-id");
  var taskDetail=gantt.getTask(ID.includes("i")?ID:parseInt(ID));

  let content={
    "start_date":cell_date,
    "due_date":cell_date,
    "fixed_version_id":ID.includes("i")?taskDetail.parent:parseInt(ID)
  }

  $.ajax({
    type: "PUT",
    url: `${url}/issues/${task.id}.json?key=${api_key}`,
    dataType: "json",
    contentType: "application/json",
    async: false,
    data: JSON.stringify({
      issue: content,
    }),
    success: function (result, status, xhr) {
      draggable.classList.add('hide');
      cardDropped=true;
      var taskId = gantt.addTask({
        row_height:50,
        bar_height:40,
        id:task_id,
        text:task.text,
        issue_id:task.id,
        Estimation: task.estimated_hours != null  ? task.estimated_hours : 0,
        estimated_hours:task.estimated_hours != null  ? task.estimated_hours : 0,
        start_date:cell_date,
        s_date:cell_date,
        fixed_version_id:ID.includes("i")?taskDetail.parent:parseInt(ID),
        parent:ID.includes("i")?taskDetail.parent:parseInt(ID),                                                                                  
        assigned_to:taskDetail.assigned_to?taskDetail.assigned_to.name:"Not Assigned",                                            
        description:task.description,
        subtask:[],
        parent:ID.includes("i")?taskDetail.parent:parseInt(ID),
        due_date:cell_date,
        end_date:cell_date,
        tracker_namename:task.tracker.name,
        done_ratio:task.done_ratio,
        progress:task.done_ratio
        
      });
   
      resource_data.data.push(gantt.getTask(task_id));
  
      const totalEstimatedHours = resource_data.data.reduce((acc, task) =>
      {
        if(task.parent==(ID.includes("i")?taskDetail.parent:parseInt(ID)))
        { 
  
          let Esimtation=task.estimated_hours?+task.estimated_hours:0;
          return  acc + Esimtation
        }
        return acc;
      }
      , 0);
   var Issues=[];

    let parent={
      id:ID.includes("i")?taskDetail.parent:parseInt(ID),
      estimated_hours:Number.isInteger(totalEstimatedHours)?totalEstimatedHours:totalEstimatedHours.toFixed(2),
      parent:0,
      issues:Issues.push(gantt.getTask(task_id))
      }
      gantt.updateTaskData(parent);
      gantt.render();
      toastr["success"](t('label_issue_dropped_successfully'));
 
       },
    error: function (xhr, status, error) {
      draggable.classList.remove('hide');
      cardDropped=false;
        if(xhr.status == 422){
           let content = JSON.parse(xhr.responseText).errors;
          content.map((i)=>{
            if(i===t('label_due_date_must_be_greater_than_start_date'))
            {
              toastr["error"](t('label_start_date_greater_than_due_date'));
            }
            else if(i===t('label_assignee_invalid'))
            {
              toastr["error"](t('label_user_not_member'));
            }
            else{
              toastr["error"](i);
            }
         })
       }
       else if(xhr.status == 403)
       {
           toastr["error"](t('label_no_permissions'));
       } 
    },
  });
} 
else {
  originalParent.insertBefore(draggedItem, originalParent.children[previousSibling]);
  draggedItem.classList.remove('hide');;
}



} // function to drop issue on gantt end 



// Add event listeners to the window object to prevent the default behavior for dragover and drop events
window.addEventListener('dragover', function (e) {
  e.preventDefault();
});

window.addEventListener('drop', function (e) {
  e.preventDefault();
    if (draggedItem) {
      if (cardDropped==true) {
        // Drop inside the "gantt-div," hide the card
        draggedItem.classList.add('hide');
      }else {
        // Drop anywhere else, restore to previous position
        // originalParent.insertBefore(draggedItem, previousSibling);
        originalParent.insertBefore(draggedItem, originalParent.children[previousSibling]);
        draggedItem.classList.remove('hide');
      }
      // Reset variables
      draggedItem = null;
      originalParent = null;
      previousSibling = null;
    }
});


// end of drag and drop code for issues

});



