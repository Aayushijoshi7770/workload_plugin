
  class IssueHook < Redmine::Hook::ViewListener
    def controller_issues_edit_after_save(context = {})
      issue = context[:issue]
      update_gantt_dates(issue)
      update_baseline_dates(issue)

      if issue.is_a?(Issue) && issue.parent_id.present?
        update_parent_gantt_dates(issue)
      end
    end

    def controller_issues_bulk_edit_before_save(context ={})
      issue = context[:issue]
      update_gantt_dates(issue)
      update_baseline_dates(issue)

      if issue.is_a?(Issue) && issue.parent_id.present?
        update_parent_gantt_dates(issue)
      end
    end 



    def controller_issues_new_after_save(context = {})
      issue = context[:issue]
      update_gantt_dates(issue)
      update_baseline_dates(issue)

      if issue.is_a?(Issue) && issue.parent_id.present?
        update_parent_gantt_dates(issue)
      end
    end


    private

    def update_baseline_dates(issue)
      return unless issue.start_date && issue.due_date  
      baseline_start_date = DateTime.parse("#{issue.start_date} 00:00:00")
      baseline_due_date = DateTime.parse("#{issue.due_date} 00:00:00")
      if issue.persisted?
        issue.update_column(:baseline_start_date,  baseline_start_date)
        issue.update_column(:baseline_due_date,   baseline_due_date)
        else
          issue.baseline_start_date=baseline_start_date
          issue.baseline_due_date=baseline_due_date
        end 
     
    end

    def update_gantt_dates(issue)
      return unless issue.start_date && issue.due_date 
      gantt_start_date = DateTime.parse("#{issue.start_date} 00:00:00")
      gantt_due_date = DateTime.parse("#{issue.due_date} 00:00:00")

      if issue.persisted?
        issue.update_column(:gantt_start_date, gantt_start_date)
        issue.update_column(:gantt_due_date, gantt_due_date)
        else
          issue.gantt_start_date=gantt_start_date
          issue.gantt_due_date=gantt_due_date
        end 
    end

    def update_parent_gantt_dates(subtask)
      parent_issue = Issue.find_by(id: subtask.parent_id)
      if parent_issue.present?
        created_time = Time.now.strftime('%H:%M:%S')
        parent_issue.update_columns(
          gantt_start_date: "#{parent_issue.start_date} 00:00:00",
          gantt_due_date: "#{parent_issue.due_date} 00:00:00"
        )
     
      end
    end
  end

