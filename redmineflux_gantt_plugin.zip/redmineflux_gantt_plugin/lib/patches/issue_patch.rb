module Patches
  module IssuePatch
    def self.included(base)
      base.class_eval do
        before_create :generate_light_color
      end
    end

    private

    def generate_light_color
      return if color.present?
      letters = %w[B C D E F]
      self.color = '#'
      6.times { self.color += letters.sample }
    end
  end
end



Issue.send(:include, Patches::IssuePatch)