module Patches
  module UpdateIssuePatchGantt
    def self.included(base)
      base.class_eval do
          puts "code executed"
          safe_attributes 'baseline_id' 
      end
    end
  end
end

Issue.send(:include, Patches::UpdateIssuePatchGantt)