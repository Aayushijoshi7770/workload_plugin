require_dependency 'issue'

  if Redmine::VERSION::MAJOR == 4
    require_relative './lib/issue_hook.rb'
    require_relative './lib/patches/issue_relation_patch.rb'
    require_relative './lib/patches/issue_patch.rb'
   require_relative './lib/patches/update_issue_patch_gantt.rb'
  elsif  Redmine::VERSION::MAJOR == 5
    require File.expand_path('./lib/issue_hook.rb', __dir__)
    require File.expand_path('./lib/patches/issue_relation_patch.rb', __dir__)
    require File.expand_path('./lib/patches/issue_patch.rb', __dir__)
    require File.expand_path('./lib/patches/update_issue_patch_gantt.rb', __dir__)
  end

Redmine::Plugin.register :redmineflux_gantt_plugin do
  name 'Redmineflux Gantt Plugin'
  author 'Redmineflux - Powered by Zehntech Technologies Inc'
  description "Redmineflux Gantt Chart Plugin displays project schedules, tasks, and dependencies visually, helping teams plan, monitor, and track progress effectively."
  version '1.0.10'
  url 'https://www.redmineflux.com/knowledge-base/plugins/gantt-chart/'
  author_url 'https://www.redmineflux.com'
  

  # menu :application_menu, :redmineflux_gantt, { controller: 'redmineflux_gantt', action: 'index' }, caption: 'Flux Gantt'
    project_module :redmineflux_gantt_chart do 
      permission :redmineflux_gantt, { redmineflux_gantt: [:index ] }, public: true
      Redmine::MenuManager.map :project_menu do |menu|
      menu.push :redmineflux_gantt, { :controller => 'redmineflux_gantt', :action => 'index' }, :caption => Proc.new { I18n.t(:label_flux_gantt) }, before: :activity, :param => :project_id
    end
  end
    project_module :baselines do 
      permission :view_baselines, { projects: [:settings ] }, public: true
  end 
  settings partial: 'settings/blank_page'
  menu :top_menu, :redmineflux_gantt, { controller: 'project_gantt', action: 'index'}, caption: Proc.new { I18n.t(:label_flux_gantt) }
  #  plugin name 
end




