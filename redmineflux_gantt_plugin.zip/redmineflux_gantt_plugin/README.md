# Redmineflux Gantt Chart plugin
The Redmienflux Gantt Chart plugin represents a robust Redmine extension designed to elevate your project planning and enhance your ability to track project progress.

## Introduction

## Table of Contents
- [Installation](#installation)
- [Getting-started](#Getting-started)
- [Features](#Features)
- [Uninstallation](#Uninstallation)
- [Version-Compatibility](#Version Compatibility)

# Installation

To install the Redmineflux Gantt Chart Plugin, follow the below steps.
- Ensure that you have a functional installation of Redmine.
- Unzip the Redmineflux Gantt Chart Plugin in Redmine/plugins directory, and do not change the plugin folder name
- Run the following command to install the dependencies

  ```sh
    bundle install
  ```
- Run migrate command to migrate the database 
  - In production 
  ```sh
    RAILS_ENV=Production bundle exec rails redmine:plugins:migrate
  ```
  
  - In development 
  ```sh
    RAILS_ENV=Development bundle exec rails redmine:plugins:migrate
  ```
  
  - Run the below two rake command to create dependencies
    - In production
      ```sh
        RAILS_ENV=production bundle exec rake colors:update_issue_colors
      ```
      ```sh
        RAILS_ENV=production bundle exec rake updatedates:update
      ```

    - In development
      ```sh
        RAILS_ENV=development bundle exec rake colors:update_issue_colors
      ```

      ```sh
        RAILS_ENV=development bundle exec rake updatedates:update
      ```

  - Restart Redmine server to load the plugin
  ```sh 
    rails s
  ```

# Getting Started
**Step 1:**  To Enable REST API 
   - Login as a administrator.
   - Navigate to **Administration** tab from top menu.
   - Click on **Settings** and find the **API** tab and enable the rest API.

**Step 2:** Ensure that default values are set for the following attributes
  - Establish a default priority value by selecting one from the available issue priorities. 
  - Choose a default tracker value from the list of available trackers.
  - Specify a default status value by selecting one from the available issue statuses.

**Step 2:** Enabling Gantt Chart Plugin in a project
  - Navigate to projects tab on top menu.
  - Click on any project from the list.
  - Navigate to project settings 
  - Enable the **Redmineflux Gantt Chart** from the modules and click on save to apply the changes.
  - Now you can see the Gantt Chart plugin on project menu.

**Step 3:** Create a new Version/Release
   - Click on **Add release** button, enter the desired result and click on save to create.
   - Provide the desired information such as name, description, due date and click on save.

    ![New Version](./assets/images/new-release.png)
  
   - The start date of version will be created date.

**Step 4:** Create a new Issue/Task
   - Navigate to Gantt Chart dashboard and click on **Add Issue** button. 
   - Enter the neccessary information by selecting the version for which you are planning and click on save to create new issue.
    
    ![New Issue](./assets/images/new-issue.png)

***Step 5:**  Update Task Using Redmineflux Gantt Chart 
  - To update task in Gantt Chart follow these steps 
  - Double-click on the task bars within the timeline area. 
  - A popup will appear, displaying fields like subject, start date, release, and more. 
  - Update the desired field and click the "Save" button. 
  - The selected task will be updated and will be reflected in the Gantt dashboard. 
  - If you wish to discard the changes, you can click the "Cancel" button to revert the changes and close the popup window. 

**Step 6:**  Delete task Using Redmineflux Gantt Chart 
  To Delete task from Gantt Chart, follow these steps: 
  - Double-click the task you wish to delete in the Gantt Chart. 
  - A popup will appear; within this popup, you will find a “Delete” button. 
  - Click the **Delete** button.
  - A confirmation popup will subsequently appear, click the **Delete** button within this confirmation popup to remove the task from the Gantt Chart. 
  - Should you need to discard the changes, you can click the **Cancel** button to undo the changes and close the popup window. 

**Step 7:**  To add more informations such as progress, estimation, assignee to the Gantt Chart 
   - Find the settings icon and click on it.
   - Select the check box of assignee, progress and estimated hours from the modal.
   
   ![New Issue](./assets/images/more-information.png)
**Step 8:** Add task relation Using Redmine Flux Gantt Chart  
  To establish task relations (links) in the Gantt Chart, follow these steps: 
  - Open your Redmine project and navigate to the Gantt Chart view. 
  - Identify the task you want to link with another task. Click on the task bar to select it. 
  - While holding down the mouse button, drag the selected task's bar to the target task's bar. This initiates the process of creating a task relation. 
  - Once you've positioned the selected task's bar over the target task's bar, release the mouse button. This action will trigger a context menu. 
  - The task relation will then be established between the two tasks. 
  - The Gantt Chart will now illustrate the established task relation, providing a clear representation of the interdependency between the tasks. 

**Step 9:** Delete task relation (link) Using Redmine Flux Gantt Chart
  To delete task relations (links) in the Gantt Chart, follow these steps: 
  - Double-click on the task link. 
  - A confirmation popup will appear. Click the **Delete** button to remove the task relation. 
  - Click on **Cancel** button to discard the changes. 
  - Once you have clicked the **Delete** button, task relation will be removed from the Gantt Chart. 

**Step 10:**  View Gantt Chart in multiple Zoom level 
   - Navigate to zoom level drop down menu.
   - Choose your preferred time scale (day, week, month, or year) from the dropdown menu to specify how you'd like to view the Gantt chart. The default will be Day view.

   ![New Issue](./assets/images/week-view.png)
 
**Step 11:**  Various choices for calendars
   - Navigate to Date From/To drop down menu on Gantt Chart.
   - Select your desired date range option to access and view past or upcoming day's plans.
   
    ![New Issue](./assets/images/different-date-calendar.png)

**Step 12:** Move task from one release to other release Using Redmineflux Gantt Chart 
  To move task from one release to another using Redmine Flux Gantt Chart, follow these steps: 
  - Choose the task that you intend to move from its current release to another one. 
  - Click and hold the selected task, then drag it to the section corresponding to the desired release. 
  - Release the mouse button to drop the task into the chosen release section. 
  - After dropping the task, the release associated with the task will be automatically updated. You will now see this change reflected in the Gantt Dashboard 

**Step 13:** Expand and Collapse Gantt Chart  
  - To Collapse Gantt Chart, simply click on **Collapse Al** option.
  - To Expand Gantt Chart, simply click on **Expand All** option. 

**Step 14:** Search for Tasks or Releases in the Gantt Chart
  The Redmine Flux Gantt Chart feature allows users to conveniently search for tasks within the Gantt dashboard using task ID or subject. Additionally, users can search for specific release by utilizing release ID or name. 

# Features
  - Effective Project Planning and Task Management
  - Manage Task Relation
  - Effortless Task Management with Interactive Drag and Drop Interface
  - Custom Color Options and Enhanced Zooming Functionality
  - Milestone Task and Progress Tracking
  - Advanced Customization Options

# Uninstallation  
To uninstall the Redmineflux Gantt Chart Plugin, follow these steps: 
  - Navigate to the Plugins directory in Redmine. 
  - Delete the entire Gantt Chart directory from Redmine/plugins directory. This step removes the plugin files from your Redmine installation. 
  - If the plugin required a migration, run the following command to downgrade your database (make a db backup before) 

  ```sh
     Bundle exec rake redmine:plugins:migrate Name=plugin name VERSION=0  RAILS_ENV=production 
  ```

  - Restart the Redmine server to see the changes. 
  - This will uninstall the Redmineflux Gantt Chart Plugin from Redmine

# Version Compatibility  
  Redmine Versions 
  - 4.0.x, 4.1.x, 4.2.x 
  - 5.0.x 
  - 6.0.x(coming soon) 


**Library Credits**

This Redmienflux Gantt Chart plugin is built using the Gantt Chart library developed by Zehntech Technologies Pvt. Ltd.
  
  [Gantt-Chart](https://github.com/zehntech/zt-gantt/)

