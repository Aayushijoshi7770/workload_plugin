class CreateBaselineData < (ActiveRecord::VERSION::MAJOR >= 6 ? ActiveRecord::Migration[6.1] : ActiveRecord::Migration[5.2])
  def change
    create_table :baseline_data do |t|
      t.integer :issue_id
      t.integer :project_id
      t.integer :baseline_id
      t.datetime :baseline_start_date
      t.datetime :baseline_due_date
      t.timestamps
    end
  end
end
