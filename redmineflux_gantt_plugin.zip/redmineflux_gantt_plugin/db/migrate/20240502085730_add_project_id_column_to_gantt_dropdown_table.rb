class AddProjectIdColumnToGanttDropdownTable < (ActiveRecord::VERSION::MAJOR >= 6 ? ActiveRecord::Migration[6.1] : ActiveRecord::Migration[5.2])
  def self.up 
    add_column :gantt_dropdown_preferences, :project_id, :integer 
   end

   def self.down 
    remove_column :gantt_dropdown_preferences, :project_id
   end 
end
