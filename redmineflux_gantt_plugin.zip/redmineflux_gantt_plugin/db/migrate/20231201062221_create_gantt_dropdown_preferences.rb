class CreateGanttDropdownPreferences < ActiveRecord::Migration[5.2]
 def up
  unless table_exists?(:gantt_dropdown_preferences)
    create_table :gantt_dropdown_preferences do |t|
      t.integer :user_id
      t.string :selected_option
      t.timestamps
    end 
  end
 end
 def down
  if table_exists?(:gantt_dropdown_preferences)
    drop_table :gantt_dropdown_preferences
  end
end
end
