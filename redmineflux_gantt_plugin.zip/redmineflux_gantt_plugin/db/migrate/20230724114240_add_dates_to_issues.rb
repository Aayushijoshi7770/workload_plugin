class AddDatesToIssues < ActiveRecord::Migration[5.2]
  def change
    add_column :issues, :gantt_start_date, :datetime
    add_column :issues, :gantt_due_date, :datetime
  end
end
