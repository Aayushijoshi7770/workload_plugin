class AddBaselineIdToIssueTable < (ActiveRecord::VERSION::MAJOR >= 6 ? ActiveRecord::Migration[6.1] : ActiveRecord::Migration[5.2])
  def change
    add_column :issues, :baseline_id, :integer
  end
end
