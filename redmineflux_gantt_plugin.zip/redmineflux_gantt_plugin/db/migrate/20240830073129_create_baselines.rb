class CreateBaselines <(ActiveRecord::VERSION::MAJOR >= 6 ? ActiveRecord::Migration[6.1] : ActiveRecord::Migration[5.2])
  def change
    create_table :baselines do |t|
      t.string :name
      t.integer :project_id
      t.boolean :selected
      t.timestamps
    end
  end
end
