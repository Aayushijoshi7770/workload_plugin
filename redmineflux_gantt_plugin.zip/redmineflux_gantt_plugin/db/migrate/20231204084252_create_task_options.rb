class CreateTaskOptions < ActiveRecord::Migration[5.2]
  def change
    unless table_exists?(:task_options)
    create_table :task_options do |t|
      t.integer :user_id
      t.string  :project_id
      t.boolean :assignee, default:false
      t.boolean :progress, default:false
      t.boolean :estimated_hour, default:false
      t.boolean :task, default: false
    end
  end
  end
  def down
    if table_exists?(:task_options)
      drop_table :task_options
    end
  end
end
