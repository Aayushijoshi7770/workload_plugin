class AddColorColumnToIssues < ActiveRecord::Migration[5.2]
  def self.up 
    add_column :issues, :color, :string  
   end

   def self.down 
    remove_column :issues, :color
   end 
end
