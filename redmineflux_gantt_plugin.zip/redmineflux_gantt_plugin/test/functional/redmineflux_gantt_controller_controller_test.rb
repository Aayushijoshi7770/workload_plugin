require File.expand_path('../../test_helper', __FILE__)

class RedminefluxGanttControllerControllerTest < ActionController::TestCase
  # Replace this with your real tests.
  def test_truth
    assert true
  end
end
