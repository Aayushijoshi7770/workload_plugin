# Plugin's routes
# See: http://guides.rubyonrails.org/routing.html
get '/flux_gantt', to: 'redmineflux_gantt#index'
get '/gantt/data', to: 'redmineflux_gantt#gantt_data'
get '/gantt_members', to: 'redmineflux_gantt#project_members'
put '/gantt/issues', to: 'redmineflux_gantt#update_color'
put '/update/dates', to: 'redmineflux_gantt#update'
post '/create/issue', to:'redmineflux_gantt#create'

# Post API to store expand and collapse all data 
post "/update_preference", to: "redmineflux_gantt#update_preference"

# POST API to save filter options 
post '/update_task_options', to: 'redmineflux_gantt#save_filter'

# get API to get saved filters
get '/get/filter/data', to:'redmineflux_gantt#get_filter'
get '/issues/without/version', to: 'redmineflux_gantt#issues_without_version'
get '/search/issues/without/version', to: 'redmineflux_gantt#search_issues_without_version'


# global gantt controller
get 'project_gantt/index', to: 'project_gantt#index'
get 'project/view', to: 'project_gantt#showProject'
 
post '/save/baseline', to: 'redmineflux_gantt#CreateBaselines'
get 'get/baseline', to: 'redmineflux_gantt#getbaseline'
post 'save/selected/baseline', to: 'redmineflux_gantt#storeBaseline'
delete 'delete/baseline', to: 'redmineflux_gantt#deleteBaseline'

# baseline data apis
 
post 'store/baseline/data',to: 'redmineflux_gantt#create_baseline_data'



