module GanttDropdownPreferencesHelper
end
