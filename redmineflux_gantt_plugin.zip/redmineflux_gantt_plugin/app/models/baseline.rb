class Baseline < ActiveRecord::Base
  validates :name, presence: true, length: { maximum: 52 }, uniqueness: { scope: :project_id, case_sensitive: true }
end
