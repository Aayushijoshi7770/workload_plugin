class GanttDropdownPreferences < ActiveRecord::Base
    belongs_to :user
end
