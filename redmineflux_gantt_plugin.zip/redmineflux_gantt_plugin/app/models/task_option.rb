class TaskOption < ActiveRecord::Base
end
