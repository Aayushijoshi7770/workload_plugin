class BaselineData < ActiveRecord::Base
  validates :issue_id, presence: true
  validates :baseline_id, presence: true
  validates :project_id, presence: true
  validates :baseline_start_date, presence: true
  validates :baseline_due_date, presence: true
  validate :validate_baseline_dates

  private

  # Custom validation for ensuring the start date is before the due date
  def validate_baseline_dates
    if baseline_start_date.present? && baseline_due_date.present? && baseline_start_date > baseline_due_date
      errors.add(:baseline_due_date, "must be after the issue start date")
    end
  end
end
