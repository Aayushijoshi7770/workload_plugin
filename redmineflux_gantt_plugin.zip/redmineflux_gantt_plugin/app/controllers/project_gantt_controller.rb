class ProjectGanttController < ApplicationController
  before_action :require_login
  accept_api_auth :showProject

  include QueriesHelper
  helper :queries

  def index
    if ActiveRecord::Base.connection.table_exists?('gantt_dropdown_preferences')
      @preference = GanttDropdownPreferences.where(user_id: User.current.id, project_id:  @projectID).first_or_create(selected_option: "collapse").selected_option
      end
      @query = query_class.new
      @query.user = User.current
      @query.build_from_params(params)
  end

  def query_class
    Query.get_subclass(params[:type] || 'IssueQuery')
  end

  def showProject
 if params[:start_date] && params[:due_date].present?
    @start_date = Date.parse(params[:start_date]) 
    @due_date = Date.parse(params[:due_date])
    project_perpage=params[:project_perpage]
    project_pagenum=params[:project_pagenum]
    @gantt_data = {} 

    project = Project.visible.order(name: :asc).paginate(page: project_pagenum, per_page: project_perpage)
    allproject= Project.visible
    
    project_id =  project.pluck(:id)
        # Fetch issues as before
        if params[:set_filter].present? 
          category_ids = params[:v] ? params[:v]["category_id"] : nil
          query = IssueQuery.new(name: "_")
          # Parse the query parameters and build the IssueQuery
          query.build_from_params(params)
          # Fetch the issues that match the query
          issue_ids =  query.issues
           @Issues = Issue.where(id: issue_ids)
           if category_ids.present?
            @Issues = @Issues.where(category_id: category_ids)
          end

          if params[:v]&& params[:v]["project_id"].present?
            project = Project.where(id: params[:v]["project_id"]).order(name: :asc).paginate(page: project_pagenum, per_page: project_perpage)
          elsif  @Issues.empty?  # Check if issue data is empty
            render json: { error: "No data to display" }, status: :not_found
            return
          end
          @Issues = @Issues.where("(#{Issue.table_name}.start_date BETWEEN ? AND ?) AND (#{Issue.table_name}.due_date BETWEEN ? AND ?)",@start_date, @due_date, @start_date, @due_date).order(created_on: :desc)
          else
           @Issues =  Issue.where(project_id: project_id).where("(#{Issue.table_name}.start_date BETWEEN ? AND ?) AND (#{Issue.table_name}.due_date BETWEEN ? AND ?)",@start_date, @due_date, @start_date, @due_date)
          end

          @data=project.map{|p|
          issues_for_project = if params[:project_id].present?
            @Issues.select { |issue| issue.project_id == p.id }
          else
            @Issues.where(project_id: p.id)
          end
           { :id => p.id, :description => p.description, :text => p.name, :parent => 0,  :issues =>   issues_for_project }} +
            @Issues.map{|i|    
           subtasks_for_issue = if params[:project_id].present?
            @Issues.select { |issue| issue.parent_id == i.id }
          else
            @Issues.where(parent_id: i.id)
          end
           {:id => "i"+i.id.to_s, :color => i.color, :text=> i.subject, :fixed_version_id => i.fixed_version_id,  :gantt_start_date => i.gantt_start_date, :gantt_due_date => i.gantt_due_date,  :start_date => i.start_date, :s_date => i.start_date, :description => i.description, :end_date => i.due_date, :due_date => i.due_date, :parent => i.project_id,  :subtask =>   subtasks_for_issue,  :estimated_hours => i.estimated_hours.present? ? i.estimated_hours.round(2) : 0, :progress => i.done_ratio, :done_ratio => i.done_ratio, :parent_id => i.parent_id ,:tracker_name => i.tracker.name, :assigned_to => i.assigned_to && i.assigned_to.firstname+" "+i.assigned_to.lastname   }}
        
          # Issue relation logic 
          issue_relation_ids=@Issues.pluck(:id)
          relation_data =  IssueRelation.where(:issue_to_id => [issue_relation_ids])
          issue_relation = relation_data.map{|r| {:id => r.id, :source => "i"+r.issue_from_id.to_s, :target => "i"+r.issue_to_id.to_s, :type => r.relation_type}}
          # Issue relation logic end
          @gantt_data[:links] = issue_relation
          @gantt_data[:data]=   @data
          @gantt_data[:pagination]={ total_pages:   project.total_pages, total_entries:   project.total_entries }
          @gantt_data[:allProjects]= allproject


          if params[:f].present? || params[:v].present?
            errors = []
          params[:f].each do |field|
            # if (params[:op][field] == "~" || params[:op][field] == "=") && (!params.key?(:v) || params[:v][field].nil? || params[:v][field].all?(&:blank?))
            if (params[:op] && params[:op][field] == "~" || params[:op] && params[:op][field] == "=") && (!params.key?(:v) || params[:v] && params[:v][field].nil? || params[:v] && params[:v][field].all?(&:blank?))
              errors << "#{field.capitalize} cannot be empty"
            end
            
          end
        
          if errors.present?
            render json: { errors: errors }, status: :unprocessable_entity
            return
          end
          end

        render :json =>@gantt_data
          respond_to do |format|
            format.html
              format.api do
                @gantt_data
              end
            end
          end
    end
end
