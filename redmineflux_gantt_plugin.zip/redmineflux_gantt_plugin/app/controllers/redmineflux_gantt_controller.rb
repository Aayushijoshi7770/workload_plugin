class RedminefluxGanttController < ApplicationController
    before_action :require_login
    accept_api_auth :gantt_data, :CreateBaselines, :project_members, :update_color, :generate_light_color, :update, :create,  :update_preference, :save_filter, :get_filter, :filter_data, :issues_without_version, :search_issues_without_version, :getbaseline, :storeBaseline, :deleteBaseline, :create_baseline_data
    # for core filter
    include QueriesHelper
    helper :queries

    def index
        @project = Project.find(params[:project_id])
        @projectID=@project.id
        # for core filter 
        @query = query_class.new
        @query.user = User.current
        @query.project = @project
        @query.build_from_params(params)
        # logic to store collapse by default start
        current_user = User.current.id
        if ActiveRecord::Base.connection.table_exists?('gantt_dropdown_preferences')
          @preference = GanttDropdownPreferences.where(user_id: User.current.id, project_id:  @projectID).first_or_create(selected_option: "collapse").selected_option
        end
        # logic ends
    end

       def query_class
      Query.get_subclass(params[:type] || 'IssueQuery')
    end




    def gantt_data
    if params[:start_date] && params[:due_date].present? && params[:project_id].present? 
        @project_id= params[:project_id]
        @start_date = Date.parse(params[:start_date]) 
        @due_date = Date.parse(params[:due_date])
   
        @gantt_data = {} 
        project_releases =Version.where(project_id: @project_id, status: "open").where("DATE(effective_date) >= ?", @start_date.to_date).where("DATE(effective_date) <= ?", @due_date.to_date).order(created_on: :desc)
        version_id = project_releases.pluck(:id)
     
         # Fetch issues as before
        if params[:set_filter].present? 
        category_ids = params[:v] ? params[:v]["category_id"] : nil
        query = IssueQuery.new(name: "_")
        # Parse the query parameters and build the IssueQuery
        query.build_from_params(params)
        # Fetch the issues that match the query
        issue_ids =  query.issues
        @Issues = Issue.where(id: issue_ids, project_id: @project_id, fixed_version_id: version_id)
         if category_ids.present?
          @Issues = @Issues.where(category_id: category_ids)
        end


        @Issues = @Issues.where("(#{Issue.table_name}.start_date BETWEEN ? AND ?) AND (#{Issue.table_name}.due_date BETWEEN ? AND ?)",
                                 @start_date, @due_date, @start_date, @due_date).order(created_on: :desc).paginate(page: params[:page], per_page: params[:per_page])
         @allIssues=@Issues.where("(#{Issue.table_name}.start_date BETWEEN ? AND ?) AND (#{Issue.table_name}.due_date BETWEEN ? AND ?)",
         @start_date, @due_date, @start_date, @due_date).order(created_on: :desc)
          if @Issues.empty?  # Check if issue data is empty
          render json: { error: "No data to display" }, status: :not_found
          return
        end
        
       else
        @Issues=Issue.where(:project_id =>  @project_id, :fixed_version_id => version_id).where("(#{Issue.table_name}.start_date BETWEEN ? AND ?) AND (#{Issue.table_name}.due_date BETWEEN ? AND ?)", @start_date,@due_date,@start_date,@due_date).order(created_on: :desc).paginate(:page => params[:page], :per_page => params[:per_page])
        @allIssues=Issue.where(:project_id =>  @project_id, :fixed_version_id => version_id).where("(#{Issue.table_name}.start_date BETWEEN ? AND ?) AND (#{Issue.table_name}.due_date BETWEEN ? AND ?)", @start_date,@due_date,@start_date,@due_date).order(created_on: :desc)
      end
      # baselin id present 
     if  params[:baseline_id].present? 

            @data= project_releases.map{|p|
              issues_for_version = if params[:project_id].present?
              @Issues.select { |issue| issue.fixed_version_id == p.id }
            else
              @Issues.where(fixed_version_id: p.id)
            end
            { :id => p.id, :effective_date => p.effective_date, :description => p.description, :text => p.name, :parent => 0,  :issues =>    issues_for_version }} +
              @Issues.map{|i|
            subtasks_for_issue = if params[:project_id].present?
              @Issues.select { |issue| issue.parent_id == i.id }
            else
              @Issues.where(parent_id: i.id)
            end
            baseline_issues = BaselineData.where(baseline_id: params[:baseline_id], project_id: @project_id, issue_id: i.id)
            puts "baseline_issues#{baseline_issues.to_json}#{i.id}"
        # Find the baseline_issue for the current issue `i`
         baseline_issue = baseline_issues.find { |issue| issue['issue_id'] == i.id }

              {:id => "i"+i.id.to_s,  :baseline_id => baseline_issue ? baseline_issue.baseline_id : nil,      :baseline_start_date =>  baseline_issue ? baseline_issue.baseline_start_date : nil,
              :baseline_due_date=>  baseline_issue ? baseline_issue.baseline_due_date : nil,  :color => i.color, :text=> i.subject, :fixed_version_id => i.fixed_version_id,  :gantt_start_date => i.gantt_start_date, :gantt_due_date => i.gantt_due_date,  :start_date => i.start_date, :s_date => i.start_date, :description => i.description, :end_date => i.due_date, :due_date => i.due_date, :parent => i.fixed_version_id,  :subtask =>   subtasks_for_issue,  :estimated_hours => i.estimated_hours.present? ? i.estimated_hours.round(2) : 0, :progress => i.done_ratio, :done_ratio => i.done_ratio, :parent_id => i.parent_id ,:tracker_name => i.tracker.name, :assigned_to => i.assigned_to && i.assigned_to.firstname+" "+i.assigned_to.lastname   }}
        else
            @data= project_releases.map{|p|
            issues_for_version = if params[:project_id].present?
            @Issues.select { |issue| issue.fixed_version_id == p.id }
          else
            @Issues.where(fixed_version_id: p.id)
          end
          { :id => p.id, :effective_date => p.effective_date, :description => p.description, :text => p.name, :parent => 0,  :issues =>    issues_for_version }} +
            @Issues.map{|i|
          subtasks_for_issue = if params[:project_id].present?
            @Issues.select { |issue| issue.parent_id == i.id }
          else
            @Issues.where(parent_id: i.id)
          end
            {:id => "i"+i.id.to_s,   :color => i.color, :text=> i.subject, :fixed_version_id => i.fixed_version_id,  :gantt_start_date => i.gantt_start_date, :gantt_due_date => i.gantt_due_date,  :start_date => i.start_date, :s_date => i.start_date, :description => i.description, :end_date => i.due_date, :due_date => i.due_date, :parent => i.fixed_version_id,  :subtask =>   subtasks_for_issue,  :estimated_hours => i.estimated_hours.present? ? i.estimated_hours.round(2) : 0, :progress => i.done_ratio, :done_ratio => i.done_ratio, :parent_id => i.parent_id ,:tracker_name => i.tracker.name, :assigned_to => i.assigned_to && i.assigned_to.firstname+" "+i.assigned_to.lastname   }}
    end 
    # baseline id not presetn
      # Issue relation logic 
      issue_relation_ids= @Issues.pluck(:id)
      relation_data =  IssueRelation.where(:issue_to_id => [issue_relation_ids])
      issue_relation = relation_data.map{|r| {:id => r.id, :source => "i"+r.issue_from_id.to_s, :target => "i"+r.issue_to_id.to_s, :type => r.relation_type}}
      # Issue relation logic end
      @gantt_data[:links] = issue_relation
      @gantt_data[:data]=   @data
      @gantt_data[:pagination]={ total_pages:  @Issues.total_pages,total_entries:  @Issues.total_entries }
      @gantt_data[:allIssues]= @allIssues
      
      
      if params[:f].present? || params[:v].present?
        errors = []
       params[:f].each do |field|
        #  if (params[:op][field] == "~" || params[:op][field] == "=") && (!params.key?(:v) || params[:v][field].nil? || params[:v][field].all?(&:blank?))
        if (params[:op] && params[:op][field] == "~" || params[:op] && params[:op][field] == "=") && (!params.key?(:v) || params[:v] && params[:v][field].nil? || params[:v] && params[:v][field].all?(&:blank?))
           errors << "#{field.capitalize} cannot be empty"
         end
        
       end
    
       if errors.present?
         render json: { errors: errors }, status: :unprocessable_entity
         return
       end
      end
      
      render :json =>@gantt_data
      respond_to do |format|
        format.html
          format.api do
            @gantt_data
          end
        end
        
       end
    end

    def project_members
        if params[:project_name].present?
         @project_name = params[:project_name]
         project = Project.find_by(identifier: @project_name)
         active_users = project.principals.map{|m| { :id => m.id,  :name => m.name }}
         render :json =>  active_users
        end     
    end
     
    # API for update color in issues table
     def update_color 
        @issue_id=params[:issue_id]
        @color=params[:color]
        if params[:issue_id] && params[:color].present?
        issue=Issue.find(@issue_id).update_column(:color, @color)
        render :json =>  issue
        end
    end
   
    def update
        data = JSON.parse(request.body.read)
        issue_id = data['issue_params']['issue_id']
        issue = Issue.find(issue_id)
  
        if issue
          issue_params = data['issue_params']
          
          # Construct the update attributes hash based on the provided parameters
          update_attributes = {}
          update_attributes[:gantt_start_date] = issue_params['gantt_start_date'] if issue_params['gantt_start_date'].present?
          update_attributes[:gantt_due_date] = issue_params['gantt_due_date'] if issue_params['gantt_due_date'].present?
          update_attributes[:fixed_version_id] = issue_params['fixed_version_id'] if issue_params['fixed_version_id'].present?
          update_attributes[:project_id] = issue_params['project_id'] if issue_params['project_id'].present?
          update_attributes[:start_date] = issue_params['start_date'] if issue_params['start_date'].present?
          update_attributes[:due_date] = issue_params['due_date'] if issue_params['due_date'].present?
          update_attributes[:baseline_id]=issue_params['baseline_id'] if issue_params['baseline_id'].present?
          
          issue.update(update_attributes)
          render json: { message: 'Issue updated successfully' }
        else
            render json: { error: 'Issue ID is required or invalid' }, status: :unprocessable_entity
        end
      end
     
      def create
        data = JSON.parse(request.body.read)
        issue_params = data['issue_params']
  
        # Construct the parameters for creating the new issue
        create_attributes = {}
        create_attributes[:subject] = issue_params['subject'] if issue_params['subject'].present?
        create_attributes[:gantt_start_date] = issue_params['gantt_start_date'] if issue_params['gantt_start_date'].present?
        create_attributes[:gantt_due_date] = issue_params['gantt_due_date'] if issue_params['gantt_due_date'].present?
        create_attributes[:fixed_version_id] = issue_params['fixed_version_id'] if issue_params['fixed_version_id'].present?
        create_attributes[:start_date] = issue_params['start_date'] if issue_params['start_date'].present?
        create_attributes[:due_date] = issue_params['due_date'] if issue_params['due_date'].present?
        create_attributes[:tracker_id] = issue_params['tracker_id'] if issue_params['tracker_id'].present?
        create_attributes[:author_id] = issue_params['author_id'] if issue_params['author_id'].present?
        create_attributes[:parent_id] = issue_params['parent_id'] if issue_params['parent_id'].present?
        if issue_params['project_id'].present?
           project_id=Project.find_by(identifier: issue_params['project_id']).id
           create_attributes[:project_id]=project_id
        end
        issue = Issue.new(create_attributes)
        #   render json:  project_id
        if issue.save
          render json: { message: 'Issue created successfully', issue_id: issue.id }
        else
          render json: { errors: issue.errors.full_messages }, status: :unprocessable_entity
        end
      end
      
    
     
      # API to save assignee, progress data in database
      def save_filter
        user_id = User.current.id
      
        if params[:project_id].present?
            project_id=params[:project_id]
            task_option = TaskOption.find_or_initialize_by(user_id: user_id, project_id: project_id)
            task_option.project_id=params[:project_id]
            # Update attributes based on params
            if params[:progress].present?
              task_option.progress = params[:progress]
            end
            if params[:assignee].present?
            task_option.assignee = params[:assignee]
            end 
            if params[:estimated_hour]
              task_option.estimated_hour = params[:estimated_hour]
            end
            if params[:task]
              task_option.task = params[:task]
            end
            # Save the record
            task_option.save

        # Check if project identifier is different
      if task_option.persisted? && task_option.project_id != params[:project_id]
        new_task_option = TaskOption.new(user_id: user_id, project_id: params[:project_id])
      # Copy attributes from the original task_option
        new_task_option.attributes = task_option.attributes.slice('progress', 'assignee', 'estimated_hour', 'task')
      # Save the new record
        new_task_option.save
        end
  
    else 
 
      task_option= TaskOption.find_or_initialize_by(user_id: user_id, project_id: project_id)
            # Update attributes based on params
        task_option.progress = params[:progress] if params[:progress].present?
        task_option.assignee = params[:assignee] if params[:assignee].present?
        task_option.estimated_hour = params[:estimated_hour] if params[:estimated_hour].present?
        task_option.task = params[:task] if params[:task].present?

        # Save the record
        task_option.save

    end 
    render json: { success: true }
      end
           
      # API to get stored columns data
      def get_filter
        if params[:project_id].present?
          project=params[:project_id]
        filterdata=TaskOption.where(user_id: User.current.id, project_id:project)
        render json: { success: true , data: filterdata}
      
      else
        filterdata=TaskOption.where(user_id: User.current.id)
        render json: { success: true , data: filterdata} 
      end
      end
 
      def update_preference
        selected_option = params[:selected_option]
        project_id=params[:project_id]
        current_user = User.current
        if project_id.present?
        
          preference = GanttDropdownPreferences.find_or_initialize_by(user_id: current_user.id, project_id:  project_id)
        else
          preference = GanttDropdownPreferences.find_or_initialize_by(user_id: current_user.id, project_id: nil)
        end 
        preference.selected_option = selected_option
        preference.save
        render json: { success: true , selected_option: preference }
      end


      def issues_without_version
        issue_details =[]
        if params[:project_id].present?
            closed_status_id = IssueStatus.where(is_closed: true).pluck(:id)
            @project_id=params[:project_id]
            @issues= Issue.where(:project_id => @project_id).where.not(status_id: closed_status_id).order(created_on: :desc).where(:fixed_version_id => nil).limit(25)
    
          issue_details = @issues.map{|issue| {:id=> issue.id, :done_ratio => issue.done_ratio, :estimated_hours=> issue.estimated_hours.present? ? issue.estimated_hours.round(2) : 0, :project_name => issue.project.name, :text => issue.subject, 
          :project_id => issue.project_id, :due_date => issue.due_date, :end_date => issue.due_date, :s_date => issue.start_date, :row_height => 50, :bar_height => 40,
          :type => "issue",   :description=>issue.description, :tracker => issue.tracker, :assigned_to_id => issue.assigned_to}}
         
      
       render :json => issue_details  
       respond_to do |format|
         format.api do 
           issue_details 
         end 
       end 
      end
      
     end
     
     def search_issues_without_version
      @value = params[:issue]
      searched_issues = []
    
      if @value.present?
        @str = @value.to_s.downcase
        @user_id = User.current.id
        closed_status_id = IssueStatus.where(is_closed: true).pluck(:id)
        @project_id = params[:project_id]
    
        if @str.match?(/^\d+$/) # If the input is only digits
          issues = Issue.where(project_id: @project_id, fixed_version_id: nil, id: @str.to_i)
                       .where.not(status_id: closed_status_id)
        else
          issues_by_subject = Issue.where(project_id: @project_id)
                                   .where.not(status_id: closed_status_id)
                                   .where(fixed_version_id: nil)
                                   .where("LOWER(subject) LIKE ?", "%#{@str}%")

    
          issues = issues_by_subject 
        end
    
        searched_issues = issues.map do |issue|
          {
            id: issue.id,
            done_ratio: issue.done_ratio,
            estimated_hours: issue.estimated_hours.present? ? issue.estimated_hours.round(2) : 0,
            project_name: issue.project.name,
            text: issue.subject,
            project_id: issue.project_id,
            due_date: issue.due_date,
            end_date: issue.due_date,
            s_date: issue.start_date,
            type: "issue",
            description: issue.description,
            tracker: issue.tracker,
            assigned_to_id: issue.assigned_to
          }
        end
    
        respond_to do |format|
          format.json { render json: searched_issues }
          format.api { searched_issues }
        end
      end
    end

    def CreateBaselines
        errors = {}
        
        # Check for presence of 'name'
        if params[:name].blank?
           errors[:name] = "Name cannot be blank"
        elsif params[:name].length > 52
          errors[:name] = "Name cannot exceed 52 characters"
      end
        
        # Check for presence of 'project_id'
        if params[:project_id].blank?
          errors[:project_id] = "Project ID is required"
        end
        
        # If there are errors, return a 422 response with the errors
        if errors.any?
          respond_to do |format|
            format.json { render json: { errors: errors }, status: :unprocessable_entity }
            format.api { render json: { errors: errors }, status: :unprocessable_entity }
          end
          return
        end

         # Set all other baselines for the same project to selected: false
         Baseline.where(project_id: params[:project_id]).update_all(selected: false)
        # Create a new baseline with the provided parameters
        @baseline = Baseline.new(name: params[:name], project_id: params[:project_id], selected: true)
      
        if @baseline.save
          respond_to do |format|
            format.json { render json: @baseline }
            format.api { render json: @baseline }
          end
        else
          respond_to do |format|
            format.json { render json: @baseline.errors, status: :unprocessable_entity }
            format.api { render json: @baseline.errors, status: :unprocessable_entity }
          end
        end
    end

    def getbaseline
      @baseline =Baseline.where(project_id: params[:project_id]).order(created_at: :desc)
      if @baseline.present?
        respond_to do |format|
          format.json { render json: @baseline }
          format.api { render json: @baseline }
        end
      else
        render json: []
      end
    end
    def storeBaseline
      # Expecting project_id and baseline_id to be passed in the parameters
      project_id = params[:project_id]
      baseline_id = params[:baseline_id]
    
      # Check if both project_id and baseline_id are present
      if project_id.present? && baseline_id.present?
        # Find the baseline by project_id and baseline_id
        baseline = Baseline.find_by(project_id: project_id, id: baseline_id)
    
        if baseline
            # Ensure no other baselines are marked as selected for the same project
             Baseline.where(project_id: project_id).update_all(selected: false)
          # Update the selected attribute to true
          if baseline.update(selected: true)
            # Return a success response if the update was successful
            respond_to do |format|
              format.json { render json: { status: 'success', message: 'Baseline updated successfully' } }
              format.api { render json: { status: 'success', message: 'Baseline updated successfully' } }
            end
          else
            # Return an error response if the update failed
            respond_to do |format|
              format.json { render json: { status: 'error', message: 'Failed to update baseline' }, status: :unprocessable_entity }
              format.api { render json: { status: 'error', message: 'Failed to update baseline' }, status: :unprocessable_entity }
            end
          end
        else
          # Return an error response if the baseline was not found
          respond_to do |format|
            format.json { render json: { status: 'error', message: 'Baseline not found' }, status: :not_found }
            format.api { render json: { status: 'error', message: 'Baseline not found' }, status: :not_found }
          end
        end
      else
        # Return an error response if either project_id or baseline_id is missing
        respond_to do |format|
          format.json { render json: { status: 'error', message: 'Project ID or Baseline ID is missing' }, status: :bad_request }
          format.api { render json: { status: 'error', message: 'Project ID or Baseline ID is missing' }, status: :bad_request }
        end
      end
    end

    def deleteBaseline
      project_id = params[:project_id]
      baseline_id = params[:baseline_id]
    
      # Check if both project_id and baseline_id are present
      if project_id.present? && baseline_id.present?
        # Find the baseline by project_id and baseline_id
        baseline = Baseline.find_by(project_id: project_id, id: baseline_id)
    
        if baseline
          # Start a transaction to ensure both deletions succeed or fail together
          ActiveRecord::Base.transaction do
            # Delete the baseline record
            baseline.destroy!
    
             # Delete related records from the baseline_data table
           BaselineData.where(baseline_id: baseline_id).destroy_all

            selected_baseline = Baseline.where(project_id: project_id, selected: true).first
            # If no baseline is selected, find the most recently created baseline and set it as selected
            if selected_baseline.nil?
              most_recent_baseline = Baseline.where(project_id: project_id).order(created_at: :desc).first
              most_recent_baseline.update(selected: true) if most_recent_baseline
            end
            # Return a success response if both deletions were successful
            respond_to do |format|
              format.json { render json: { status: 'success', message: 'Baseline and related issues deleted successfully' } }
              format.api { render json: { status: 'success', message: 'Baseline and related issues deleted successfully' } }
            end
          end
        else
          # Return an error response if the baseline was not found
          respond_to do |format|
            format.json { render json: { status: 'error', message: 'Baseline not found' }, status: :not_found }
            format.api { render json: { status: 'error', message: 'Baseline not found' }, status: :not_found }
          end
        end
      else
        # Return an error response if either project_id or baseline_id is missing
        respond_to do |format|
          format.json { render json: { status: 'error', message: 'Project ID or Baseline ID is missing' }, status: :bad_request }
          format.api { render json: { status: 'error', message: 'Project ID or Baseline ID is missing' }, status: :bad_request }
        end
      end
    rescue ActiveRecord::RecordInvalid => e
      # Handle transaction rollback and return error response
      respond_to do |format|
        format.json { render json: { status: 'error', message: 'Failed to delete baseline and related issues' }, status: :unprocessable_entity }
        format.api { render json: { status: 'error', message: 'Failed to delete baseline and related issues' }, status: :unprocessable_entity }
      end
    end
    


    def create_baseline_data
      errors = []
    
      # Expecting multiple issues data in params[:issues], which should be an array of hashes
      issues_data = params[:issues]
    
      issues_data.each do |issue|
        # Validate each issue data before saving
        baseline_data = BaselineData.new(
          issue_id: issue[:issue_id],
          baseline_id: issue[:baseline_id],
          project_id: issue[:project_id],
          baseline_start_date: issue[:baseline_start_date],
          baseline_due_date: issue[:baseline_due_date]
        )
    
        # Save the baseline data and handle any validation errors
        if baseline_data.invalid?
          errors << {
            issue_id: issue[:issue_id],
            errors: baseline_data.errors.full_messages
          }
        else
          baseline_data.save
        end
      end
    
      # If there are any errors, return them
      if errors.any?
        respond_to do |format|
          format.json { render json: { errors: errors }, status: :unprocessable_entity }
          format.api { render json: { errors: errors }, status: :unprocessable_entity }
        end
      else
        respond_to do |format|
          format.json { render json: { message: "Data saved successfully" }, status: :ok }
          format.api { render json: { message: "Data saved successfully" }, status: :ok }
        end
      end
    end
    

end
