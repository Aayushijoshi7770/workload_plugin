class HelpdeskSupportLevelsController < ApplicationController

  before_action :find_project


  def index


  end

  def save_support_levels


    support_params = params[:HelpdeskSupportLevel] || {}

    # Get the selected user IDs from the params or set them to empty arrays if not present
    l1_support_users = support_params[:l1_support_users] || []
    l2_support_users = support_params[:l2_support_users] || []
    l3_support_users = support_params[:l3_support_users] || []

    # Check for duplicate users across the levels
    duplicate_users = (l1_support_users & l2_support_users) | (l1_support_users & l3_support_users) | (l2_support_users & l3_support_users)

    if duplicate_users.any?
      # Show error message if any user is selected in multiple levels
      flash[:error] = "Error: The same user cannot be selected for multiple support levels. Please ensure each level has unique users."
      redirect_to settings_project_path(@project, tab: 'support_levels')
      return
    end

    # Find or create the record for the current project
    support_level = HelpdeskSupportLevel.find_or_initialize_by(project_id: @project.id)

    # Save the values in the corresponding fields
    support_level.l1_user_ids = l1_support_users
    support_level.l2_user_ids = l2_support_users
    support_level.l3_user_ids = l3_support_users
    support_level.user_id = User.current.id # Save the current logged-in user

    if support_level.save
      flash[:notice] = l(:notice_successful_update_helpdesk)
    else
      flash[:error] = l(:notice_failed_update_helpdesk)
    end


    redirect_to settings_project_path(@project, tab: 'support_levels')
 
  end
  

  private

  def find_project
    @project = Project.find(params[:project_id])
  end

end
