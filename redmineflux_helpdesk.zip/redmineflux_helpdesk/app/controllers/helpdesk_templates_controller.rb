class HelpdeskTemplatesController < ApplicationController
  before_action :find_project
  before_action :find_helpdesk_template, only: [:save_helpdesk_templates]

  

  def save_helpdesk_templates
    if @template.update(template_params)
      flash[:notice] = l(:notice_successful_update)
      redirect_to settings_project_path(@project, tab: 'helpdesk_template') 
    else
      flash.now[:error] = @template.errors.full_messages.join("<br/>")
      render :helpdesk_templates
    end
  end

  private

  def template_params
    params.require(:helpdesk_template).permit(:answer_subject, :answer_header, :answer_footer, :send_auto_answer, :email_auto_answer_template_name,:autoclose_subject, :autoclose_body)
  end

  def find_helpdesk_template
    puts "Projectss_id :: #{@project}"
    @template = @project.helpdesk_templates.first || @project.helpdesk_templates.build
  end

  def find_project
    @project = Project.find(params[:project_id])
  end
end
 