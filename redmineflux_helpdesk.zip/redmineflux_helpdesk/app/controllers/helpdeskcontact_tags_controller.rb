class HelpdeskcontactTagsController < ApplicationController
  before_action :set_contact, only: [:edit, :update, :destroy]
  accept_api_auth :update_contact_tags

  # Create action
  def create
    @contact = Contact.new(contact_params)
    if @contact.save
      save_tags(@contact, contact_params[:tags]) # Save tags after creating the contact
      redirect_to helpdeskcontact_tags_path, notice: 'Contact tag created successfully.'
    else
      render :new
    end
  end

  # Edit action
  def edit
    @contact = Contact.find(params[:id])
    @contact_tags = @contact.migrate_tags # Fetch tags associated with the contact
  end

  # Update action
  def update
    puts "Tags being updated..."
    
    if @contact.update(contact_params)
      if contact_params[:tags].present?
        puts "Tags being updated: #{contact_params[:tags]}"
        @contact.migrate_tags.clear # Clear existing tags if new tags are provided
        save_tags(@contact, contact_params[:tags]) # Save new tags after updating the contact
      end
  
      flash[:notice] = 'Contact tag updated successfully.'
      
      respond_to do |format|
        format.html do
          redirect_to plugin_settings_path(:redmineflux_helpdesk, tab: 'contact_tags')
        end
        format.xml { render xml: @contact } # Assuming you want to return the updated contact in XML format
      end
    else
      flash[:alert] = 'Error updating contact.' # Add an error message for feedback
      respond_to do |format|
        format.html { render :edit }
        format.xml { render xml: @contact.errors, status: :unprocessable_entity }
      end
    end
  end

  def update_contacttag
    @contact = Contact.find(params[:id]) # Find the contact by ID
    puts "Contact gets #{@contact}" # Debugging to ensure contact is found correctly
  
    if params[:tag_list].present?
      tags = params[:tag_list].split(",").map(&:strip) # Split tag_list into an array of tags
  
      if update_contact_tags(@contact, tags) # Use @contact and tags for updating
        render json: @contact
      else
        render json: { error: "Failed to add tags" }, status: :unprocessable_entity
      end
    else
      render json: { error: "No tags provided" }, status: :unprocessable_entity
    end
  rescue ActiveRecord::RecordNotFound
    render json: { error: "Contact not found" }, status: :not_found
  rescue StandardError => e
    render json: { error: "Failed to add tags due to an error: #{e.message}" }, status: :unprocessable_entity
  end
  
  
  # Delete action
  def destroy
    @contact.destroy
    redirect_to helpdeskcontact_tags_path, notice: 'Contact tag deleted successfully.'
  end

  private

  def set_contact
    @contact = Contact.find(params[:id]) # Find contact by ID
  end

  # Adjust contact_params method
  def contact_params
    params.require(:contact).permit(:other, :attributes, :here).tap do |whitelisted|
      # Convert tags to an array
      tags = params.dig(:contact, :tags)
      whitelisted[:tags] = Array(tags) if tags.present?
    end
  end

  def update_contact_tags(contact, tags)
    contact.migrate_tags.clear # Clear existing tags
    save_tags(contact, tags) # Save new tags
  end

  def save_tags(contact, tags)
    tags.each do |tag_name|
      tag = MigrateTag.find_or_create_by(name: tag_name.strip) # Use MigrateTag instead of Tag
      unless contact.migrate_tags.include?(tag)
        contact.migrate_tags << tag
      end
    end
  end

 
end
