class ContactsController < ApplicationController
  before_action :find_project
  helper :attachments
  include AttachmentsHelper
  include QueriesHelper
  helper :queries
  include RedminefluxHelpdesk::CountryHelper
 

  def context_menu
    if params[:project_id].present?
      @project = Project.find(params[:project_id])
  
      if params[:contact_ids].present?
        ids = []
        ids.concat(params[:contact_ids]) 
        ids << params[:contact_id] if params[:contact_id].present?  
        @contacts = @project.contacts.where(id: ids)
      elsif params[:contact_id].present?
        @contacts = @project.contacts.where(id: params[:contact_id])
      else
        @contacts = []  
      end
      
    else
      if params[:contact_ids].present?
        ids = []
        ids.concat(params[:contact_ids]) 
        ids << params[:contact_id] if params[:contact_id].present? 
        @contacts = Contact.where(id: ids)
      elsif params[:contact_id].present?
        @contacts = Contact.where(id: params[:contact_id])
      else
        @contacts = []  
      end
    end
    
    respond_to do |format|
      format.html { render partial: 'context_menu' }
      format.js
    end
  end
  
  
  
  def send_email_from

    if params[:contact_ids].present?
      contact_ids = Array(params[:contact_ids]).map(&:to_i)
    elsif params[:contact_id].present?
      contact_ids = [params[:contact_id].to_i] 
    else
      contact_ids = [] 
    end
    
    @contacts = Contact.where(id: contact_ids)
  end
  
  def send_email
    @project = Project.find(params[:project_id])
    
    contact_ids = if params[:contact_ids].present?
                    params[:contact_ids].map(&:to_i)
                  elsif params[:contact_id].present?
                    [params[:contact_id].to_i]
                  else
                    []
                  end
  
    email_sent_count = 0
  
    contact_ids.each do |contact_id|
      begin
        @contact = Contact.find(contact_id)
  
        email_send = ContactEmailSend.new(
          from: params[:from],
          cc: params[:cc],
          bcc: params[:bcc],
          subject: params[:subject],
          message_content: params[:message_content],
          project_id: @project.id,
          updated_by: User.current.id,
          contact_id: @contact.id
        )
  
        if email_send.save
          ContactMailer.send_email(email_send, @contact)
          email_sent_count += 1
        end
  
      rescue ActiveRecord::RecordNotFound
        puts "Contact not found for ID: #{contact_id}"
      end
    end
  
    if email_sent_count > 0
      flash[:notice] = "#{email_sent_count} Email(s) sent successfully."
    else
      flash[:error] = "Failed to send any emails."
    end
  
    redirect_to project_contacts_path(@project)  
  end
  
  
  def index
    @project = Project.find(params[:project_id]) if params[:project_id].present?
    @list_style = params[:contacts_list_style] || 'list_excerpt'
    @contact_queries = @project.present? ? ContactQuery.where(project_id: @project.id) : ContactQuery.all
    
    if params[:query_id].present?
      @query = ContactQuery.find(params[:query_id]) 
    else
      @query = ContactQuery.new(name: 'My Query')
      @query.user = User.current
      @query.project = @project if @project.present?
      @query.build_from_params(params)
    end
  
    if @query.valid?
      @contacts = @project.present? ? @project.contacts : Contact.all
      
      @contacts = @query.apply_filters(@contacts)
      
      @contacts = @contacts.order(created_at: :desc)
      @contact_count = @contacts.count
      
      per_page = params['per_page'].present? ? params['per_page'].to_i : 25
      @contact_pages = Paginator.new(@contact_count, per_page, params['page']) 
      
      @contacts = @contacts.offset(@contact_pages.offset).limit(@contact_pages.per_page)
      
      @valid_query = true
    else
      @contacts = []
      @valid_query = false
    end
  end

  def show
    if @project.present?
      @contact = @project.contacts.find(params[:id])
    else
      @contact = Contact.find(params[:id])
    end
  
    @current_tab = params[:tab] || 'notes'
    @issue_helpdesk_contacts = IssueHelpdeskContact.where(contact_id: @contact.id).includes(:issue)
  end

  def edit
    @countries = country_values

    if params[:project_id].present?
      @project = Project.find(params[:project_id])
      @contact = @project.contacts.find(params[:id])
    else
      @contact = Contact.find(params[:id])
    end
  end

  # def update
  #   @project = Project.find(params[:project_id])
  #   @contact = @project.contacts.find(params[:id])
  
  #   if @contact.update(contact_params)
  #     save_attachments(@contact)
  #     redirect_to project_contact_path(@project, @contact), notice: 'Contact was successfully updated.'
  #   else
  #     flash[:error] = @contact.errors.full_messages.join("<br>").html_safe
  #     render :edit
  #   end
  # end

  def update
    if params[:project_id].present?
      @project = Project.find(params[:project_id])
      @contact = @project.contacts.find(params[:id])
    else
      @contact = Contact.find_by(id: params[:id])
    end
    
    if @contact.update(contact_params)
       if Redmine::Plugin.registered_plugins[:flux_tags] 
      update_save_tags(@contact, params[:tags]) # Save the tags after updating the contact
    end
      save_attachments(@contact)
      
      if @project
        redirect_to project_contact_path(@project, @contact), notice: 'Contact was successfully updated.'
      else
        redirect_to contact_path(@contact), notice: 'Contact was successfully updated.'
      end
    else
      flash[:error] = @contact.errors.full_messages.join("<br>").html_safe
      render :edit
    end
  end


  def bulk_edit
    @contacts = Contact.where(id: params[:contact_ids])
    @countries = country_values
    @project_all = Project.all
  end
  
  def bulk_update
    bulk_contact_params = params.require(:contact).permit(
      :first_name, :middle_name, :last_name, :company, :birthday, :job_title,
      :street1, :street2, :city, :state, :zip, :country, :phone_no, :email,
      :company_details, :company_name, :industry, :website, :skype, :project_id,
      :background, :tags, :responsible, :visibility
    )
  
    @contacts = Contact.where(id: params[:contact_ids])
  
    Contact.transaction do
      @contacts.each do |contact|
     
        project_id = bulk_contact_params[:project_id].present? ? bulk_contact_params[:project_id] : contact.project_id 
  
        updated_params = bulk_contact_params.merge(project_id: project_id)
  
        unless contact.update(updated_params)
          flash[:error] = contact.errors.full_messages.join("<br>").html_safe
          render :bulk_edit and return
        end
  
        save_attachments(contact) if params[:attachments]
      end
    end
  
    redirect_to contacts_path, notice: "#{@contacts.size} contacts were successfully updated."
  end
  
  
  

  def new
    @countries = country_values
    @contact = @project.contacts.new
  end

  def create
    @contact = @project.contacts.new(contact_params)
  
    if @contact.save
      if Redmine::Plugin.registered_plugins[:flux_tags] 
      puts "#{@contact.tags}, testing" # Ensure tags are being logged correctly
      save_tags(@contact, @contact.tags) # Save the tags after creating the contact
      end
      save_attachments(@contact)
      redirect_to project_contacts_path(@project), notice: 'Contact was successfully created.'
    else
      flash[:error] = @contact.errors.full_messages.join("<br>").html_safe
      render :new
    end
  end

  def destroy
    if params[:contact_ids].present?
      Contact.where(id: params[:contact_ids]).destroy_all
      flash[:notice] = 'Selected contacts were successfully deleted.'
    else
      @contact = @project.contacts.find(params[:id])
      @contact.destroy
      flash[:notice] = 'Contact was successfully deleted.'
    end

    redirect_to project_contacts_path(@project)
  end

  def destroy_multiple
    if params[:contact_ids].present?
      Contact.where(id: params[:contact_ids]).destroy_all
      flash[:notice] = 'Selected contacts were successfully deleted.'
    else
      flash[:error] = 'No contacts selected for deletion.'
    end
  
    redirect_to project_contacts_path(@project)
  end


  
  
  # def update
  #   @contact = @project.contacts.find(params[:id]) # Find the contact by ID
  
  #   if @contact.update(contact_params) # Update the contact with the provided parameters
  #     puts "#{@contact.tags}, testing" # Ensure tags are being logged correctly
  #     update_save_tags(@contact, @contact.tags) # Save the tags after updating the contact
   
  #     redirect_to project_contacts_path(@project), notice: 'Contact was successfully updated.'
  #   else
  #     flash[:error] = @contact.errors.full_messages.join("<br>").html_safe
  #     render :edit
  #   end
  # end
  # def save_tags(contact, tags)
  #   return unless tags.present?
  
  #   tag_names = tags.split(",").map(&:strip).uniq
  
  #   tag_names.each do |name|
  #     # Use MigrateTag instead of Tag
  #     tag = MigrateTag.find_or_create_by(name: name)
  
  #     # Check if this contact already has the tag to avoid duplicates
  #     unless contact.migrate_tags.exists?(name: name)
  #       contact.migrate_tags << tag # Use the correct association
  #     end
  #   end
  # end
  

private
if Redmine::Plugin.registered_plugins[:flux_tags] 
  def save_tags(contact, tags)
    # Split the tags string by commas, and remove any extra spaces
    puts "Tags param: #{params[:contact][:tags].inspect}"
    tags_array = params[:contact][:tags].split(',').map(&:strip)
  
    # Clear the old tags for the contact
    MigrateTagging.where(taggable_type: 'Contact', taggable_id: contact.id).destroy_all
  
    # Iterate over the array to create or assign tags
    tags_array.each do |tag_name|
      tag = MigrateTag.find_or_create_by(name: tag_name) # Assuming 'MigrateTag' is your tag model
      MigrateTagging.create(
        taggable_type: 'Contact',  # Ensure this matches the correct model name
        taggable_id: contact.id,   # The ID of the contact being tagged
        tag_id: tag.id,            # Associate the correct tag ID
        context: 'tags'            # Based on your requirements
      )
    end
  end
end

if Redmine::Plugin.registered_plugins[:flux_tags] 
  def update_save_tags(contact, tags)
    # Check if tags are present in the params, and handle if nil
    if params[:tags].present?
      # Split the tags string by commas, and remove any extra spaces
      puts "Tags param: #{params[:tags].inspect}"
      tags_array = params[:tags].split(',').map(&:strip)
    
      # Clear the old tags for the contact
      MigrateTagging.where(taggable_type: 'Contact', taggable_id: contact.id).destroy_all
  
      # Iterate over the array to create or assign tags
      tags_array.each do |tag_name|
        tag = MigrateTag.find_or_create_by(name: tag_name) # Assuming 'MigrateTag' is your tag model
        MigrateTagging.create(
          taggable_type: 'Contact',  # Ensure this matches the correct model name
          taggable_id: contact.id,   # The ID of the contact being tagged
          tag_id: tag.id,            # Associate the correct tag ID
          context: 'tags'            # Based on your requirements
        )
      end
    else
      puts "No tags provided for this contact."
    end
  end
end
  

  # def update_save_tags(contact)

  #     # Access tags directly from params
  #     tags_string = params[:contact][:tags] # Access params correctly
  #     return if tags_string.nil? # Return early if tags_string is nil
      
  #     # Split the tags string by commas, and remove any extra spaces
  #     tags_array = tags_string.split(',').map(&:strip)
    
  #     # Iterate over the array to create or assign tags
  #     tags_array.each do |tag_name|
  #       tag = MigrateTag.find_or_create_by(name: tag_name) # Assuming 'MigrateTag' is your tag model
  #       MigrateTagging.create(
  #         taggable_type: 'Contact',  # Ensure this matches the correct model name
  #         taggable_id: contact.id,   # The ID of the contact being tagged
  #         tag_id: tag.id,            # Associate the correct tag ID
  #         context: 'tags'            # Based on your screenshot
  #       )
  #     end
  #   end
    
  

  
  

  def find_project
    if params[:project_id].present?
      @project = Project.find(params[:project_id])
    else
      @project = nil 
    end
  end

  def bulk_contact_params(contact_id)
    params.require(:contact).permit(
      :first_name, :middle_name, :last_name, :company, :birthday, :job_title,
      :street1, :street2, :city, :state, :zip, :country, :phone_no, :email, :project_id,
      :company_details, :company_name, :industry, :website, :skype, 
      :background, :tags, :responsible, :visibility
    ).transform_keys { |key| "#{key}_#{contact_id}" }
  end

  def contact_params
    params.require(:contact).permit(:first_name, :middle_name, :last_name, :company, :birthday, :job_title,
                                    :street1, :street2, :city, :state, :zip, :country, :phone_no, :email, :company_details ,:company_name,:industry,
                                    :website, :skype, :background,
                                    :responsible, :visibility)
  end

  def save_attachments(contact)
    if params[:attachments]
      contact.attachments = Attachment.attach_files(contact, params[:attachments])[:files]
    end
  end

  def query_class
    Query.get_subclass(params[:type] || 'ContactQuery')
  end
end

