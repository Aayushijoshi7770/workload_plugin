class IssueHelpdeskController < ApplicationController
  accept_api_auth :update_helpdesk_contact, :helpdesk_contact_destroy


def update_helpdesk_contact
    @issue_contact = IssueHelpdeskContact.find_or_initialize_by(issue_id: params[:issue_id])
    helpdesk_contact_params = params.permit(:contact_id, :source, :ticket_date, :ticket_time , :project_id)
    @issue_contact.assign_attributes(helpdesk_contact_params)
  

    if @issue_contact.save
      if @issue_contact.persisted?  
        render json: { message: "Helpdesk contact updated successfully." }, status: :ok
      else  
        render json: { message: "Helpdesk contact created successfully." }, status: :created
      end
    else      
      render json: { error: "Failed to save Helpdesk contact: #{@issue_contact.errors.full_messages.join(', ')}" }, status: :unprocessable_entity
    end

  end
  


  def helpdesk_contact_destroy
    @issue_contact = IssueHelpdeskContact.find(params[:id])
    
    if @issue_contact.destroy
      render json: { message: "Helpdesk contact deleted successfully." }, status: :ok
    else
      render json: { error: "Failed to delete Helpdesk contact." }, status: :unprocessable_entity
    end
  end
  




end
