class HelpdesksController < ApplicationController
  before_action :find_project
  before_action :find_helpdesk_setting, only: [:settings, :save_settings]

  
  def fetch_emails
    @helpdesk_setting = HelpdeskSetting.find_or_initialize_by(project_id: @project.id)
    
    if params[:helpdesk_setting].present?
      if @helpdesk_setting.update(helpdesk_settings_params)
        begin
          email_processor = RedminefluxHelpdesk::Patches::HelpdeskEmailProcessor.new(@project)
          email_count = email_processor.fetch_and_process_emails
          
          respond_to do |format|
            format.html do
              if email_count > 0
                render partial: 'email_status', locals: { message: "#{email_count} emails processed and issues created." }
              else
                render partial: 'email_status', locals: { message: "0 emails processed." }
              end
            end
          end
        rescue => e
          respond_to do |format|
            format.html do
              render partial: 'email_status', locals: { message: "Error processing emails: #{e.message}" }
            end
          end
        end
      else
        respond_to do |format|
          format.html do
            render partial: 'email_status', locals: { message: "Error updating Helpdesk settings." }
          end
        end
      end
    else
      render partial: 'email_status', locals: { message: "Helpdesk settings not provided." }
    end
  rescue => e
    respond_to do |format|
      format.html do
        render partial: 'email_status', locals: { message: "Error processing emails: #{e.message}" }
      end
    end
  end
  

  def settings
    Rails.logger.debug "Helpdesk Setting: #{@helpdesk_setting.inspect}"
  end

  def save_settings
    if @helpdesk_setting.update(helpdesk_settings_params)
      flash[:notice] = l(:notice_successful_update)
      redirect_to settings_project_path(@project, tab: 'helpdesk')
    else
      flash.now[:error] = @helpdesk_setting.errors.full_messages.join("<br/>")
      render :settings
    end
  end

  private

  def helpdesk_settings_params
    params.require(:helpdesk_setting).permit(
      :from_address, :cc_addresses, :bcc_address, :answered_ticket_status,
      :incoming_host, :incoming_port , :incoming_ssl , :incoming_starttls , :incoming_apop , :incoming_delete_unprocessed_messages , 
      :reopen_ticket_status, :ticket_tracker, :assign_ticket_to, :ticket_lifetime,
      :incoming_protocol, :incoming_username, :incoming_password, :imap_folder,
      :move_on_success, :move_on_failure, :outgoing_protocol , 
      :contacts_whitelist, :blacklist_emails, :tags,
      :use_default_settings, :smtp_server, :port, :domain,
      :authentication_method, :username, :password,
      :ssl, :tls, :skip_cert_verification
    )
  end

  def find_helpdesk_setting
    puts "Projectss_id ::: #{@project}"
    @helpdesk_setting = @project.helpdesk_setting || @project.build_helpdesk_setting
  end

  def find_project
    @project = Project.find(params[:project_id])
  end
end
