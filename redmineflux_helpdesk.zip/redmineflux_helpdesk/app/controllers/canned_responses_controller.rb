class CannedResponsesController < ApplicationController
  accept_api_auth :canned_macros, :apply_canned_response ,:check_helpdesk_tracker
  before_action :find_project, only: [:index, :new, :create, :edit, :update, :destroy]
  before_action :find_canned_response, only: [:show, :edit, :update, :destroy]
  before_action :authorize_manage_canned_responses, only: [:new, :edit, :delete]

  helper :attachments
  include AttachmentsHelper

  def index
  end

  def new
    @canned_response = CannedResponse.new
  end

  

  def apply_canned_response
    canned_response = CannedResponse.find(params[:id])
    user = User.current
    new_attachments  = copy_attachments(canned_response , user) 
    render json: { attachments: new_attachments.map { |a| { id: a.id, token: a.token, filename: a.filename, digest: a.digest } } }   
  end

  def canned_macros
    canned_response = CannedResponse.find(params[:canned_id])
    issue = Issue.find(params[:issue_id])
    contact_id = issue.issue_helpdesk_contact.contact_id
    contact = Contact.find(contact_id)
    new_content = macros_convert(canned_response , issue , contact)
    render json: { content: new_content }   
  end

  def create
    @canned_response = CannedResponse.new(canned_response_params)
    @canned_response.created_by = User.current.id

    if params[:canned_response][:is_for_all] == "1"
      @canned_response.project_id = nil
    elsif params[:canned_response][:is_for_all] == "0"
      if @project.present?
      @canned_response.project_id = params[:project_id]
      else
      @canned_response.project_id = nil
      end
    end

    if @canned_response.save
      save_attachments(@canned_response)
      flash[:notice] = l(:notice_successful_create)
      redirect_based_on_context
    else
      flash[:error] = @canned_response.errors.full_messages.join("<br>").html_safe
      render :new
    end
  end

  def edit
  end

  def update
    @canned_response.updated_by = User.current.id

    if params[:canned_response][:is_for_all] == "1"
      @canned_response.project_id = nil
    elsif params[:canned_response][:is_for_all] == "0"
      if @project.present?
        @canned_response.project_id = @project.id
        else
       
        end
    end

    if params[:canned_response][:deleted_attachment_ids].present?
      Attachment.where(id: params[:canned_response][:deleted_attachment_ids]).each(&:destroy)
    end

    if @canned_response.update(canned_response_params)
      if params[:attachments].present?
        attachments_with_token = params[:attachments].values.any? { |attachment| attachment['token'].present? }
        if attachments_with_token
          new_files = Attachment.attach_files(@canned_response, params[:attachments])[:files]
          @canned_response.attachments << new_files if new_files.present?
        end
      end

      flash[:notice] = l(:notice_successful_update)
      redirect_based_on_context
    else
      flash[:error] = @canned_response.errors.full_messages.join("<br>").html_safe
      render :edit
    end
  end

  def destroy
    @canned_response.destroy
    flash[:notice] = l(:notice_successful_delete)
    redirect_based_on_context
  end

  def check_helpdesk_tracker
    @project = Project.find_by(id: params[:project])
    
    if (@project.present? && @project.module_enabled?(:helpdesk)) && (@project.present? && @project.module_enabled?(:contacts)) 
        helpdesk_setting = HelpdeskSetting.find_by(project_id: @project.id)
      if helpdesk_setting
          render json: { tracker_id: helpdesk_setting.ticket_tracker }, status: :ok
       else
          render json: { error: "Helpdesk setting not found for project" }, status: :not_found
      end

     else
        render json: { error: "Helpdesk or Contacts module is not enabled for this project " }
     end
  
  end

  private

  def find_project
    @project = Project.find_by(id: params[:project_id])
  end

  def find_canned_response
    @canned_response = CannedResponse.find(params[:id])
  end

  def canned_response_params
    params.require(:canned_response).permit(:name, :content, :is_public)
  end

  def save_attachments(canned_response)
    if params[:attachments]
      canned_response.attachments = Attachment.attach_files(canned_response, params[:attachments])[:files]
    end
  end

  def redirect_based_on_context
    if @project.present?
      redirect_to "/projects/#{@project.identifier}/settings/canned_responses"
    else
      redirect_to plugin_settings_path(:redmineflux_helpdesk, :tab => 'canned_responses')
    end
  end

  def copy_attachments(canned_response ,user)
    new_attachments = []
    canned_response.attachments.each do |attachment|

      new_attachment = Attachment.create(
        file: attachment.file,
        filename: attachment.filename,
        description: attachment.description,
        content_type: attachment.content_type,
        filesize: attachment.filesize,
        disk_directory: attachment.disk_directory,
        disk_filename: attachment.disk_filename,
        digest: attachment.digest,
        author: user
      )
      new_attachments << new_attachment if new_attachment.persisted?
    end
    new_attachments
  end

  def authorize_manage_canned_responses
    unless User.current.admin? || User.current.allowed_to?(:manage_canned_responses, @project)
      render_403 
    end
  end


  def macros_convert(canned_response, issue, contact)
    new_content = canned_response.content
  
    # Replacing contact macros
    new_content.gsub!("{%contact.first_name%}", contact.first_name.to_s)
    new_content.gsub!("{%contact.last_name%}", contact.last_name.to_s)
    # new_content.gsub!("{%contact.name%}", contact.first_name.to_s) 
    new_content.gsub!("{%contact.name%}", "#{contact.first_name} #{contact.last_name}".strip) 
    new_content.gsub!("{%contact.company%}", contact.company.to_s)
    new_content.gsub!("{%contact.middle_name%}", contact.middle_name.to_s)
    new_content.gsub!("{%ticket.id%}", issue.id.to_s)
    new_content.gsub!("{%ticket.tracker%}", issue.tracker.name.to_s)
    new_content.gsub!("{%ticket.project%}", issue.project.name.to_s)
    new_content.gsub!("{%ticket.subject%}", issue.subject.to_s)
    new_content.gsub!("{%ticket.status%}", issue.status.to_s)
    new_content.gsub!("{%ticket.done_ratio%}", issue.done_ratio.to_s)
    new_content.gsub!("{%ticket.priority%}", issue.priority.name.to_s)
    new_content.gsub!("{%ticket.assigned_to%}", issue.assigned_to ? issue.assigned_to.name : '')
    new_content.gsub!("{%ticket.estimated_hours%}", issue.estimated_hours.to_s)
    new_content.gsub!("{%ticket.start_date%}", issue.start_date.to_s)
    new_content.gsub!("{%ticket.due_date%}", issue.due_date.to_s)
    new_content.gsub!("{%ticket.closed_on%}", issue.closed_on.to_s)
    new_content.gsub!("{%ticket.description%}", issue.description.to_s)
    new_content.gsub!("{%response.author%}", issue.author.to_s)
    new_content.gsub!("{%date%}", Date.today.to_s)
  
    return new_content
  end
  

end
