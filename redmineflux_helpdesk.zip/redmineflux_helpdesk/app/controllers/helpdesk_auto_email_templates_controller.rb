class HelpdeskAutoEmailTemplatesController < ApplicationController
  before_action :find_template, only: [:edit, :update, :destroy]

  def index
    @helpdesk_auto_email_templates = HelpdeskAutoEmailTemplate.all
    
  end

  def new
    @helpdesk_auto_email_templates = HelpdeskAutoEmailTemplate.new
  end

  def create
    @helpdesk_auto_email_templates = HelpdeskAutoEmailTemplate.new(template_params)
    Rails.logger.debug(@helpdesk_auto_email_templates.inspect)  # Log the object state
    if @helpdesk_auto_email_templates.save
      redirect_to plugin_settings_path(:redmineflux_helpdesk, :tab => 'auto_email_template') , notice: 'Template created successfully.'
    else
      flash[:error] = "Template name has already been taken."
      render :new
    end
  end

  def edit
  end

  def update
    if @helpdesk_auto_email_templates.update(template_params)
      redirect_to plugin_settings_path(:redmineflux_helpdesk, :tab => 'auto_email_template'), notice: 'Template updated successfully.'
    else
      render :edit
    end
  end

  def destroy
    if @helpdesk_auto_email_templates && @helpdesk_auto_email_templates.destroy
      Rails.logger.info "Template deleted successfully."
      redirect_to plugin_settings_path(:redmineflux_helpdesk, tab: 'auto_email_template'), notice: 'Template deleted successfully.'
    else
      Rails.logger.error "Failed to delete template."
      redirect_to plugin_settings_path(:redmineflux_helpdesk, tab: 'auto_email_template'), alert: 'Failed to delete template.'
    end
  end


  private

  def find_template
    @helpdesk_auto_email_templates = HelpdeskAutoEmailTemplate.find_by(id: params[:id])
    
    # If the template is not found, redirect with an error message
    unless @helpdesk_auto_email_templates
      Rails.logger.error "Template with ID #{params[:id]} not found."
      redirect_to plugin_settings_path(:redmineflux_helpdesk, tab: 'auto_email_template'), alert: 'Template not found.'
    end
  end

  def template_params
    params.require(:helpdesk_auto_email_template).permit(:email_auto_answer_template_name,:email_auto_answer_subject, :email_auto_answer_body,:email_auto_answer_footer)
  end
end
