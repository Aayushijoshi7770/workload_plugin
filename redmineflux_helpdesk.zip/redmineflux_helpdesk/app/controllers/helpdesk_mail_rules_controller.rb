class HelpdeskMailRulesController < ApplicationController

  # before_action :find_email_rule, only: [:edit, :update, :destroy]

  def index
    @email_rule = EmailRules.all
  end

  def new
    @email_rule = EmailRules.new
    @contacts=Contact.all
    @helpdesk_issue_statuses=IssueStatus.all
    @helpdesk_trackers=Tracker.all
    @helpdesk_priority = Enumeration.where(type: "IssuePriority", active: true, project_id: nil)
    @helpdesk_projects =Project.joins(:enabled_modules).where(enabled_modules: { name: ['helpdesk'] })
    @helpdesk_version=Version.all
    @helpdesk_version =Version.all.includes(:project).map do |version|
      version.attributes.merge('project_name' => version.project.name)
    end
    @helpdesk_assignee=User.where(status: 1)
    
  end

  def create
    # Make a copy of email_rule_params to modify conditions and actions
    email_rule_params_with_parsed_conditions_and_actions = email_rule_params.dup

    # Parse the JSON string in the conditions field to convert it into a hash
    if email_rule_params[:conditions].present?
      email_rule_params_with_parsed_conditions_and_actions[:conditions] = JSON.parse(email_rule_params[:conditions])
    end

    # Parse the JSON string in the actions field to convert it into an array
    if email_rule_params[:actions].present?
      email_rule_params_with_parsed_conditions_and_actions[:actions] = JSON.parse(email_rule_params[:actions])
    end

    @email_rule = EmailRules.new(email_rule_params_with_parsed_conditions_and_actions)
  

    if @email_rule.save
      flash[:notice] = 'Email Rule created successfully.'
      redirect_to plugin_settings_path(:redmineflux_helpdesk, :tab => 'email_rules')
    else
      render :new
    end
  
  end

  def edit
    @contacts=Contact.all
    @helpdesk_issue_statuses=IssueStatus.all
    @helpdesk_trackers=Tracker.all
    @helpdesk_priority = Enumeration.where(type: "IssuePriority", active: true, project_id: nil)
    @helpdesk_projects =Project.joins(:enabled_modules).where(enabled_modules: { name: ['helpdesk'] })
    @helpdesk_version=Version.all
    @helpdesk_version =Version.all.includes(:project).map do |version|
      version.attributes.merge('project_name' => version.project.name)
    end
    @helpdesk_assignee=User.where(status: 1)
    @emall_rule=EmailRules.find(params[:id])
  end

  def update
    # Find the existing email rule by its ID
    @emall_rule = EmailRules.find(params[:id])
  
    # Prepare the email rule parameters with parsed conditions and actions
    email_rule_params_with_parsed_conditions_and_actions = email_rule_params.dup
  
    # Parse the JSON string in the conditions field to convert it into a hash
    if email_rule_params[:conditions].present?
      email_rule_params_with_parsed_conditions_and_actions[:conditions] = JSON.parse(email_rule_params[:conditions])
    end
  
    # Parse the JSON string in the actions field to convert it into an array
    if email_rule_params[:actions].present?
      email_rule_params_with_parsed_conditions_and_actions[:actions] = JSON.parse(email_rule_params[:actions])
    end
  
    # Update the email rule with the new parameters
    if @emall_rule.update(email_rule_params_with_parsed_conditions_and_actions)
      flash[:notice] = 'Email Rule updated successfully.'
      redirect_to plugin_settings_path(:redmineflux_helpdesk, tab: 'email_rules')
    else
      render :edit
    end
  end
  

  
  def delete
    @email_rule = EmailRules.find(params[:id])
    puts "#{@email_rule.inspect} delete model"
    respond_to do |format|
      format.js
    end
  end 

  def destroy
    @email_rule = EmailRules.find(params[:id]) # Find the email rule by ID from parameters
    if @email_rule.destroy
      flash[:notice] = "Email rule deleted successfully"
    else
      flash[:alert] = "Error deleting email rule"
    end
    
  end

  private

  def find_email_rule
    @email_rule = EmailRules.find(params[:id])
  end

  def email_rule_params
    params.require(:email_rules).permit(:mail_type, :conditions, :actions)
  end
end
