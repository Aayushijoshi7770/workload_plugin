class ContactMailer
  EMAIL_REGEX = /\A[^@\s]+@([^@\s]+\.)+[^@\s]+\z/

  def self.send_email(email_send, contact)
    settings = HelpdeskSetting.find_by(project_id: email_send.project_id)
    return unless settings

    smtp_address = settings.smtp_server
    smtp_port = settings.port
    smtp_username = settings.username.strip
    smtp_password = settings.password

    from = email_send.from.strip
    to =  contact.email.strip 
    cc = email_send.cc.strip if email_send.cc.present?
    bcc = email_send.bcc.strip if email_send.bcc.present?
    subject = email_send.subject

    return false unless valid_email?(from) && valid_email?(to) &&
                        (cc.nil? || valid_email?(cc)) &&
                        (bcc.nil? || valid_email?(bcc))

    message_content = substitute_macros(email_send.message_content, contact)


    message = build_message(from, to, cc, subject, message_content)

    recipients = [to]
    recipients << cc if cc.present?
    recipients << bcc if bcc.present?
    recipients.flatten!
    recipients.compact!

    begin
      smtp = Net::SMTP.new(smtp_address, smtp_port)
      smtp.enable_starttls if smtp_port == 587

      smtp.start(smtp_address, smtp_username, smtp_password, :login) do |smtp|
        smtp.send_message(message, from, recipients)
      end
      true
    rescue StandardError => e
      Rails.logger.error "Failed to send email: #{e.message}"
      false
    end
  end

  def self.substitute_macros(message, contact)
    full_name = "#{contact.first_name} #{contact.last_name}".strip

    message.gsub!('%%NAME%%', full_name) if full_name.present?
    message.gsub!('%%LAST_NAME%%', contact.last_name) if contact.last_name
    message.gsub!('%%FULL_NAME%%', full_name) if full_name.present?
    message.gsub!('%%COMPANY%%', contact.company) if contact.company
    message.gsub!('%%DATE%%', Time.current.strftime('%Y-%m-%d')) 

    message
  end

  def self.valid_email?(email)
    email =~ EMAIL_REGEX
  end

  def self.build_message(from, to, cc, subject, body)
    headers = []
    headers << "From: #{from}"
    headers << "To: #{to}"
    headers << "Subject: #{subject}"
    headers << "Cc: #{cc}" if cc.present?
    headers << "Content-Type: text/plain; charset=UTF-8"
    headers << "" 
    headers << body

    headers.join("\r\n")
  end
end
