module HelpdeskTemplatesHelper
  
 def self.replace_macros(content, issue)
      return if content.nil?
    
      content.gsub!("{%contact.first_name%}", issue.issue_helpdesk_contact&.contact&.first_name.to_s.presence || '')
      content.gsub!("{%contact.last_name%}", issue.issue_helpdesk_contact&.contact&.last_name.to_s.presence || '')
      # content.gsub!("{%contact.name%}", issue.issue_helpdesk_contact&.contact&.first_name.to_s.presence || '')
      content.gsub!("{%contact.name%}", "#{issue.issue_helpdesk_contact&.contact&.first_name.to_s.presence || ''} #{issue.issue_helpdesk_contact&.contact&.last_name.to_s.presence || ''}".strip)
      content.gsub!("{%contact.company%}", issue.issue_helpdesk_contact&.contact&.company.to_s.presence || '')
      content.gsub!("{%contact.middle_name%}", issue.issue_helpdesk_contact&.contact&.middle_name.to_s.presence || '')
      content.gsub!("{%ticket.id%}", issue.id.to_s.presence || '')
      content.gsub!("{%ticket.tracker%}", issue.tracker&.name.to_s.presence || '')
      content.gsub!("{%ticket.project%}", issue.project&.name.to_s.presence || '')
      content.gsub!("{%ticket.subject%}", issue.subject.to_s.presence || '')
      content.gsub!("{%ticket.status%}", issue.status.to_s.presence || '')
      content.gsub!("{%ticket.done_ratio%}", issue.done_ratio.to_s.presence || '')
      content.gsub!("{%ticket.priority%}", issue.priority&.name.to_s.presence || '')
      content.gsub!("{%ticket.assigned_to%}", issue.assigned_to ? issue.assigned_to.name.to_s.presence || '' : '')
      content.gsub!("{%ticket.estimated_hours%}", issue.estimated_hours.to_s.presence || '')
      content.gsub!("{%ticket.start_date%}", issue.start_date.to_s.presence || '')
      content.gsub!("{%ticket.due_date%}", issue.due_date.to_s.presence || '')
      content.gsub!("{%ticket.closed_on%}", issue.closed_on.to_s.presence || '')
      content.gsub!("{%ticket.description%}", issue.description.to_s.presence || '')
      content.gsub!("{%response.author%}", issue.author.to_s.presence || '')
      content.gsub!("{%date%}", Date.today.to_s)
    
      content
    end    
      
end
