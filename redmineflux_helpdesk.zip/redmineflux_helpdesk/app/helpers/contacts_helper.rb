module ContactsHelper
    def grouped_contact_list(contacts, query, &block)
        puts "contacts:: #{contacts}"
        ancestors = []
        grouped_query_results(contacts, query) do |contact, group_name, group_count, group_totals|
          while ancestors.any? && !contact.is_descendant_of?(ancestors.last)
            ancestors.pop
          end
          yield contact, ancestors.size, group_name, group_count, group_totals
          ancestors << contact unless contact.leaf?
        end
      end
    
      private
    
      def grouped_query_results(contacts, query)
        grouped_contacts = contacts.group_by(&:category) 
        grouped_contacts.each do |group_name, group_contacts|
          group_count = group_contacts.size
          group_totals = calculate_group_totals(group_contacts) 
          group_contacts.each do |contact|
            yield contact, group_name, group_count, group_totals
          end
        end
      end
    
      def calculate_group_totals(group_contacts)
      end
end
