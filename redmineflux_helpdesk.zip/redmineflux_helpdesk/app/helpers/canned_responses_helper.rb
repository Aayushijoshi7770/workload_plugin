module CannedResponsesHelper
end
