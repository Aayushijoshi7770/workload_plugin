module HelpdeskAutoEmailTemplatesHelper
end
