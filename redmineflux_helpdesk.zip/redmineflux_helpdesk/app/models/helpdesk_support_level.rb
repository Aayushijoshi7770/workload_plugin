class HelpdeskSupportLevel < ActiveRecord::Base

  serialize :l1_user_ids, Array  # Serialize to store multiple user IDs
  serialize :l2_user_ids, Array
  serialize :l3_user_ids, Array
  
end
