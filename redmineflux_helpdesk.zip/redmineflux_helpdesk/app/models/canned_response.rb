class CannedResponse < ActiveRecord::Base
    has_many :attachments, as: :container, dependent: :destroy
    acts_as_attachable
    validates :name, presence: true, uniqueness: true, length: { maximum: 255 }
    validates :content, presence: true 
end
