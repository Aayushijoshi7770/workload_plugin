class AddHelpdeskSlaTrackingFields < ActiveRecord::Base

end
