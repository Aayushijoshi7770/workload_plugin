class IssueHelpdeskContact < ActiveRecord::Base
    belongs_to :issue
    belongs_to :contact
end
