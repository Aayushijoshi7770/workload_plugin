class ContactEmailSend < ActiveRecord::Base
    belongs_to :contact

    def send_email(email_send)
        @message_content = email_send.message_content
        mail(
          to: email_send.from,
          cc: email_send.cc,
          bcc: email_send.bcc,
          subject: email_send.subject
        ) do |format|
          format.text 
          format.html
        end
      end
end
