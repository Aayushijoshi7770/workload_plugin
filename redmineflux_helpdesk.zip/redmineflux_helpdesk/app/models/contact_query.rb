class ContactQuery < Query
    include RedminefluxHelpdesk::CountryHelper
    self.queried_class = Contact
    self.view_permission = :view_contacts
    
  

 self.available_columns = [
    QueryColumn.new(:id, sortable: "#{Contact.table_name}.id", default_order: 'desc', caption: '#', frozen: true),
    QueryColumn.new(:first_name, sortable: "#{Contact.table_name}.first_name", caption: :field_name),
    QueryColumn.new(:email, sortable: "#{Contact.table_name}.email", caption: :field_email),
    QueryColumn.new(:phone_no, sortable: "#{Contact.table_name}.phone_no", caption: :field_phone),
    QueryColumn.new(:country, sortable: "#{Contact.table_name}.country",  groupable: true , caption: :field_country), 
    QueryColumn.new(:is_company, sortable: "#{Contact.table_name}.company",  groupable: true ,caption: :field_company), 
    QueryColumn.new(:tags, sortable: "#{Contact.table_name}.tags", caption: :field_tags), 
    TimestampQueryColumn.new(:created_at, sortable: "#{Contact.table_name}.created_at", default_order: 'desc', groupable: true , caption: :field_created),
    TimestampQueryColumn.new(:updated_at, sortable: "#{Contact.table_name}.updated_at", default_order: 'desc', groupable: true , caption: :field_updated),
    
    QueryColumn.new(:notes, inline: false, caption: :field_notes)
  ]


  has_many :projects, foreign_key: 'default_contact_query_id', dependent: :nullify, inverse_of: 'default_contact_query'
  after_update { projects.clear unless visibility == VISIBILITY_PUBLIC }
  scope :for_all_projects, -> { where(project_id: nil) }


  def self.default(project: nil, user: User.current)
    if user&.logged? && (query_id = user.pref.default_contact_query).present?
      query = find_by(id: query_id)
      return query if query&.visible?(user)
    end

    query = project&.default_contact_query
    return query if query&.visibility == VISIBILITY_PUBLIC
    if (query_id = Setting.default_contact_query).present?
      query = find_by(id: query_id)
      return query if query&.visibility == VISIBILITY_PUBLIC
    end
    nil
  end
  
    def initialize(attributes = nil, *args)
      super(attributes)
      self.filters ||= {}
    end

  
    def initialize_available_filters
        # add_available_filter("ids", type: :list, name: l(:field_contact))  
      
        # add_available_filter("country", 
        #     type: :list_optional, 
        #     name: l(:field_country), 
        #     values: lambda { country_values })


        # add_available_filter("is_company", type: :text, name: l(:field_is_company))
        # add_available_filter("has_deals", type: :text, name: l(:field_has_deals))
        # add_available_filter("tags", type: :text, name: l(:field_tags))
        #  add_available_filter("author_id", 
        #     type: :list_optional, 
        #     name: l(:field_author), 
        #     values: User.all.collect { |u| [u.name, u.id.to_s] },
        #     operators: %w(= != !* *))

        #     add_available_filter("assigned_to_id", 
        #         type: :list_optional, 
        #         name: l(:field_assignee), 
        #         values: lambda { User.all.collect { |u| [u.name, u.id.to_s] } })


        # add_available_filter("has_open_issues", type: :text, name: l(:field_open_issues))
        # add_available_filter("number_of_tickets", type: :integer, name: l(:field_tickets_count))
        # add_available_filter("open_tickets", type: :integer, name: l(:field_opened_tickets))
      
        # Text group
        add_available_filter("first_name", 
          type: :text, 
          name: l(:field_first_name),
          values: lambda { Contact.pluck(:first_name).uniq.map { |name| [name, name] } })
      
      add_available_filter("last_name", 
          type: :text, 
          name: l(:field_last_name),
          values: lambda { Contact.pluck(:last_name).uniq.map { |name| [name, name] } })
      
      add_available_filter("middle_name", 
          type: :text, 
          name: l(:field_middle_name),
          values: lambda { Contact.pluck(:middle_name).uniq.map { |name| [name, name] } })
      
      add_available_filter("job_title", 
          type: :text, 
          name: l(:field_job_title),
          values: lambda { Contact.pluck(:job_title).uniq.map { |title| [title, title] } })
      
      add_available_filter("company", 
          type: :text, 
          name: l(:field_company),
          values: lambda { Contact.pluck(:company).uniq.map { |company| [company, company] } })
      
      add_available_filter("phone_no", 
          type: :text, 
          name: l(:field_phone),
          values: lambda { Contact.pluck(:phone_no).uniq.map { |phone| [phone, phone] } })
      
      add_available_filter("email", 
          type: :text, 
          name: l(:field_email),
          values: lambda { Contact.pluck(:email).uniq.map { |email| [email, email] } })
      
      add_available_filter("full_address", 
          type: :text, 
          name: l(:field_address),
          values: lambda { Contact.pluck(:full_address).uniq.map { |address| [address, address] } })
      
      add_available_filter("street1", 
          type: :text, 
          name: l(:field_street1),
          values: lambda { Contact.pluck(:street1).uniq.map { |street| [street, street] } })
      
      add_available_filter("street2", 
          type: :text, 
          name: l(:field_street2),
          values: lambda { Contact.pluck(:street2).uniq.map { |street| [street, street] } })
      
      add_available_filter("city", 
          type: :text, 
          name: l(:field_city),
          values: lambda { Contact.pluck(:city).uniq.map { |city| [city, city] } })
      
      add_available_filter("region", 
          type: :text, 
          name: l(:field_region),
          values: lambda { Contact.pluck(:region).uniq.map { |region| [region, region] } })
      
      add_available_filter("postcode", 
          type: :text, 
          name: l(:field_zip),
          values: lambda { Contact.pluck(:postcode).uniq.map { |postcode| [postcode, postcode] } })
      
      
        # Date group
        # add_available_filter("last_note", type: :date, name: l(:field_last_note))
        add_available_filter("updated_at", type: :date, name: l(:field_updated))
        add_available_filter("created_at", type: :date, name: l(:field_created))
    
      end
      
  
      def build_from_params(params, defaults = {})
        super(params, defaults)
        return self unless params[:set_filter] == '1'
        return self unless params[:f].is_a?(Array)
        params[:f].each_with_index do |field, index|
          next if field.blank?
          operator = params[:op].is_a?(Hash) && params[:op][field] || nil
          values = params[:v].is_a?(Hash) && params[:v][field] || []
          self.filters[field] = { operator: operator, values: values } if operator
        end
      
        self
      end

      

    def apply_filters(contacts)
        filters.each do |field, filter|
          operator = filter[:operator]
          values = filter[:values]
      
          if values.any?
            case field
            when 'first_name', 'last_name','middle_name' ,'email', 'phone_no', 'tags', 'notes', 'full_address', 'street1', 'street2', 'city', 'region', 'postcode'
              value_condition = "%#{values.first.downcase}%"
              
              case operator
              when "="
                contacts = contacts.where("#{Contact.table_name}.#{field} = ?", values.first)
              when "~"
                contacts = contacts.where("LOWER(#{Contact.table_name}.#{field}) LIKE ?", value_condition)
              when "!~"
                contacts = contacts.where.not("LOWER(#{Contact.table_name}.#{field}) LIKE ?", value_condition)
              when "^"
                contacts = contacts.where("LOWER(#{Contact.table_name}.#{field}) LIKE ?", "#{values.first.downcase}%")
              when "$"
                contacts = contacts.where("LOWER(#{Contact.table_name}.#{field}) LIKE ?", "%#{values.first.downcase}")
              when "!*"
                contacts = contacts.where("#{Contact.table_name}.#{field} IS NULL OR #{Contact.table_name}.#{field} = ''")
              when "*"
                next
              end
      
            when 'country'
              case operator
              when "="
                contacts = contacts.where("#{Contact.table_name}.country = ?", values.first)
              when "!"
                contacts = contacts.where.not("#{Contact.table_name}.country = ?", values.first)
              when "!*"
                contacts = contacts.where("#{Contact.table_name}.country IS NULL OR #{Contact.table_name}.country = ''")
              when "*"
                next
              end

            # when 'author_id'
            #     if values.any?
            #       case operator
            #       when "="
            #         contacts = contacts.where("#{Contact.table_name}.author_id = ?", values.first)
            #       when "!"
            #         contacts = contacts.where.not("#{Contact.table_name}.author_id = ?", values.first)
            #       when "!*"
            #         contacts = contacts.where("#{Contact.table_name}.author_id IS NULL")
            #       when "*"
            #         next 
            #     end
            # end
            when 'is_company'
              contacts = contacts.where("#{Contact.table_name}.company = ?", values.first) if values.any?
      
            when 'created_at', 'updated_at'
              case operator
              when "="
                date_value = Date.parse(values.first) rescue nil
                if date_value
                  contacts = contacts.where("#{Contact.table_name}.#{field} >= ?", date_value.beginning_of_day)
                  contacts = contacts.where("#{Contact.table_name}.#{field} <= ?", date_value.end_of_day)
                end
              when ">="
                date_value = Date.parse(values.first) rescue nil
                contacts = contacts.where("#{Contact.table_name}.#{field} >= ?", date_value.beginning_of_day) if date_value
              when "<="
                date_value = Date.parse(values.first) rescue nil
                contacts = contacts.where("#{Contact.table_name}.#{field} <= ?", date_value.end_of_day) if date_value
              when "><"
                start_date, end_date = values.map { |v| Date.parse(v) rescue nil }
                contacts = contacts.where("#{Contact.table_name}.#{field} BETWEEN ? AND ?", start_date.beginning_of_day, end_date.end_of_day) if start_date && end_date
              when "<t+"
                days = values.first.to_i
                contacts = contacts.where("#{Contact.table_name}.#{field} >= ?", Time.now - days.days)
              when ">t+"
                days = values.first.to_i
                contacts = contacts.where("#{Contact.table_name}.#{field} <= ?", Time.now + days.days)
              when "><t+"  
                days = values.first.to_i
                contacts = contacts.where("#{Contact.table_name}.#{field} BETWEEN ? AND ?", Time.now, Time.now + days.days)
              when "t+" 
                contacts = contacts.where("#{Contact.table_name}.#{field} >= ?", Time.now.beginning_of_day)
                contacts = contacts.where("#{Contact.table_name}.#{field} <= ?", Time.now.end_of_day)
              when "nd"  
                contacts = contacts.where("#{Contact.table_name}.#{field} >= ?", Date.tomorrow.beginning_of_day)
                contacts = contacts.where("#{Contact.table_name}.#{field} <= ?", Date.tomorrow.end_of_day)
              when "t" 
                contacts = contacts.where("#{Contact.table_name}.#{field} >= ?", Date.today.beginning_of_day)
                contacts = contacts.where("#{Contact.table_name}.#{field} <= ?", Date.today.end_of_day)
              when "ld" 
                contacts = contacts.where("#{Contact.table_name}.#{field} >= ?", Date.yesterday.beginning_of_day)
                contacts = contacts.where("#{Contact.table_name}.#{field} <= ?", Date.yesterday.end_of_day)
              when "nw"
                contacts = contacts.where("#{Contact.table_name}.#{field} >= ?", Date.today.beginning_of_week)
              when "w" 
                contacts = contacts.where("#{Contact.table_name}.#{field} >= ?", Date.today.beginning_of_week)
              when "lw" 
                contacts = contacts.where("#{Contact.table_name}.#{field} < ?", Date.today.beginning_of_week)
              when "l2w"  
                contacts = contacts.where("#{Contact.table_name}.#{field} < ?", 2.weeks.ago)
              when "nm" 
                contacts = contacts.where("#{Contact.table_name}.#{field} >= ?", Date.today.next_month.beginning_of_month)
              when "m" 
                contacts = contacts.where("#{Contact.table_name}.#{field} >= ?", Date.today.beginning_of_month)
              when "lm" 
                contacts = contacts.where("#{Contact.table_name}.#{field} < ?", Date.today.beginning_of_month)
              when "y" 
                contacts = contacts.where("#{Contact.table_name}.#{field} >= ?", Date.today.beginning_of_year)
              when ">t-"  
                days = values.first.to_i
                contacts = contacts.where("#{Contact.table_name}.#{field} > ?", Time.now - days.days)
              when "<t-" 
                days = values.first.to_i
                contacts = contacts.where("#{Contact.table_name}.#{field} < ?", Time.now - days.days)
              when "><t-"  
                days = values.first.to_i
                contacts = contacts.where("#{Contact.table_name}.#{field} BETWEEN ? AND ?", Time.now - days.days, Time.now)
              when "t-" 
                days = values.first.to_i
                contacts = contacts.where("#{Contact.table_name}.#{field} = ?", Time.now - days.days)
              when "!*"
                contacts = contacts.where.not("#{Contact.table_name}.#{field} IS NOT NULL")
              when "*"
                next 
              end
            end
          end
        end
      
        contacts
      end
      
      
  end
  