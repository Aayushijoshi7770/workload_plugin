class Contact < ActiveRecord::Base
  belongs_to :project
  belongs_to :issue_helpdesk_contact

  has_many :attachments, as: :container, dependent: :destroy
  has_many :migrate_taggings, as: :taggable, dependent: :destroy
  has_many :migrate_tags, through: :migrate_taggings, source: :migrate_tag
  acts_as_taggable_on :tags
  

  acts_as_attachable

  validate :conditional_name_validation

  def self.available_tags(options = {})
    # Replace with your logic to fetch available tags
    tags_scope = ActsAsTaggableOn::Tag.joins(:taggings)
                                       .where(taggings: { taggable_type: 'Contact' })
    
    if options[:name_like]
      pattern = "%#{options[:name_like].to_s.strip}%"
      tags_scope = tags_scope.where('LOWER(tags.name) LIKE LOWER(:p)', p: pattern)
    end
 def leaf?
  !has_children? 
 end

    tags_scope
  end

  private 

  def conditional_name_validation
    if company_details
      errors.add(:company_name, "can't be blank") if company_name.blank?
    else
      errors.add(:first_name, "can't be blank") if first_name.blank?
    end
  end
def has_children?
  false 
end

def css_classes(user = User.current)
  s = +"contact" 
  s << " project-#{project_id}" if project_id.present?

  s
end

private 

def conditional_name_validation
  if company_details
    errors.add(:company_name, "can't be blank") if company_name.blank?
  else
    errors.add(:first_name, "can't be blank") if first_name.blank?
  end
end
end
