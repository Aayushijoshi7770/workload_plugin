class HelpdeskTemplate < ActiveRecord::Base
  belongs_to :project
end
