class CustomMailer < ActionMailer::Base
  def issue_note_helpdesk(issue, journal, recipient_email, notes , subject , header , footer )


      message_body = "#{header}\n\n#{notes}\n\n#{footer}"
  

       mail(
        to: recipient_email,
        subject: subject,
        body: message_body,
        from: Setting.mail_from,
        content_type: "text/plain"
       )
   end
end
  