class HelpdeskcontactTags < ActiveRecord::Base
end
