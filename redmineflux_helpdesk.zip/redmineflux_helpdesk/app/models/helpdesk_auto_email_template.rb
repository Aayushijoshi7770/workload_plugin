class HelpdeskAutoEmailTemplate < ActiveRecord::Base
  validates :email_auto_answer_template_name, presence: true, uniqueness: true, length: { maximum: 255 }
  validates :email_auto_answer_subject, presence: true, length: { maximum: 255 }
  validates :email_auto_answer_body, presence: true

end
