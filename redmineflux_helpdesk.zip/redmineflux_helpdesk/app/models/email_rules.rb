class EmailRules < ActiveRecord::Base

  serialize :conditions, Hash
  serialize :actions, Hash

  validates :mail_type, presence: true
end
