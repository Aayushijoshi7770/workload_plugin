class HelpdeskSetting < ActiveRecord::Base
    belongs_to :project
end
