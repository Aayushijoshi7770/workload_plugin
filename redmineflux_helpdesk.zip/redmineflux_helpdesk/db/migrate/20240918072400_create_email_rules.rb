class CreateEmailRules < (ActiveRecord::VERSION::MAJOR >= 6 ? ActiveRecord::Migration[6.1] : ActiveRecord::Migration[5.2])
  def change
    create_table :email_rules do |t|
      t.string :mail_type
      t.text :conditions
      t.text :actions
      t.timestamps
    end
  end
end
