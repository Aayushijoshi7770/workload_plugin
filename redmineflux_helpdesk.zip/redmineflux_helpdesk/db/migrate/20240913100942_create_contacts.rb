class CreateContacts < (ActiveRecord::VERSION::MAJOR >= 6 ? ActiveRecord::Migration[6.1] : ActiveRecord::Migration[5.2])
  def change
    create_table :contacts do |t|
      t.integer :project_id
    
      t.boolean :company_details

      t.string :avatar
      t.string :first_name, null: false
      t.string :middle_name
      t.string :last_name
      t.string :company  
      t.date :birthday
      t.string :job_title

      t.string :company_name
      t.string :industry

  
      t.string :street1
      t.string :street2
      t.string :city
      t.string :state
      t.string :zip
      t.string :country

 
      t.text :phone_no
      t.text :email
      t.text :website
      t.text :skype

      t.text :background
      t.text :tags 

  
      t.string :responsible
      t.string :visibility  

      t.timestamps
    end
  end
end
