class CreateContactEmailSends < (ActiveRecord::VERSION::MAJOR >= 6 ? ActiveRecord::Migration[6.1] : ActiveRecord::Migration[5.2])
  def change
    create_table :contact_email_sends do |t|
      t.integer :contact_id
      t.string :from
      t.string :cc
      t.string :bcc
      t.string :subject
      t.text :message_content
      t.integer :project_id
      t.integer :updated_by
      t.timestamps
    end
  end
end


