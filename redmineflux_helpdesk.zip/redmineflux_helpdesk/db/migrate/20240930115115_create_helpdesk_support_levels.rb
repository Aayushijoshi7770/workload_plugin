class CreateHelpdeskSupportLevels < (ActiveRecord::VERSION::MAJOR >= 6 ? ActiveRecord::Migration[6.1] : ActiveRecord::Migration[5.2])
  def change
    create_table :helpdesk_support_levels do |t|
      t.integer :user_id
      t.integer :project_id
      t.text :l1_user_ids  # Text to store multiple user IDs
      t.text :l2_user_ids
      t.text :l3_user_ids
     
      t.timestamps
    end
  end
end
