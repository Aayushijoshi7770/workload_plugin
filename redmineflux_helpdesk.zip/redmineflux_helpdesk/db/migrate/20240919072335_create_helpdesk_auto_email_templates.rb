class CreateHelpdeskAutoEmailTemplates < (ActiveRecord::VERSION::MAJOR >= 6 ? ActiveRecord::Migration[6.1] : ActiveRecord::Migration[5.2])

  def change
    create_table :helpdesk_auto_email_templates do |t|
      t.string :email_auto_answer_template_name
      t.string :email_auto_answer_subject
      t.text :email_auto_answer_body
      t.text :email_auto_answer_footer
    end

  end

end

  