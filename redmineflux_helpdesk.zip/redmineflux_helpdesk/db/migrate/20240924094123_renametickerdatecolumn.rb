class Renametickerdatecolumn  < (ActiveRecord::VERSION::MAJOR >= 6 ? ActiveRecord::Migration[6.1] : ActiveRecord::Migration[5.2])
  def change
    rename_column :issue_helpdesk_contacts, :ticker_date, :ticket_date
  end
end
