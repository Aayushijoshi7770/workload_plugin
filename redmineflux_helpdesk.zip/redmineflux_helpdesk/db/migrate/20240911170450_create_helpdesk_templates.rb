class CreateHelpdeskTemplates < (ActiveRecord::VERSION::MAJOR >= 6 ? ActiveRecord::Migration[6.1] : ActiveRecord::Migration[5.2])

  def change
    create_table :helpdesk_templates do |t|
        t.references :project, null: false 
      t.string :answer_subject
      t.text :answer_header
      t.text :answer_footer
      t.boolean :send_auto_answer, default: false
      t.string :auto_answer_subject
      t.text :auto_answer_body
      t.string :autoclose_subject
      t.text :autoclose_body

      t.timestamps

    end
  end
end

