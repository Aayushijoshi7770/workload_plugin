class AddColumnDefaultContactQueryIdToProjectTable < (ActiveRecord::VERSION::MAJOR >= 6 ? ActiveRecord::Migration[6.1] : ActiveRecord::Migration[5.2])
  def change
    add_column :projects, :default_contact_query_id, :integer
  end
end
