class CreateHelpdeskSettings < (ActiveRecord::VERSION::MAJOR >= 6 ? ActiveRecord::Migration[6.1] : ActiveRecord::Migration[5.2])
  def change
    create_table :helpdesk_settings do |t|
      t.references :project, null: false 
      t.string :from_address
      t.text :cc_addresses
      t.text :bcc_address
      t.integer :answered_ticket_status
      t.integer :reopen_ticket_status
      t.integer :ticket_tracker
      t.integer :assign_ticket_to
      t.integer :ticket_lifetime
      t.string :incoming_protocol
      t.string :incoming_username
      t.string :incoming_password
      t.string :imap_folder
      t.string :move_on_success
      t.string :move_on_failure

      t.string :outgoing_protocol
      t.text :contacts_whitelist 
      t.text :blacklist_emails 
      t.string :tags 
      t.boolean :use_default_settings, default: false 
      t.string :smtp_server 
      t.integer :port 
      t.string :domain 
      t.string :authentication_method 
      t.string :username 
      t.string :password 
      t.boolean :ssl, default: false 
      t.boolean :tls, default: false 
      t.boolean :skip_cert_verification, default: false
      t.integer :updated_by

      t.timestamps
    end
  end
end
