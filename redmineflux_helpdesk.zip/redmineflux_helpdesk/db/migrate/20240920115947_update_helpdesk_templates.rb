class UpdateHelpdeskTemplates < (ActiveRecord::VERSION::MAJOR >= 6 ? ActiveRecord::Migration[6.1] : ActiveRecord::Migration[5.2])
  def change

    # Remove auto_answer_subject and auto_answer_body columns
    remove_column :helpdesk_templates, :auto_answer_subject, :string
    remove_column :helpdesk_templates, :auto_answer_body, :text

    # Add new column for email_auto_answer_template_name
    add_column :helpdesk_templates, :email_auto_answer_template_name, :integer

  end
end

