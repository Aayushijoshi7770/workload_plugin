class CreateCannedResponses < (ActiveRecord::VERSION::MAJOR >= 6 ? ActiveRecord::Migration[6.1] : ActiveRecord::Migration[5.2])
  def change
    create_table :canned_responses do |t|
      t.string :name, null: false
      t.text :content, null: false
      t.integer :project_id
      t.integer :created_by
      t.integer :updated_by
      t.boolean :is_public, default: false
      t.timestamp :created_on
      t.timestamp :updated_on
    end

    add_index :canned_responses, :project_id
    add_index :canned_responses, :created_by
    add_index :canned_responses, :updated_by
    
  end
end
