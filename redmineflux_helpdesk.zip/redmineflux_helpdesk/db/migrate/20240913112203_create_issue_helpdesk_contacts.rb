class CreateIssueHelpdeskContacts < (ActiveRecord::VERSION::MAJOR >= 6 ? ActiveRecord::Migration[6.1] : ActiveRecord::Migration[5.2])
  def change
    create_table :issue_helpdesk_contacts do |t|
      t.integer :issue_id, null: false
      t.integer :contact_id, null: false
      t.string :source
      t.date :ticker_date
      t.time :ticket_time

      t.timestamps
    end

    add_index :issue_helpdesk_contacts, :issue_id
    add_index :issue_helpdesk_contacts, :contact_id
  end
end
