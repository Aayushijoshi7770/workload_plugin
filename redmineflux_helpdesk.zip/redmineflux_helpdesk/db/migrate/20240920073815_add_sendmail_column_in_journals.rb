class AddSendmailColumnInJournals  < (ActiveRecord::VERSION::MAJOR >= 6 ? ActiveRecord::Migration[6.1] : ActiveRecord::Migration[5.2])
  def change
    add_column :journals, :is_send_mail, :boolean, default: false 
  end
end
