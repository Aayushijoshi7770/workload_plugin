class AddColumnPortToHelpdeskSettingTable < (ActiveRecord::VERSION::MAJOR >= 6 ? ActiveRecord::Migration[6.1] : ActiveRecord::Migration[5.2])
  def up
    add_column :helpdesk_settings, :incoming_host, :text
    add_column :helpdesk_settings, :incoming_port, :integer
    add_column :helpdesk_settings, :incoming_ssl, :boolean, default: false
    add_column :helpdesk_settings, :incoming_starttls, :boolean, default: false
    add_column :helpdesk_settings, :incoming_delete_unprocessed_messages, :boolean, default: false
    add_column :helpdesk_settings, :incoming_apop, :boolean, default: false
    remove_column :helpdesk_settings, :contacts_whitelist if column_exists?(:helpdesk_settings, :contacts_whitelist)
    add_column :helpdesk_settings, :contacts_whitelist, :boolean, default: false

  end

  def down
    remove_column :helpdesk_settings, :incoming_host
    remove_column :helpdesk_settings, :incoming_port
    remove_column :helpdesk_settings, :incoming_ssl
    remove_column :helpdesk_settings, :incoming_starttls
    remove_column :helpdesk_settings, :incoming_delete_unprocessed_messages
    remove_column :helpdesk_settings, :incoming_apop
    remove_column :helpdesk_settings, :contacts_whitelist
    add_column :helpdesk_settings, :contacts_whitelist, :text if column_exists?(:helpdesk_settings, :contacts_whitelist)
  end
end
