class CreateAddHelpdeskSlaTrackingFields < (ActiveRecord::VERSION::MAJOR >= 6 ? ActiveRecord::Migration[6.1] : ActiveRecord::Migration[5.2])
  def change
    add_column :issues, :time_to_first_response, :datetime
    add_column :issues, :time_to_reaction, :datetime
    add_column :issues, :time_to_resolve, :datetime
    add_column :issues, :waiting_for_response, :datetime
  end
end
