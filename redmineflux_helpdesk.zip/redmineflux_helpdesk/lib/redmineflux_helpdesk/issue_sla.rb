module RedminefluxHelpdesk
  class IssueSla < ApplicationController

  def initialize(issue)
    @issue = issue
    @helpdesk_contact = IssueHelpdeskContact.find_by(issue_id: @issue.id)
  end

  # Fetch Helpdesk Ticket DateTime
  def helpdesk_ticket_datetime
    if @helpdesk_contact
      helpdesk_date = @helpdesk_contact.ticket_date
      helpdesk_time = @helpdesk_contact.ticket_time
      DateTime.parse("#{helpdesk_date} #{helpdesk_time}")
    
    else
      @issue.created_on
    end
  end

  # First Response Time Calculation
  def first_response_time
    first_response_journal = @issue.journals.where(is_send_mail: true).order(:created_on).first
    if first_response_journal
      time_difference_in_words(helpdesk_ticket_datetime, first_response_journal.created_on)
    end
    
  end

  # Reaction Time Calculation (can be based on the first update by the support team)
  def reaction_time
    # Implement logic here
    first_reaction_journal =  @issue.journals.order(:created_on).first
    
    if  first_reaction_journal
      time_difference_in_words(helpdesk_ticket_datetime, first_reaction_journal.created_on)
    end
  end

  # Time to Resolve (can be based on when the issue was closed)
  def time_to_resolve
    blank_notes = @issue.journals.where(is_send_mail: true)
    if blank_notes.present? &&  @issue.closed_on 
      time_difference_in_words(helpdesk_ticket_datetime, @issue.closed_on)
    end
  end

  def waiting_for_response
    
  end 

  private

  # Helper method to calculate and format time difference
  def time_difference_in_words(start_time, end_time)
    difference_in_seconds = (end_time - start_time).to_i
    if start_time.to_date == end_time.to_date
      # If on the same day, return difference in minutes
      difference_in_minutes = (difference_in_seconds / 60).to_i.abs
      if difference_in_minutes >= 1440
        # If the difference is 1440 minutes or more, show in days
        difference_in_days = (difference_in_minutes / 1440).to_i.abs
        result = "#{difference_in_days} days"
      elsif difference_in_minutes < 1
        result = "Less than a minute"
      else
        result = "#{difference_in_minutes} minutes"
      end

    else
      # Otherwise, return difference in days
      difference_in_days = (difference_in_seconds / 1.day).to_i.abs
      result = "#{difference_in_days} days"
    end
    return result
  end

  end
end 