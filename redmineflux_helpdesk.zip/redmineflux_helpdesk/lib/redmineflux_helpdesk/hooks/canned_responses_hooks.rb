module RedminefluxHelpdesk

module Hooks
    class CannedResponsesHooks < Redmine::Hook::ViewListener
      render_on :view_issues_form_details_bottom, :partial => 'issues/mail_reply'
      render_on :view_issues_form_details_top, :partial => 'issues/add_helpdesk_contact'
      render_on :view_issues_show_details_bottom, :partial => 'issues/sla_fields'
      render_on :view_issues_sidebar_planning_bottom, partial: 'issues/helpdesk_contact_detail'
      # render_on :view_issues_show_details_bottom, :partial => 'issues/helpdesk_contact_attribute'


         # Conditionally render the helpdesk sidebar only on the project overview page
    def view_layouts_base_sidebar(context)
      if context[:controller].controller_name == 'projects' && context[:controller].action_name == 'show'
        context[:hook_caller].render partial: 'helpdesk_sidebar/helpdesk_sidebar_overview'
      end
    end

      def view_layouts_base_html_head(context)
        stylesheet_link_tag('canned_responses.css', :plugin => :redmineflux_helpdesk)
      end

    end
  end

end
