module RedminefluxHelpdesk
module Hooks
    class IssueReplyHook < Redmine::Hook::ViewListener
        def controller_issues_edit_before_save(context = {})
            issue = context[:issue]
            journal = context[:journal]
            params = context[:params]

            if params[:helpdesk].present?
            if params[:helpdesk][:is_send_mail] == "1" && journal.notes.present?     
              journal.is_send_mail = true
              journal.journal_contact = issue.issue_helpdesk_contact.contact.id 

              notes = journal.notes
              helpdesk_contact_email = issue.issue_helpdesk_contact.try(:contact).try(:email)

              subject = params[:issue][:email_subject]
              header = params[:issue][:email_header]
              footer = params[:issue][:email_footer]

              if helpdesk_contact_email.present?
                send_issue_note_email(issue, journal, helpdesk_contact_email, notes , subject , header , footer)
              end

             end
            end
          end

          private

          def send_issue_note_email(issue, journal, recipient_email, notes , subject , header , footer)
            CustomMailer.issue_note_helpdesk(issue, journal, recipient_email, notes , subject , header , footer).deliver_now
          end


    end
end

end