module RedminefluxHelpdesk
module Hooks
    class IssueHelpdeskContactController < Redmine::Hook::ViewListener
      def controller_issues_new_after_save(context = {})
        issue = context[:issue]
        params = context[:params]

        helpdesk_contact_id = params[:helpdesk_contact_id]
        helpdesk_ticket_source = params[:ticket_source]
        helpdesk_time = params[:ticket_time]
        helpdesk_date = params[:ticket_date]


        if helpdesk_contact_id.present?
        helpdesk_contact = IssueHelpdeskContact.find_or_initialize_by(issue_id: issue.id)
        helpdesk_contact.contact_id = helpdesk_contact_id
        helpdesk_contact.source = helpdesk_ticket_source
        helpdesk_contact.project_id = issue.project_id
        # helpdesk_contact.ticket_time = helpdesk_time

        if helpdesk_time.present?
           begin   
            local_time = Time.parse(helpdesk_time)
            utc_time = local_time.utc 
             helpdesk_contact.ticket_time = utc_time 
                rescue ArgumentError => e 
                  Rails.logger.error "Invalid time format for ticket_time: #{helpdesk_time}, Error: #{e.message}"       
                 end     
         end
        

        if helpdesk_date.present? 
            begin
              helpdesk_contact.ticket_date = Date.parse(helpdesk_date)
            rescue ArgumentError => e
              Rails.logger.error "Invalid date format for ticket_date: #{helpdesk_date}, Error: #{e.message}"
            end
        end


        if helpdesk_contact.save 
           Rails.logger.info "Helpdesk contact successfully updated for issue #{issue.id}."
        else
           Rails.logger.error "Error saving helpdesk contact for issue #{issue.id}: #{helpdesk_contact.errors.full_messages.join(', ')}"
        end


       end
      end
    end
end

end