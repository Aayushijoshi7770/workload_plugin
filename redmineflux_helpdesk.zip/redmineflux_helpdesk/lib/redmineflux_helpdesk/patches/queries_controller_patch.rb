module RedminefluxHelpdesk
  module Patches
    module QueriesControllerPatch
      extend ActiveSupport::Concern

      included do
        def redirect_to_contact_query(options)
          action_type = options[:action_type] || 'create'
          project_id = options[:query_id].try(:project_id) if options[:query_id].present?
          
          # Try to find project by id
          @project = Project.find_by(id: project_id) if project_id.present?
          
          # Use project identifier if available, otherwise fallback to params or nil
          project_id = @project.identifier if @project.present?
          project_id ||= params["project_id"]

          # Handle redirection with a project
          if project_id.present?
            case action_type
            when 'New', 'create'
              redirect_to project_contacts_path(project_id, query_id: options[:query_id].try(:id))
            when 'edit', 'update'
              redirect_to project_contacts_path(project_id, query_id: options[:query_id].try(:id))
            when 'delete', 'destroy'
              # When deleting, just redirect to contacts_path without query_id
              redirect_to project_contacts_path(project_id)
            else
              redirect_to project_contacts_path(project_id)
            end
          else
            # Handle redirection without a project
            case action_type
            when 'New', 'create'
              redirect_to contacts_path(query_id: options[:query_id].try(:id))
            when 'edit', 'update'
              redirect_to contacts_path(query_id: options[:query_id].try(:id))
            when 'delete', 'destroy'
              # When deleting, just redirect to contacts_path without query_id
              redirect_to contacts_path
            else
              redirect_to contacts_path
            end
          end
        end
      end
    end
  end
end

# Apply the patch
base = QueriesController
patch = RedminefluxHelpdesk::Patches::QueriesControllerPatch
base.send(:include, patch) unless base.included_modules.include?(patch)
