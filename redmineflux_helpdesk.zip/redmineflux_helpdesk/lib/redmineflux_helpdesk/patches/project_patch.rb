module RedminefluxHelpdesk
  module Patches
    module ProjectPatch
      def self.included(base)
        Rails.logger.debug "Applying ProjectPatch"
        base.class_eval do
          has_one :helpdesk_setting, dependent: :destroy
          accepts_nested_attributes_for :helpdesk_setting

          has_many :helpdesk_templates, dependent: :destroy
          accepts_nested_attributes_for :helpdesk_templates

          has_many :contacts, dependent: :destroy
          accepts_nested_attributes_for :contacts

          belongs_to :default_contact_query, class_name: 'ContactQuery', optional: true, inverse_of: :projects
        end
      end
    end
  end
end

  base = Project
  patch = RedminefluxHelpdesk::Patches::ProjectPatch
  base.send(:include, patch) unless base.included_modules.include?(patch)