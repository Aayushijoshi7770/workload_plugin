module RedminefluxHelpdesk
    module Patches
      module HelpdeskStatementQueryPatch
        def self.included(base)
          base.send :include, InstanceMethods
          base.class_eval do
            alias_method :statement_without_helpdesk_contact, :statement
            alias_method :statement, :statement_with_helpdesk_contact
          end
        end
  
        module InstanceMethods
          def statement_with_helpdesk_contact
            filters_clauses = []
  
            # Original filters processing
            if filters and valid?
              filters.each_key do |field|
                next if field == "subproject_id"
                v = values_for(field).clone
                next unless v and !v.empty?
                
                operator = operator_for(field)
  
                # Handle 'me' value substitution
                if %w(assigned_to_id author_id user_id watcher_id updated_by last_updated_by).include?(field)
                  if v.delete("me")
                    if User.current.logged?
                      v.push(User.current.id.to_s)
                      v += User.current.group_ids.map(&:to_s) if %w(assigned_to_id watcher_id).include?(field)
                    else
                      v.push("0")
                    end
                  end
                end
  
                # Add helpdesk_contact condition
                if field == 'helpdesk_contact'
                  filters_clauses << helpdesk_contact_condition(operator, v)
                elsif field == 'helpdesk_ticket_source'
                  filters_clauses << helpdesk_source_condition(operator, v)
                elsif field == 'project_id' || (self.type == 'ProjectQuery' && %w[id parent_id].include?(field))
                  if v.delete('mine')
                    v += User.current.memberships.map(&:project_id).map(&:to_s)
                  end
                  if v.delete('bookmarks')
                    v += User.current.bookmarked_project_ids
                  end
                elsif field =~ /^cf_(\d+)\.cf_(\d+)$/
                  filters_clauses << sql_for_chained_custom_field(field, operator, v, $1, $2)
                elsif field =~ /cf_(\d+)$/
                  filters_clauses << sql_for_custom_field(field, operator, v, $1)
                elsif field =~ /^cf_(\d+)\.(.+)$/
                  filters_clauses << sql_for_custom_field_attribute(field, operator, v, $1, $2)
                elsif respond_to?(method = "sql_for_#{field.tr('.', '_')}_field")
                  filters_clauses << send(method, field, operator, v)
                else
                  filters_clauses << '(' + sql_for_field(field, operator, v, queried_table_name, field) + ')'
                end
              end
            end
  
            # Original condition appending
            if (c = group_by_column) && c.is_a?(QueryCustomFieldColumn)
              filters_clauses << c.custom_field.visibility_by_project_condition
            end
  
            filters_clauses << project_statement
            filters_clauses.reject!(&:blank?)
  
            filters_clauses.any? ? filters_clauses.join(' AND ') : nil
          end
  

        end
      end
    end
  end
  
  base = Query
  patch = RedminefluxHelpdesk::Patches::HelpdeskStatementQueryPatch
  base.send(:include, patch) unless base.included_modules.include?(patch)