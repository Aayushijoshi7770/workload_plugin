module RedminefluxHelpdesk
    module Patches
      module QueriesHelperPatch
        extend ActiveSupport::Concern
        included do
          alias_method :original_filters_options_for_select, :filters_options_for_select
        end
  
        def filters_options_for_select(query)
          options = original_filters_options_for_select(query)
          if query.is_a?(ContactQuery)
            options << [l(:field_contacts_list_style), "contacts_list_style"]
          end
  
          options
        end
      end
    end
  end
  
  base = QueriesHelper
  patch = RedminefluxHelpdesk::Patches::QueriesHelperPatch
  base.send(:include, patch) unless base.included_modules.include?(patch)
  