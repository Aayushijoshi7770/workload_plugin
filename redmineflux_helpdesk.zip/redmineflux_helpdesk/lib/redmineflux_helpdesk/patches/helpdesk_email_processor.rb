require 'net/imap'
require 'net/pop'
require 'mail'

module RedminefluxHelpdesk
  module Patches
    class HelpdeskEmailProcessor
      def initialize(project)
        @project = project
        @settings = project.helpdesk_setting
        @current_user = User.current.id
      end

      def fetch_and_process_emails
        protocol = @settings.incoming_protocol
        required_fields = check_required_fields(protocol)

        if required_fields.any?
          raise "Missing required fields: #{required_fields.join(', ')}"
        end

        case protocol
        when 'imap'
          fetch_imap_emails
        when 'pop3'
          fetch_pop3_emails
        when 'gmail', 'yahoo', 'yandex'
          fetch_webmail_emails(protocol)
        else
          raise "Unsupported protocol: #{protocol}"
        end
      end

      def check_required_fields(protocol)
        missing_fields = []

        if @settings.incoming_username.blank?
          missing_fields << "Username"
        end

        if @settings.incoming_password.blank?
          missing_fields << "Password"
        end

        case protocol
        when 'imap'
          missing_fields << "Host" if @settings.incoming_host.blank?
          missing_fields << "Port" if @settings.incoming_port.blank?
        when 'pop3'
          missing_fields << "Host" if @settings.incoming_host.blank?
          missing_fields << "Port" if @settings.incoming_port.blank?
        end

        missing_fields
      end

      private

      def fetch_imap_emails
        imap_settings = configure_imap_settings
        imap = Net::IMAP.new(imap_settings[:address], imap_settings[:port], imap_settings[:ssl])
        imap.login(imap_settings[:username], imap_settings[:password])

        folder = @settings.imap_folder.presence || 'INBOX'
        imap.select(folder)

        unseen_emails = imap.search(['UNSEEN'])
        processed_count = 0

        unseen_emails.each do |message_id|
          raw_email_data = imap.fetch(message_id, 'RFC822')[0].attr['RFC822']

          if process_email(raw_email_data)
            imap.store(message_id, '+FLAGS', [:Seen])
            processed_count += 1
          end
        end

        imap.logout
        imap.disconnect

        processed_count
      end

      def fetch_pop3_emails
        pop3_settings = configure_pop3_settings
        pop = Net::POP3.new(pop3_settings[:address], pop3_settings[:port], pop3_settings[:ssl])
        pop.start(pop3_settings[:username], pop3_settings[:password])

        processed_count = 0

        if pop.mails.any?
          pop.mails.each do |mail|
            if process_email(mail.pop)
              mail.delete if @settings.incoming_delete_unprocessed_messages 
              processed_count += 1
            end
          end
        end

        pop.finish
        processed_count
      end

      def fetch_webmail_emails(provider)
        imap_settings = configure_webmail_settings(provider)
        imap = Net::IMAP.new(imap_settings[:address], imap_settings[:port], imap_settings[:ssl])
        imap.login(imap_settings[:username], imap_settings[:password])

        folder = @settings.imap_folder.presence || 'INBOX'
        imap.select(folder)

        unseen_emails = imap.search(['UNSEEN'])
        processed_count = 0

        unseen_emails.each do |message_id|
          raw_email_data = imap.fetch(message_id, 'RFC822')[0].attr['RFC822']

          if process_email(raw_email_data)
            imap.store(message_id, '+FLAGS', [:Seen])
            processed_count += 1
          end
        end

        imap.logout
        imap.disconnect

        processed_count
      end

      def process_email(raw_email_data)
        email = Mail.read_from_string(raw_email_data)
        sender_email = email.from&.first

        return false if blacklisted?(sender_email)
        return false if @settings.contacts_whitelist && !contact_exists_in_redmine?(sender_email)

        create_issue_from_email(email)
      end

      def configure_imap_settings
        {
          address: @settings.incoming_host,
          port: @settings.incoming_port,
          ssl: @settings.incoming_ssl,
          starttls: @settings.incoming_starttls, 
          username: @settings.incoming_username,
          password: @settings.incoming_password
        }
      end

      def configure_pop3_settings
        {
          address: @settings.incoming_host,
          port: @settings.incoming_port,
          ssl: @settings.incoming_ssl,
          username: @settings.incoming_username,
          password: @settings.incoming_password,
          apop: @settings.incoming_apop 
        }
      end

      def configure_webmail_settings(provider)
        case provider
        when 'gmail'
          { address: 'imap.gmail.com', port: 993, ssl: true, username: @settings.incoming_username, password: @settings.incoming_password }
        when 'yahoo'
          { address: 'imap.mail.yahoo.com', port: 993, ssl: true, username: @settings.incoming_username, password: @settings.incoming_password }
        when 'yandex'
          { address: 'imap.yandex.com', port: 993, ssl: true, username: @settings.incoming_username, password: @settings.incoming_password }
        end
      end

      def send_acknowledgment_email(recipient, issue)
        settings = @project.helpdesk_setting
        
        # Prepare dynamic SMTP settings based on user input or defaults
        smtp_settings = {
          address:              settings.smtp_server.presence || 'default.smtp.server',
          port:                 settings.port.presence || 587,
          domain:               settings.domain.presence || 'yourdomain.com',
          user_name:            settings.username.presence || 'default_username',
          password:             settings.password.presence || 'default_password',
          authentication:       settings.authentication_method.presence || 'plain', 
          enable_starttls_auto: settings.tls || false,  
          ssl:                  settings.ssl || false, 
          openssl_verify_mode:  settings.skip_cert_verification ? OpenSSL::SSL::VERIFY_NONE : OpenSSL::SSL::VERIFY_PEER
        }
      
        recipient_email, recipient_name = recipient.is_a?(Array) ? recipient : [recipient, 'User']
        outgoing_email = settings.username || 'default_email@example.com' 
        
        Mail.defaults do
          delivery_method :smtp, smtp_settings
        end
      
        # Email body content
        body_text = <<~TEXT
          Dear #{recipient_name},
      
          Thank you for reaching out to us. We have successfully created a new issue with the ID ##{issue.id}.
      
          Our team will review and address your issue as soon as possible. You will receive further updates once progress is made.
      
          If you have any additional information or questions, please do not hesitate to contact us.
      
          Best regards,
          The Support Team
          Your Company Name
        TEXT
      
        body_html = <<~HTML
          <p>Dear #{recipient_name},</p>
      
          <p>We hereby confirm that we have received your message.</p>
      
          <p>We will handle your request and get back to you as soon as possible.</p>
      
          <p>Your request has been assigned the following case ID ##{issue.id}.</p>
      
          <p>Best regards,<br>The Support Team<br>Your Company Name</p>
        HTML
      
        # Send the email
        Mail.deliver do
          from    outgoing_email
          to      recipient_email
          subject "Issue Created: Thank You for Your Submission"
          html_part do
            content_type 'text/html; charset=UTF-8'
            body body_html
          end
        end
      
      rescue => e
        Rails.logger.error "Failed to send acknowledgment email to #{recipient} for issue ##{issue.id}: #{e.message}"
      end

    

      def create_issue_from_email(email)
          # # Get the list of support users from settings
          # l1_support_users = Setting.plugin_redmineflux_helpdesk['l1_support_users'] || []
          # puts "#{ l1_support_users}"
          # l2_support_users = Setting.plugin_redmineflux_helpdesk['l2_support_users'] || []
          # l3_support_users = Setting.plugin_redmineflux_helpdesk['l3_support_users'] || []
        
          # # Determine which user to assign based on available support levels
          # assigned_user_id = nil
        
          # if l1_support_users.any?
          #   # Assign to the first L1 user if available
          #   assigned_user_id = l1_support_users.first
          # elsif l2_support_users.any?
          #   # If no L1 users, assign to the first L2 user if available
          #   assigned_user_id = l2_support_users.first
          # elsif l3_support_users.any?
          #   # If no L1 or L2 users, assign to the first L3 user if available
          #   assigned_user_id = l3_support_users.first
          # end
        
          # # If no users are available in L1, L2, or L3, assign to the default user
          # assigned_user_id ||= @settings.assign_ticket_to

         support_level = HelpdeskSupportLevel.find_by(project_id: @project.id) 
         l1_support_users = support_level&.l1_user_ids || [] 
         l2_support_users = support_level&.l2_user_ids || [] 
         l3_support_users = support_level&.l3_user_ids || [] 

          # Determine which user to assign based on available support levels
          assigned_user_id = nil
        
          if l1_support_users.any?
            # Assign to the first L1 user if available
            assigned_user_id = l1_support_users.sample
          elsif l2_support_users.any?
            # If no L1 users, assign to the first L2 user if available
            assigned_user_id = l2_support_users.sample
          elsif l3_support_users.any?
            # If no L1 or L2 users, assign to the first L3 user if available
            assigned_user_id = l3_support_users.sample
          end
        
          # If no users are available in L1, L2, or L3, assign to the default user
          assigned_user_id ||= @settings.assign_ticket_to
         
          # If still no user is assigned, assign the ticket to the logged-in user
          assigned_user_id ||= User.current.id

        # Extract the body content from the email
        email_body = extract_clean_email_body(email.body)

        issue = Issue.new(
          project: @project,
          subject: email.subject,
          description: email_body.strip,
          tracker_id: @settings.ticket_tracker,
          status_id: @settings.answered_ticket_status,
          assigned_to_id:  assigned_user_id,
          author_id: @current_user
        )

        if issue.save
          attach_files_to_issue(issue, email)
          link_contact_to_issue(email, issue)
          send_acknowledgment_email(email.from, issue)
        end

      rescue => e
        Rails.logger.error "Failed to create issue from email: #{e.message}"
        raise
      end

      def extract_clean_email_body(email_body)
        email_body_string = email_body.to_s
        parts = email_body_string.split(/--\w+/)
        plain_text_content = ""
        html_content = ""
      
        parts.each do |part|
          if part =~ /Content-Type:\s*text\/plain/i
            plain_text_content = part.split("\n\n", 2).last.strip if part.split("\n\n").length > 1
          end
      
          if part =~ /Content-Type:\s*text\/html/i
            html_content = part.split("\n\n", 2).last.strip if part.split("\n\n").length > 1
          end
        end
      
        clean_body = plain_text_content.empty? ? ActionController::Base.helpers.strip_tags(html_content) : plain_text_content
      
        clean_body
      end

      def link_contact_to_issue(email, issue)
        contact = save_contact_from_email(email)
        if contact
          IssueHelpdeskContact.create!(
            issue_id: issue.id,
            contact_id: contact.id,
            source: 'Email',
            ticket_date: Date.today,
            ticket_time: Time.now
          )
        end
      end

      

      def attach_files_to_issue(issue, email)
        mail = Mail.new(email.raw_source)
        attachments = mail.attachments.select { |a| a.content_disposition && a.content_disposition.start_with?('attachment') }
        attachments.each do |attachment|
          next if attachment.decoded.blank? || attachment.filename.blank?
          attachment_params = {
            container: issue,
            file: StringIO.new(attachment.decoded),
            filename: attachment.filename,
            content_type: attachment.mime_type,
            author_id: @current_user
          }
          begin
            Attachment.create!(attachment_params)
            Rails.logger.info "Successfully attached #{attachment.filename} to issue ##{issue.id}"
          rescue => e
            Rails.logger.error "Failed to attach file #{attachment.filename} to issue ##{issue.id}: #{e.message}"
          end
        end
      end
      

      def save_contact_from_email(email)
        from_email = email.from.first
        contact = Contact.find_or_initialize_by(email: from_email, project_id: @project.id)
        contact.first_name ||= email.from.first.split('@').first
        contact.phone_no ||= extract_phone_from_email(email.body.decoded)
        contact.company ||= extract_company_from_email(email.body.decoded)
      
        contact.save!
        contact
      rescue => e
        Rails.logger.error "Failed to save contact from email #{email.message_id}: #{e.message}"
        nil
      end
      
      def extract_phone_from_email(body)
        phone_regex = /(\+?\d{1,4}?[-.\s]?)\(?\d{1,4}?\)?[-.\s]?\d{1,4}[-.\s]?\d{1,9}/
        match = body.match(phone_regex)
        match ? match[0] : nil
      end
      
      def extract_company_from_email(body)
        company_regex = /(?:Company|Organization|Corp|Inc|LLC):?\s*(.*)/
        match = body.match(company_regex)
        match ? match[1].strip : nil
      end

      def contact_exists_in_redmine?(email)
        Contact.exists?(email: email)
      end

      def blacklisted?(email)
        blacklist = @settings.blacklist_emails || ''
        blacklist_patterns = blacklist.split("\n").map(&:strip).reject(&:empty?)
        blacklist_patterns.any? do |pattern|
          regex_pattern = Regexp.new(Regexp.escape(pattern).gsub("\\*", ".*"), Regexp::IGNORECASE)
          email.match?(regex_pattern)
        end
      end

    end
  end
end

