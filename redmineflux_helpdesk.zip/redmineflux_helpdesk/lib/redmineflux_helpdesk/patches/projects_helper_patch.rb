module RedminefluxHelpdesk
  module Patches
    module ProjectsHelperPatch
      def self.included(base)
        base.send(:include, InstanceMethods)

        base.class_eval do
          unloadable
          alias_method :project_settings_tabs_without_helpdesk_contacts, :project_settings_tabs
          alias_method :project_settings_tabs, :project_settings_tabs_with_helpdesk_contacts
        end
      end

      module InstanceMethods
        def project_settings_tabs_with_helpdesk_contacts
          tabs = project_settings_tabs_without_helpdesk_contacts

          if @project.module_enabled?(:helpdesk) 
            tabs.push(
              name: 'helpdesk',
              partial: 'helpdesks/settings',
              label: :label_helpdesk
            )

            tabs.push(
              name: 'helpdesk_template',
              partial: 'helpdesk_templates/helpdesk_template_settings',
              label: :label_helpdesk_template
            )
         if User.current.allowed_to?(:manage_canned_responses, @project) || User.current.admin? 
            tabs.push(
              name: 'canned_responses',
              partial: 'canned_responses/canned_responses_table',
              label: :label_canned_responses
            )
         end

            tabs.push(
              
                name:    'support_levels',
                partial: 'helpdesk_support_level/support_levels',
                label:   :label_support_levels # Add this line for the L1, L2, L3 settings
            
            )

          end

          if @project.module_enabled?(:contacts)
            tabs.push(
              name: 'contacts',
              partial: 'contacts/settings',
              label: :label_contacts
            )
          end
          tabs
        end
      end
    end
  end
end

base = ProjectsHelper
patch = RedminefluxHelpdesk::Patches::ProjectsHelperPatch
base.send(:include, patch) unless base.included_modules.include?(patch)
