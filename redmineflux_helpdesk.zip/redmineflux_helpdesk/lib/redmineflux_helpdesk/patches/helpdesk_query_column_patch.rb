module RedminefluxHelpdesk
    module Patches
      module HelpdeskQueryColumnPatch
        def self.included(base)
          base.send :include, InstanceMethods
          base.class_eval do

            alias_method :value_object_without_helpdesk_contact, :value_object
            alias_method :value_object, :value_object_with_helpdesk_contact

          end
        end
  
        module InstanceMethods
      
          def value_object_with_helpdesk_contact(object)
            if name == :helpdesk_contact
              object.issue_helpdesk_contact&.contact&.first_name
            elsif name == :helpdesk_company
              object.issue_helpdesk_contact&.contact&.company
            elsif name == :helpdesk_ticket_source
              object.issue_helpdesk_contact&.source
            else       
              value_object_without_helpdesk_contact(object)
            end
          end

        end
      end
    end
  end
  

  
  
  base = QueryColumn
  patch = RedminefluxHelpdesk::Patches::HelpdeskQueryColumnPatch
  base.send(:include, patch) unless base.included_modules.include?(patch)