module RedminefluxHelpdesk
    module Patches
      module IssueHelpdeskTab
        def self.included(base)
          base.send(:include, InstanceMethods)
  
          base.class_eval do
            alias_method :issue_history_tabs_without_helpdesk_field, :issue_history_tabs
            alias_method :issue_history_tabs, :issue_history_tabs_with_helpdesk_field
          end
        end
  
        module InstanceMethods
          def issue_history_tabs_with_helpdesk_field
           
            tabs = issue_history_tabs_without_helpdesk_field
  
           
            if @journals.present? 
              has_helpdesk_conversation = @journals.any? {|value| value.notes.present? && value.is_send_mail}
              project_has_modules = @issue.project.module_enabled?(:helpdesk) && @issue.project.module_enabled?(:contacts)
  
              if has_helpdesk_conversation && project_has_modules
                tabs << {
                  :name => 'helpdesk_conversation',
                  :label => :label_issue_helpdesk_conversation, 
                  :onclick => 'showIssueHistory("helpdesk_conversation", this.href)',
                  :partial => 'issues/tabs/helpdesk_conversation', 
                  :locals => { :issue => @issue, :journals => @journals }
                }
              end
            end
  
         
            tabs
          end
        end
      end
    end
  end
  

  unless IssuesHelper.included_modules.include?(RedminefluxHelpdesk::Patches::IssueHelpdeskTab)
    IssuesHelper.send(:include, RedminefluxHelpdesk::Patches::IssueHelpdeskTab)
  end
