module RedminefluxHelpdesk
    module Patches
      module HelpdeskTicketFilter
          
                  def self.included(base)
                      base.send :include, InstanceMethods
                      base.class_eval do 
  
                          alias_method :available_filters_without_helpdesk_contact, :available_filters
                          alias_method :available_filters, :available_filters_with_helpdesk_contact
  
                          alias_method :sql_for_field_without_helpdesk_contact, :sql_for_field
                          alias_method :sql_for_field, :sql_for_field_with_helpdesk_contact
  
                          alias_method :add_filter_error_without_helpdesk, :add_filter_error
                          alias_method :add_filter_error, :add_filter_error_with_helpdesk
          
                          alias_method :available_columns_without_helpdesk_contact, :available_columns
                          alias_method :available_columns, :available_columns_with_helpdesk_contact
                      end 
                  end
              end
              
              module InstanceMethods
  
                  def sql_for_field_with_helpdesk_contact(field, operator, value, db_table, db_field, is_custom_filter = false)
                      case field
                      when 'helpdesk contact'
                           helpdesk_contact_condition( operator , value)
                      else
                          sql_for_field_without_helpdesk_contact(field, operator, value, db_table, db_field, is_custom_filter)                        
                      end
                    end
  
                    def add_filter_error_with_helpdesk(field, message)
                      field_label = field.is_a?(Symbol) ? field.to_s.capitalize : label_for(field)
                      m = "#{field_label} #{l(message, :scope => 'activerecord.errors.messages')}"
                      errors.add(:base, m)
                    end
  

                  def available_filters_with_helpdesk_contact
                      if @available_filters.blank?  
                        
                           add_available_filter('helpdesk_contact', 
                            type: :list_optional, 
                            name: l(:field_helpdesk_contact),
                            values: Contact.all.map { |c| [c.first_name, c.id.to_s] }
                            ) unless available_filters_without_helpdesk_contact.key?('helpdesk_contact')

                            add_available_filter('helpdesk_ticket_source', 
                            type: :list_optional, 
                            name: l(:field_helpdesk_ticket_source),
                            values: [['Email', 'email'], ['Phone', 'phone'], ['Web', 'web'], ['Conversation', 'conversation']]
                            ) unless available_filters_without_helpdesk_contact.key?('helpdesk_ticket_source')

                            
                      else
                          available_filters_without_helpdesk_contact
                      end
                    @available_filters
                  end 
          

  
                  def available_columns_with_helpdesk_contact
                    if @available_columns.blank?
                      @available_columns = available_columns_without_helpdesk_contact
                              
                       @available_columns << QueryColumn.new(:helpdesk_contact, 
                          caption: :field_helpdesk_contact ,                 
                          groupable: true
                       )

                       @available_columns << QueryColumn.new(:helpdesk_company, 
                        caption: :field_helpdesk_company ,                 
                        groupable: true
                       )

                      @available_columns << QueryColumn.new(:helpdesk_ticket_source, 
                       caption: :field_helpdesk_ticket_source ,                 
                       groupable: true
                     )

                    else
                      available_columns_without_helpdesk_contact
                    end
                  
                    @available_columns
                  end
                  
                    
  
                  private
  
  
                  def helpdesk_contact_condition(operator, value)
                    if value.present? && value.any?(&:present?)
                      helpdesk_contact_ids = value.map(&:to_i)
                  
                      case operator
                      when "="               
                        "#{Issue.table_name}.id IN (SELECT issue_id FROM #{IssueHelpdeskContact.table_name} WHERE contact_id IN (#{helpdesk_contact_ids.join(',')}))"
                      
                      when "!"
                        "#{Issue.table_name}.id NOT IN (SELECT issue_id FROM #{IssueHelpdeskContact.table_name} WHERE contact_id IN (#{helpdesk_contact_ids.join(',')}))"
                      
                      else
                        ""
                      end
                    elsif operator == "!*"
                      "#{Issue.table_name}.id NOT IN (SELECT issue_id FROM #{IssueHelpdeskContact.table_name})"
                    
                    elsif operator == "*"
                      "#{Issue.table_name}.id IN (SELECT issue_id FROM #{IssueHelpdeskContact.table_name})"
                    
                    else
                      ""
                    end
                  end
                  
                  def helpdesk_source_condition(operator, value)
                    if value.present? && value.any?(&:present?)
                      helpdesk_source_values = value.map { |v| "'#{v}'" } 
                      
                      case operator
                      when "="
                        "#{Issue.table_name}.id IN (SELECT issue_id FROM #{IssueHelpdeskContact.table_name} WHERE source IN (#{helpdesk_source_values.join(',')}))"
                      
                      when "!"
                        "#{Issue.table_name}.id NOT IN (SELECT issue_id FROM #{IssueHelpdeskContact.table_name} WHERE source IN (#{helpdesk_source_values.join(',')}))"
                      
                      else
                        ""
                      end
                    elsif operator == "!*"
                      "#{Issue.table_name}.id NOT IN (SELECT issue_id FROM #{IssueHelpdeskContact.table_name})"
                    
                    elsif operator == "*"
                      "#{Issue.table_name}.id IN (SELECT issue_id FROM #{IssueHelpdeskContact.table_name})"
                    
                    else
                      ""
                    end
                  end
                  
                
   
               end
              end 
          end 
          
          base = IssueQuery
          patch = RedminefluxHelpdesk::Patches::HelpdeskTicketFilter
          base.send(:include, patch) unless base.included_modules.include?(patch)