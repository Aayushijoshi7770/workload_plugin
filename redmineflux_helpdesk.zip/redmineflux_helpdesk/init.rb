

Redmine::Plugin.register :redmineflux_helpdesk do
  name 'Redmineflux Helpdesk plugin'
  author 'Redmineflux - Powered by Zehntech Technologies Inc'
  description 'The Redmineflux Helpdesk Plugin enhances Redmine with advanced help desk functionality. It integrates ticket management, customer support workflows, and reporting features to streamline your support process and improve customer satisfaction.'
  version '1.0.0'
  url 'https://www.redmineflux.com'
  author_url 'https://www.redmineflux.com'

# require_relative './app/models/issue_sla'

  settings default: {
    'empty' => true,
    'answer_subject' => 'Re: {{ticket.subject}}',
    'answer_header' => '',
    'answer_footer' => 'Best regards, {{response.author.first_name}}',
    'auto_answer_subject' => 'Re: {{ticket.subject}}',
    'auto_answer_body' => 'Hello, {{contact.first_name}}, We confirm we have received your request...',
    'autoclose_subject' => '',
    'autoclose_body' => '',
    'email_css' => ''
  }, partial: 'settings/helpdesk_config'

  menu :admin_menu, :redmineflux_helpdesk, { controller: 'settings', action: 'plugin', id: 'redmineflux_helpdesk' }, 
  caption: :label_helpdesk, html: { class: 'icon' }, partial: 'settings/helpdesk_config'

  project_module :helpdesk do
    permission :view_helpdesk, :helpdesks => [:index]
    permission :manage_public_canned_responses, {:canned_responses => [:new, :create, :edit, :update, :destroy]}, :require => :loggedin
    permission :manage_canned_responses, {:canned_responses => [:new, :create, :edit, :update, :destroy]}, :require => :loggedin
    permission :send_response, public: true , :require => :loggedin
  end

  project_module :contacts do
    permission :view_contacts, :contacts => [:index]
  end

  menu :project_menu, 
       :contacts, 
       { controller: 'contacts', action: 'index' }, 
       caption: 'Contacts', 
       after: :files,
       param: :project_id

  menu :application_menu, 
     :all_contacts, 
     { controller: 'contacts', action: 'index' }, 
     caption: 'Contacts', 
     after: :news
 
  if Redmine::VERSION::MAJOR == 4
    require_relative './lib/redmineflux_helpdesk/patches/projects_helper_patch.rb'
    require_relative './lib/redmineflux_helpdesk/patches/project_patch.rb'
    require_relative './lib/redmineflux_helpdesk/patches/helpdesk_email_processor.rb'
    require_relative './lib/redmineflux_helpdesk/hooks/canned_responses_hooks.rb'
    require_relative './lib/redmineflux_helpdesk/country_helper.rb'

     require_relative './lib/redmineflux_helpdesk/patches/queries_controller_patch.rb'
     require_relative './lib/redmineflux_helpdesk/patches/queries_helper_patch.rb'
    
     require_relative './lib/redmineflux_helpdesk/hooks/issue_reply_hook.rb'
      require_relative './lib/redmineflux_helpdesk/hooks/issue_helpdesk_contact_controller.rb'
      require_relative './lib/redmineflux_helpdesk/patches/issue_helpdesk_tab.rb'
      require_relative './lib/redmineflux_helpdesk/patches/helpdesk_ticket_filter.rb'
      require_relative './lib/redmineflux_helpdesk/patches/helpdesk_query_column_patch.rb'
       require_relative './lib/redmineflux_helpdesk/patches/helpdesk_statement_query_patch.rb'
     require_relative './lib/redmineflux_helpdesk/patches/helpdesk_issue_pdf.rb'
       require_relative './lib/redmineflux_helpdesk/issue_sla.rb'
      
    Rails.configuration.to_prepare do
      # Issue.send(:belongs_to, :issue_helpdesk_contact)  
      Issue.send(:has_one, :issue_helpdesk_contact, class_name: 'IssueHelpdeskContact')
    end
  elsif Redmine::VERSION::MAJOR == 5
    require File.expand_path('./lib/redmineflux_helpdesk/patches/projects_helper_patch.rb', __dir__)
    require File.expand_path('./lib/redmineflux_helpdesk/patches/project_patch.rb', __dir__)
    require File.expand_path('./lib/redmineflux_helpdesk/patches/helpdesk_email_processor.rb', __dir__)
    require File.expand_path('./lib/redmineflux_helpdesk/hooks/canned_responses_hooks.rb', __dir__)
    require File.expand_path('./lib/redmineflux_helpdesk/country_helper.rb', __dir__)

    require File.expand_path('./lib/redmineflux_helpdesk/patches/queries_controller_patch.rb', __dir__)
    require File.expand_path('./lib/redmineflux_helpdesk/patches/queries_helper_patch.rb', __dir__)
    require File.expand_path('./lib/redmineflux_helpdesk/hooks/issue_reply_hook.rb', __dir__)
    require File.expand_path('./lib/redmineflux_helpdesk/hooks/issue_helpdesk_contact_controller.rb', __dir__)
    require File.expand_path('./lib/redmineflux_helpdesk/patches/issue_helpdesk_tab.rb',__dir__)
    require File.expand_path('./lib/redmineflux_helpdesk/patches/helpdesk_ticket_filter.rb',__dir__)
    require File.expand_path('./lib/redmineflux_helpdesk/patches/helpdesk_query_column_patch.rb',__dir__)
    require File.expand_path('./lib/redmineflux_helpdesk/patches/helpdesk_statement_query_patch.rb',__dir__)
    require File.expand_path('./lib/redmineflux_helpdesk/patches/helpdesk_issue_pdf.rb',__dir__)
    require File.expand_path( './lib/redmineflux_helpdesk/issue_sla.rb',__dir__)
    Rails.application.config.before_initialize do
      # Issue.send(:belongs_to, :issue_helpdesk_contact) 
      Issue.send(:has_one, :issue_helpdesk_contact, class_name: 'IssueHelpdeskContact')
  end
 end
end

