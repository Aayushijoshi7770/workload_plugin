$(document).ready(function(){

   
    window.openDeleteConfirmationPopup = function(cannedResponseId){
       
        let body_div = document.getElementsByClassName("controller-settings");
        let div = document.createElement("div");
        div.className = "delete-dialog-backdrop"; 
        body_div[0].appendChild(div);
        
        var modal = document.createElement('div');
        modal.id = 'deleteConfirmationModal';
        modal.classList.add('canned_delete-modal');
      
        var modalContent = document.createElement('div');
        modalContent.classList.add('canned_modal-content');
      
        var headingDiv = document.createElement('div');
        headingDiv.classList.add('heading-div');
      
        var heading = document.createElement('h3');
        heading.classList.add('delete-heading');
        heading.textContent = 'Delete Canned Response';
        headingDiv.appendChild(heading);

        var cross_div = document.createElement('div');
        cross_div.classList.add('cross-folder');
        cross_div.setAttribute('onclick', 'closeDeleteConfirmationPopup()');
        cross_div.style.cursor = 'pointer';
        var img = document.createElement('img');
        img.classList.add('image-folder');
        img.src = '/plugin_assets/redmineflux_helpdesk/images/cross.svg';
        cross_div.appendChild(img);
        headingDiv.appendChild(cross_div);
      
        var confirmationMessage = document.createElement('p');
        confirmationMessage.classList.add('delete-para');
        confirmationMessage.textContent = 'Are you sure you want to delete this canned response?';
      
        var buttonContainer = document.createElement('div');
        buttonContainer.classList.add('canned_button-container');
      
        // Create the Cancel button
        var cancelButton = document.createElement('a');
        cancelButton.id = 'cancel-btn';
        cancelButton.textContent = 'Cancel';
        cancelButton.addEventListener('click', closeDeleteConfirmationPopup);
      

        var deleteButton = document.createElement('a');
        deleteButton.id = 'delete-btn';
        deleteButton.textContent = 'Delete';
        deleteButton.setAttribute('href', '/canned_responses/' + cannedResponseId);
        deleteButton.setAttribute('data-method', 'delete');
        deleteButton.setAttribute('rel', 'nofollow');
        deleteButton.addEventListener('click', function() {
          closeDeleteConfirmationPopup();
        });

      
        buttonContainer.appendChild(cancelButton);
        buttonContainer.appendChild(deleteButton);
      
        modalContent.appendChild(headingDiv);
        modalContent.appendChild(confirmationMessage);
        modalContent.appendChild(buttonContainer);
        modal.appendChild(modalContent);
        
        // Append the modal to the body
        document.body.appendChild(modal);
      }
      
      window.closeDeleteConfirmationPopup = function(){
        var modal = document.getElementById('deleteConfirmationModal');
        let backdrop = document.getElementsByClassName('delete-dialog-backdrop')[0];
        if (modal) {
          modal.remove();
        }
        if (backdrop) {
            backdrop.remove();
          }

      }

      
      window.openDeleteConfirmationPopup_project = function(cannedResponseId , project_id){
        disableTabindex(".canned_delete-modal");
        let body_div = document.getElementsByClassName("controller-projects");
        let div = document.createElement("div");
        div.className = "delete-dialog-backdrop"; 
        body_div[0].appendChild(div);
        
        var modal = document.createElement('div');
        modal.id = 'deleteConfirmationModal';
        modal.classList.add('canned_delete-modal');
      
        var modalContent = document.createElement('div');
        modalContent.classList.add('canned_modal-content');
      
        var headingDiv = document.createElement('div');
        headingDiv.classList.add('heading-div');
      
        var heading = document.createElement('h3');
        heading.classList.add('delete-heading');
        heading.textContent = 'Delete Canned Response';
        headingDiv.appendChild(heading);

        var cross_div = document.createElement('div');
        cross_div.classList.add('cross-folder');
        cross_div.setAttribute('onclick', 'closeDeleteConfirmationPopup()');
        cross_div.style.cursor = 'pointer';
        var img = document.createElement('img');
        img.classList.add('image-folder');
        img.src = '/plugin_assets/redmineflux_helpdesk/images/cross.svg';
        cross_div.appendChild(img);
        headingDiv.appendChild(cross_div);
      
        var confirmationMessage = document.createElement('p');
        confirmationMessage.classList.add('delete-para');
        confirmationMessage.textContent = 'Are you sure you want to delete this canned response?';
      
        var buttonContainer = document.createElement('div');
        buttonContainer.classList.add('canned_button-container');
      
        // Create the Cancel button
        var cancelButton = document.createElement('a');
        cancelButton.id = 'cancel-btn';
        cancelButton.textContent = 'Cancel';
        cancelButton.addEventListener('click', closeDeleteConfirmationPopup);
      

        var deleteButton = document.createElement('a');
        deleteButton.id = 'delete-btn';
        deleteButton.textContent = 'Delete';
        deleteButton.setAttribute('href', '/canned_responses/' + cannedResponseId + '?project_id=' + project_id);
        deleteButton.setAttribute('data-method', 'delete');
        deleteButton.setAttribute('rel', 'nofollow');
        deleteButton.addEventListener('click', function() {
          closeDeleteConfirmationPopup();
        });

      
        buttonContainer.appendChild(cancelButton);
        buttonContainer.appendChild(deleteButton);
      
        modalContent.appendChild(headingDiv);
        modalContent.appendChild(confirmationMessage);
        modalContent.appendChild(buttonContainer);
        modal.appendChild(modalContent);
        
        // Append the modal to the body
        document.body.appendChild(modal);
      }


      window.disableTabindex=function(modalSelector){
        if ($(modalSelector).is(':visible')) {
          $(":tabbable").attr("tabindex", -1);
          $(modalSelector + " [tabindex='-1']").attr("tabindex", 0);
          $("html").css("overflow", "hidden");
        } else {
          $("[tabindex]").removeAttr("tabindex");
          $("html").css("overflow", "auto");
        }
      }


});