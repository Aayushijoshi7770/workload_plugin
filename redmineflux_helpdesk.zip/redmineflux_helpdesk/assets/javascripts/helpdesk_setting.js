$(document).ready(function(){
  const defaultSettingsCheckbox = document.getElementById("use_default_settings");
  const customEmailSettings = document.getElementById("custom_email_settings");

  function toggleEmailSettings() {
    if (defaultSettingsCheckbox.checked) {
      customEmailSettings.style.display = "none"; 
    } else {
      customEmailSettings.style.display = "block"; 
    }
  }
  toggleEmailSettings();
  defaultSettingsCheckbox.addEventListener("change", toggleEmailSettings);


  var protocolField = document.getElementById('incoming_protocol');
  var fields = {
    host: document.getElementById('host_field'),
    port: document.getElementById('port_field'),
    username: document.getElementById('username_field'),
    password: document.getElementById('password_field'),
    ssl: document.getElementById('ssl_field'),
    starttls: document.getElementById('starttls_field'),
    apop: document.getElementById('apop_field'),
    delete_unprocessed: document.getElementById('delete_unprocessed_field'),
    imap_folder: document.getElementById('imap_folder_field'),
    move_on_success: document.getElementById('move_on_success_field'),
    move_on_failure: document.getElementById('move_on_failure_field')
  };

  function updateFields() {
    var protocol = protocolField.value;
    Object.values(fields).forEach(function (field) {
      field.style.display = 'none';
    });
    if (['gmail', 'yahoo', 'yandex'].includes(protocol)) {
      fields.username.style.display = 'block';
      fields.password.style.display = 'block';
      fields.imap_folder.style.display = 'block';
      fields.move_on_success.style.display = 'block';
      fields.move_on_failure.style.display = 'block';
    } else if (protocol === 'pop3') {
      fields.host.style.display = 'block';
      fields.port.style.display = 'block';
      fields.username.style.display = 'block';
      fields.password.style.display = 'block';
      fields.ssl.style.display = 'block';
      fields.starttls.style.display = 'block';
      fields.apop.style.display = 'block';
      fields.delete_unprocessed.style.display = 'block';
    } else if (protocol === 'imap') {
      fields.host.style.display = 'block';
      fields.port.style.display = 'block';
      fields.username.style.display = 'block';
      fields.password.style.display = 'block';
      fields.ssl.style.display = 'block';
      fields.starttls.style.display = 'block';
      fields.imap_folder.style.display = 'block';
      fields.move_on_success.style.display = 'block';
      fields.move_on_failure.style.display = 'block';
    }
  }

  updateFields();
  protocolField.addEventListener('change', updateFields);
})

function updateCustomForm(url) {
  $.ajax({
    url: url,
    type: 'POST',
    data: $('#helpdesk_form').serialize(), 
    dataType: 'html',
    success: function(response) {
      $('#error_message').hide();
      $('#test_connection_messages').html(response);  
    },
    error: function(xhr) {
      $('#error_message').html('Error processing the request.').show();
      $('#test_connection_messages').html('');
    }
  });
}