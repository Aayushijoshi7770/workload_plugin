document.addEventListener("DOMContentLoaded", function() {
  const conditionsSelect = document.getElementById('conditions-select');
  const actionsSelect = document.getElementById('actions-select');
  const conditionsTable = document.getElementById('conditions-table').getElementsByTagName('tbody')[0];
  const actionsTable = document.getElementById('actions-table').getElementsByTagName('tbody')[0];
  const conditionsInput = document.getElementById('conditions-input');
  const actionsInput = document.getElementById('actions-input');
  const createButton = document.getElementById('create-button'); 

if(Email_rules)
{
for (const [key, condition] of Object.entries(Email_rules.conditions)) {
    addRow('condition', key, conditionsTable,condition);
}

// Add actions to the table
for (const [key, action] of Object.entries(Email_rules.actions)) {
    addRow('action', key, actionsTable,action);
}
}
  // Handle conditions selection
  conditionsSelect.addEventListener('change', function(event) {
      const selectedValue = event.target.value;
      const selectedOption = event.target.options[event.target.selectedIndex];
      if (selectedValue) {
          addRow('condition', selectedValue, conditionsTable);
          selectedOption.disabled = true;

          // Reset the selected value to an empty option after selecting
          event.target.value = ''; //
      }
  });

  // Handle actions selection
  actionsSelect.addEventListener('change', function(event) {
      const selectedValue = event.target.value;
      const selectedOption = event.target.options[event.target.selectedIndex];
      if (selectedValue) {
          addRow('action', selectedValue, actionsTable);
          selectedOption.disabled = true;

          // Reset the selected value to an empty option after selecting
          event.target.value = ''; //;
      }
  });

  createButton.addEventListener('click', function() {
    updateInput();
});

  function addRow(type, selectedValue, table, value) {
    const newRow = document.createElement('tr');
    newRow.id = `tr_${type}_${selectedValue}`;

    // Create the first <td> for the checkbox and label
    const tdField = document.createElement('td');
    tdField.classList.add('field');

    const checkbox = document.createElement('input');
    checkbox.type = 'checkbox';
    checkbox.checked = true;
    checkbox.name = 'f[]';
    checkbox.value = selectedValue;



    tdField.appendChild(checkbox);

    const label = document.createElement('label');
    label.setAttribute('for', `cb_${type}_${selectedValue}`);
      console.log(value,"values..")
        if(value)
        {
        label.innerText=selectedValue;
        }
        else{
            label.innerText = (type === 'condition' ? conditionsSelect : actionsSelect).options[(type === 'condition' ? conditionsSelect : actionsSelect).selectedIndex].text;
        }
            
    tdField.appendChild(label);

    // Create the second <td> for the operator dropdown (only for conditions)
    const tdOperator = document.createElement('td');
    tdOperator.classList.add('operator');
    if (type === 'condition') {
        const operatorSelect = document.createElement('select');
        operatorSelect.name = `op[${selectedValue}]`;

        // Define operators based on selected value
        let operatorsHTML = '';
        if (["Contact", "Contact tags", "Tags"].includes(selectedValue)) {
            operatorsHTML = `
                <option value="=">is</option>
                <option value="!">is not</option>
                <option value="!*">none</option>
                <option value="*">all</option>
            `;
        } else if (["Subject", "From address", "Message body"].includes(selectedValue)) {
            operatorsHTML = `
                <option value="~">contains</option>
                <option value="*~">contains any of</option>
                <option value="=">is</option>
                <option value="!~">doesn't contain</option>
                <option value="!">is not</option>
                <option value="^">starts with</option>
                <option value="$">ends with</option>
                <option value="!*">none</option>
                <option value="*">all</option>
            `;
        } else if (selectedValue === "Message type") {
            operatorsHTML = `
                <option value="=">is</option>
                <option value="!">is not</option>
            `;
        }
        operatorSelect.innerHTML = operatorsHTML;
        tdOperator.appendChild(operatorSelect);
    }
    else if(type === 'action'){
        if (selectedValue === 'Due Date') {
            const operatorSelect = document.createElement('select');
            operatorSelect.name = `op[${selectedValue}]`;
            operatorSelect.id = `operators_${selectedValue}`;
            operatorSelect.onchange = function () { toggleActionOperator(selectedValue); };
    
            // Define the specific operators for the Due Date field
            operatorSelect.innerHTML = `
                <option value="=">is</option>
                <option value="t">today</option>
                <option value="nd">tomorrow</option>
                <option value="da">after</option>
            `;
    
            tdOperator.appendChild(operatorSelect);
        } 
    }

    // Create the third <td> for the values dropdown or input
    const tdValues = document.createElement('td');
    tdValues.classList.add('values');
    
    const valuesSelect = document.createElement('select');
    valuesSelect.multiple = true;
    valuesSelect.name = `v[${selectedValue}][]`;

    const dueDateInput = document.createElement('input');
    dueDateInput.type = 'date';  // Use input type 'date'
    dueDateInput.name = `v[${selectedValue}][]`; 
    if(selectedValue=="Due Date")
    {
        dueDateInput.value=value.values;
    }
   

    if (selectedValue === "Contact") {
        if(contacts.length>0)
        {
        contacts.forEach(contact => {
            const option = document.createElement('option');
            option.value = contact.id;   // Use contact ID as the value
            option.textContent = contact.first_name;  // Use contact name as the display text
            valuesSelect.appendChild(option);
        });
    }
    } 
    else if(selectedValue==="Tracker"){
        valuesSelect.multiple = false;
        if(helpdesk_trackers.length>0)
            {
                helpdesk_trackers.forEach(ht=> {
                const option = document.createElement('option');
                option.value = ht.id;   // Use contact ID as the value
                option.textContent = ht.name;  // Use contact name as the display text
                if(value&&value.id[0]==ht.id)
                    {
                        option.selected=true;
                    }
                valuesSelect.appendChild(option);
            });
        }
    }
    else if(selectedValue==="Issue status")
    {
        valuesSelect.multiple = false;
        if(helpdesk_issue_statuses.length>0)
            {
                helpdesk_issue_statuses.forEach(hs=> {
                const option = document.createElement('option');
                option.value = hs.id;   // Use contact ID as the value
                option.textContent = hs.name;  // Use contact name as the display text
                if(value&&value.id[0]==hs.id)
                    {
                        option.selected=true;
                    }
                valuesSelect.appendChild(option);
            });
        }
    }
    else if(selectedValue==="Priority")
        {
            valuesSelect.multiple = false;
            if(helpdesk_priority.length>0)
                {
                    helpdesk_priority.forEach(hs=> {
                    const option = document.createElement('option');
                    option.value = hs.id;   // Use contact ID as the value
                    option.textContent = hs.name;  // Use contact name as the display text
                    if(value&&value.id[0]==hs.id)
                    {
                        option.selected=true;
                    }
                    valuesSelect.appendChild(option);
                });
            }
        }
        else if(selectedValue==="Project")
        {
            valuesSelect.multiple = false;
            if(helpdesk_project.length>0)
                {
                    helpdesk_project.forEach(hs=> {
                    const option = document.createElement('option');
                    option.value = hs.id;   // Use contact ID as the value
                    option.textContent = hs.name;  // Use contact name as the display text
                    if(value&&value.id[0]==hs.id)
                    {
                        option.selected=true;
                    }
                    valuesSelect.appendChild(option);
                });
            }
        }
        else if(selectedValue==="Target Version")
        {
            valuesSelect.multiple = false;
            if(helpdesk_version.length>0)
                {
                    helpdesk_version.forEach(hs=> {
                    const option = document.createElement('option');
                    option.value = hs.id;   // Use contact ID as the value
                    option.textContent = hs.name+" "+"-" +" "+hs.project_name;  // Use contact name as the display text
                    if(value&&value.id[0]==hs.id)
                        {
                            option.selected=true;
                        }
                    valuesSelect.appendChild(option);
                });
            }
        }
        else if(selectedValue==="Assignee")
            {
                valuesSelect.multiple = false;
                if(helpdesk_assignee.length>0)
                    {
                        helpdesk_assignee.forEach(hs=> {
                        const option = document.createElement('option');
                        option.value = hs.id;   // Use contact ID as the value
                        option.textContent = hs.firstname+" "+hs.lastname;  // Use contact name as the display text
                        if(value&&value.id[0]==hs.id)
                            {
                                option.selected=true;
                            }
                        valuesSelect.appendChild(option);
                    });
                }
            }
            else if(selectedValue === 'Due Date') {
              // Name it according to the form structure
                tdValues.appendChild(dueDateInput);  // Add the input to the tdValues
            }
            else if(selectedValue === "Message type")
            {
                valuesSelect.innerHTML = `
                <option value="1">New</option>
                <option value="2">Response</option>
            
            `;
            }
    else {
    valuesSelect.innerHTML = `
        <option value="1">Option 1</option>
        <option value="2">Option 2</option>
        <option value="3">Option 3</option>
    `;
}

    const valueInput = document.createElement('input');
    valueInput.name = `v[${selectedValue}][]`;
    valueInput.type = "text";
    console.log(value,"value..")
    if(value)
    {
        valueInput.value=value.values;
    }

        

    if (["Subject", "From address", "Message body"].includes(selectedValue)) {
        tdValues.appendChild(valueInput);
    } else if (["Contact", "Contact tags", "Tags", "Message type"].includes(selectedValue)) {
        tdValues.appendChild(valuesSelect);
        // Initialize Select2 (if you use it)
        $(valuesSelect).select2();
    } 
    else if(["Due Date"].includes(selectedValue)){
        {
         tdValues.appendChild(dueDateInput);
        }
    }
    else{
        tdValues.appendChild(valuesSelect);
    }

    // Append all <td> elements to the new row
    newRow.appendChild(tdField);
    newRow.appendChild(tdOperator);
    newRow.appendChild(tdValues);

    // Append the new row to the appropriate table
    table.appendChild(newRow);

    // Event listener for checkbox
    checkbox.addEventListener('change', function() {
        if (checkbox.checked) {
            tdOperator.style.display = ''; // Show the operator field
            tdValues.style.display = '';   // Show the value field
        } else {
            tdOperator.style.display = 'none'; // Hide the operator field
            tdValues.style.display = 'none';   // Hide the value field
        }
    });

    // Initialize with visible fields
    tdOperator.style.display = checkbox.checked ? '' : 'none';
    tdValues.style.display = checkbox.checked ? '' : 'none';
  }

  function updateInput() {
    const conditionData = {};
    document.querySelectorAll('#conditions-table tbody tr').forEach(row => {
        const key = row.querySelector('.field input')?.value;
        const operator = row.querySelector('.operator select')?.value;
        
        const values = Array.from(row.querySelector('.values select')?.selectedOptions || []).map(option => option.innerText);
        const ids=Array.from(row.querySelector('.values select')?.selectedOptions || []).map(option => option.value);
        const valueInput = row.querySelector('.values input')?.value;

        if (key) {
            conditionData[key] = {
                operator: operator,
                values: valueInput ? [valueInput] : values,
                id:ids
            };
        }
    });

    const actionData = {};
    document.querySelectorAll('#actions-table tbody tr').forEach(row => {
        const key = row.querySelector('.field input')?.value;
        const operator = row.querySelector('.operator select')?.value;
        const values = Array.from(row.querySelector('.values select')?.selectedOptions || []).map(option => option.innerText);
        const ids=Array.from(row.querySelector('.values select')?.selectedOptions || []).map(option => option.value);
        const valueInput = row.querySelector('.values input')?.value;


        if (key) {
            actionData[key] = {
                operator: operator,
                values: valueInput ? valueInput : values,
                id:ids
            };
        }
 
    });


 
    conditionsInput.value = JSON.stringify(conditionData);
    actionsInput.value = JSON.stringify(actionData);
   
  }

  window.closeDeleteModal=function(){
    let modal = document.getElementById("delete_team_modal");
    let overlay = document.getElementById("delete_team_overlay");
    modal.style.display = "none";
    overlay.style.display = "none";
    $("body :tabbable").removeAttr("tabindex");
    setTimeout(() => {
      modal.classList.remove("show_team_modal");
      overlay.classList.remove("show_team_modal");
      $("[tabindex]").removeAttr("tabindex");
      $("html").css("overflow", "auto");
    }, 1);
  }
});

function deleteEmailRule(id)
{
    $.ajax({
        url: '/helpdesk_email_rule/destroy',
        method: 'DELETE',
        data: { id: id },
        dataType: 'json',
        success: function(response) {
          console.log(response,"response...");
          window.location.reload();
            // Handle success response
        },
        error: function(xhr, status, error) {
            // Handle error response
            console.error('Error deleting teams:', error);
        }
      });
}
