

resources :projects do
    # resources :canned_responses
    resources :helpdesks do
      collection do
        post 'settings', to: 'helpdesks#save_settings'
        post 'fetch_emails', to: 'helpdesks#fetch_emails'
      end
    end
  end

  resources :projects do
    resources :helpdesk_templates, only: [:create, :update] do
      collection do
        post 'save_helpdesk_templates', to: 'helpdesk_templates#save_helpdesk_templates'
      end
    end
  end
  
  resources :canned_responses
  resources :helpdesk_mail_rules 

  resources :helpdesk_mail_rules  do
    get 'delete', on: :member

  end
  delete '/helpdesk_email_rule/destroy' , to:'helpdesk_mail_rules#destroy'
  # resources :contacts
  resources :helpdesk_auto_email_templates
  # resources :issue_helpdesk_contacts, only: [:update, :destroy]

 resources :projects do 
    resource :helpdesk_support_level, only: [:index, :save_support_levels] do
      post :save_support_levels, on: :collection
    end
  end


  
  

  resources :contacts do
    collection do
      get 'send_email_from' 
      post 'send_email'
      get 'context_menu' 
      get 'bulk_edit'
      patch 'bulk_update'
    end
    member do
      post 'update_contact_tags', to: 'helpdeskcontact_tags#update_contacttag'
    end
  end
  





  post 'canned_responses/:id/apply', to: 'canned_responses#apply_canned_response'
  post 'canned_macros', to: 'canned_responses#canned_macros'
  get 'helpdesk/check_project_tracker' , to: 'canned_responses#check_helpdesk_tracker'
  delete '/issue_helpdesk_contact_destroy', to: 'issue_helpdesk#helpdesk_contact_destroy', as: 'issue_helpdesk_contact_destroy'
  patch '/issue_helpdesk_contact_update', to: 'issue_helpdesk#update_helpdesk_contact', as: 'update_issue_helpdesk_contact'

  resources :projects do
    resources :contacts do
      resources :helpdeskcontact_tags, only: [:edit, :update, :destroy]
      post 'update_contact_tags', to: 'helpdeskcontact_tags#update_contacttag', on: :member
      collection  do
        get 'send_email_from' 
        post 'send_email'
        get 'context_menu'
        get 'bulk_edit'
        patch 'bulk_update'  
        delete 'destroy_multiple'
      end
    end
  end
  

  get 'contacts/context_menu', to: 'contacts#context_menu'
  post 'update_contact_tags', to: 'helpdeskcontact_tags#update_contacttag'
  
