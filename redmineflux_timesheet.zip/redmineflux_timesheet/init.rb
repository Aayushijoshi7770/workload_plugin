


Redmine::Plugin.register :redmineflux_timesheet do
  name 'Redmineflux Timesheet Plugin'
  author 'Redmineflux - Powered by Zehntech Technologies Inc'
  description 'Enhance your Redmine experience with the Redmineflux Timesheet Plugin, which offers efficient time tracking and reporting for better project management.'
  version '1.0.12'
  url 'https://www.redmineflux.com/knowledge-base/plugins/timesheet/'
  author_url 'https://www.redmineflux.com'

  permission :timesheets, { timesheets: [:index ] }, public: true
  menu :top_menu, :timesheets, { controller: 'timesheets', action: 'index'}, caption: Proc.new { I18n.t(:Timesheet)}, after: :project
  permission :manage_timesheet, :timesheet => [:timesheet_permissions]
  settings default: {'empty' => true}, partial: 'settings/settings'

 
end
 require_dependency 'time_entry'
 TimeEntry.send(:include, RedminefluxTimesheet::Patches::TimeEntryPatch)
    Rails.configuration.to_prepare do  
    User.send(:has_many, :team_users)
    User.send(:has_many, :teams, through: :team_users)
    User.send(:has_many, :submit_timesheets) 
    User.send(:has_many, :approvals, foreign_key: :approver_id, class_name: 'Approval')
    User.send(:has_many, :timesheet_statuses, foreign_key: :user_id, class_name: 'TimesheetStatus')
        
end



