var url = window.location.origin;

function closeNewTeamModal(){
    let modal = document.getElementById("new_team_modal");
    let overlay = document.getElementById("new_team_overlay");
    modal.style.display = "none";
    $("body :tabbable").removeAttr("tabindex");
    setTimeout(() => {
      modal.classList.remove("show_team_modal");
      overlay.classList.remove("show_team_modal");
      $("[tabindex]").removeAttr("tabindex");
    $("html").css("overflow", "auto");
    }, 1);
}

function closeUpdateTeamModal(){
  let modal = document.getElementById("update_team_modal");
  let overlay = document.getElementById("update_team_overlay");
  modal.style.display = "none";
  $("body :tabbable").removeAttr("tabindex");
  setTimeout(() => {
    modal.classList.remove("show_team_modal");
    overlay.classList.remove("show_team_modal");
    $("[tabindex]").removeAttr("tabindex");
    $("html").css("overflow", "auto");

  }, 1);
}


function closeDeleteTeamModal(){
  let modal = document.getElementById("delete_team_modal");
  let overlay = document.getElementById("delete_team_overlay");
  modal.style.display = "none";
  overlay.style.display = "none";
  $("body :tabbable").removeAttr("tabindex");
  setTimeout(() => {
    modal.classList.remove("show_team_modal");
    overlay.classList.remove("show_team_modal");
    $("[tabindex]").removeAttr("tabindex");
    $("html").css("overflow", "auto");
  }, 1);
}




// function createTeam(){
//   let testsuiteName = document.getElementById("team_name").value;
 
//   if(testsuiteName.length === 0){
//       let danger = document.getElementById("team-name-error");
//       danger.style.display = "block";
//   }else{
    // let modal = document.getElementById("new_team_modal");
    // let overlay = document.getElementById("new_team_overlay");
    // modal.style.display = "none";
    // modal.classList.remove("show_team_modal");
    // overlay.classList.remove("show_team_modal");
    
//   }
// }

// function updateTeam(){
//   let name = document.getElementById("team_name").value;
//   console.log("team name",name, $("#btn_update_team") )
//    if (name.length === 0){
//      let danger = document.getElementById("updateteam-name-error");
//      danger.style.display = "block";
//      console.log(danger, "fdsfjhsj ")
//    }else{
//      let modal = document.getElementById("update_team_modal");
//      let overlay = document.getElementById("update_team_overlay");
//      modal.style.display = "none";
   
//      modal.classList.remove("show_team_modal");
//      overlay.classList.remove("show_team_modal");
   
//    }
// }

function delete_team(teamid) {
  let teamIdsToDelete = checkedIds.length > 0 ? checkedIds : [teamid];
  console.log(teamIdsToDelete,)
  
  $.ajax({
    url: '/timesheet_teams/destroy',
    method: 'DELETE',
    data: { team_ids: teamIdsToDelete },
    dataType: 'json',
    success: function(response) {
      console.log(response,"response...");
      window.location.reload();
        // Handle success response
    },
    error: function(xhr, status, error) {
        // Handle error response
        console.error('Error deleting teams:', error);
    }
  });
}


