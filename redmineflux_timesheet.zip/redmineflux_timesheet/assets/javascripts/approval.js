function closeNewModal(){
    let modal = document.getElementById("new_approval_modal");
    let overlay = document.getElementById("new_approval_overlay");
    modal.style.display = "none";
   // $("body :tabbable").removeAttr("tabindex");
    setTimeout(() => {
      modal.classList.remove("show_team_modal");
      overlay.classList.remove("show_team_modal");

      $("[tabindex]").removeAttr("tabindex");
    $("html").css("overflow", "auto");

    }, 1);
}
    

function closeUpdateModal(){
    let modal = document.getElementById("update_approval_modal");
    let overlay = document.getElementById("update_approval_overlay");
    modal.style.display = "none";
    $("body :tabbable").removeAttr("tabindex");
    setTimeout(() => {
      modal.classList.remove("show_team_modal");
      overlay.classList.remove("show_team_modal");
      $("[tabindex]").removeAttr("tabindex");
    $("html").css("overflow", "auto");

    }, 1);
}

function closeDeleteModal(){
  let modal = document.getElementById("delete_approval_modal");
  let overlay = document.getElementById("delete_approval_overlay");
  modal.style.display = "none";
  overlay.style.display = "none";
  $("body :tabbable").removeAttr("tabindex");
  setTimeout(() => {
    modal.classList.remove("show_delete_modal");
    overlay.classList.remove("show_delete_modal");
    $("[tabindex]").removeAttr("tabindex");
    $("html").css("overflow", "auto");
  }, 1);
}

function closeRemoveUserModal(){
  let modal = document.getElementById("remove_user_modal");
  let overlay = document.getElementById("remove_user_overlay");
  modal.style.display = "none";
  overlay.style.display = "none";
  $("body :tabbable").removeAttr("tabindex");
  setTimeout(() => {
    modal.classList.remove("show_user_modal");
    overlay.classList.remove("show_user_modal");
    $("[tabindex]").removeAttr("tabindex");
    $("html").css("overflow", "auto");
  }, 1);
}


// function createApproval(){
//   let levelName = document.getElementById("approval_level_name").value;

//   if(levelName.length === 0){
//     let danger = document.getElementById("approval-name-error");
//     danger.style.display = "block";
//   }else{
//     let modal = document.getElementById("new_approval_modal");
//     let overlay = document.getElementById("new_approval_overlay");
//     modal.style.display = "none";
//     modal.classList.remove("show_team_modal");
//     overlay.classList.remove("show_team_modal");
//     window.location.reload();
    
//   }
// }

// function updateApproval(){
//   let levelName = document.getElementById("approval_level_name").value;

//   if(levelName.length === 0){
//     let danger = document.getElementById("approval-name-error");
//     danger.style.display = "block";
//   }else{
//     let modal = document.getElementById("new_team_modal");
//     let overlay = document.getElementById("new_team_overlay");
//     modal.style.display = "none";
//     modal.classList.remove("show_team_modal");
//     overlay.classList.remove("show_team_modal");
    
//   }
// }



