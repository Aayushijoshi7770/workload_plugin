var time_entry_activities=[];
var put_entry=false;
var post_entry=false;
var is_api_success=false;
var is_api_success_post=false;
var is_api_error=false;
var cell_date_on;
var error_message=[];
var put_api_success=false;
var post_api_success=false;

$(document).ready(function(){
  
  document.getElementById("search").blur();
  // function to remove default redmine loader
  removeAjaxIndicator();
  function removeAjaxIndicator() {
    $(document).bind('ajaxSend', function(event, xhr, settings) {
      if ($('.ajax-loading').length === 0 && settings.contentType != 'application/octet-stream') {
      $('#ajax-indicator').hide();   
      }
    });
    $(document).bind('ajaxStop', function() {
      $('#ajax-indicator').hide(); 
    });
  }
  // login end of loader

 // edit log time validation start
  function validateTime(data){
    // var valid=false;
    var newreg = /^(?:\d+(\.\d+)?[hH]?|\d+:\d+)$/;
    let valid = true;
    const commentInputs = document.querySelectorAll('.comment_input');
    const spentTimeInputs = document.querySelectorAll('.spent_time_input');
    const spentTimeInputsold = document.querySelectorAll('.spent_time_old');
    const commentInputsold = document.querySelectorAll('.coments');
    const errorMessages = document.querySelectorAll('.error-msg-plus');
    const errorMessagescomment = document.querySelectorAll('.error-msg-plus-comment');
    const erroroldcomment=document.querySelectorAll(".error-msg-old-comment");
    const erroroldinput=document.querySelectorAll(".error-msg-old-spent");

    commentInputs.forEach((input, index) => {
        const errorMsg = errorMessagescomment[index];

        if (input.value.trim() === '') {
            if(requiredFields&&requiredFields.length!=0)
            {
             requiredFields.map((re)=>{
              if(re==="comments")
              {
                errorMsg.innerText = t("label_error_required");
                errorMsg.parentNode.style.display = 'flex';
                valid=false;  
              }
             })
           }
           else{
            valid = true;
           }
        } else {
            errorMsg.innerText = '';
            errorMsg.parentNode.style.display = 'none';
        }
    });

    commentInputsold.forEach((input, index) => {
      const errorMsg = erroroldcomment[index];
      if (input.value.trim() === '') 
      {
        
        if(requiredFields&&requiredFields.length!=0)
        {
          requiredFields.map((re)=>{
           if(re==="comments")
          {
            errorMsg.innerText = t("label_error_required");
            errorMsg.parentNode.style.display = 'flex';
            valid = false; 
          }
         })
       }
       else{
        valid = true;
       }
      } else {
          errorMsg.innerText = '';
          errorMsg.parentNode.style.display = 'none';
      }
  });

  spentTimeInputsold.forEach((input, index) => {
    const errorMsg = erroroldinput[index ];
    const value = input.value.trim();
    if (value === '') {
        errorMsg.innerText = t("label_error_required");
        errorMsg.parentNode.style.display = 'flex';
        valid = false;
    } 
    else if (value === '0' || value === '0h'||value==="00"|| value==="000"|| value==="0:00") {
      errorMsg.innerText = 'Value should be > 0';
      errorMsg.parentNode.style.display = 'flex';
      valid = false;
    }
    else if(!(newreg.test(value)))
      {
     
          valid=false;  
          errorMsg.innerText = t('label_update_error_number');
          errorMsg.parentNode.style.display = 'flex';
        
       
      }
      else if (/^\d+$/.test(value)&&value.length > 3)
      {
        valid=false;     
        errorMsg.parentNode.style.display = 'flex';
        errorMsg.innerText=t("label_error_three_digit");
          
      }
      else {
        errorMsg.innerText = '';
        errorMsg.parentNode.style.display = 'none';
    }
});

    spentTimeInputs.forEach((input, index) => {
        const errorMsg = errorMessages[index ];
        const value = input.value.trim();
        if (value === '') {
            errorMsg.innerText = t("label_error_required");
            errorMsg.parentNode.style.display = 'flex';
            valid = false;
        } 
        else if (value === '0' || value === '0h'||value==="00"|| value==="000"|| value==="0:00") {
          errorMsg.innerText = t('label_update_error_non_zero');
          errorMsg.parentNode.style.display = 'flex';
          valid = false;
        }
        else if(!(newreg.test(value)))
        {
       
            valid=false;  
            errorMsg.innerText = t('label_update_error_number');
            errorMsg.parentNode.style.display = 'flex';
          
         
        }
        else if (/^\d+$/.test(value)&&value.length > 3)
        {
          valid=false;     
          errorMsg.parentNode.style.display = 'flex';
          errorMsg.innerText=t("label_error_three_digit");
            
        }
          else {
            errorMsg.innerText = '';
            errorMsg.parentNode.style.display = 'none';
        }
    });
     if(budgetauditPluginExists)
      {

  
      if($("#category_project").val()&&$("#category_project").val()!=0)
      {
        valid=true;
        $("#edit_category_error").css("display","none");
        $("#edit_category_error").text("");
        $(".edit_log_time").css("margin-bottom","10px");
      }
      else{
         valid=false;
         $(".edit_log_time").css("margin-bottom","0px");
         $("#edit_category_error").css("display","block");
         $("#edit_category_error").text(t("label_error_category_required"));
       
      }
    }
    if(!valid) {
      is_api_error = false; // Reset the API error flag if validation fails
    }
    return valid;
  }
  // edit log time validation end

  //  on click of log time call put and post api
   
  $("#update").submit(function(event) {
    $("#approvedhour_error").html(" ");
  // Prevent the default form submission behavior
       event.preventDefault();
        var issue_id=$("#issueID").html().replace("#","");
        var parentDiv = document.querySelector('#main_div_log');
        var childDivs = parentDiv.querySelectorAll('.edit_div');
        var valuesArray = [];

        childDivs.forEach(childDiv => {
          valuesArray.push(childDiv.getAttribute('value'));
        });
   
        var formData = new FormData(event.target);
        var comment =  formData.getAll("comment");
        var spent_time = formData.getAll("spent_time");
        var activities = formData.getAll("activity");
        var  date=formData.getAll("logdate");

        var data = comment.map((comments, index) => {
          let spent_h=spent_time[index].includes("h")?spent_time[index].replace("h",""):spent_time[index]
          return Object.assign({}, { comments, hours:spent_h, activity_id: activities[index] , date:date[index], time_entry_id:valuesArray[index] });
        });
    
       
        var comments_add=  formData.getAll("comment_plus");
        var spent_time_add = formData.getAll("spent_time_plus");
        var activities_add= formData.getAll("activity_plus");
        var  date_add=formData.getAll("logdate_add");

        var post_data=comments_add.map((comments, index) => {
          let spent_h=spent_time_add[index].includes("h")?spent_time_add[index].replace("h",""):spent_time_add[index]
          return Object.assign({}, {comments, hours:spent_h, activity_id: activities_add[index],date_add:date_add[index] });
        });

        if(budgetauditPluginExists)
        {
         let content={
           "issue_id":parseInt(issue_id),
           "category_id":parseInt($("#category_project").val()),
         }
         if($("#category_project").val()&&$("#category_project").val()!=0)
          {
            updateIssue(content);
          } 
        }
 
    // PUT API for edit log time Modal start
     if(data.length!=0){
      is_api_success=false;
      if(validateTime(data))
      {
        // console.log("put data")
      put_entry=true;
        data.map((i)=>{
      
          let content={
            "issue_id":issue_id,
            "comments":i.comments,
            "spent_on":i.date,
            "hours":i.hours,
            "activity_id":i.activity_id
          }

      $.ajax({
          type: "PUT",
          url: `${url}/time_entries/${i.time_entry_id}.json?key=${api_key}`,
          dataType: "json",
          contentType: "application/json",
          async: false,
          data: JSON.stringify({
            time_entry: content,
          }),
          success: function (result, status, xhr) {
             put_api_success=true;
             is_api_success=true;
             },
          error: function (xhr, status, error) {

            put_api_success=false;
            is_api_error=true;
              if(xhr.status == 422){
                let content = JSON.parse(xhr.responseText).errors;
                error_message=content;
            }
              else if(xhr.status == 403)
                {
                    toastr["error"]("You don't have permissions");
                } 
              },
            });
          })
          }
      }
      // PUT API of edit log time end 
          
      // POST API of edit log time modal start
       if(post_data.length!=0)
        {
          is_api_success_post=false;
          is_api_success=false;
          if(validateTime(post_data))
          {
          // console.log("<<<POST")
          post_entry=true;
          post_data.map((i)=>{
          let content={
            "issue_id":issue_id,
            "comments":i.comments,
            "spent_on":i.date_add,
            "hours":i.hours,
            "activity_id":i.activity_id
          }
    
      $.ajax({
          type: "POST",
          url: `${url}/time_entries.json?key=${api_key}`,
          dataType: "json",
          contentType: "application/json",
          async: false,
          data: JSON.stringify({
            time_entry: content,
          }),
          success: function (result, status, xhr) {
            post_api_success=true;
             is_api_success=true;
             },
          error: function (xhr, status, error) {
            post_api_success=false;
           if(xhr.status == 422){
             let content = JSON.parse(xhr.responseText).errors;
            content.map((i)=>{
              if(i==="Due date must be greater than start date")
              {
                toastr["error"]("Start date could not be greater than due date");
              }
              else if(i==="Assignee is invalid")
              {
                toastr["error"]("User is not a member of project to  which this issue belongs please check project setting");
              }
              else{
             toastr["error"](i);
             
              }
           })
         }
           else if(xhr.status == 403)
             {
                 toastr["error"]("You don't have permissions");
             } 
          },
        })
      })
    }
  }
// POST API for edit log time Modal end

      
        if(is_api_success==true)
        {
          toastr["success"](t("label_update_log_time_success"));
          $('.edit-modal').hide();
          $('.Editmodal').hide();
          disableTabindex('.Editmodal');
          $(".edit_log_time").css("margin-bottom","10px");
          $("#approvedhour_error").css("display","none");
        }
        if(is_api_error==true)
        {
             error_message.map((i)=>{
              if(i==="Due date must be greater than start date")
              {
                toastr["error"](t("label_error_start_not_greater_than_due"));
              }
              else if(i==="Assignee is invalid")
              {
                toastr["error"](t("label_error_user_not_belong_to_project"));
              }
              else if(i==="Hours not available for this category"){
                $("#approvedhour_error").css("display","block");
                $("#approvedhour_error").text(t("label_error_hours_not_available"));
                $(".edit_log_time").css("margin-bottom","0px");
              }
              else{
               toastr["error"](i);
                
              }
           })
        }
        
      if(put_api_success==true)
      {
         callAPI();
      }
       else if(post_api_success==true)
      {
        callAPI();
      }
       else if(put_api_success&&post_api_success)

      {
        callAPI();
      }
  })
  // on click of update button POST and PUT API end 



    // get API page load main api 
    function callAPI(){
      if(is_selected_team&&is_selected_team!=0)
     {
      getTotalActvitiesbyTeam(is_selected_team);
        teamperpage=10;
       teampageNum=1;
       getteamsData();
    }
    else{
      perpage=20;
      pagenum=1;
      getTotalActvities();
      getuserData();
     }
   }

    // on click of delete icon code start
    window.deleteTimeEntry=function(id){
      $.ajax({
        type: "DELETE",
        url: `${url}/time_entries/${id}.json?key=${api_key}`,
        dataType: 'json',
        async:false,
        success: function (result, status, xhr) {
          $('#time_entry'+id).remove();
           var $myDiv = $('#main_div_log'); 
           $myDiv.css('overflow-y', 'revert');
           $myDiv.css('height', 'auto');  
           let is_deleted=true;
           if(is_deleted)
           {
            callAPI();
            toastr["success"](t("label_delete_time_entry_success"));
            $('.edit-modal').hide();
            $('.Editmodal').hide();
            disableTabindex('.Editmodal');
           }  
        },
        error: function (xhr, status, error) {
       
         if(xhr.status == 403)
           {
            alert("unauthorized");
          }
        }
      });
    }


    // call users API on click of dropdown
    $(document).on('click', '#current-user', function (event) {
      $("#txtSearchValueuser").val(" ");
    getUsers();
    });  
 
    
})









