var url = window.location.origin;

$(document).ready(function () {
  // language change for timesheet 
  window.t=function(key) {
    const locale=$('html').attr('lang')||'en';
      // Set this dynamically based on the user's selected locale
      return window.I18n.translations[locale][key] || key; // Fallback to key if not found
    }

  var options = {
    auto: true,
    float: true,
    cellHeight: 145,
    minWidth: 600,
    disableOneColumnMode: true,
    row: 3,
    animate: true,
    resizable: {
      handles: "se",
    },
  };

  var grid = GridStack.init();
  $(".grid-stack").gridstack(options);

  setTimeout(() => {
    totalCards = $(".grid-stack-item").length;
  }, 200);

  $(".grid-stack").on("gridstack:load", function (event, items) {
    var grid = event.target.gridstack;

    var updatedOptions = {
      rows: totalCards,
    };
    grid.setGridOption(updatedOptions);
  });

  setTimeout(() => {
    $(".grid-stack-item").on("drag", function (event) {
      var cardTop = $(this).offset().top;
      var cardBottomPosition = $(this).offset().top + $(this).outerHeight();
      var windowHeight =
        $(window).height() + document.documentElement.scrollTop;

      if (cardBottomPosition > windowHeight) {
        document.documentElement.scrollTop += 30;
      }
      if (cardTop < document.documentElement.scrollTop) {
        document.documentElement.scrollTop -= 30;
      }
    });
  }, 200);

  setTimeout(() => {
    grid.on("change", function (event, items) {
      for (var i = 0; i < items.length; i++) {
        var item = items[i];

        grid_Xaxis = item.x;
        grid_Yaxis = item.y;
        width = item.w;
        height = item.h;
        id = item.id;

        var element = document.querySelector('[gs-id="' + id + '"]');
        var elementWidth = element.offsetWidth;

        if (width <= 3) {
          width = 3;
        }
        if (height <= 2) {
          height = 2;
        }

        if (grid_Xaxis == -0 || grid_Xaxis == 0 || grid_Xaxis <= 1) {
          grid_Xaxis = 0;
        } else if (grid_Xaxis == 2 || grid_Xaxis <= 4) {
          grid_Xaxis = 3;
        } else if (grid_Xaxis == 5 || grid_Xaxis <= 7) {
          grid_Xaxis = 6;
        } else {
          grid_Xaxis = 9;
        }

        if (grid_Yaxis == -0) {
          grid_Yaxis = 0;
        }

        const reports_dimention_url = `${url}/update_grids/dimentions.json?key=${api_key}&id=${id}&Height=${height}&Width=${width}&grid_x_axis=${grid_Xaxis}&grid_y_axis=${grid_Yaxis}`;

        fetch(reports_dimention_url)
          .then((response) => {
            if (!response.ok) {
              throw new Error(`HTTP error! Status: ${response.status}`);
            }
            return response.json();
          })
          .then((data) => {})
          .catch((error) => {
            console.error("Fetch error:", error);
          });

        grid.update(element, {
          x: grid_Xaxis,
          y: grid_Yaxis,
          w: width,
          h: height,
        });
      }
    });
  }, 200);

  renderAllGrids();
});

function appendDropDwon(selectElement) {
  const dropDown = document.getElementById("custom_filters");
  const table = document.getElementById("filters-table");

  const operatorsSpentOnSelect = document.getElementById("operators_spent_on");
  const optionThisMonth =
    operatorsSpentOnSelect.querySelector('option[value="m"]');
  const optionAny = operatorsSpentOnSelect.querySelector('option[value="*"]');

  if (
    selectElement.value === "Required Vs filled" ||
    selectElement.value === "Percent Filled"
  ) {
    if (optionThisMonth) {
      optionThisMonth.selected = true;
      optionAny.disabled = true;

      const event = new Event("change");
      operatorsSpentOnSelect.dispatchEvent(event);
    }
  } else {
    if (optionThisMonth) {
      optionThisMonth.selected = false;
      optionAny.selected = true;
      optionAny.disabled = false;

      const event = new Event("change");
      operatorsSpentOnSelect.dispatchEvent(event);
    }
  }

  $.ajax({
    url: `/custom/filters?name=${dropDown.value}`,
    type: "GET",
    success: function (response) {
      table.insertAdjacentHTML("beforeend", response);

      const newSelect = $(".dynamic_drop_down").last();

      if (
        dropDown.value != "Percent Filled" &&
        dropDown.value != "Submission Status" &&
        dropDown.value != "Required Vs filled"
      ) {
        newSelect.select2({
          closeOnSelect: false,
          allowHtml: true,
        });
      }

      const select2Selection = newSelect
        .next(".select2")
        .find(".select2-selection");
      select2Selection.addClass(`hide-${selectElement.value}`);

      if (
        selectElement.value !== "Required Vs filled" &&
        selectElement.value !== "Submission Status" &&
        selectElement.value !== "Empty"
      ) {
        var selectedOption = $(selectElement).find("option:selected");
        selectedOption.prop("disabled", true);
      }

      //Disable or enanble selected input field by using checkboxl
      const teamCheckbox = document.getElementById("Team");
      const roleCheckbox = document.getElementById("Role");
      const groupCheckbox = document.getElementById("Group");
      const statusCheckbox = document.getElementById("Status");
      const categoryCheckbox = document.getElementById("IssueCategory");
      const percentCheckbox = document.getElementById("Percent_Filled");

      const teamInputContainer = document.querySelector(".hide-Team");
      const roleInputContainer = document.querySelector(".hide-Role");

      const groupInputContainer = document.querySelector(".hide-Group");

      const statusInputContainer = document.querySelector(".hide-Status");

      const categoryInputContainer = document.querySelector(".hide-Category");

      const percentInputContainer =
        document.querySelector("#Percent_Filled_id");
      const percentselectContainer = document.querySelector(
        "#percentage_dropdown"
      );
      const percentMinContainer = document.querySelector("#min_value");
      const percentMaxContainer = document.querySelector("#max_value");

      if (teamCheckbox) {
        teamCheckbox.addEventListener("change", function () {
          teamInputContainer.style.opacity = teamCheckbox.checked ? "1" : "0";
          teamInputContainer.style.pointerEvents = teamCheckbox.checked
            ? "auto"
            : "none";
        });
      }

      if (roleCheckbox) {
        roleCheckbox.addEventListener("change", function () {
          roleInputContainer.style.opacity = roleCheckbox.checked ? "1" : "0";
          roleInputContainer.style.pointerEvents = roleCheckbox.checked
            ? "auto"
            : "none";
        });
      }

      if (groupCheckbox) {
        groupCheckbox.addEventListener("change", function () {
          groupInputContainer.style.opacity = groupCheckbox.checked ? "1" : "0";
          groupInputContainer.style.pointerEvents = groupCheckbox.checked
            ? "auto"
            : "none";
        });
      }

      if (statusCheckbox) {
        statusCheckbox.addEventListener("change", function () {
          statusInputContainer.style.opacity = statusCheckbox.checked
            ? "1"
            : "0";
          statusInputContainer.style.pointerEvents = statusCheckbox.checked
            ? "auto"
            : "none";
        });
      }

      if (categoryCheckbox) {
        categoryCheckbox.addEventListener("change", function () {
          categoryInputContainer.style.opacity = categoryCheckbox.checked
            ? "1"
            : "0";
          categoryInputContainer.style.pointerEvents = categoryCheckbox.checked
            ? "auto"
            : "none";
        });
      }

      if (percentCheckbox) {
        percentCheckbox.addEventListener("change", function () {
          percentInputContainer.style.opacity = percentCheckbox.checked
            ? "1"
            : "0";
          percentselectContainer.style.opacity = percentCheckbox.checked
            ? "1"
            : "0";

          percentInputContainer.style.pointerEvents = percentCheckbox.checked
            ? "auto"
            : "none";
          percentselectContainer.style.pointerEvents = percentCheckbox.checked
            ? "auto"
            : "none";
        });
      }

      var percentFilledDropdown = document.getElementById("Percent_Filled_id");

      if (percentFilledDropdown) {
        // Remove existing event listener
        percentFilledDropdown.removeEventListener("change", changeHandler);

        // Define event handler
        function changeHandler() {
          var selectedOperator = percentFilledDropdown.value;
          var percentageDropdown = document.getElementById(
            "percentage_dropdown"
          );

          var minInput = document.getElementById("min_value");
          var maxInput = document.getElementById("max_value");
          var minLabel = document.querySelector('label[for="min_value"]');
          var maxLabel = document.querySelector('label[for="max_value"]');

          // Remove existing input fields and labels if they exist
          if (minInput) minInput.parentNode.removeChild(minInput);
          if (maxInput) maxInput.parentNode.removeChild(maxInput);
          if (minLabel) minLabel.parentNode.removeChild(minLabel);
          if (maxLabel) maxLabel.parentNode.removeChild(maxLabel);

          if (selectedOperator === "between" && percentageDropdown) {
            percentageDropdown.style.display = "none";

            minLabel = document.createElement("label");
            minLabel.setAttribute("for", "min_value");
            minLabel.textContent = "Min:";
            minInput = document.createElement("input");
            minInput.setAttribute("type", "text");
            minInput.setAttribute("id", "min_value");

            maxLabel = document.createElement("label");
            maxLabel.setAttribute("for", "max_value");
            maxLabel.textContent = "Max:";
            maxInput = document.createElement("input");
            maxInput.setAttribute("type", "text");
            maxInput.setAttribute("id", "max_value");

            // Append labels and input fields
            percentageDropdown.parentNode.appendChild(minLabel);
            percentageDropdown.parentNode.appendChild(minInput);
            percentageDropdown.parentNode.appendChild(maxLabel);
            percentageDropdown.parentNode.appendChild(maxInput);
          } else {
            if (percentageDropdown) {
              percentageDropdown.style.display = "block";
            }
          }
        }

        // Attach event listener
        percentFilledDropdown.addEventListener("change", changeHandler);
      }
    },
    errors: function () {
      console.log("Error fatching partial", error);
    },
  });
}

function callGetReports() {
  var options = {
    auto: true,
    float: true,
    cellHeight: 145,
    disableOneColumnMode: true,
    row: 6,
    animate: true,
    resizable: {
      handles: "se",
    },
  };

  var grid = GridStack.init();
  $(".grid-stack").gridstack(options);
  grid.removeAll();

  setTimeout(() => {
    totalCards = $(".grid-stack-item").length;
  }, 200);

  $(".grid-stack").on("gridstack:load", function (event, items) {
    var grid = event.target.gridstack;

    var updatedOptions = {
      rows: totalCards,
    };

    grid.setGridOption(updatedOptions);
  });

  setTimeout(() => {
    $(".grid-stack-item").on("drag", function (event) {
      var cardTop = $(this).offset().top;
      var cardBottomPosition = $(this).offset().top + $(this).outerHeight();
      var windowHeight =
        $(window).height() + document.documentElement.scrollTop;

      if (cardBottomPosition > windowHeight) {
        document.documentElement.scrollTop += 30;
      }
      if (cardTop < document.documentElement.scrollTop) {
        document.documentElement.scrollTop -= 30;
      }
    });
  }, 200);
  renderAllGrids();
}

function DeleteChart(id) {

  const errorExplanation = document.getElementById("errorExplanation");

  const successDiv = document.getElementById("flash_notice");

  fetch(`${url}/delete_reports/${id}.json?key=${api_key}`, {
    method: "DELETE",
    headers: {
      "Content-Type": "application/json",
    },
  })
    .then((response) => {
      if (response.ok) {
        let background_div = document.getElementsByClassName("div-modal");
        background_div[0].style.display = "none";
        $(`#delete${id}`).css("display", "none");
        disableTabindex(".delete-modal");

        const elements = document.querySelectorAll(".grid-stack-item");
        for (let i = 0; i < elements.length; i++) {
          const element = elements[i];
          if (element.getAttribute("gs-id") == id) {
            element.remove();
            break;
          }
        }
        callGetReports();

        errorExplanation.style.display = "none";
      
        successDiv.textContent = t("label_delete_report_timesheet");
        successDiv.style.display = "block"; 
      } else {
        console.error("Failed to delete the report.");
      }
    })
    .catch((error) => {
      console.error("Network error:", error);
    });
}

function createChart() {
  const errorExplanation = document.getElementById("errorList");
  errorExplanation.innerHTML = ''; 

  const successDiv = document.getElementById("flash_notice");
  successDiv.style.display = "none"; 

  const data = {};

  let hasValidationError = false;

  var query_name = document.getElementById("custom_filters");
  var query_name_by_selected_value = query_name.value;
  var chart_type;

  const teamCheckbox = document.getElementById("Team");
  if (teamCheckbox && teamCheckbox.checked) {
    const teamSelect = document.getElementById("_Team_ids_");
    if (teamSelect) {
      const selectedTeamValues = Array.from(teamSelect.selectedOptions).map(
        (option) => option.value
      );
      if (selectedTeamValues.length > 0) {
        data["team_id"] = {
          operator: "=",
          values: selectedTeamValues,
        };
      } else {
        const errorLi = document.createElement("li");
        errorLi.textContent = `Please provide a value for team.`;
        errorExplanation.appendChild(errorLi);
        hasValidationError = true;
      }
    }
  }

  const categoriesCheckbox = document.getElementById("IssueCategory");
  if (categoriesCheckbox && categoriesCheckbox.checked) {
    const categorySelect = document.getElementById("_IssueCategory_ids_");
    if (categorySelect && categorySelect.value !== "") {
      data["category_id"] = {
        operator: "=",
        values: Array.from(categorySelect.selectedOptions).map(
          (option) => option.value
        ),
      };

      const projectSelect = document.getElementById("values_project_id_1");
      if (!projectSelect || projectSelect.value === "") {
        const errorLi = document.createElement("li");
        errorLi.textContent = `Please select a project when choosing a category.`;
        errorExplanation.appendChild(errorLi);
        hasValidationError = true;
      }
    } else {
      const errorLi = document.createElement("li");
      errorLi.textContent = `Please provide a value for category.`;
      errorExplanation.appendChild(errorLi);
      hasValidationError = true;
    }
  }

  const roleCheckbox = document.getElementById("Role");
  if (roleCheckbox && roleCheckbox.checked) {
    const roleSelect = document.getElementById("_Role_ids_");
    if (roleSelect) {
      const selectedRoleValues = Array.from(roleSelect.selectedOptions).map(
        (option) => option.value
      );
      if (selectedRoleValues.length > 0) {
        data["role_id"] = {
          operator: "=",
          values: selectedRoleValues,
        };
      } else {
        const errorLi = document.createElement("li");
        errorLi.textContent = `Please provide a value for roles.`;
        errorExplanation.appendChild(errorLi);
        hasValidationError = true;
      }
    }
  }

  const statusCheckbox = document.getElementById("Status");
  if (statusCheckbox && statusCheckbox.checked) {
    const statusSelect = document.getElementById("_Status_ids_");
    if (statusSelect) {
      const selectedStatusValues = Array.from(statusSelect.selectedOptions).map(
        (option) => option.value
      );
      if (selectedStatusValues.length > 0) {
        data["status_id"] = {
          operator: "=",
          values: selectedStatusValues,
        };
      } else {
        const errorLi = document.createElement("li");
        errorLi.textContent = `Please provide a value for status.`;
        errorExplanation.appendChild(errorLi);
        hasValidationError = true;
      }
    }
  }

  const groupCheckbox = document.getElementById("Group");
  if (groupCheckbox && groupCheckbox.checked) {
    const groupSelect = document.getElementById("_Group_ids_");
    if (groupSelect) {
      const selectedGroupValues = Array.from(groupSelect.selectedOptions).map(
        (option) => option.value
      );
      if (selectedGroupValues.length > 0) {
        data["group_id"] = {
          operator: "=",
          values: selectedGroupValues,
        };
      } else {
        const errorLi = document.createElement("li");
        errorLi.textContent = `Please provide a value for group.`;
        errorExplanation.appendChild(errorLi);
        hasValidationError = true;
      }
    }
  }

  const percentFilledCheckbox = document.getElementById("Percent_Filled");
  const percentFilledSelect = document.getElementById("Percent_Filled_id");
  if (percentFilledCheckbox && percentFilledCheckbox.checked) {
    const selectedOperator = percentFilledSelect.value;
    if (selectedOperator === "between") {
      const minValue = document.getElementById("min_value").value;
      const maxValue = document.getElementById("max_value").value;

      if (minValue && maxValue) {
        data["percent_Filled_id"] = {
          operator: "between",
          values: [minValue, maxValue],
        };
      } else {
        const errorLi = document.createElement("li");
        errorLi.textContent = `Please provide both Min and Max values for percent filled.`;
        errorExplanation.appendChild(errorLi);
        hasValidationError = true;
      }
    } else {
      const percentFilledValuesSelect = document.getElementById(
        "percentage_dropdown"
      );
      const selectedPercentFilledValue = percentFilledValuesSelect.value;

      if (selectedPercentFilledValue !== "") {
        data["percent_Filled_id"] = {
          operator: selectedOperator,
          values: [selectedPercentFilledValue],
        };
      } else {
        const errorLi = document.createElement("li");
        errorLi.textContent = `Please select a value for percent filled.`;
        errorExplanation.appendChild(errorLi);
        hasValidationError = true;
      }
    }
  }

  const fieldMapping = {
    "Issue's Tracker": "issue_tracker_id",
    "Issue's Status": "issue_status_id",
    "Issue's Target version": "issue_target_version_id",
    "Project's Status": "project_status",
  };

  const filtersTable = document.getElementById("filters-table");
  const filterRows = filtersTable.querySelectorAll(".filter");

  filterRows.forEach((row) => {
    const checkbox = row.querySelector(".field input[type='checkbox']");
    if (checkbox && checkbox.checked) {
      const rowId = row.id;

      var field = "";

      if (
        rowId.startsWith("tr_issue_cf_") ||
        rowId.startsWith("tr_project_cf_")
      ) {
        field = rowId;
      } else {
        const fieldLabel = row.querySelector(".field label");
        field =
          fieldMapping[fieldLabel.textContent.trim()] ||
          fieldLabel.textContent.trim();
      }

      const operatorSelect = row.querySelector(".operator select");
      const operator = operatorSelect.value;

      const values = [];
      const valueInputs = row.querySelectorAll(".values input, .values select");

      valueInputs.forEach((input) => {
        if (input.tagName === "INPUT") {
          if (input.type === "date" || input.type === "text") {
            const trimmedValue = input.value.trim();
            if (trimmedValue !== "") {
              values.push(trimmedValue);
            }
          }
        } else if (input.tagName === "SELECT") {
          if (input.multiple) {
            const selectedOptions = Array.from(input.selectedOptions);
            values.push(...selectedOptions.map((option) => option.value));
          } else {
            if (input.value.trim() !== "") {
              values.push(input.value.trim());
            }
          }
        }
      });
      if (
        operator === "*" ||
        operator === "!*" ||
        operator === "y" ||
        operator === "lm" ||
        operator === "lw" ||
        operator === "m" ||
        operator === "l2w" ||
        operator === "w" ||
        operator === "ld" ||
        operator === "t"
      ) {
        values.push("");
      }
      if (values.length === 0) {
        const fieldLabel = row.querySelector(".field label");
        let fieldName = fieldLabel.textContent.trim();
        const errorLi = document.createElement("li");
        errorLi.textContent = `Please provide a value for ${fieldName}.`;
        errorExplanation.appendChild(errorLi);
        hasValidationError = true;
      }

      if (operator === "between" && values.length === 2) {
        data[field] = {
          operator: operator,
          values: values,
        };
      } else if (operator !== "between" && values.length > 0) {
        data[field] = {
          operator: operator,
          values: values,
        };
      }
    }
  });

  if (hasValidationError) {
    errorExplanation.parentNode.style.display = "block"; 
    return;
  } else {
    errorExplanation.parentNode.style.display = "none"; 
  }
  var group_by = document.getElementById("reports_group_by_filter");
  var group_by_selected_value = group_by.value;

  const apiUrl = `${url}/create_reports.json?key=${api_key}`;
  const headers = {
    "Content-Type": "application/json",
  };

  if (
    query_name_by_selected_value === "Submission Status" ||
    query_name_by_selected_value === "Required Vs filled" ||
    query_name_by_selected_value === "Team" ||
    query_name_by_selected_value === "Role" ||
    query_name_by_selected_value === "Group" ||
    query_name_by_selected_value === "Status" ||
    query_name_by_selected_value === "Category" ||
    query_name_by_selected_value === "Percent Filled"
  ) {
    chart_type = "bar";
  } else {
    chart_type = "donut";
  }

  var queryData = {
    filters: data,
    group_by: group_by_selected_value,
    chart_type: chart_type,
    query_name: query_name_by_selected_value,
  };

  fetch(apiUrl, {
    method: "POST",
    headers: headers,
    body: JSON.stringify(queryData),
  })
    .then((response) => {
      if (!response.ok) {
        throw new Error("Request failed");
      }
      return response.json();
    })
    .then((responseData) => {
      if (responseData && responseData.id) {
        createGridItem(
          responseData.id,
          responseData.filters,
          responseData.group_by,
          responseData.chart_type,
          responseData.query_name
        );
        errorExplanation.parentNode.style.display = "none";

        successDiv.textContent = t("label_report_create_success");
        successDiv.style.display = "block";
      } else {
        console.error("Invalid responseData format:", responseData);
      }
    });
}

function createGridItem(id, filters, group_by_reports, chart_type, query_name) {
  $(".nodata").css("display", "none");
  const grid = GridStack.init();

  const content = `
  <div id="query_heading${id}" class="color" style="background: #d1ebfa; height: 25px;"></div>
  <div id="chart_id${id}" title="Chart Settings" onclick="Chartsetting(${id})"><img class="setting" style="width: 15px; margin-top: -19px; cursor: pointer; margin-left: 24px; margin-right:40px; float: right;" src="/plugin_assets/redmineflux_timesheet/images/chart_setting.svg"></div>
    <div class="card_icons">
      <a title="Close"  tabindex="0" class="icon-only icon-close close${id} null" style="margin-right: 5px; margin-top: 17px;" onclick="Closecontainer(${id})" onkeypress="if(event.key === 'Enter') Closecontainer(${id})"></a>
    </div>
    <div class="chart_class" id="chart${id}" style="height: 300px;"></div>
    <div class="ui-resizable-handle ui-resizable-se" style="z-index: 100; user-select: none;"></div>
  `;

  grid.addWidget({
    id: id,
    w: 3,
    h: 2,
    content: content,
  });

  $.ajax({
    url: `${url}/chart/show`,
    method: "GET",
    data: {
      filters: filters,
      grid_id: id,
      group_by: group_by_reports,
      chart_type: chart_type,
      query_name: query_name,
    },
    dataType: "html",
    success: function (response) {
      $(`#chart${id}`).html(response);
    },
    error: function (xhr, status, error) {
      console.error("AJAX request failed:", status, error);
    },
  });
}

function renderAllGrids() {
  var numRequests = 0;

  function hideLoader() {
    numRequests--;
    if (numRequests <= 0) {
      $(".circle-loader-reports").hide();
      $(".unknown-div").css("display", "none");
    }
  }

  $.ajax({
    url: `${url}/get_all_reports.json?key=${api_key}`,
    method: "GET",
    dataType: "json",
    beforeSend: function () {
      numRequests++;
      let body_div = document.querySelector(
        ".controller-timesheet_reports.action-index"
      );
      let div = document.createElement("div");
      div.className = "unknown-div";
      div.style.display = "block";
      body_div.appendChild(div);
      $(".circle-loader-reports").show();
    },
    success: function (data) {
      if (data.length > 0) {
        $(".nodata").css("display", "none");

        numRequests = data.length;

        data.sort(function (a, b) {
          return a.id - b.id; // Change fieldName to the actual field you want to sort by
        });

        data.forEach(function (query) {
          var filters = query.filters;
          var grid_id = query.id;
          var group_by_reports = query.group_by;
          var grid_height = query.Height || 2;
          var grid_width = query.Width || 3;
          var grid_x_axis = query.grid_x_axis;
          var grid_y_axis = query.grid_y_axis;
          var chart_type = query.chart_type;
          var query_name = query.query_name;

          var grid = GridStack.init();

          grid.addWidget({
            id: grid_id,
            w: grid_width,
            h: grid_height,
            x: grid_x_axis,
            y: grid_y_axis,
            content: `
              <div id="query_heading${grid_id}" class="color" style="background: #d1ebfa; height: 25px;"></div>
              <div id="chart_id${grid_id}" title="Chart Settings" onclick="Chartsetting(${grid_id})"><img class="setting" style="width: 15px; margin-top: -19px; cursor: pointer; margin-left: 24px; margin-right:40px; float: right;" src="/plugin_assets/redmineflux_timesheet/images/chart_setting.svg"></div>
              <div class="card_icons">
                <a title="Close"  tabindex="0" class="icon-only icon-close close${grid_id} null" style="margin-right: 5px; margin-top: 17px;" onclick="Closecontainer(${grid_id})"onkeypress="if(event.key === 'Enter') Closecontainer(${grid_id})"></a>
              </div>
              <div class="chart_class" id="chart${grid_id}" style="height: 300px;"></div>
              <div class="ui-resizable-handle ui-resizable-se" style="z-index: 100; user-select: none;"></div>
            `,
          });

          $.ajax({
            url: `${url}/chart/show`,
            method: "GET",
            data: {
              filters: filters,
              grid_id: grid_id,
              group_by: group_by_reports,
              chart_type: chart_type,
              query_name: query_name,
            },
            dataType: "html",
            success: function (response) {
              $(`#chart${grid_id}`).html(response);
              hideLoader();
            },
            error: function () {
              hideLoader();
            },
            complete: function () {
              hideLoader();
            },
          });
        });
        hideLoader();
      } else {
        $(".nodata")
          .text("No reports available right now")
          .css("display", "block");
        hideLoader();
      }
    },
    error: function (xhr, status, error) {
      console.error("AJAX request failed:", status, error);
      hideLoader();
    },
  });
}

window.Closecontainer = function (cardId) {
  let background_div = document.getElementsByClassName("div-modal");
  background_div[0].style.display = "block";
  $(".chart-search").hide();

  if ($(`#delete${cardId}`).length === 0) {
    $("body").append(`<div  id="delete${cardId}" class="delete-modal">
                              <div style="display:flex; justify-content:space-between;" class="heading-div">
                               <div style="display:flex;">
                                  <h2 class="delete-heading">${t('delete_report_heading')}</h2>
                               </div>
                            <div onclick="ClosedeleteModal(${cardId})" style="display:flex; cursor:pointer;">
                               <img style="width:12.8px; height:12.8px;" src="/plugin_assets/redmineflux_timesheet/images/cross.svg">
                            </div>
                          </div> 
                            <p class="delete-para"> ${t('text_delete_report_message')}</p>
                          <div style="display:flex; justify-content:center;">
                            <div id="btn-plan" onclick="ClosedeleteModal(${cardId})" style="display:flex; margin-right:15px; cursor:pointer">
                              <button  id="cancel-btn" style="cursor:pointer" class="button-plan">${t('Cancel')} </button>
                             </div>
                           <div onclick="DeleteChart(${cardId})" type="button" style="display:flex; cursor:pointer">
                             <button id="save-btn" style="cursor:pointer" class="button-cross">${t('Delete')}  </button>
                            </div>
                        </div>
                      </div>`);
  } else {
    $(`#delete${cardId}`).css("display", "block");
  }
  disableTabindex(".delete-modal");
};

function ClosedeleteModal(id) {
  let background_div = document.getElementsByClassName("div-modal");
  background_div[0].style.display = "none";
  $(`#delete${id}`).css("display", "none");
  disableTabindex(".delete-modal");
}

function clearFilter() {
  window.location.href = `${url}/timesheet_reports`;
}

window.Chartsetting = function (cardId) {
  let background_div = document.getElementsByClassName("div-modal");
  background_div[0].style.display = "block";
  $(".chart-search").hide();

  $.ajax({
    url: `${url}/get_all_reports.json?key=${api_key}`,
    method: "GET",
    dataType: "json",
    async: false,
    success: function (response) {
      gridData = response;
      const chartData = gridData.find((chart) => chart.id === cardId);
      if (chartData) {
        var chart_type = chartData.chart_type;
        var chart_filter = chartData.filters;
        var query_name = chartData.query_name;

        // var chart_filter_data = chart_filter
        //   .replace(/"=>/g, '":')
        //   .replace(/"([^"]+)"\s*:/g, '"$1":');
        // var convertedData = JSON.parse('{' + chart_filter_data.slice(1, -1) + '}');
        // var chartOptions = "";

        if (
          query_name === "Submission Status" ||
          query_name === "Required Vs filled" ||
          query_name === "Team" ||
          query_name === "Role" ||
          query_name === "Group" ||
          query_name === "Status" ||
          query_name === "Category" ||
          query_name === "Percent Filled"
        ) {
          chartOptions = `
              <option value="" selected disabled>Please select type </option>
              <option class="bar" value="bar">Bar Chart</option>
              <option class="line" value="line">Line Chart</option>
              <option class="area" value="area">Area Chart</option>
            `;
        } else {
          chartOptions = `
              <option value="" selected disabled>Please select type </option>
              <option class="pie" value="pie">Pie Chart</option>
              <option class="donut" value="donut">Donut Chart</option>
              <option class="polar" value="polarArea">Polar Chart</option>
            `;
        }

        if ($(`#setting${cardId}`).length === 0) {
          $("body").append(`<div  id="setting${cardId}" class="setting-modal">
                              <div style="display:flex; justify-content:space-between;" class="heading-div">
                               <div style="display:flex;">
                                  <h2 class="setting-heading">${t('setting')}</h2>
                               </div>
                            <div onclick="closeSetting(${cardId})" style="display:flex; cursor:pointer;">
                               <img style="width:14px; margin-top:-2px;" src="/plugin_assets/redmineflux_timesheet/images/cross.svg">
                            </div>
                          </div> 
      
                            <div class='select_type' style="display:flex; flex-direction:column; margin-top:10px">
                            <label class="label-chart" style="font-size: 15px !important;">${t('choose_chart_type')}</label>
                            <select class="chart_selection" id="chart_type${cardId}" style="height: 35px;">
                            ${chartOptions}
                            </select>
                          </div>
      
                          <div id="updateChart${cardId}"  style="display:flex; justify-content:flex-end; margin-top:30px;">
                            <div id="btn-plan" onclick="closeSetting(${cardId})" style="display:flex; margin-right:15px; cursor:pointer">
                              <button  id="cancel-btn" style="cursor:pointer" class="button-plan">${t('Cancel')} </button>
                             </div>
                           <div  onclick="saveChart(${cardId})" type="button" style="display:flex;">
                             <button  id="save-btn"  class="button-cross" disabled>${t('save')} </button>
                            </div>
                        </div>
                      </div>`);
        } else {
          $(`#setting${cardId}`).css("display", "block");
        }
        disableTabindex(".setting-modal");

        if (chart_type) {
          $(`#chart_type${chartData.id}`).val(chart_type);
        }
      }
    },
  });


  document.querySelector(`#updateChart${cardId} #save-btn`).disabled = true;
  document.querySelector(`#updateChart${cardId} #save-btn`).style.cursor = "not-allowed";
// Select all input fields with the class 'your-class'
var inputs = document.querySelectorAll('.chart_selection');

// Add an 'input' event listener to each input field
  inputs.forEach(function(input) {
  input.addEventListener('input', function() {
    // Enable the button when an input field receives input
    document.querySelector(`#updateChart${cardId} #save-btn`).disabled = false;
    document.querySelector(`#updateChart${cardId} #save-btn`).style.cursor = "pointer";
  });
});

};

function closeSetting(id) {
  let background_div = document.getElementsByClassName("div-modal");
  background_div[0].style.display = "none";
  $(`#setting${id}`).css("display", "none");
  disableTabindex(".setting-modal");
}

function saveChart(grid_id) {

  const errorExplanation = document.getElementById("errorExplanation");
  

  const successDiv = document.getElementById("flash_notice");

  var selectedType = document.getElementById(`chart_type${grid_id}`);
  var chart_type = selectedType.options[selectedType.selectedIndex].value;

  fetch(`${url}/update_setting/${grid_id}.json?key=${api_key}`, {
    method: "PUT",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ chart_type: chart_type }),
  })
    .then((response) => response.json())
    .then((data) => {
      let background_div = document.getElementsByClassName("div-modal");
      background_div[0].style.display = "none";
      $(`#setting${grid_id}`).css("display", "none");

      if (data && data.id) {
        rederUpdatedChart(
          data.id,
          data.filters,
          data.group_by,
          data.chart_type,
          data.query_name
        );

        errorExplanation.style.display = "none";

        disableTabindex(".setting-modal");

        successDiv.textContent = t('label_update_chart_type');
        successDiv.style.display = "block"; 
      }
    })
    .catch((error) => {
      console.error("Error updating chart type:", error);
    });
}

function rederUpdatedChart(grid_id, filters, group_by, chart_type, query_name) {
  var chartElement = document.getElementById("chart" + grid_id);
  $.ajax({
    url: `${url}/chart/show`,
    method: "GET",
    data: {
      filters: filters,
      grid_id: grid_id,
      group_by: group_by,
      chart_type: chart_type,
      query_name: query_name,
    },
    dataType: "html",
    success: function (response) {
      if (chartElement instanceof Element) {
        var newChart = $("<div>", { id: "chart" + grid_id });
        $(chartElement).replaceWith(newChart);
      }


      $(`#chart${grid_id}`).html(response);
    },
    error: function (xhr, status, error) {
      console.error("AJAX request failed:", status, error);
    },
  });
}

window.disableTabindex = function (modalSelector) {
  if ($(modalSelector).is(":visible")) {
    $(":tabbable").attr("tabindex", -1);
    $(modalSelector + " [tabindex='-1']").attr("tabindex", 0);
    $("html").css("overflow", "hidden");
  } else {
    $("[tabindex]").removeAttr("tabindex");
    $("html").css("overflow", "auto");
  }
};
