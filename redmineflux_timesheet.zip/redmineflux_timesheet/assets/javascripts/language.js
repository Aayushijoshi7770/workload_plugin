// $(document).ready(function(){
//     var translations = {
//         en: {
//           addNewItem: "New Checklist Item",
//           save: "Save",
//           add: "Add",
//           edit: "Edit",
//           delete: "Delete",
//           new: 'New',
//             in_progress: 'In Progress',
//             done: 'Done',
//         },
//         ar: {
//           addNewItem: "عنصر قائمة جديد",
//           save: "حفظ",
//           add: "أضف",
//           edit: "تعديل",
//           delete: "حذف",
//           new: 'جديد',
//         in_progress: 'قيد التقدم',
//         done: 'منجز',
//         }
//       };  
//     var currentLanguage = $('html').attr('lang') || 'en' ;  
// })

 