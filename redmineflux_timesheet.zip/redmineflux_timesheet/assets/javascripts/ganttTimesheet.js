var total_pages;
var start;
var end ;
var perpage=15;
var pagenum=1;
var resource_data=[];
var is_search="";
var skills="";
var team="";
var spent_date;
var GanttIssueid;
var start_range;
var due_range;
var storedStart;
var storedEnd;
var uniqueIssues;
var timesheet={};
var is_selected_team=0;
var is_workload_imported=false;
var is_timesheet_submitted=false;
var check_timesheet=false;
var is_unsubmit=true;
let timesheet_status=null;
let level_status=null;
var logTimeClicked=false;
var  teamperpage=10;
var teampageNum=1;
var teamtotalPages;


// get values of url params if redirected
let params =window.location.search
let parameters = new URLSearchParams(params);

const start_date=parameters.get('start_date');
const end_date=parameters.get('end_date');
const  user_id = parameters.get('user_id');
const user_name=parameters.get('user_name');
let tstatus=parameters.get('status');




$(document).ready(function(){

 
  // latest code......
    // // initialize gantt element
    var element = document.getElementById("gantt_here"); 
     window.gantt = new ztGantt(element);

    var is_admin=false;
    var user_hour;
     // gantt options
    gantt.options.scale_height = 50;
    gantt.options.row_height = 50;
    gantt.options.bar_height = 40;
    gantt.options.todayMarker = false; 
    gantt.options.weekends = ["Sat", "Sun"];
    gantt.options.date_format="%Y-%m-%d"; 
    gantt.options.minColWidth = 50; 

    let input = document.getElementById('tree-select-input');
    let dropdown1 = document.getElementById('tree-select-dropdown');

    // language change for timesheet 
    window.t=function(key) {
    const locale=$('html').attr('lang')||'en';

  const translations = window.I18n.translations;

  // Try to find the translation in the selected locale, then fallback to English
      if (translations[locale] && translations[locale][key]) {
        return translations[locale][key];
      } else if (translations['en'] && translations['en'][key]) {
        console.warn(`Missing translation for key: "${key}" in locale: "${locale}". Falling back to English.`);
        return translations['en'][key];  // Fallback to English if not found in the selected locale
      } else {
        console.warn(`Missing translation for key: "${key}" in both Arabic and English.`);
        return key;  // If the key is not found in either language, return the key itself
      }
    }
  
  
    // permission API to check if user is admin or not 
  $.ajax({
    type: "GET",
    url: url+`/timesheet_permissions.json?key=${api_key}`,
    dataType: "json",
    contentType: 'application/json',
    async:false,
    success: function (result, status, xhr) {
    if (result.approve_timesheet === true || result.admin === true){
      $("#timesheet_team").css("display","flex");
      is_admin=true;
      fetchTimesheetTeam();
    }
    else{
      is_admin=false;
      $("#timesheet_team").css("display","none");
    }
    }          
    });
    // permission API end


    // gantt columns left side start
    var textFilter = `<div class='searchEl'>Issue <span tabindex = '0' onclick='AddIssue()' onkeypress='if(event.keyCode === 13) AddIssue()' class='button_issue'>${t('log_time')}</span></div>`;

      gantt.options.columns=[
        {name:"text", tree: !0,   min_width: 230,  max_width: 450, label:textFilter,width:250,  resize:true ,template: function (task) {
          if(task.parent==0)
          {
            return `<div>${task.text}</div>`;
          }
          else{
            return `<div class="two-line-name"><div class="project_name"><b>${task.project_name}</b></div><div class="issue_name" >${task.text}</div></div>`
          }   
       }
        },
        {name:`activity_name`,label:t('Activity'),
           align: "center" ,width:100 ,template: function(task){
            return task.activity_name
         }},
       ];

        // gantt column right side end       
       gantt.options.rightGrid = 
             [
                {
                    name: "spent_hours", label: t('total'), min_width: 90,  resize:true, max_width: 120, width:80,  align: "center",template: function(task)
                    {
                      var totalHours = 0;
                        if(task.parent!=0)
                        {

                          if(task.dates&&task.dates.length!=0)
                          {
                          for (let i = 0; i < task.dates.length; i++) {
                            if(task.time_format==="minutes")
                            {
                              var timeArray = task.dates[i].hours.split(":");
                              totalHours+= parseInt(timeArray[0]) + parseInt(timeArray[1]) / 60; 
                            }
                            else{
                              totalHours += task.dates[i].hours;
                            }
                           
                          }
                        }
                        if(task.time_format==="decimal"&&Number.isInteger(totalHours))
                        {
                          totalHours=totalHours
                        }
                        else if(task.time_format==="decimal"){
                          totalHours=totalHours.toFixed(2)
                        }
                        else{
                          const hourPart = Math.floor(totalHours);
                          const minutePart = Math.round((totalHours  - hourPart) * 60);
                          const minutePartWithZero = String(minutePart).padStart(2, '0');
                          totalHours=hourPart+":"+minutePartWithZero;
                        }
                  
                         return  `<b>${totalHours}</b>`;
                        }
                        else{
                            return `<b>${task.spent_hours}</b>`;
                        }
                    }
                },
                {
                    name: "Stats", width: 150, label: t('statistics'),  align: "center", template: function (task) {
                    
                          let width=0;
                          let color="#29435C";
                          let totalHours = 0;
                          var Estimated_hours;
                          var estimated_h=0;
                          var spent_time=0;
                          if(task.parent!=0)
                          {
                            if(task.dates&&task.dates.length!=0)
                            {
                            for (let i = 0; i < task.dates.length; i++) {
                              if(task.time_format==="minutes")
                              {
                                var timeArray = task.dates[i].hours.split(":");
                                totalHours+= parseInt(timeArray[0]) + parseInt(timeArray[1]) / 60; 
                              }
                              else{
                                totalHours += task.dates[i].hours;
                              }
                            }
                          }
                          if(task.time_format==="decimal"&&Number.isInteger(totalHours))
                          {
                            totalHours=totalHours
                          }
                          else if(task.time_format==="decimal"){
                            totalHours=totalHours.toFixed(2)
                          }
                          else{
                            const hourPart = Math.floor(totalHours);
                            const minutePart = Math.round((totalHours  - hourPart) * 60);
                            const minutePartWithZero = String(minutePart).padStart(2, '0');
                            totalHours=hourPart+":"+minutePartWithZero;
                          }
                          spent_time=totalHours;
                          }
                          else{
                            if(task.parent==0&&task.children.length!=0)
                            {
                              spent_time=task.spent_hours;;
                            }
                            else{
                              spent_time=task.time_format=="minutes"?"0:00":0;
                            }
            
                          }
                            if(task.parent==0)
                            {
                              const processedIssueIds = new Set();
                              gantt.options.data.map((options)=>{
                                options.children.map((list)=>{
                                  if(list.parent==task.id && !processedIssueIds.has(list.issue_id  + '_'+ list.parent))
                                    {
                                      if(task.time_format==="minutes")
                                      {
                                         list.estimated_hours=list.estimated_hours&&list.estimated_hours!=null?list.estimated_hours:0
                                         if(list.estimated_hours!=0)
                                         {
                                          var timeArray = list.estimated_hours.split(":");
                                          estimated_h+= parseInt(timeArray[0]) + parseInt(timeArray[1]) / 60; 
                                         }
                                      }
                                      else{
                                        estimated_h=estimated_h+list.estimated_hours;
                                      }
                              
                                    }
                                    processedIssueIds.add(list.issue_id + '_'+list.parent);
                                })
                              })
                           
                              if(task.time_format==="decimal"&&Number.isInteger(estimated_h))
                              {
                                estimated_h=estimated_h
                              }
                              else if(task.time_format==="decimal"){
                                estimated_h=parseFloat(estimated_h.toFixed(2));
                              }
                              else{
                                const hourPart = Math.floor(estimated_h);
                                const minutePart = Math.round((estimated_h  - hourPart) * 60);
                                const minutePartWithZero = String(minutePart).padStart(2, '0');
                                estimated_h=hourPart+":"+minutePartWithZero;
                              }
                              Estimated_hours=estimated_h;

                            
                            }
                            else{
                              if(task.time_format==="decimal")
                              {
                                Estimated_hours=task.estimated_hours&&task.estimated_hours!=null?task.estimated_hours:0;
                              }
                              else{
                                Estimated_hours=task.estimated_hours&&task.estimated_hours!=null?task.estimated_hours:"0:00";
                              }
                            }
                        
                                   // Function to convert time in the format "1:2" to minutes
                              const convertTimeToDecimal = (time) => {
                                var timeArray =time.split(":");
                              return  parseInt(timeArray[0]) + parseInt(timeArray[1]) / 60; 
                              };
                             
                            // convert time entries 
                            if(task.time_format==="minutes")
                            {
                         
                              spent_time= convertTimeToDecimal(spent_time);
                              Estimated_hours=  convertTimeToDecimal(Estimated_hours);
                            }
                                  // Function to convert minutes to time in the format "1:2"
                            const convertTimeToMinutes= (hours) => {
                              const hourPart = Math.floor(hours);
                              const minutePart = Math.round(( hours  - hourPart) * 60);
                              const minutePartWithZero = String(minutePart).padStart(2, '0');
                            return hourPart+":"+minutePartWithZero;
                            };

                          if(spent_time||Estimated_hours!=0)
                          {
                             width=(spent_time/Estimated_hours)*100
                          }
                          if(Estimated_hours==0||spent_time==0)
                          {
                              if(Estimated_hours==0)
                              {
                                width=101
                              }
                              if(spent_time==0)
                              {
                                width=0
                              }
                          }
                  
                          if(width>100)
                          {
                              color="#EE4263";
                          }

                          if(task.time_format==="minutes")
                          {
                          
                            spent_time= convertTimeToMinutes(spent_time);
                            Estimated_hours=  convertTimeToMinutes(Estimated_hours);
                          }

                        return `<div class="two-line-name"><div style="margin-left:60px;" class="project_name"><b >${spent_time!=null?spent_time:"0"}/${Estimated_hours}</b></div><div class="bar-main-div" style="margin-top:4px;"><div class="progress-container"><div  style="width:${width}%; background-color:${color};" class="progress-bar"></div></div></div></div>`;
                    }
                }
            ]
        

        // add background color to left side grid header
        gantt.templates.grid_header_class = function(columnName, column){
            return "gantt_grid_header";
        };

      //ZT Gantt header class to show background color on  right date scale
      gantt.templates.scale_cell_class = (date, scale, scaleIndex) => {
        if(scaleIndex==0)
        {
            return "my-scale-class_timesheet"
        }
      }
       
      // add class to task bars
      gantt.templates.task_class  = (start, end, task) => {
         return "timesheet_task"   
      }



    // show user name in circle  folder icon 
    gantt.templates.grid_folder = function(item)
    { 
      var name=item.text.trim().split(" ");
      var firstname = name[0]
      var lastname = name[1] ? name[1] : "";
      var intials = firstname.charAt(0).toUpperCase() + lastname.charAt(0).toUpperCase();
    return  `<div style="background-color:${item.color!= null ? item.color : "#87B9E4"};"  class='gantt_tree_icon user_name random_${firstname.charAt(0).toUpperCase()}   gantt_folder_${(item.$open ? "open" : "closed")}'>${intials}</div>`; 
    };
    
      // show  first name and last name circle if user has not any assigned issues
        gantt.templates.grid_blank = function(item) {
        var name=item.text.trim().split(" ");
        var firstname = name[0];
        var lastname = name[1] ? name[1]: "";
        var intials = firstname.charAt(0).toUpperCase() + lastname.charAt(0).toUpperCase();
        if(item.parent!=0)
        {
      
        return `<div  class='gantt_blank'><a  target='_blank'  href='${url}/issues/${item.issue_id}'><i style="font-size:16px; margin-top:16px; margin-left:-1px; color:#00000080;" class="fa-solid fa-up-right-from-square"></i></a></div>`;
        }
        else{
          return " ";
        }
        };

   
       // show issue id custom code for child section
       gantt.templates.grid_file = function(item) {
        var issue_id;
        if(item.parent!=0)
        {
          return `<div class='gantt_tree_icon gantt_file ${item.trackers_name}'><div><a  target="_blank" class="link-issue ${item.trackers_name}" href='${url}/issues/${item.issue_id}'>#${item.issue_id}</a></div>`; 
        }
        else{
          issue_id=item.id;
          return ``; 
        }
        };
      

        // gantt scale code
        gantt.options.scales = [
            { unit: "day", step:1, format: function (date)
            {
              return  `${gantt.formatDateToString("%d", date)}   <br/><span class='day_scale'>${gantt.formatDateToString("%D", date)}</span>`;
            }  }
        ]

        function convertToDecimalHours(time) {
          if (typeof time === 'string' && time.includes(':')) {
              let parts = time.split(':');
              let hours = parseInt(parts[0], 10);
              let minutes = parseInt(parts[1], 10);
              return hours + (minutes / 60);
          }
          return parseFloat(time);
      }

      // show html in gantt timeline area task bars
      gantt.templates.taskbar_text = function(start, end, task) {
         let currentDate = new Date(start);
         let innerHTML = "";
         let timesheet_color;
         const taskLeft = gantt.posFromDate(start);
         while(currentDate.valueOf() <= end.valueOf()){
         // knowing the scale config you can get min/max dates of each column 
           let cellStart = currentDate;
          const cellEnd = gantt.add(currentDate,1,"day");
               // get relative position of each column inside the task
            const cellLeft = gantt.posFromDate(cellStart) - taskLeft;
            const cellRight = gantt.posFromDate(cellEnd) - taskLeft;
            const cellWidth = cellRight - cellLeft;

           var cellDate= changeFormat(cellStart);
           if(task.parent!=0)
           {

             if(task.dates&&task.dates.length!=0)
             {
              task.dates.map((i)=>{
                      if(i.date==cellDate)
                       {
                        if(task.time_format==="decimal"&&Number.isInteger(i.hours))
                        {
                          i.hours=i.hours;
                        }
                        else if(task.time_format==="decimal")
                        {
                          i.hours=i.hours
                        }
                        else{
                          i.hours=i.hours;
                        }
                    
                         innerHTML += `<div   class='task-content-inner' data-id=${task.time_entry_id} style='position:absolute;left:
                          ${cellLeft}px; width:${cellWidth}px;'>${i.hours}</div>`;
                       }
                 })
             }
           }
           else 
           {
             hours = 0;
            // let parent_data=timesheet.data;
            let parent_data = gantt.originalData;
            for(i=0; i < parent_data.length; i ++)
              {
               if(parent_data[i].parent==task.id)
               {
                if(task.time_format==="minutes")
                  {
                    hours= hours + getHours(parent_data[i],cellDate);
                  }
                  else{
                    hours= hours + getHours(parent_data[i],cellDate);
                  }
               }
             }
    
             if(hours!=0)
             {
              if(task.time_format==="decimal"&&Number.isInteger(hours))
              {
                hours=hours;
              }
              else if(task.time_format==="decimal")
              {
      
                hours=hours.toFixed(2);
              }
              else{
                const hourPart = Math.floor(hours);
                const minutePart = Math.round(( hours  - hourPart) * 60);
                const minutePartWithZero = String(minutePart).padStart(2, '0');
                hours=hourPart+":"+minutePartWithZero;
              }

              
              // Convert hours and required_spent_hours to decimal if they are in colon format
                let spent_hours = convertToDecimalHours(hours);
                required_spent_hours = convertToDecimalHours(required_spent_hours);
       
              let required_percent=(spent_hours/required_spent_hours)*100;
              if(required_percent < 50)
              {
                 timesheet_color='red-cell';
              }
              else if (required_percent < 100 && required_percent >= 50)
              {
                 timesheet_color= 'yellow-cell';
              }
              else if(required_percent==100)
              {
                 timesheet_color= 'green-cell';
              }
              else{
                timesheet_color= 'orange-cell';
              }
               innerHTML += `<div   class='task-content-inner ${timesheet_color}' data-id=${task.time_entry_id} style='position:absolute;left:
               ${cellLeft}px; width:${cellWidth}px;'>${hours}
                </div>`;
             }
          
           }
           currentDate = cellEnd;
         }
         return innerHTML;    
   }
    //   task bar text function end 

   // css class in timeline cell class
 gantt.templates.timeline_cell_class = function(task,date){

    if(is_timesheet_submitted==false)
    {
         if(task.parent==0)
        {
           return `User`;
          }
          else{
            return `Task`;
          }
        }
   }
      // timeline cell class function end 
     window.getteamsData=function (isscroll = false){
      $.ajax({
        type: "GET",
        url: `${url}/timesheet/selected/team_data.json?key=${api_key}`,
        dataType: 'json',
        // async:false,
        beforeSend: function(){
          $('.circle-loader').show();
        },
        data: {
         start_date:start_range,
         due_date: due_range,
         team_id:is_selected_team,
         user_page:teampageNum,
         user_per_page:teamperpage
        },
        success: function (result, status, xhr) {
          $('.circle-loader').toggleClass('load-complete');
          $('.checkmark').toggle();
          setTimeout(() => {
            $(".unknown-div").css("display","none");
            $('.circle-loader').hide();
            }, 500);
            gantt.clearAll(); 
            resource_data=result
             Users=result.users;
             tasks=result.data
              resource_data.data.map((i)=>{
              i.issue_id=i.id
              i.issue_s_date=i.start_date
              i.end_date=due_range
              i.start_date=start_range
              i.estimated_hours=i.estimated_hours&&i.estimated_hours!=null?i.estimated_hours: 0
              i.assigned_to=i.user_name 
            })
        
     
            function changeToDecimal(time) {
              const [hours, minutes] = time.split(':').map(Number);
              return hours + minutes / 60;
            }
            
            function changeToTimeFormat(decimal) {
              const hours = Math.floor(decimal);
              const minutes = Math.round((decimal - hours) * 60);
              return `${hours}:${minutes.toString().padStart(2, '0')}`;
            }
            
            var filteredActivities = resource_data.data.reduce((acc, activity) => {
              const existingActivity = acc.find(
                (a) => a.issue_id === activity.issue_id && a.activity_name === activity.activity_name
              );
            
              if (existingActivity) {
                const existingDateEntry = existingActivity.dates.find(
                  (d) => d.date === activity.spent_on
                );
            
                if (existingDateEntry) {
                
                  if (activity.time_format === "minutes") {
                    const newHours = changeToDecimal(existingDateEntry.hours) + changeToDecimal(activity.hours);
                    existingDateEntry.hours = changeToTimeFormat(newHours);
                  } else {
                    existingDateEntry.hours = parseFloat(existingDateEntry.hours) + parseFloat(activity.hours);
                  }
                  existingActivity.time_entries.push({
                    "time_entry_id": activity.time_entry_id,
                    "date": activity.spent_on,
                  });
                } else {
                  existingActivity.dates.push({
                    "hours": activity.hours,
                    "date": activity.spent_on,
                    "comments": activity.comments,
                    "activity_id": activity.activity_id,
                    "time_entry_id": activity.time_entry_id
                  });
                  existingActivity.time_entries.push({
                    "time_entry_id": activity.time_entry_id,
                    "date": activity.spent_on,
                    
                  });
                }
              } else {
                acc.push({
                  ...activity,
                  dates: [{
                    "hours": activity.hours,
                    "date": activity.spent_on,
                    "comments": activity.comments,
                    "activity_id": activity.activity_id,
                    "time_entry_id": activity.time_entry_id,
                    
                  }],
                  time_entries:[{
                    "time_entry_id": activity.time_entry_id,
                    "date": activity.spent_on,
                  }]
                });
              }
              return acc;
            }, []);
      
           timesheet.data = filteredActivities
       
 
            uniqueIssues = resource_data.data.reduce((unique, issue) => {
             if (!unique.find((item) => item.id === issue.id)) {
               unique.push(issue);
             }
             return unique;
           }, []);
       
    
            if(Users&&Users.length!=0){
              Users.map((i)=>{
              
                $("#dynamic_select_user").append(`<option value=${i.id} >${i.firstname+" "+i.lastname}</option>`)
              })
            }
    
            if(result.data.length==0)
              {
               element.style.display="none";
                   $("#menu").css("display","none");
                   if(!$(".nodata")[0])
                   {
                    $("#gantt_here").before(`<p  style="margin-top:30px;" class="nodata">No data to display</p>`);
                   }
              }
              else{
                element.style.display="block";
                if(result.hasOwnProperty("pagination"))
                {
                  teamtotalPages=result.pagination.total_pages;
                }
                else{
                  teamtotalPages=1;
                }
                    timesheet.data.map((i)=>{
                    
                       if(i.parent!=0)
                       {   
                         i.issue_id=i.id
                         if(i.activity_id!=null)
                         {
                           i.id="i"+i.id+"_"+i.activity_name.replace(/\s/g, "")
                         }
                         else{
                           i.id="i"+i.id+"_"+"no_activity"
                         }
                         i.task_with_parent=i.id+i.parent;
                         if(i.time_format=="minutes")
                         {
                           i.estimated_hours=Number.isInteger(i.estimated_hours)?i.estimated_hours:i.estimated_hours
                         }
                         else{
                           i.estimated_hours=Number.isInteger(i.estimated_hours) ? i.estimated_hours : parseFloat(i.estimated_hours.toFixed(2));
                         }
                       
                         i.spent_hours=i.hours
                         i.project_name=i.project.name
                         i.project_id=i.project.id
                       }
                       else{
                         if(i.time_format=="minutes")
                         {
                           i.spent_hours=Number.isInteger(i.spent_hours)?i.spent_hours:i.spent_hours
                         }
                         else{
                           i.spent_hours=Number.isInteger(i.spent_hours)?i.spent_hours: parseFloat(i.spent_hours.toFixed(2));
                         }
                        
                       }
                     })
        
               
                     $(".nodata").remove();
                     $("#menu").css("display","block");
                     if(isscroll)
                      {
                        const uniqueData = timesheet.data
                        let mergeData = [...gantt.originalData, ...uniqueData];
                        mergeData =    mergeData.reduce((acc, activity) => {
                          const existingActivity = acc.find(
                            (a) => a.issue_id === activity.issue_id && a.activity_name === activity.activity_name && a.parent === activity.parent
                          );
                          
                          if (existingActivity) {
                            existingActivity.spent_hours += activity.hours;
                            existingActivity.dates.push({"hours":activity.hours,"date":activity.spent_on,"comments":activity.comments,"activity_id":activity.activity_id,"time_entry_id":activity.time_entry_id });
                            existingActivity.time_entries.push({
                               "time_entry_id":activity.time_entry_id
                            })
                            
                          } else {
                            acc.push({...activity,
                             dates: [{"hours":activity.hours,"date":activity.spent_on,"comments":activity.comments,"activity_id":activity.activity_id,"time_entry_id":activity.time_entry_id}],
                              time_entries:[{
                                "time_entry_id":activity.time_entry_id
                              }]
                            });
                          
                          }
                          return acc;
                        }, []);
                      
                        gantt.options.data= mergeData;
                        gantt.render();
                      }
                      else{
                     
                        gantt.options.data=timesheet.data;
                        gantt.render();
                      }
              }

        },
        error: function (xhr, status, error) {
          $('.circle-loader').toggleClass('load-complete');
          $('.checkmark').toggle();
          setTimeout(() => {
            $(".unknown-div").css("display","none");
            $('.circle-loader').hide();
            }, 500);
        }
    });
      }



       window.getuserData=function(isscroll = false) {
     
      return  $.ajax({
          type: "GET",
          url: `${url}/users_timesheets.json?key=${api_key}&per_page=${perpage}&page=${pagenum}`,
          dataType: 'json',
          beforeSend: function(){
            $('.circle-loader').show();
          },
          data: {
           start_date:  start_range,
           due_date: due_range,
           user_id:user_id!=null?user_id:login_user_id
         },
          success: function (result, status, xhr) {
     
          
            $('.circle-loader').toggleClass('load-complete');
            $('.checkmark').toggle();
            setTimeout(() => {
              $(".unknown-div").css("display","none");
              $('.circle-loader').hide();
              }, 500);
           
              gantt.clearAll(); 
              resource_data=result
               Users=result.users;
               tasks=result.data
              resource_data.data.map((i)=>{
                i.issue_id=i.id
                i.issue_s_date=i.start_date
                var date = due_range;
                  date  = new Date(due_range);
                  date.setDate(date.getDate() + 1);
                i.end_date=date
                i.start_date=start_range
                i.estimated_hours=i.estimated_hours&&i.estimated_hours!=null?i.estimated_hours: 0
                i.assigned_to=i.user_name 
 
              })
       
              function changeToDecimal(time) {
                const [hours, minutes] = time.split(':').map(Number);
                return hours + minutes / 60;
              }
              
              function changeToTimeFormat(decimal) {
                const hours = Math.floor(decimal);
                const minutes = Math.round((decimal - hours) * 60);
                return `${hours}:${minutes.toString().padStart(2, '0')}`;
              }
              
              var filteredActivities = resource_data.data.reduce((acc, activity) => {
                const existingActivity = acc.find(
                  (a) => a.issue_id === activity.issue_id && a.activity_name === activity.activity_name
                );
              
                if (existingActivity) {
                  const existingDateEntry = existingActivity.dates.find(
                    (d) => d.date === activity.spent_on
                  );
              
                  if (existingDateEntry) {
                  
                    if (activity.time_format === "minutes") {
                      const newHours = changeToDecimal(existingDateEntry.hours) + changeToDecimal(activity.hours);
                      existingDateEntry.hours = changeToTimeFormat(newHours);
                    } else {
                      existingDateEntry.hours = parseFloat(existingDateEntry.hours) + parseFloat(activity.hours);
                    }
                    existingActivity.time_entries.push({
                      "time_entry_id": activity.time_entry_id,
                      "date": activity.spent_on,
                    });
                  } else {
                    existingActivity.dates.push({
                      "hours": activity.hours,
                      "date": activity.spent_on,
                      "comments": activity.comments,
                      "activity_id": activity.activity_id,
                      "time_entry_id": activity.time_entry_id
                    });
                    existingActivity.time_entries.push({
                      "time_entry_id": activity.time_entry_id,
                      "date": activity.spent_on,
                    });
                  }
             
                } else {
                  acc.push({
                    ...activity,
                    dates: [{
                      "hours": activity.hours,
                      "date": activity.spent_on,
                      "comments": activity.comments,
                      "activity_id": activity.activity_id,
                      "time_entry_id": activity.time_entry_id
                    }],
                    time_entries:[{
                      "time_entry_id": activity.time_entry_id,
                      "date": activity.spent_on,
                    }]
                  });
                }
                return acc;
              }, []);

       
 
             timesheet.data = filteredActivities
   
              uniqueIssues = resource_data.data.reduce((unique, issue) => {
               if (!unique.find((item) => item.id === issue.id)) {
                 unique.push(issue);
               }
               return unique;
             }, []);
      
              if(Users&&Users.length!=0){
                Users.map((i)=>{
                  $("#dynamic_select_user").append(`<option value=${i.id} >${i.firstname+" "+i.lastname}</option>`)
                })
              }
              if(result.data.length==0)
                {
              
                     element.style.display="none";
                     $("#menu").css("display","none");
                     if(!$(".nodata")[0])
                     {
                      $("#gantt_here").before(`<p  style="margin-top:30px;" class="nodata">No data to display</p>`);
                     }
  
                }
                else{
                  element.style.display="block";
                  if(result.hasOwnProperty("pagination"))
                  {
                    total_pages=result.pagination.total_pages;
                  }
                  else{
                    total_pages=1;
                  }
                     
                          timesheet.data.map((i) => {
                            if (i.parent != 0) {
                              i.issue_id = i.id;
                              if (i.activity_id != null) {
                                i.id = "i" + i.id + "_" + i.activity_name.replace(/\s/g, "");
                              } else {
                                i.id = "i" + i.id + "_" + "no_activity";
                              }
                              if (i.time_format == "minutes") {
                                i.estimated_hours = Number.isInteger(i.estimated_hours) ? i.estimated_hours : i.estimated_hours;
                              } else {
                                i.estimated_hours = Number.isInteger(i.estimated_hours) ? i.estimated_hours :parseFloat(i.estimated_hours.toFixed(2));
                              }
                              i.spent_hours = parseFloat(i.hours);
                              i.project_name = i.project.name;
                              i.project_id = i.project.id;
                            } else {
                              if (i.time_format == "minutes") {
                                i.spent_hours = i.spent_hours;

                              } else {
                                i.spent_hours = parseFloat(i.spent_hours).toFixed(2);
                              }
                            }
                          });
                          
               
                          $(".nodata").remove();
                          $("#menu").css("display", "block");
                          
                          if (isscroll) {
                            // gantt.options.collapse = false;
                            const uniqueData = timesheet.data
                            const mergeData = [...gantt.originalData, ...uniqueData];
                            let sumData = mergeData.reduce((acc, task) => {
                            const existingTask = acc.find(t => t.id === task.id);

                              if (existingTask&&task.parent==0) {
                                if(task.time_format=="minutes")
                                  {
                                    existingTask.spent_hours = changeToDecimal(existingTask.spent_hours) + changeToDecimal(task.spent_hours) ;
                                  }
                                  else{
                                    existingTask.spent_hours = parseFloat(existingTask.spent_hours) + parseFloat(task.spent_hours);
                                  }
                                }
                                else if(existingTask&&task.parent!=0){
                                  task.dates.forEach(dateEntry => {
                                    const existingDateEntry = existingTask.dates.find(d => d.date === dateEntry.date);
                                    if (existingDateEntry) {
                                      if (task.time_format == "minutes") {
                                        const newHours = changeToDecimal(existingDateEntry.hours) + changeToDecimal(dateEntry.hours);
                                        existingDateEntry.hours = changeToTimeFormat(newHours);
                                      } else {
                                        existingDateEntry.hours = parseFloat(existingDateEntry.hours) + parseFloat(dateEntry.hours);
                                      }
                             
                                      existingTask.time_entries.push({
                                        "time_entry_id":dateEntry.time_entry_id,
                                        "date": dateEntry.date,
                                     })
                                    } else {
                                      existingTask.dates.push(dateEntry);
                                      existingTask.time_entries.push({
                                        "time_entry_id":dateEntry.time_entry_id,
                                        "date": dateEntry.date,
                                     })
                                    }
                                  });
                                }

                            else {
                                acc.push(task);
                              }

                              return acc;
                            }, []);
                            sumData.forEach((list) => {
                              if (list.parent == 0) {
                                if(list.time_format=="minutes")
                                  {
                                    const hourPart = Math.floor( list.spent_hours);
                                    const minutePart = Math.round((  list.spent_hours  - hourPart) * 60);
                                    const minutePartWithZero = String(minutePart).padStart(2, '0');
                                    list.spent_hours =   hourPart+":"+minutePartWithZero;
                                  }
                                  else{
                                    list.spent_hours = parseFloat(list.spent_hours).toFixed(2);
                                  }
                              
                              }
                            });
                        
                            gantt.options.data=sumData;
                            gantt.render();
                          }
                        else{
                          gantt.options.data=timesheet.data;
                          gantt.render(element);
                        }
                }
          },
          error: function (xhr, status, error) {
            $('.circle-loader').toggleClass('load-complete');
            $('.checkmark').toggle();
            setTimeout(() => {
              $(".unknown-div").css("display","none");
              $('.circle-loader').hide();
              }, 500);
          }
    });
      }

      function getImportworkloadData()
      {
        $.ajax({
          type: "GET",
          url: `${url}/timesheet/import/workload.json?key=${api_key}`,
          dataType: 'json',
          // async:false,
          data: {
          start_date: start_range,
          end_date: due_range,
          user_id:login_user_id
        },
          success: function (result, status, xhr) {
              
            $('.circle-loader').toggleClass('load-complete');
            $('.checkmark').toggle();
            setTimeout(() => {
              $(".unknown-div").css("display","none");
              $('.circle-loader').hide();
              }, 500);

              gantt.clearAll(); 
              resource_data=result
              Users=result.users;
              tasks=result.data
              resource_data.data.map((i)=>{
                i.issue_id=i.id
                i.issue_s_date=i.start_date
                var date = due_range;
                  date  = new Date(due_range);
                  date.setDate(date.getDate() + 1);
                i.end_date=date
                i.start_date=start_range
                i.estimated_hours=i.estimated_hours&&i.estimated_hours!=null?i.estimated_hours: 0
                i.assigned_to=i.user_name 

              })
      
            var filteredActivities =   resource_data.data.reduce((acc, activity) => {
              const existingActivity = acc.find(
                (a) => a.issue_id === activity.issue_id && a.activity_name === activity.activity_name
              );
      
              if (existingActivity) {
                existingActivity.spent_hours += activity.hours;
                existingActivity.dates.push({"hours":activity.hours,"date":activity.spent_on,"comments":activity.comments,"activity_id":activity.activity_id,"time_entry_id":activity.time_entry_id });
                
              } else {
                acc.push({...activity, dates: [{"hours":activity.hours,"date":activity.spent_on,"comments":activity.comments,"activity_id":activity.activity_id,"time_entry_id":activity.time_entry_id}]});
              
              }
              
              return acc;
            }, []);

            timesheet.data = filteredActivities
    
              uniqueIssues = resource_data.data.reduce((unique, issue) => {
              if (!unique.find((item) => item.id === issue.id)) {
                unique.push(issue);
              }
              return unique;
            }, []);
      
              if(Users&&Users.length!=0){
                Users.map((i)=>{
                  $("#dynamic_select_user").append(`<option value=${i.id} >${i.firstname+" "+i.lastname}</option>`)
                })
              }
      
              if(result.data.length==0)
                {
                    element.style.display="none";
                    $("#menu").css("display","none");
                    if(!$(".nodata")[0])
                    {
                      $("#gantt_here").before(`<p  style="margin-top:30px;" class="nodata">No data to display</p>`);
                    }
  
                }
                else{
                  element.style.display="block";
                        timesheet.data.map((i)=>{
                          if(!(i.hasOwnProperty("activity_id")))
                          {
                               i.dates=[]
                          }
                        if(i.parent!=0)
                        {   
                          i.issue_id=i.id
                          // i.parent=i.assigned_to_id
                          if(i.activity_id!=null)
                          {
                            i.id="i"+i.id+"_"+i.activity_name.replace(/\s/g, "")
                          }
                          else{
                            i.id="i"+i.id+"_"+"no_activity"
                          }
                          if(i.time_format=="minutes")
                          {
                            i.estimated_hours=Number.isInteger(i.estimated_hours)?i.estimated_hours:i.estimated_hours
                          }
                          else{
                    
                            i.estimated_hours=Number.isInteger(i.estimated_hours)?i.estimated_hours:parseFloat(i.estimated_hours.toFixed(2))
                          }
                          i.spent_hours=i.hours
                          i.project_name=i.project.name
                          i.project_id=i.project.id
                        }
                        else{
                          if(i.time_format=="minutes")
                          {
                            i.spent_hours=Number.isInteger(i.spent_hours)?i.spent_hours:i.spent_hours
                          }
                          else{
                            i.spent_hours=Number.isInteger(i.spent_hours)?i.spent_hours:parseFloat(i.spent_hours.toFixed(2))
                          }
                        }
                      })

                
                      $(".nodata").remove();
                      $("#menu").css("display","block");
      
                      gantt.options.data=timesheet.data;
                      gantt.render(element);
                }
          },
          error: function (xhr, status, error) {
            $('.circle-loader').toggleClass('load-complete');
            $('.checkmark').toggle();
            setTimeout(() => {
              $(".unknown-div").css("display","none");
              $('.circle-loader').hide();
              }, 500);
          }
    });
      }

      //  This function is called when we need to replace url params on data range picker changes
      function updateUrlParams(params) {
        // Get the current URL parameters
        const urlParams = new URLSearchParams(window.location.search);
    
        // Remove existing parameters
        for (const key of urlParams.keys()) {
            if (!(key in params)) {
                urlParams.delete(key);
            }
        }
    
        // Add or update parameters
        for (const [key, value] of Object.entries(params)) {
            if (value !== null && value !== undefined) {
                urlParams.set(key, value);
            } else {
                urlParams.delete(key);
            }
        }
    
        // Update the URL without triggering a page reload
        const newUrl = `${window.location.pathname}?${urlParams.toString()}`;
        window.history.replaceState({}, '', newUrl);
       }
      //  function end 

      start =moment().clone().isoWeekday(1);
      end = moment().clone().isoWeekday(7);



      
      storedStart = localStorage.getItem("start_timesheet");
      storedEnd = localStorage.getItem("end_timesheet");



      // This function is called when we click on apply button of date range picker
      function updateDates (s,d){
        // update date on start and due range
        start_range=logTimeClicked?s:s.format('YYYY-MM-DD');
        due_range=logTimeClicked?d:d.format('YYYY-MM-DD');
    

      // add issue log date min and max date in edit log time modal and add log time modal
       $("#log_date").attr("min",logTimeClicked?s:s.format('YYYY-MM-DD'));
       $("#log_date").attr("max",logTimeClicked?d:d.format('YYYY-MM-DD'));


        $('#reportrange span').html(logTimeClicked?moment(start_range).format("D MMM YY") + ' - ' +moment(due_range).format("D MMM YY") :s.format('D MMM YY') + ' - ' + d.format('D MMM YY')); 

        localStorage.setItem("start_timesheet",logTimeClicked?s: s.format('YYYY-MM-DD'));
        localStorage.setItem("end_timesheet",logTimeClicked?d:d.format('YYYY-MM-DD'));  

        storedStart = localStorage.getItem("start_timesheet");
        storedEnd = localStorage.getItem("end_timesheet");

        gantt.options.startDate =logTimeClicked?s: s.format('YYYY-MM-DD');
        gantt.options.endDate =logTimeClicked?d:d.format('YYYY-MM-DD');
  

        const urlParams = {
             user_id:user_id,
             user_name:user_name,
            start_date:logTimeClicked?s: s.format('YYYY-MM-DD'),
            end_date:logTimeClicked?d: d.format('YYYY-MM-DD')
        };

        if(start_date!=null&&end_date!=null)
        {
          updateUrlParams(urlParams);  
        }


        if(is_admin)
        {
               if(is_selected_team&&is_selected_team!=0)
                 {
                   getTotalActvitiesbyTeam(is_selected_team);
                   teamperpage=10;
                   teampageNum=1;
                   getteamsData();
                 }
                 else{
                  perpage=15;
                  pagenum=1;
                   is_timesheet_submitted=false;
                   check_timesheet=false;
                   getTImesheet();
                   getTotalActvities();
                   getuserData();
                  //  if(is_workload_imported)
                  //  {
                  //    getImportworkloadData();
                  //  }
                  //  else
                  //  {
                  //  getuserData();
                  //  }
                }
      }
      else{
        perpage=15;
        pagenum=1;
              is_timesheet_submitted=false;
               check_timesheet=false;
               // function to get selected submit timesheet data
               getTImesheet();
               // get activity sum of user
               getTotalActvities();

              //  if(is_workload_imported)
              //  {
              //   getImportworkloadData();
              //  }
              // else{
                 getuserData();
              // }  
          }

          logTimeClicked = false;
      }


      
     // on date picker change call this function 
      function cb(start, end) {

       start_range=start.format('YYYY-MM-DD');
       due_range=end.format('YYYY-MM-DD');
   
   
       // add issue log date min and max date in edit log time modal and add log time modal
       $("#log_date").attr("min",start.format('YYYY-MM-DD'));
       $("#log_date").attr("max", end.format('YYYY-MM-DD'));

       localStorage.setItem("start_timesheet", start_range);
       localStorage.setItem("end_timesheet", due_range);

         if(start_date!=null&&end_date!=null)
         {
          localStorage.setItem("start_timesheet", start_date);
          localStorage.setItem("end_timesheet",end_date); 
          
           start_range=start_date;
           due_range=end_date;  
           
           $("#log_date").attr("min",start_date);
           $("#log_date").attr("max", end_date);
         }
        storedStart = localStorage.getItem("start_timesheet");
        storedEnd = localStorage.getItem("end_timesheet");
         
        gantt.options.startDate = storedStart ? storedStart :start.format('YYYY-MM-DD');
        gantt.options.endDate = storedEnd? storedEnd :end.format('YYYY-MM-DD');
     
       // show start and end date in date picker span tag
       $('#reportrange span').html(moment(start_range).format("D MMM YY") + ' - ' + moment(due_range).format("D MMM YY"));

             if(is_admin)
             {
                  if(user_id!=null)
                  {
                    is_selected_team=0;
                    $("#timesheet_team").css("display","none");

                  }
                      if(is_selected_team&&is_selected_team!=0)
                      {
                     
                        teamperpage=10;
                        teampageNum=1;
                          getTotalActvitiesbyTeam(is_selected_team);
                          getteamsData();
                      }
                    
                      else{
                        perpage=15;
                        pagenum=1;
                        is_timesheet_submitted=false;
                        check_timesheet=false;
                        getTImesheet();
                        getTotalActvities();
                        if(is_workload_imported)
                        {
                          getImportworkloadData();
                        }
                        else
                        {
                        getuserData();
                        }
                     }
           }
           else{
            perpage=15;
            pagenum=1;
                   is_timesheet_submitted=false;
                    check_timesheet=false;
                    // function to get selected submit timesheet data
                    getTImesheet();
                    // get activity sum of user
                    getTotalActvities();
    
                    if(is_workload_imported)
                    {
                     getImportworkloadData();
                    }
                   else{
                      getuserData();
                   }  
               }
      }


         
       $('#reportrange').daterangepicker({
       
           startDate: storedStart ? moment(storedStart) : start,
           endDate:storedEnd ? moment(storedEnd) : end,
           ranges: {
            [t('today')]: [moment(), moment()],
            [t('yesterday')]: [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
            [t('current_week')]: [moment().clone().isoWeekday(1), moment().clone().isoWeekday(7)],
            [t('last_7_days')]: [moment().subtract(6, 'days'), moment()],
            [t('last_30_days')]: [moment().subtract(29, 'days'), moment()],
            [t('this_month')]: [moment().startOf('month'), moment().endOf('month')],
            [t('last_month')]: [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')],
            [t('next_month')]: [moment().add(1, 'month').startOf('month'), moment().add(1, 'month').endOf('month')]
        },
        locale: {
            customRangeLabel: t('custom_range'), // Add translation for Custom Range
            applyLabel: t('apply'),  // Translate "Apply"
            cancelLabel: t('Cancel') 
          
        }
       },updateDates);

 
  
       cb(moment(storedStart ? storedStart : start), moment(storedEnd  ? storedEnd : end));
    
       $("[data-range-key='Custom Range']").click(function() {
          
         $(this).addClass("active");
         $("[data-range-key='Today']").removeClass("active");
         $("[data-range-key='Current Week']").removeClass("active");
         $("[data-range-key='Next Month']").removeClass("active");
         $("[data-range-key='This Month']").removeClass("active");
         $("[data-range-key='Last Month']").removeClass("active");
         $("[data-range-key='Last 30 Days']").removeClass("active");
         $("[data-range-key='Last 7 Days']").removeClass("active");
         $("[data-range-key='Yesterday']").removeClass("active");
    
         //Do Acction

         
     });

     $(document).on('click', '#issue-drop', function (event) {
      $("#txtSearchValueissue").val(" ");
      var user_id= $("#current-issue").attr("user_id");
       getIssues(user_id);

     });
    // function cb date range picker end  
 window.updateIssue=function(content)
 {
  $.ajax({
    type: "PUT",
    url: `${url}/issues/${content.issue_id}.json?key=${api_key}`,
    dataType: "json",
    contentType: "application/json",
    async: false,
    data: JSON.stringify({
      issue: content,
    }),
    success: function (result, status, xhr) {
       },
    error: function (xhr, status, error) {
     if(xhr.status == 422){
       let content = JSON.parse(xhr.responseText).errors;
      content.map((i)=>{
        if(i==="Due date must be greater than start date")
        {
          toastr["error"](t("label_error_start_not_greater_than_due"));
        }
        else if(i==="Assignee is invalid")
        {
          toastr["error"](t("label_error_user_not_belong_to_project"));
        }
        else{
     
              toastr["error"](i);
            
         
        }
     })
   }
     else if(xhr.status == 403)
       {
           toastr["error"](t("label_error_not_have_permission"));
       } 
    },
  });
 }
      //  Add time entry in the gantt start
 window.LogTime=function(elem)
 {
  $("#c_div").css("margin-bottom","9px");
  $("#category-div-error").css("display","none");
  let  loguserid=$("#current-issue").attr("user_id");
   let issue_id=$("#current-issue").attr("value")
   let content={
     "issue_id":parseInt(issue_id),
     "comments":$(".text-area-res").val(),
     "spent_on":$("#log_date").val(),
     "hours":$("#spent_hour").val(),
     "activity_id":$("#select_activity").val(),
     "user_id":loguserid&&loguserid!=null? parseInt(loguserid):login_user_id
   }
   if(budgetauditPluginExists)
   {
    let content={
      "issue_id":parseInt(issue_id),
      "category_id":parseInt($("#select_category").val()),
    }
    if($("#select_category").val()!=0&&$("#select_category").val()!=null)
      {
        updateIssue(content);
      }
 
   }
     if(validateData())
     {
     $.ajax({
         type: "POST",
         url: `${url}/time_entries.json?key=${api_key}`,
         dataType: "json",
         contentType: "application/json",
         async: false,
         data: JSON.stringify({
           time_entry: content,
         }),
         success: function (result, status, xhr) {
               logTimeClicked=true;
             updateDates(storedStart,storedEnd);

              toastr["success"](t("label_log_time_success"));
               $('.modal').hide();
               $('.div-modal').hide();
               disableTabindex('.modal');
            },
         error: function (xhr, status, error) {
          if(xhr.status == 422){
            let content = JSON.parse(xhr.responseText).errors;
           content.map((i)=>{
             if(i==="Due date must be greater than start date")
             {
               toastr["error"](t("label_error_start_not_greater_than_due"));
             }
             else if(i==="Assignee is invalid")
             {
               toastr["error"](t("label_error_user_not_belong_to_project"));
             }
             else{
              //  toastr["error"](i);
              if(budgetauditPluginExists)
            {
               if(i==="Hours not available for this category")
                {
                     $("#c_div").css("margin-bottom","0px");
                     $("#category-div-error").css("display","flex");
                     $("#category-error").html(t("label_error_hours_not_available"));
                    
                }
                else{
                        toastr["error"](i);
                        $("#c_div").css("margin-bottom","9px");
                      $("#category-div-error").css("display","none");
                }
              }
              else{
                toastr["error"](i);
              }
             }
          })
        }
          else if(xhr.status == 403)
            {
                toastr["error"](t("label_error_not_have_permission"));
            } 
         },
       });



     }
 }
//  add time entry in the gantt end 

  
      //  a function to check whether to show submit timesheet button or not 
      submitButtonVisibility();
      function submitButtonVisibility(){
      // logic if user is login user show submit timesheet button
      let selectedTeam=document.getElementById("tree-select-input");
          setTimeout(()=>{
            if(is_admin==false)
            { 
            $("#submitTimesheet").css("display", "flex");
            $("#exportWorkload").css("display","flex");
            }
            else if(is_admin==true&&(selectedTeam.innerHTML==t("my_timesheet"))&&user_id==null)
            { 
          
                $("#submitTimesheet").css("display", "flex");
                $("#exportWorkload").css("display","flex");
            }
            else if(is_admin==true&&user_id==null)
            {
      
              $("#submitTimesheet").css("display","none");
              $("#exportWorkload").css("display","none");
            }
           else if(is_admin==true&&user_id!=null&&check_timesheet==true&&timesheet_status=="submitted"&&((unsubmit_timesheet==false)||(unsubmit_timesheet==true)))
            {
              
              $("#submitTimesheet").css("display","none");
              $("#approveTimesheet").css("display","flex");
              $("#rejectTimesheet").css("display","flex");
            }
          },300)
          //  if user is login user show submit timesheet button
      }
      
   


         // zt gantt tolltip formatiing
      gantt.templates.tooltip_text = function (start, end, task) {
        if(task.parent!=0)
        {
          let end_date=task.due_date!=null? gantt.formatDateToString("%d-%m-%y",task.due_date):"dd-mm-yy";
          let start_date=task.issue_s_date!=null? gantt.formatDateToString("%d-%m-%y",task.issue_s_date):"dd-mm-yy"
          let html = "<b>Project:</b> " + task.project_name + "<br/><b>Task:</b> " + task.text + "<br/><b>Start Date:</b> " +
                      start_date +"<br/><b>Due Date:</b> " + end_date
         return html;
      }
      else{
        return false;
      }
    }


    // zt gantt tooltip code end 

      // change date format of date
      function changeFormat(date) {
        var today = new Date(date);
        var dd = String(today.getDate()).padStart(2, "0");
        var mm = String(today.getMonth() + 1).padStart(2, "0"); //January is 0!
        var yyyy = today.getFullYear();
        return  today = yyyy + "-" + mm + "-" + dd;
      }
    
             // API to get team data if user is admin
                  function fetchTimesheetTeam() {
                    $.ajax({
                      type: "GET",
                      url: `${url}/timesheet_teams.json?key=${api_key}`,
                      dataType: 'json',
                      async: false,
                      success: function (result, status, xhr) {
                        // $("#Select_team_timesheet").html(" ");
                        // $("#Select_team_timesheet").append(`<option value="0">My Timesheet</option>`);
                        if (result.length != 0) {
                          // Build tree structure
                          const teamTree = buildTeamTree(result);
                          // Render tree structure
                          const option = document.createElement('div');
                          option.className = 'tree-select-option';
                     
                          option.style.paddingLeft = '9px';
                          option.textContent = t('my_timesheet');
                          option.id="0";
                          option.addEventListener('click', (e) => {
                            e.stopPropagation();
                            filterteam(0);
                            input.innerHTML = t('my_timesheet');
                            dropdown1.classList.remove('open');
                            setSelectedOption(option)
                          });
                     
                          dropdown1.appendChild(option);
                          renderTreeOptions(teamTree);
                        }
                        selectedTeam(result);
                      },
                      error: function (xhr, status, error) {
                        $("#Select_team").html(" ");
                      }
                    });
                  }
                  
                  function buildTeamTree(teams) {
                    const teamMap = {};
                    teams.forEach(team => {
                      teamMap[team.id] = { ...team, children: [] };
                    });
                  
                    const tree = [];
                    teams.forEach(team => {
                      if (team.parent_id) {
                        teamMap[team.parent_id].children.push(teamMap[team.id]);
                      } else {
                        tree.push(teamMap[team.id]);
                      }
                    });
                  
                    return tree;
                  }
              
                  // Get selected team id from backend
                  function selectedTeam(teamdata) {
                    let isTeamexists=false;
                    // Get selected team data through API
                    $.ajax({
                      type: "GET",
                      url: `${url}/selected/team.json?key=${api_key}`,
                      dataType: 'json',
                      async: false,
                      success: function (result, status, xhr) {
                        let teamname=t('my_timesheet');
                        if (result.length != 0) {
                           is_selected_team = result[0].team_id;
                           teamdata.forEach((i)=>{
                            if(i.id==is_selected_team)
                            {
                              teamname=i.name;
                              const selectedOption = document.getElementById(i.id);
                              isTeamexists=true;
                              if (selectedOption) {
                                selectedOption.classList.add('selected');
                                setSelectedOption(selectedOption);
                              }
                            }
                         
                      
                           })
                          input.innerHTML= teamname;
                     
                        }
                          if(isTeamexists==false)
                          {
                              let option =document.getElementById("0");
                                 setSelectedOption(option);
                          } 
                      
                      
                      },
                      error: function (xhr, status, error) {
                        // Handle error
                      }
                    });
                  }
                

                  input.addEventListener('click', () => {
                    dropdown1.classList.toggle('open');
                  });
                  
                  function renderTreeOptions(tree, level = 0) {
                    tree.forEach(node => {
                      const option = document.createElement('div');
                      option.className = 'tree-select-option';
                      option.setAttribute("data-toggle","tooltip");
                      option.setAttribute("title",node.name);
                      option.style.paddingLeft = level>0? `${level * 20}px`:'9px';
                      option.textContent = node.name;
                      option.id=node.id;
               
                      option.addEventListener('click', (e) => {
                        e.stopPropagation();
                        filterteam(node.id);
                        input.innerHTML = node.name;
                        dropdown1.classList.remove('open');
                        setSelectedOption(option)
                      });

                   
                    
                      dropdown1.appendChild(option);
                  
                      if (node.children && node.children.length > 0) {
                        const childrenContainer = document.createElement('div');
                        childrenContainer.className = 'tree-select-children';
                        dropdown1.appendChild(childrenContainer);
                        renderTreeOptions(node.children, level + 1);
                      }
                    });
                  }

                  document.addEventListener('click', (e) => {
                    if (!dropdown1.contains(e.target) && !input.contains(e.target)) {
                      dropdown1.classList.remove('open');
                    }
                  });

                  function setSelectedOption(option) {
                    // Remove the selected class from any previously selected option
                    const previouslySelected = document.querySelector('.tree-select-option.selected');
                    if (previouslySelected) {
                      previouslySelected.classList.remove('selected');
                    }
        
                    // Add the selected class to the newly selected option
                    option.classList.add('selected');
                  }


       
    // Reject timesheet function start 
    window.openRejectModal=function(){
      $("#reject-error").css("display","none");
      $("#comment-reject").val("");
      let backgroundModal=document.getElementsByClassName("div-modal");
      let rejectModal=document.getElementsByClassName("reject-modal");
     

      if(backgroundModal.length>0)
      {
        backgroundModal[0].style.display="block";

      }
      if(rejectModal)
      {
        rejectModal[0].style.display="block";
      } 
      disableTabindex('.reject-modal');
      gantt.updateBody();
    }
    
    // close reject modal 
    window.closeModal=function(){
      let backgroundModal=document.getElementsByClassName("div-modal");
      let rejectModal=document.getElementsByClassName("reject-modal");
      if(backgroundModal.length>0)
      {
        backgroundModal[0].style.display="none";

      }
      if(rejectModal)
      {
        rejectModal[0].style.display="none";
        
      }
      disableTabindex('.reject-modal');

    }
    // close reject modal 

    function validateComment(value)
    {
      let errors={};
      let comment=$("#comment-reject").val();
      if(comment.trim()===''||comment.length==="0")
      {
           $("#reject-error").css("display","block");
           $("#reject-error").html(t("label_error_required"));
           errors.reject=t("label_error_required");
      }
      else{
        $("#reject-error").css("display","none");
      }
      
      if(Object.keys(errors).length)
      {
        return count=false;
      }
      else{
        return count=true;
      }
  }

    // call API on reject button click 
    window.rejectTimesheet=function(){
      let userId=login_user_id;
      let comment=$("#comment-reject").val();
      if(user_id!=null)
      {
        userId=user_id;
      }
      if(validateComment(comment))
      {
      $.get("/reject/timesheet", { 
        user: userId,
        start_date:start_range,
        end_date:due_range,
        comment:comment,
       }, function(data) {
        if (data) {
          let backgroundModal=document.getElementsByClassName("div-modal");
          let rejectModal=document.getElementsByClassName("reject-modal");
          if(backgroundModal.length>0)
          {
            backgroundModal[0].style.display="none";
    
          }
          if(rejectModal)
          {
            rejectModal[0].style.display="none";
          }
          disableTabindex('.reject-modal');
          getTImesheet();
          getTotalActvities();
          getuserData();
          // Successfully updated preference
        }
      });
      }
    }
    
    // approve timesheet function start
    window.approveTimesheet=function(){
      let userId=login_user_id;
      if(user_id!=null)
      {
        userId=user_id;
      }
      $.get("/approve_timesheet", { 
        user_id: userId,
        params_start_date:start_range,
        params_end_date:due_range
       }, function(data) {
        if (data) {

          $("#submitTimesheet").css("display", "flex");
          $("#approveTimesheet").css("display","none");
          $("#rejectTimesheet").css("display","none");
   is_timesheet_submitted=true;
    $(".submit-timesheet").html("Timesheet Approved");
    $(".submit-timesheet").prop("disabled", true);
    $(".submit-timesheet").css("cursor", "not-allowed")
    $(".submit-timesheet").addClass("disable_timesheet");
    $(".submit-timesheet").addClass("approved_timesheet");
    // $(".submit-timesheet").css("background-color","#50C878");

    $(".export_workload").prop("disabled", true);
    $(".export_workload").css("cursor", "not-allowed");
    $(".export_workload").addClass("disable_timesheet");
     textFilter = `<div class='searchEl'>Issue<span style='background-color:#0094ffc7; cursor:not-allowed;'  class='button_issue disable_timesheet'>${t('log_time')}</span></div>`;
    // gantt left side columns
      gantt.options.columns=[
      
        {name:"text", tree: !0,   min_width: 230,  max_width: 450, label:textFilter,width:250,  resize:true ,template: function (task) {
          if(task.parent==0)
          {
            return `<div>${task.text}</div>`;
          }
          else{
            return `<div class="two-line-name"><div class="project_name"><b>${task.project_name}</b></div><div class="issue_name" style="margin-top:2px;">${task.text}</div></div>`
          }   
       }
        },
     
         {name:"activity_name",label:t('Activity'), align: "center" ,width:100 ,template: function(task){
            return task.activity_name
         } },
         
       ];
       gantt.render();
          getTotalActvities();
          getuserData();
          // Successfully updated preference
        }
      });
    }
    //approve timesheet function end 


  

    // API to check submitted timesheet of users
  function getTImesheet(){
       level_status=null;
       const selectedTeam=document.getElementById("tree-select-input");

       $("#submitTimesheet").css("display", "none");
       $("#approveTimesheet").css("display","none");
       $("#rejectTimesheet").css("display","none");
      //  add logic to show submit timesheet button as according to requirement 
      if(is_admin==false)
      {  
          $("#submitTimesheet").css("display", "flex");
          $("#exportWorkload").css("display","flex");
      }
      else if(is_admin==true&& selectedTeam.innerHTML==t('my_timesheet')&&user_id==null)
      { 
    
        $("#submitTimesheet").css("display", "flex");
        $("#exportWorkload").css("display","flex");
      }
      else if (is_admin==true&&user_id==null)
      {
        $("#submitTimesheet").css("display","none");
        $("#exportWorkload").css("display","none");
      }
      else{
        $("#submitTimesheet").css("display","flex");
        $("#exportWorkload").css("display","flex");
      }
    //  add logic to show submit timesheet button according to requirement 

    timesheet_status=null;
    let userId=login_user_id;
    if(user_id!=null)
    {
      userId=user_id;
    }
   $.ajax({
    type: "GET",
    url: `${url}/users_submitted_timesheet.json?key=${api_key}`,
    dataType: "json",
    contentType: "application/json",
    async: false,
    data:{
      start_date:  start_range,
      due_date: due_range,
      user_id:userId
    },
    success: function (result, status, xhr) {
            if(result.date_range&&result.date_range.length!=0&&result.user_id==userId)
             {
              // to unsubmit timesheet button 
              level_status=result.level_status;
                let urlParams = {
                user_id:user_id,
                user_name:user_name,
                start_date: result.start_date,
                end_date: result.end_date,
                status:result.status
                };
                if(tstatus&&tstatus!=null&&tstatus!="approved")
                {
                  let params1 =window.location.search
                  let parameters1 = new URLSearchParams(params1);
                  if(tstatus=="waiting for approval"&&start_date==result.start_date&&end_date==result.end_date)
                  {
              
                    tstatus="waiting for approval";
                    urlParams.status="waiting for approval";
                    if(start_date!=null&&end_date!=null)
                    {
                      updateUrlParams(urlParams);  
                    }
                   
                  }
                  else{
                    if(start_date!=null&&end_date!=null)
                    {
                      updateUrlParams(urlParams);  
                    }
                    tstatus=parameters1.get('status');
                  }
                
                }
      
              for (let j = 0; j <result.date_range.length; j++) {
                const element = result.date_range[j];
                if(element>=start_range&&element<=due_range)
                {
                   is_approve=result.status
                  check_timesheet=true;
                 timesheet_status=result.status;
                
                }
                
              }
           
            }      
    },
    error:function(error,status,xhr){
    }
  })

  // add logic if timesheet is submitted or approve disable the gantt
  if(is_admin==true&&user_id!=null&&check_timesheet==true&&timesheet_status=="submitted"&&((unsubmit_timesheet==false)||(unsubmit_timesheet==true)))
  {
    $("#submitTimesheet").css("display","none");
    $("#approveTimesheet").css("display","flex");
    $("#rejectTimesheet").css("display","flex");
  }
    else if(user_id!=null&&check_timesheet==true&&timesheet_status=="submitted"&&((unsubmit_timesheet==false)||(unsubmit_timesheet==true)))
    {
      $("#submitTimesheet").css("display","none");
      $("#approveTimesheet").css("display","flex");
      $("#rejectTimesheet").css("display","flex");
    }
  else if(timesheet_status==null&&check_timesheet==false)
  {
    is_timesheet_submitted=false;
    $(".submit-timesheet").html(t('submit_timesheet'));
    $(".submit-timesheet").prop("disabled", false);
    $(".submit-timesheet").css("cursor", "pointer");
    $(".submit-timesheet").removeClass("disable_timesheet");
    $(".submit-timesheet").removeClass("approved_timesheet");

    $(".export_workload").prop("disabled", false);
    $(".export_workload").css("cursor", "pointer");
    $(".export_workload").removeClass("disable_timesheet");
    textFilter = `<div class='searchEl'>Issue <span tabindex = '0' onclick='AddIssue()' onkeypress='if(event.keyCode === 13) AddIssue()' class='button_issue'>${t('log_time')}</span></div>`;
    // gantt left side columns
      gantt.options.columns=[
      
        {name:"text", tree: !0,   min_width: 230,  max_width: 450, label:textFilter,width:250,  resize:true ,template: function (task) {
          if(task.parent==0)
          {
            return `<div>${task.text}</div>`;
          }
          else{
            return `<div class="two-line-name"><div class="project_name"><b>${task.project_name}</b></div><div class="issue_name" >${task.text}</div></div>`
          }   
       }
        },
     
        {name:"activity_name",label:t('Activity'), align: "center" ,width:100 ,template: function(task){
            return task.activity_name
         } },
         
       ];
       gantt.render();
  }
  else if(user_id==null&&timesheet_status==="waiting for approval"&&check_timesheet==true&&unsubmit_timesheet==true&&level_status!="approved")
  {
    $(".submit-timesheet").html(t('unsubmit_timesheet'));
     is_timesheet_submitted=false;
  }
  else if(user_id!=null&&timesheet_status==="waiting for approval"&&check_timesheet==true&&unsubmit_timesheet==true)
  {
    is_timesheet_submitted=true;
    $(".submit-timesheet").html(timesheet_status);
    $(".submit-timesheet").prop("disabled", true);
    $(".submit-timesheet").css("cursor", "not-allowed")
    $(".submit-timesheet").addClass("disable_timesheet");
    $(".submit-timesheet").removeClass("approved_timesheet");

    $(".export_workload").prop("disabled", true);
    $(".export_workload").css("cursor", "not-allowed");
    $(".export_workload").addClass("disable_timesheet");
     textFilter = `<div class='searchEl'>Issue<span style='background-color:#0094ffc7; cursor:not-allowed;'  class='button_issue'>${t('log_time')}</span></div>`;
    // gantt left side columns
      gantt.options.columns=[
      
        {name:"text", tree: !0,   min_width: 230,  max_width: 450, label:textFilter,width:250,  resize:true ,template: function (task) {
          if(task.parent==0)
          {
            return `<div>${task.text}</div>`;
          }
          else{
            return `<div class="two-line-name"><div class="project_name"><b>${task.project_name}</b></div><div class="issue_name" style="margin-top:2px;">${task.text}</div></div>`
          }   
       }
        },
     
         {name:"activity_name",label:t('Activity'), align: "center" ,width:100 ,template: function(task){
            return task.activity_name
         } },
         
       ];
       gantt.render();  
  }

  else if(timesheet_status==="submitted"&&check_timesheet==true&&unsubmit_timesheet==false)
  {
    is_timesheet_submitted=true;
    $(".submit-timesheet").html("Timesheet Submitted");
    $(".submit-timesheet").prop("disabled", true);
    $(".submit-timesheet").css("cursor", "not-allowed")
    $(".submit-timesheet").addClass("disable_timesheet");
    $(".submit-timesheet").removeClass("approved_timesheet");

    $(".export_workload").prop("disabled", true);
    $(".export_workload").css("cursor", "not-allowed");
    $(".export_workload").addClass("disable_timesheet");
     textFilter = `<div class='searchEl'>Issue<span style='background-color:#0094ffc7; cursor:not-allowed;'  class='button_issue disable_timesheet'>${t('log_time')}</span></div>`;
    // gantt left side columns
      gantt.options.columns=[
      
        {name:"text", tree: !0,   min_width: 230,  max_width: 450, label:textFilter,width:250,  resize:true ,template: function (task) {
          if(task.parent==0)
          {
            return `<div>${task.text}</div>`;
          }
          else{
            return `<div class="two-line-name"><div class="project_name"><b>${task.project_name}</b></div><div class="issue_name" style="margin-top:2px;">${task.text}</div></div>`
          }   
       }
        },
     
         {name:"activity_name",label:t('Activity'), align: "center" ,width:100 ,template: function(task){
            return task.activity_name
         } },
         
       ];
       gantt.render();
  }
  else if(timesheet_status==="approved"&&check_timesheet==true)
  {
    is_timesheet_submitted=true;
    $(".submit-timesheet").html("Timesheet Approved");
    $(".submit-timesheet").prop("disabled", true);
    $(".submit-timesheet").css("cursor", "not-allowed")
    $(".submit-timesheet").addClass("disable_timesheet");
    $(".submit-timesheet").addClass("approved_timesheet");
    // $(".submit-timesheet").css("background-color","#50C878");

    $(".export_workload").prop("disabled", true);
    $(".export_workload").css("cursor", "not-allowed");
    $(".export_workload").addClass("disable_timesheet");
     textFilter = `<div class='searchEl'>Issue<span style='background-color:#0094ffc7; cursor:not-allowed;'  class='button_issue disable_timesheet'>${t('log_time')}</span></div>`;
    // gantt left side columns
      gantt.options.columns=[
      
        {name:"text", tree: !0,   min_width: 230,  max_width: 450, label:textFilter,width:250,  resize:true ,template: function (task) {
          if(task.parent==0)
          {
            return `<div>${task.text}</div>`;
          }
          else{
            return `<div class="two-line-name"><div class="project_name"><b>${task.project_name}</b></div><div class="issue_name" style="margin-top:2px;">${task.text}</div></div>`
          }   
       }
        },
     
         {name:"activity_name",label:t('Activity'), align: "center" ,width:100 ,template: function(task){
            return task.activity_name
         } },
         
       ];
       gantt.render();
  }
  else if(timesheet_status==="submitted"&&check_timesheet==true)
  {
    is_timesheet_submitted=true;
    $(".submit-timesheet").html("Timesheet submitted");
    $(".submit-timesheet").prop("disabled", true);
    $(".submit-timesheet").css("cursor", "not-allowed")
    $(".submit-timesheet").addClass("disable_timesheet");
    $(".submit-timesheet").removeClass("approved_timesheet");

    $(".export_workload").prop("disabled", true);
    $(".export_workload").css("cursor", "not-allowed");
    $(".export_workload").addClass("disable_timesheet");
     textFilter = `<div class='searchEl'>Issue<span style='background-color:#0094ffc7; cursor:not-allowed;'  class='button_issue'>${t('log_time')}</span></div>`;
    // gantt left side columns
      gantt.options.columns=[
      
        {name:"text", tree: !0,   min_width: 230,  max_width: 450, label:textFilter,width:250,  resize:true ,template: function (task) {
          if(task.parent==0)
          {
            return `<div>${task.text}</div>`;
          }
          else{
            return `<div class="two-line-name"><div class="project_name"><b>${task.project_name}</b></div><div class="issue_name" style="margin-top:2px;">${task.text}</div></div>`
          }   
       }
        },
     
         {name:"activity_name",label:t('Activity'), align: "center" ,width:100 ,template: function(task){
            return task.activity_name
         } },
         
       ];
       gantt.render();
  }
  else if(timesheet_status!=null&&timesheet_status.includes("Waiting")&&check_timesheet==true)
  {

    is_timesheet_submitted=true;
    $(".submit-timesheet").html(timesheet_status);
    $(".submit-timesheet").prop("disabled", true);
    $(".submit-timesheet").css("cursor", "not-allowed")
    $(".submit-timesheet").addClass("disable_timesheet");
    $(".submit-timesheet").removeClass("approved_timesheet");

    $(".export_workload").prop("disabled", true);
    $(".export_workload").css("cursor", "not-allowed");
    $(".export_workload").addClass("disable_timesheet");
     textFilter = `<div class='searchEl'>Issue<span style='background-color:#0094ffc7; cursor:not-allowed;'  class='button_issue'>${t('log_time')}</span></div>`;
    // gantt left side columns
      gantt.options.columns=[
      
        {name:"text", tree: !0,   min_width: 230,  max_width: 450, label:textFilter,width:250,  resize:true ,template: function (task) {
          if(task.parent==0)
          {
            return `<div>${task.text}</div>`;
          }
          else{
            return `<div class="two-line-name"><div class="project_name"><b>${task.project_name}</b></div><div class="issue_name" style="margin-top:2px;">${task.text}</div></div>`
          }   
       }
        },
     
         {name:"activity_name",label:t('Activity'), align: "center" ,width:100 ,template: function(task){
            return task.activity_name
         } },
         
       ];
       gantt.render();  
  }
  else if(timesheet_status!=null&&timesheet_status.includes("waiting for approval")&&check_timesheet==true)
  {
    // if user redirect and found status waiting for approval 
    is_timesheet_submitted=true;
    $(".submit-timesheet").html(timesheet_status);
    $(".submit-timesheet").prop("disabled", true);
    $(".submit-timesheet").css("cursor", "not-allowed")
    $(".submit-timesheet").addClass("disable_timesheet");
    $(".submit-timesheet").removeClass("approved_timesheet");

    $(".export_workload").prop("disabled", true);
    $(".export_workload").css("cursor", "not-allowed");
    $(".export_workload").addClass("disable_timesheet");
     textFilter = `<div class='searchEl'>Issue<span style='background-color:#0094ffc7; cursor:not-allowed;'  class='button_issue'>${t('log_time')}</span></div>`;
    // gantt left side columns
      gantt.options.columns=[
      
        {name:"text", tree: !0,   min_width: 230,  max_width: 450, label:textFilter,width:250,  resize:true ,template: function (task) {
          if(task.parent==0)
          {
            return `<div>${task.text}</div>`;
          }
          else{
            return `<div class="two-line-name"><div class="project_name"><b>${task.project_name}</b></div><div class="issue_name" style="margin-top:2px;">${task.text}</div></div>`
          }   
       }
        },
     
         {name:"activity_name",label:t('Activity'), align: "center" ,width:100 ,template: function(task){
            return task.activity_name
         } },
         
       ];
       gantt.render();  
  }
  else{
  
    is_timesheet_submitted=false;
    $(".submit-timesheet").html(t('submit_timesheet'));
    $(".submit-timesheet").prop("disabled", false);
    $(".submit-timesheet").css("cursor", "pointer");
    $(".submit-timesheet").removeClass("disable_timesheet");
    $(".submit-timesheet").removeClass("approved_timesheet");

    $(".export_workload").prop("disabled", false);
    $(".export_workload").css("cursor", "pointer");
    $(".export_workload").removeClass("disable_timesheet");
    textFilter = `<div class='searchEl'>Issue<span tabindex ='0 'onclick='AddIssue()' onkeypress='if(event.keyCode === 13) AddIssue()' class='button_issue'>${t('log_time')}</span></div>`;
    // gantt left side columns
      gantt.options.columns=[
      
        {name:"text", tree: !0,   min_width: 230,  max_width: 450, label:textFilter,width:250,  resize:true ,template: function (task) {
          if(task.parent==0)
          {
            return `<div>${task.text}</div>`;
          }
          else{
            return `<div class="two-line-name"><div class="project_name"><b>${task.project_name}</b></div><div class="issue_name" >${task.text}</div></div>`
          }   
       }
        },
     
        {name:"activity_name",label:t('Activity'), align: "center" ,width:100 ,template: function(task){
            return task.activity_name
         } },
         
       ];
       gantt.render();
  }

 }
   // API to get submitted timesheets of user end 
 
// timesheet team select on change function 
// $("#Select_team_timesheet").change(function(){
  function filterteam(teamid)
  {
  var team_id=teamid
  is_selected_team=team_id


  $("#submitTimesheet").css("display","none");
  $("#exportWorkload").css("display","none");

  if(team_id!=0)
  {
    is_timesheet_submitted=false;
    check_timesheet=false;
    textFilter = `<div class='searchEl'>Issue<span tabindex = '0' onclick='AddIssue()' onkeypress='if(event.keyCode === 13) AddIssue()' class='button_issue'>${t('log_time')}</span></div>`;
    // gantt left side columns
      gantt.options.columns=[
      
        {name:"text", tree: !0,   min_width: 230,  max_width: 450, label:textFilter,width:250,  resize:true ,template: function (task) {
          if(task.parent==0)
          {
            return `<div>${task.text}</div>`;
          }
          else{
            return `<div class="two-line-name"><div class="project_name"><b>${task.project_name}</b></div><div class="issue_name" >${task.text}</div></div>`
          }   
       }
        },
     
        {name:"activity_name",label:t('Activity'), align: "center" ,width:100 ,template: function(task){
            return task.activity_name
         } },
         
       ];
        teampageNum=1;
        teamperpage=10;
     getTotalActvitiesbyTeam(team_id);
     getteamsData();
  }
  else{
  const selectedTeam=document.getElementById("tree-select-input");
  selectedTeam.innerHTML=t('my_timesheet');
        perpage=15;
        pagenum=1;
        getTImesheet();
       // get activity sum 
       getTotalActvities();
       getuserData();
  }

    // POST API to send team  data to backend 
    $.ajax({
      type: "POST",
      url: `${url}/create/team.json?key=${api_key}`,
      dataType: 'json',
      // async:false,
      data: {
        team_id:team_id,
      },
      success: function (result, status, xhr) {
      },
      error:function(xhr,status,error)
      {
         
      }
    })
  }
// })
 // POST API to send team  data to backend  end

//  get user assigned issue API 
window.getIssues=function(user_id){
 $.ajax({
   type: "GET",
   url: `${url}/users_assigned_issues.json?user_id=${user_id}&key=${api_key}`,
   dataType: 'json',
   async:false,
   success: function (result, status, xhr) {
   $("#dynamic_select").html(" ");
    $("#issue-drop ul").html(" ");
  if(result.length!=0){
   result.map((i)=>{
   $("#issue-drop ul").append(`<li class='option${($(i).is(':selected') ? 'selected' : '')}'  data-category=${i.category_id}  data-value=${i.id}  data-project=${i.project_id} ><span class="task_id"> ${'#'+i.id}</span><span>${i.subject }</span></li>`)
     $("#dynamic_select").append(`<option data-project=${i.project_id}  data-category=${i.category_id}   id=${user_id} value=${i.id} >${i.subject}</option>`)
  })
  }
   },
   error: function (xhr, status, error) {
     $("#dynamic_select").html(" ");
         $("#issue-drop ul").html(" ");
    if(xhr.status == 403)
      {
       alert("unauthorized");
     }
   }
 });
}
// get user assigned API end 
function getHours(task,cellDate){
  var sum=0;
    if(task.dates&&task.dates.length!=0)
    {
      task.dates.map((list)=>{
        if(list.date==cellDate)
        {
   
          if(task.time_format==="minutes")
          {
            var timeArray = list.hours.split(":");
            sum += parseInt(timeArray[0]) + parseInt(timeArray[1]) / 60; 
          }
          else{
            sum =sum+list.hours;
         
          }
        
        }
      })
    }
  return sum;
}

// get particular issue detail API start
function getIssueDetail(id)
{
  var issues=null;
  $.ajax({
    type: "GET",
    url:`${url}/issues/${id}.json?key=${api_key}`,
    dataType: "json",
    contentType: "application/json",
    async:false,
    success: function (result, status, xhr) {
      issues=result.issue;
    },

    error: function (xhr, status, error) {
    },
  });
  return issues;
}
// get particular issue detail API end 


// gantt events and functions start 
// on cell click event 
gantt.attachEvent("onCellClick", function(event){

  var is_timeentry=false;
  clickoncell=true;
  $("#user_div").css("display","none");
  $("#current-user").attr("value");
  $(".issue_name_div").css("width","586px");
  $("#edit_category_error").css("display","none");
  $(".edit_log_time").css("margin-bottom","10px");
  $("#approvedhour_error").html(" ");
  let Task=event.task;


  if(is_timesheet_submitted==false)
  {
   if(Task.parent==0)
   {
    let userId=Task.id;
    if(user_id)
    {
      userId=user_id
    }
    let cell_date=event.cellDate;
    getIssues(userId);
    $("#spent_hour").val("");
    $("#current-issue").attr("user_id",userId);
    $("#current-issue").removeAttr("value");
    $("#issue-error-div").css("display","none");
    $("#spent-error-div").css("display","none");
    $("#activity-div").css("display","none");
    $("#comment-div").css("display","none");
    $("#current-issue").html(t("search_issues"));
    $("#i-div").css("margin-bottom","9px");
    $("#log_date").val(cell_date);
    $("#select_activity").html(" ");
    $("#select_category").html(" ");
    if($(".text-area-res").val()!==t("comments"))
    {
      $(".text-area-res").val("");
    }
    var issue_dropdown = $('#issue-drop')
    issue_dropdown.prop('disabled',false);
    $('#issue-drop').css("opacity","revert");
    $('#issue-drop').css("cursor","pointer");
    $('.div-modal').show();
    $('.modal').show();
    disableTabindex('.modal');
     

    checkrequiredfields();
    $("#user_div").css("display","none");

  }
  else {
    is_timeline=true;
    let date=event.cellDate;
    cellDate=date;
    $("#user_div").css("display","none");
        var spent_hours;
        var time_entry_id=Task.time_entry_id;
        var activity_name=Task.activity_name;
        var activity_id=Task.activity_id;
        var issue_name=Task.subject;
        var issue_id =Task.issue_id;
        var project_id=Task.project_id;
        var task_id=Task.issue_id;
        let user_id=Task.parent;
        let cell_date=event.cellDate;
        var issue_detail= getIssueDetail(issue_id);
        issue_name=issue_detail.subject;
        project_id=issue_detail.project.id;

       if(Task.dates&&Task.dates.length!=0){
           Task.dates.map((t)=>{
            if(t.date==event.cellDate)
            {
               is_timeentry=true;
            }
           })
        }
       if(!is_timeentry)
      {
      spent_hours==undefined||spent_hours==='hour'? $("#spent_hour").val(""):$("#spent_hour").val(spent_hours);
      issue_name==undefined? $("#current-issue").html("Search issues..."):$("#current-issue").html(issue_name);
       activity_name==undefined? $("#select_activity").val():$("#select_activity").val(activity_name);
      $("#current-issue").attr("user_id",user_id);
      $("#current-issue").attr("value",issue_id);
      $("#issue-error-div").css("display","none");
      $("#spent-error-div").css("display","none");
      $("#activity-div").css("display","none");
      $("#comment-div").css("display","none");
      $("#i-div").css("margin-bottom","9px");
      $("#log_date").val(cell_date);
      getProjectTimeentry(project_id);
      if(budgetauditPluginExists)
      {
   
        getProjectactivity(project_id);
      }
   

      $("#select_activity").val(activity_id);
      if($(".text-area-res").val()!==t("comments"))
      {
          $(".text-area-res").val("");
      }
      var issue_dropdown = $('#issue-drop')
      issue_dropdown.prop('disabled',true);
      $('#issue-drop').css("opacity","0.7");
      $('#issue-drop').css("cursor","default");
       $('.div-modal').show();
       $('.modal').show();
       checkrequiredfields();
       disableTabindex('.modal');
      //  $('#issue-drop').focus();
      
       }
       else{
         var new_array=[];
         var array_data=[];
        function makeRequest(url) {
          return new Promise((resolve, reject) => {
            $.ajax({
              url: url,
              async:false,
              success: function(data) {
                resolve(data);
                array_data=data.time_entries;
              },
              error: function(error) {
                reject(error);
              }
            });
          });
        }
        async function getData() {
          try {
            const data = await makeRequest(`${url}/time_entries.json?issue_id=${issue_id}&key=${api_key}`);
           
            
          } catch (error) {
            console.error(error);
          }
        }
        getData();
        array_data.map((list)=>{
    
          let activity_api_name=list.activity.name.replace(/\s/g, "");
          let activities_name=activity_name.replace(/\s/g, "");
         
          if(Task.parent===list.user.id&&activity_api_name===activities_name&&list.spent_on===cell_date)
          {
            new_array.push(list)

          }
        })

        // Assuming new_array and task.time_entries are already defined
      let matchedEntries = [];

      new_array.forEach(list => {
        let matchingEntry = Task.time_entries.find(entry => entry.time_entry_id == list.id);
        if (matchingEntry) {
          matchedEntries.push(list);
        }
      });
      new_array =matchedEntries;

        var $myDiv = $('#main_div_log'); 
        $myDiv.css('overflow-y', 'auto');
        $myDiv.css('height', "auto"); 
          GanttIssueid=task_id;
           var activities= getProjectTimeentry(project_id);
           $(".plus_entry").css("display","none");
            $('.edit-modal').show();
            $('.Editmodal').show();
            disableTabindex('.Editmodal');
          $("#main_div_log").html(" ");
           if(new_array&&new_array.length!=0)
           {
              let Dates=new_array;
              Dates.map((i)=>{
              
                let issue_comment=" ";
                if(i.comments.length!=0)
                {
                  issue_comment=i.comments.split(" ").join("&nbsp;") 
                }
                else{
                 
                  issue_comment=issue_comment.split(" ").join("&nbsp;")
                }
        
                if(Task.time_format==="decimal")
                {
                  i.hours=Number.isInteger(i.hours)?i.hours:i.hours.toFixed(2)
                }
                else if(Task.time_format==="minutes")
                {
                  const hourPart = Math.floor(i.hours);
                  const minutePart = Math.round((i.hours  - hourPart) * 60);
                  const minutePartWithZero = String(minutePart).padStart(2, '0');
                  i.hours= hourPart+":"+minutePartWithZero;
                }
                $("#main_div_log").append(`<div  value=${i.id} class="edit_div" id="time_entry${i.id}" style="display:flex; flex-direction:row; gap:16px;">
                  <div style="display:flex; flex-direction:column;">
                  <div style="display:flex;">
                     <label  class="label_edit_timesheet">${t('Date')}</label>
                  
                   </div>
                   <div  style="display:flex;">
                       <input  autocomplete="off" min=${storedStart ? storedStart :start_range} max=${storedEnd ? storedEnd: due_range} name="logdate" value="${i.spent_on}" class="input_comment disable_button" id="issue_date"  type="date">
                     </div>
               </div>
      
                <div style="display:flex; flex-direction:column;">
                    <div style="display:flex;">
                       <label  class="label_edit_timesheet">${t('Comment')}</label>
                       <span style="display:none;"  class="text-asterik-edit">*</span>
                     </div>
                      <div style="display:flex; flex-direction:column;">
                      <div style="display:flex;">
                       <input  autocomplete="off"  value="${issue_comment}"  name="comment" id="t_comments" style="width:250px;" class="input_comment disable_button  coments" />
                     </div>
                     <div class="error-div-old-comment" style="display:none;">
                     <div  class="error-msg-old-comment error" style="font-size:11px;"> </div>
                   </div>
                   </div>
                 </div>
      
                <div style="display:flex; flex-direction:column;">
                    <div style="display:flex;">
                       <label class="label_edit_timesheet">${t('spent_time')}</label>
                       <span class="text-asterik">*</span>
                     </div>
                      <div style="display:flex; flex-direction:column;">
                      <div style="display:flex;">
                       <input autocomplete="off" value="${i.hours}"  name="spent_time" id="spent_h" style="width:140px;" class="input_comment disable_button  spent_time_old"  />
                     </div>

                     <div class="error-div-old-spent" style="display:none;">
                     <div  class="error-msg-old-spent error" style="font-size:11px;"> </div>
                  </div>
                  </div>
                 </div>
      
                  <div style="display:flex; flex-direction:column;">
                    <div style="display:flex;">
                       <label  class="label_edit_timesheet">${t('Activity')}</label>
                     </div>
                      <div style="display:flex;">
                           <select  name="activity"  id="activity_project" class="edit_activity disable_button" >
                            ${activities.map((i)=>{
                              if(i.id==activity_id)
                              {
                                return `<option selected value=${i.id} id=${i.id}>${i.name}</option>` 
                              }
                              else{
                                return `<option value=${i.id} id=${i.id}>${i.name}</option>` 
                              }
                            
                            })}
                           </select>
                     </div>
                 </div>
      
                 <div style="display:flex; flex-direction:column;">
                      <div class="disable_button_delete"  name="time" onclick="openDeleteConfirmationPopup(${i.id})" style="display:flex; justify-content:center;">
                        <img  style="height:17px; width:17px; margin-top:29px; cursor:pointer;" src="/plugin_assets/redmineflux_timesheet/images/Delete Icon.svg"/>
                     </div>
                 </div>

      
            </div>`)
              })
           }
            checkrequiredfields();
   
           $("#issueID").html(`#${issue_id}`);

           $("#issueID").attr("title",`${issue_id}`);
           $("#issueID").attr("value",time_entry_id)
           //  edit issue min and max date
           $("#issue_date").attr("min",storedStart ? storedStart :start_range);
           $("#issue_date").attr("max", storedEnd ? storedEnd: due_range);
           $("#issue_name").html(issue_name);
           $("#issue_name").attr("title",`${issue_name}`);
           if (($myDiv.children().length > 5)) {
             $myDiv.css('overflow-y', 'scroll');
             $myDiv.css('height', "320px"); 
            }
      }
  }


} 
 if(budgetauditPluginExists)
  {

    $("#c_div").css("margin-bottom","9px");
    $("#category-div-error").css("display","none");
    $("#category_project").html("");
    $("#select_category").html(" ");
    $(".issue_name_div").css("width","390px");
     if(Task.project_id)
      {
       var category=getProjectactivity(Task.project_id);
      }
      
     if(category&&category.length!=0)
     {
         is_timeentry? $("#category_project").append(`<option selected  value="0" >Select Category</option>`):$("#select_category").append(`<option selected  value="0" >Select Category</option>`);
       category.map((i)=>{
        if(!is_timeentry)
          {
            if(Task.category&&i.id==Task.category.id)
              {
                $("#select_category").append(`<option selected  value=${i.id} id=${i.id}>${i.name}</option>`);
              }
              else{
                $("#select_category").append(`<option  value=${i.id} id=${i.id}>${i.name}</option>`);
              }
          }
          else{
            if(Task.category&&i.id==Task.category.id)
              {
                $("#category_project").append(`<option selected  value=${i.id} id=${i.id}>${i.name}</option>`);
              }
              else{
                $("#category_project").append(`<option  value=${i.id} id=${i.id}>${i.name}</option>`);
              }
          }
       })
      }

  }
  document.getElementById('edit_timesheet_btn').disabled = true;
  document.getElementById('edit_timesheet_btn').style.cursor = "not-allowed";
// Select all input fields with the class 'your-class'
var inputs = document.querySelectorAll('.disable_button');

var deleteicon=document.querySelectorAll(".disable_button_delete");
deleteicon.forEach(function(input){
  input.addEventListener('click',function(){
    document.getElementById('edit_timesheet_btn').disabled = false;
    document.getElementById('edit_timesheet_btn').style.cursor = "pointer";
  })
})

// Add an 'input' event listener to each input field
  inputs.forEach(function(input) {
  input.addEventListener('input', function() {
    // Enable the button when an input field receives input
    document.getElementById('edit_timesheet_btn').disabled = false;
    document.getElementById('edit_timesheet_btn').style.cursor = "pointer";
  });
});
gantt.updateBody();
})
// gantt on cell click event end


// on task double click event 
gantt.attachEvent("onTaskDblClick", function(event){
  is_timeline=false;
  var $myDiv = $('#main_div_log'); 
  $myDiv.css('overflow-y', 'auto');
  $(".issue_name_div").css("width","586px");
  $myDiv.css('height', "auto"); 
  $("#edit_category_error").css("display","none");
  $(".edit_log_time").css("margin-bottom","10px");
  $("#approvedhour_error").html(" ");
  var task =event.task;
   if(is_timesheet_submitted==false)
  {
  if(task.parent==0)
  {
    return false;
  }
  else{
    cellDate=null;
    spent_date=task.spent_on;
    GanttIssueid=task.id;
      var category=null;
     var activities= getProjectTimeentry(task.project_id);

    $(".plus_entry").css("display","none");
    var task_id=task.issue_id;
    $('.edit-modal').show();
    $('.Editmodal').show();
   disableTabindex('.Editmodal');

    $("#main_div_log").html(" ");

     if(task.dates&&task.dates.length!=0)
     { 
        let Dates=task.dates;
      
        Dates.map((i)=>{
          if(task.time_format==="decimal")
          {
            i.hours=Number.isInteger(i.hours)?i.hours:i.hours.toFixed(2)
          }
          else if(task.time_format==="minutes"){
             i.hours=i.hours
          }
          $("#main_div_log").append(`<div  value=${i.time_entry_id} class="edit_div" id="time_entry${i.time_entry_id}" style="display:flex; flex-direction:row; gap:16px;">
            <div style="display:flex; flex-direction:column;">
            <div style="display:flex;">
               <label  class="label_edit_timesheet">${t('Date')}</label>
             </div>
             <div  style="display:flex;">
                 <input  min=${storedStart ? storedStart :start_range} max=${storedEnd ? storedEnd: due_range} name="logdate" value="${i.date}" class="input_comment disable_button" id="issue_date"  type="date">
               </div>
         </div>

          <div style="display:flex; flex-direction:column;">
              <div style="display:flex;">
                 <label  class="label_edit_timesheet">${t('Comment')}</label>
                 <span style="display:none;" class="text-asterik-edit">*</span>
               </div>
                <div  style="display:flex; flex-direction:column;">
                <div style=display:flex;">
                 <input value="${i.comments}"  name="comment" id="t_comments" style="width:250px;" class="input_comment  disable_button coments" />
                </div>
                  <div class="error-div-old-comment" style="display:none;">
                    <div  class="error-msg-old-comment error" style="font-size:11px;"> </div>
                  </div>
               </div>
           </div>

          <div style="display:flex; flex-direction:column;">
              <div style="display:flex;">
                 <label class="label_edit_timesheet">${t('spent_time')}</label>
                 <span class="text-asterik">*</span>
                 
               </div>
                <div style="display:flex; flex-direction:column;">
                <div style="display:flex;">
                 <input value="${i.hours}"  name="spent_time" id="spent_h" style="width:140px;" class="input_comment spent_time_old disable_button"  />
               </div>

               <div class="error-div-old-spent" style="display:none;">
                  <div  class="error-msg-old-spent error" style="font-size:11px;"> </div>
               </div>
               </div>
           </div>

         
    
            


            <div style="display:flex; flex-direction:column;">
              <div style="display:flex;">
                 <label  class="label_edit_timesheet">${t('Activity')}</label>
               </div>
                <div style="display:flex;">
                     <select  name="activity"  id="activity_project" class="edit_activity disable_button" >
                      ${activities.map((i)=>{
                        if(i.id==task.activity_id)
                        {
                          return `<option selected value=${i.id} id=${i.id}>${i.name}</option>` 
                        }
                        else{
                          return `<option value=${i.id} id=${i.id}>${i.name}</option>` 
                        }
                      
                      })}
                     </select>
               </div>
           </div>

           <div style="display:flex; flex-direction:column;">
                <div  class="disable_button_delete" name="time" onclick="openDeleteConfirmationPopup(${i.time_entry_id})" style="display:flex; justify-content:center;">
                  <img  style="height:17px; width:17px; margin-top:29px; cursor:pointer;" src="/plugin_assets/redmineflux_timesheet/images/Delete Icon.svg"/>
               </div>
           </div>

      </div>`)
        })


     }
     checkrequiredfields();
     $("#issueID").html(`#${task_id}`);
     $("#issueID").attr("title",`${task_id}`);
     $("#issueID").attr("value",task.time_entry_id)
     $("#issue_date").val(task.spent_on);
     //  edit issue min and max date
     $("#issue_date").attr("min",storedStart ? storedStart :start_range);
     $("#issue_date").attr("max", storedEnd ? storedEnd: due_range);
     $("#issue_name").html(task.text);
     $("#issue_name").attr("title",`${task.text}`);
     if (($myDiv.children().length > 5)) {
       $myDiv.css('overflow-y', 'scroll');
       $myDiv.css('height', "320px"); 
      }

  }
  if(budgetauditPluginExists)
  {
     $(".issue_name_div").css("width","390px");
     category=getProjectactivity(task.project_id);
     $("#category_project").html(" ");
     if(category.length!=0)
     {
      $("#category_project").append(`<option selected  value="0" >Select Category</option>`);
       category.map((i)=>{
         if(task.category&&(i.id==task.category.id))
          {
            $("#category_project").append(`<option selected  value=${i.id} id=${i.id}>${i.name}</option>`);
          }
          else{
            $("#category_project").append(`<option  value=${i.id} id=${i.id}>${i.name}</option>`);
          }
      
       })
      }

  }
  gantt.updateBody();
  document.getElementById('edit_timesheet_btn').disabled = true;
  document.getElementById('edit_timesheet_btn').style.cursor = "not-allowed";
// Select all input fields with the class 'your-class'
var inputs = document.querySelectorAll('.disable_button');
var deleteicon=document.querySelectorAll(".disable_button_delete");
deleteicon.forEach(function(input){
  input.addEventListener('click',function(){
    document.getElementById('edit_timesheet_btn').disabled = false;
    document.getElementById('edit_timesheet_btn').style.cursor = "pointer";
  })
})
// Add an 'input' event listener to each input field
  inputs.forEach(function(input) {
  input.addEventListener('input', function() {
    // Enable the button when an input field receives input
    document.getElementById('edit_timesheet_btn').disabled = false;
    document.getElementById('edit_timesheet_btn').style.cursor = "pointer";
  });
});
  return true;
}
else{
  return false;
}


});
// on task double click event end

 // ZT gantt event on scroll of gantt vertical scroll bar 
    gantt.attachEvent("onScroll", (event) => {
      let element1= $(".zt-gantt-ver-scroll");
      var scrollElement = element1;
      var scrollTop = scrollElement.scrollTop();
      var scrollHeight = scrollElement.prop("scrollHeight");
      var clientHeight = scrollElement.prop("clientHeight");
      if(scrollTop + clientHeight >= scrollHeight) {
      //make your ajax call her
            // if(total_pages!=pagenum)
            // {
             
              if(user_id!=null)
                {
                  is_selected_team=0;
                  $("#timesheet_team").css("display","none");

                }
              setTimeout(() => {
              if(is_admin)
                {
                        if(is_selected_team&&is_selected_team!=0)
                         {
                          // pagenum++;
                          if(teamtotalPages!=teampageNum)
                            {
                              teampageNum++;
                              getteamsData(true);
                            }
                         }
                         else {
                          if(total_pages!=pagenum)
                            {
                              pagenum++;
                              getuserData(true);
                            }
                          }
                 }
               else{
                if(total_pages!=pagenum)
                  {
                     pagenum++;
                    getuserData(true);
                  }    
               }
              },500);
        // }
          }
  });
    // ZT gantt event on scroll of gantt vertical scroll bar 
 
    // search issues and users in gantt function start
    window.searchTask=function(e) {
      let isFilter = e.target.value.trim() !== "";
      gantt.filterTask((task) => {
        if (task.parent === 0) {
          return task.text.toLowerCase().includes(e.target.value.toLowerCase())||task.id==e.target.value;
        } else {
          return task.text.toLowerCase().includes(e.target.value.toLowerCase())||task.issue_id==e.target.value;
        }
      }, isFilter,true);
    }
    // search users and issues in gantt end 

        // check spent hours function to send in timesheet API 
        function checkHours(){
          let is_hours=false;
          let userId=login_user_id;
          if(user_id!=null)
          {
            userId=user_id
          }
          gantt.eachTask((list)=>{
            if(list.time_format=="decimal"&&list.spent_hours!=0)
            {
              is_hours=true;
            }
            else if(list.time_format=="minutes"&&list.spent_hours!="0:00")
            {
              is_hours=true;
            }
            if(list.id==userId)
            {
              user_hour=list.spent_hours
            }
          })
          if(is_hours==true)
          {
            return true;
          }
          else{
            return false;
          }
        }
        // check spent hour function end

         // Helper function to convert day string to day number (0 for Sunday, 1 for Monday, etc.)
         function getDayNumber(day) {
          const daysOfWeek = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
          const index = daysOfWeek.indexOf(day[0]);
          if (index !== -1) {
              return index;
          } else {
              // Handle invalid day input
              console.error('Invalid day:', day[0]);
              return null;
          }
          // return days.getDay(day);
      }

        // on submit button click call POST API 
        window.SubmitTimesheet=function(){
          var enable_timesheet=false;
          let value= checkHours();
          let checkformat=null;
           let activities = timesheet.data.filter(li => li.parent !== 0).map(li => {
            let hours=0;
             if(li.dates&&li.dates.length!=0)
             { 
               for (let i = 0; i < li.dates.length; i++) {
                 if(li.activity_id===li.activity_id)
                 {
                 if(li.time_format==="minutes")
                 {  
                  checkformat="minutes";
                   var timeArray = li.dates[i].hours.split(":");
                   hours+= parseInt(timeArray[0]) + parseInt(timeArray[1]) / 60; 
                 }
                 else{
                   hours += li.dates[i].hours;
                 }
               }  
               }
             }
             return { "activity_id": li.activity_id, "hours":Number.isInteger(hours)?hours:hours.toFixed(2), "activity_name": li.activity_name };
           }).filter(Boolean);

          if(!is_timesheet_submitted)
          {
            if(!value)
            {
              enable_timesheet=false;
              toastr["error"](t("label_fill_your_timesheet")); 
            }
            else if(timesheetFrequency&&timesheetFrequency[0]==='Monthly')
            {

                 let startYear = new Date(start_range).getFullYear();
                 let startMonth = new Date(start_range).getMonth();
                 let endYear = new Date(due_range).getFullYear();
                 let endMonth = new Date(due_range).getMonth();
                 let firstDay = new Date(startYear, startMonth, 1);
                 let lastDay = new Date(endYear, endMonth + 1, 0);
                 if (start_range=== changeFormat(firstDay) &&  due_range=== changeFormat(lastDay)) {
                  //  $("#submitTimesheet").css("display","flex");
                   enable_timesheet=true;
                 }
                  else {
                    enable_timesheet=false;
                    if(timesheet_status==="submitted")
                    {
                    toastr["error"](t("label_unsubmit_timesheet_monthly"));
                    }
                    else{
                      toastr["error"](t("label_submit_timesheet_monthly"));
                    } 
                 }
               
            }
            else if(timesheetFrequency&&timesheetFrequency[0]==='Weekly')
             {
              let startDate = new Date(start_range);
              if(startDate.getDay()==getDayNumber(week_start))
              {
               let startDate = new Date(start_range);
               let endDate = new Date(due_range);
               let differenceInTime = endDate.getTime() - startDate.getTime();
               let differenceInDays = differenceInTime / (1000 * 3600 * 24);
                 if (differenceInDays + 1 === 7) { 
                   enable_timesheet=true;// Display the submit button
                     
                } else {
                  enable_timesheet=false;
                  if(timesheet_status==="submitted")
                  {
                    toastr["error"](t("label_unsubmit_timesheet_weekly")); 
                  }
                  else{
                    toastr["error"](t("label_submit_timesheet_weekly"));  
                  }
              }
            }
            else{

              toastr["error"](`Please select  ${week_start[0]}  as start of the week (7days) to submit your timesheet. The submission frequency is set to weekly`);
            }
              
          }
          else if(timesheetFrequency&&timesheetFrequency[0]==='Partial')
          {
            enable_timesheet=true;
          }
            
              if(enable_timesheet)
              {
              if(timesheet_status==null||timesheet_status==="pending"||unsubmit_timesheet==false||timesheet_status==="unsubmitted"||timesheet_status==="rejected"||timesheet_status==="unsubmit")
               {
                let userId=login_user_id;
                if(user_id!=null)
                {
                  userId=user_id;
                }
               let submit_timesheet={
                "user_id":userId,
                "hours":user_hour.toString(),
                "start_date":start_range,
                "end_date":due_range,
                "timesheet_activities_attributes":activities
               }
                  $.ajax({
                  type: "POST",
                  url: `${url}/submit_timesheet.json?key=${api_key}`,
                  dataType: "json",
                  contentType: "application/json",
                  async: false,
                  data: JSON.stringify({
                    "submit_timesheet":submit_timesheet,
                  }),
                  success: function (result, status, xhr) {
                    let res=result.timesheet
                    getTImesheet();
                    const languagePreference = $('html').attr('lang')||'en';// Change this to 'ar' for Arabic

                    if (languagePreference === 'ar') {
                        toastr["success"](`تم تقديم الجدول الزمني للنطاق ${start_range} و ${due_range} ، يرجى الانتظار لموافقة المدير`);
                    } else {
                        toastr["success"](`Timesheet is submitted for range ${start_range} & ${due_range}, please wait for manager approval`);
                    }
                  //  toastr["success"](`Timesheet is submitted for range ${start_range} & ${due_range} , please wait for manager approval`); 
                
                  },
                  error:function(error,status,xhr){
                
                  if(xhr.status == 500){
                    toastr["error"]("Server Error");  
                  }
                  else {
                  // let content = JSON.parse(xhr.responseText).errors;
                    toastr["error"](error.responseText); 
                  }

                  }
                  })
              }
              else{
                if(timesheet_status==="waiting for approval"&&unsubmit_timesheet==true)
                {
                  let userId=login_user_id;
                  if(user_id!=null)
                  {
                    userId=user_id;
                  }
                  $.ajax({
                    type: "PUT",
                    url: `${url}/unsubmit/timesheet.json?key=${api_key}&&user_id=${userId}&&start_date=${start_range}&&end_date=${due_range}`,
                    dataType: "json",
                    contentType: "application/json",
                    async: true,
                    success: function (result, status, xhr) {
                      const languagePreference = $('html').attr('lang')||'en'; // Change this to 'ar' for Arabic

                      if (languagePreference === 'ar') {
                          toastr["success"](`تم إلغاء تقديم الجدول الزمني للنطاق ${start_range} و ${due_range}`);
                      } else {
                          toastr["success"](`Timesheet is unsubmitted for range ${start_range} & ${due_range}`);
                      }
                      
                      // toastr["success"](`Timesheet is unsubmitted for range ${start_range} & ${due_range}`); 
                      getTImesheet();
                    
                    }  
                    ,
                    error:function(error,status,xhr){
                  
                    if(xhr.status == 500){
                      toastr["error"]("Server Error");  
                    }
                    else {
                    // let content = JSON.parse(xhr.responseText).errors;
                      toastr["error"](error.responseText); 
                    }
                  }
                    })
                }
              }
            }
        
        }
      }   
      // on submit button click POST API end  




window.filter=function(){
  var valThis = $('#txtSearchValueuser').val();

  if(valThis.length!=0)
  {
  $.ajax({
      type: "GET",
      url: `${url}/search_timesheet_users.json?key=${api_key}`,
      dataType: 'json',
      async:false,
      contentType: "application/json",
      data: {
        name: valThis.trim(),
        team_id:is_selected_team
      },
      success: function (result, status, xhr) {
          $("#user-drop ul").html(" ");
          if (Array.isArray(result) && result.length != 0)
          {
              result.map((i)=>{
                  $("#user-drop ul").append('<li class="option ' + ($(i).is(':selected') ? 'selected' : '') + '" data-value="' + i.id + '">' + i.firstname+" "+i.lastname + '</li>')
            })
          }
      
      },
      error: function (xhr, status, error) {
      }
      });
    }
       else{
      $("#user-drop ul").html( " ");
      if(Users.length!=0){
          Users.map((i)=>{
            $("#user-drop ul").append('<li class="option ' + ($(i).is(':selected') ? 'selected' : '') + '" data-value="' + i.id + '">' + i.firstname+" "+i.lastname + '</li>')
          })
        }
  }

};
    

// gantt collapse/expand start
var  dropdown = $("#detail"); 
if (dropdown_selected_option) {
  dropdown.val(dropdown_selected_option);
  if(dropdown_selected_option==="expand")
  {
   gantt.options.collapse =false;
  }
  else{
    gantt.options.collapse = true;
  }
}
//On dropdown change and save the preference to the database
$("#detail").on("change", function() {
  const selectedOption = $(this).val();
  if(selectedOption=="expand")
    {
      gantt.expandAll();
    }
    else{
      gantt.collapseAll();
    }
  $.post("/update_timesheetdropdown_preference", { selected_option: selectedOption }, function(data) {
    if (data.success) {
   
    }
  });
});
// gantt collapse/expand start end 
// add full screen 
window.showFullscreentimesheet=function(){
  gantt.requestFullScreen();
  $("#wrapper").addClass("timesheetfullscreen");
}
gantt.attachEvent("onCollapse", function (){
 $("#wrapper").removeClass('zt-timesheet-fullScreen-wrapper');


});
gantt.attachEvent("onExpand", function (){
  $("#wrapper").addClass('zt-timesheet-fullScreen-wrapper');
 });


document.addEventListener("fullscreenchange", function() {
  if (!document.fullscreenElement) {
    $("#wrapper").removeClass("timesheetfullscreen");
    $('.tooltip').hide();
  }
});

})
// document  ready function end 




// export workload function start 
window.initWorkload=function(){
  let workload_imported=false;
  var mergedArray=[];

  $.ajax({
    type: "GET",
    url: `${url}/workload/issues.json?key=${api_key}`,
    dataType: 'json',
    async:false,
    beforeSend: function(){
      let body_div=document.getElementsByClassName("has-main-menu controller-timesheets  action-index");
      let div=document.createElement("div");
      div.className="unknown-div";
      div.style.display="block";
      body_div[0].appendChild(div);
       $('.circle-loader').show();
     },
    data: {
      start_date: start_range,
      due_date:due_range
    },
    success: function (result, status, xhr) {

     
      $('.circle-loader').toggleClass('load-complete');
      $('.checkmark').toggle();
      setTimeout(() => {
        $(".unknown-div").css("display","none");
        $('.circle-loader').hide();
        }, 500);
   
        gantt.clearAll();
       

        if(result&&result.length==0)
          {
            // workload_imported=false;
             mergedArray=[...timesheet.data]

        
          }
          else{
         
            timesheet.data.map((i)=>{
              result.map((j)=>{
          
                if(j.id==i.issue_id)
                {
                  workload_imported=true;
                  return;
                }
              })
            })
            if(workload_imported==false)
            {
              mergedArray=[...timesheet.data, ...result]
              gantt.options.data = mergedArray;
              gantt.render();
            }
        
                
          }

    },
    error: function (xhr, status, error) {
      $('.circle-loader').toggleClass('load-complete');
      $('.checkmark').toggle();
      setTimeout(() => {
        $(".unknown-div").css("display","none");
        $('.circle-loader').hide();
        }, 500);
    }
});

let issue_ids=[];
mergedArray.map((i)=>{
  if(i.parent!=0)
  {
    return issue_ids.push(i.issue_id)
  }
 
})

if(workload_imported==false)
{

  let import_workload={
  "user_id":login_user_id,
  "start_date":start_range,
  "end_date":due_range,
  "issue_ids":issue_ids
  }
$.ajax({
  type: "POST",
  url: `${url}/import/workload.json?key=${api_key}`,
  dataType: 'json',
  contentType: "application/json",
  async: false,
  data: JSON.stringify(({
    "import_workload":import_workload
  })),
  success: function (result, status, xhr) {
    is_workload_imported=true;
    
  },
  error:function(xhr,status,error)
  {
     if(xhr.status==422)
     {
      toastr["success"](xhr.responseJSON.errors);
     }
  }
})
}
else {
  toastr["success"]("Issues already Imported");
}


}

// export workload function end 


  // delay function when user search isseus start
  function delay(callback, ms) {
    var timer = 0;
    return function() {
      var context = this, args = arguments;
      clearTimeout(timer);
      timer = setTimeout(function () {
        callback.apply(context, args);
      }, ms || 0);
    };
  }
    // delay function when user search isseus end
    
  // search issues function start
 window.filterIssues=delay(function(){

  var user_id=$("#dynamic_select").children(":selected").attr("id");
  var valThis = $('#txtSearchValueissue').val();
  if(valThis.length!=0)
  {
  $.ajax({
      type: "GET",
      url: `${url}/search_user_issues.json?key=${api_key}&&user_id=${user_id}`,
      dataType: 'json',
      async:false,
      contentType: "application/json",
      data: {
          parameter:valThis,
      },
      success: function (result, status, xhr) {
          $("#issue-drop ul").html( " ");
          if (Array.isArray(result) && result.length != 0)
          {
              result.map((i)=>{
                  $("#issue-drop ul").append(`<li class='option${($(i).is(':selected') ? 'selected' : '')}'  data-category=${i.category_id}  data-value=${i.id}  data-project=${i.project_id} ><span class="task_id"> ${'#'+i.id}</span><span>${i.subject }</span></li>`)
            })
          }
      
      },
      error: function (xhr, status, error) {
      }
      });
    }
       else{
      $.ajax({
        type: "GET",
        url: `${url}/users_assigned_issues.json?user_id=${user_id}&key=${api_key}`,
        dataType: 'json',
        async:false,
        success: function (result, status, xhr) {
        $("#dynamic_select").html(" ");
         $("#issue-drop ul").html(" ");
       if(result.length!=0){
        result.map((i)=>{
        $("#issue-drop ul").append(`<li class='option${($(i).is(':selected') ? 'selected' : '')}' data-category=${i.category_id}   data-value=${i.id}  data-project=${i.project_id} ><span class="task_id"> ${'#'+i.id}</span><span>${i.subject }</span></li>`)
          $("#dynamic_select").append(`<option data-project=${i.project_id} data-category=${i.category_id}  id=${user_id} value=${i.id} >${i.subject}</option>`)
       })
       }
        },
        error: function (xhr, status, error) {
          $("#dynamic_select").html(" ");
              $("#issue-drop ul").html(" ");
         if(xhr.status == 403)
           {
            alert("unauthorized");
          }
        }
      });
 
      }
});
// search user issues end 


// on click of Add issue button show modal function 
function AddIssue(){

       clickoncell=false;
        $("#issue-drop ul").html(" ");
  
        let userId=login_user_id;
        let userName=login_user;
        Users.map((user)=>{
          if(is_selected_team==0)
            {
              var user_dropdown = $('#user-drop')
                user_dropdown.prop('disabled', true);
               $('#user-drop').css("opacity","0.7");
               $('#user-drop').css("cursor","default");
              $("#current-user").html(user.firstname+" "+user.lastname);
              $("#current-user").attr("value",login_user_id);
              $(".user-asterik").css("display","none");
               $("#current-issue").attr("user_id",login_user_id);
    
                 if(user_id!=null||user_name!=null)
                 {
                   userId=user_id;    
                   userName=user_name;
                 }
             getIssues(userId);
            }
            else{
              $(".user-asterik").css("display","block");
              $("#current-user").html("Select users...");
              // $("#current-user").attr("value"," ");  
              $("#current-user").removeAttr("value"); 
              var user_dropdown = $('#user-drop')
              user_dropdown.prop('disabled', false);
             $('#user-drop').css("opacity","revert");
             $('#user-drop').css("cursor","pointer");
             $("#current-issue").removeAttr("value");
             $("#current-issue").removeAttr("user_id");
            } 
        })
    
     
        $("#user_div").css("display","flex");
        var issue_dropdown = $('#issue-drop')
        issue_dropdown.prop('disabled',false);
        $('#issue-drop').css("opacity","revert");
        $('#issue-drop').css("cursor","pointer");

       if(is_timesheet_submitted==false)
        {
         $('.div-modal').show();
         $('.modal').show(); 
         disableTabindex('.modal');
         checkrequiredfields();
        }

 
    
      $("#spent_hour").val("");
      $("#current-issue").attr("user_id",userId);
      $("#current-issue").removeAttr("value");
      $("#issue-error-div").css("display","none");
      $("#user-error-div").css("display","none");
      $("#spent-error-div").css("display","none");
      $("#activity-div").css("display","none");
      $("#category-div-error").css("display","none");
      $("#comment-div").css("display","none");
      $("#current-issue").html(t("search_issues"));
      $("#i-div").css("margin-bottom","9px");
      $("#c_div").css("margin-bottom","9px");
      $("#user-div-option").css("margin-bottom","9px");
    
      $("#select_activity").html(" ");
      $("#select_category").html(" ");
      if($(".text-area-res").val()!==t("comments"))
      {
          $(".text-area-res").val("");
      }

      $("#log_date").val(start_range);

      gantt.updateBody();
  
}

// on click of Add issue button show modal function end

  // get total activities zehntech billable of login user only 
  function getTotalActvities(){
    var start_date=start_range;
    var due_date=due_range;
    $("#total").html(" ");
    const params =window.location.search
    const parameters = new URLSearchParams(params);
    const  user_id = parameters.get('user_id');
      $.ajax({
          type: "GET",
          url:`${url}/activities_total_spent.json?key=${api_key}&start_date=${start_date}&due_date=${due_date}&user_id=${user_id?user_id:login_user_id}`,
          dataType: "json",
          async:false,
          contentType: "application/json",
          beforeSend: function(){
            $('.circle-loader').show();
          },
          success: function (result, status, xhr) {
           
            if (result.total_time.length != 0) {
              time_entry_activities=result.total_time
              time_entry_activities.map((list)=>{
                $("#total").append(`<div class="a-div" style="display:flex;">
                             <label class="activities-label">${list.name}</label>
                              <span class="label-activity">${Number.isInteger(list.hours) ? list.hours+"H" :list.hours+"H"}</span>
                                </div>`)
              })
        
            }
          //  is_workload_imported= result.workload_import;
          },
          error: function (xhr, status, error) {
  
          },
        });
  }
  // get total activities zehntech billable of login user only end

 // Get activity of all users when user has admin access team spent time API 
 function getTotalActvitiesbyTeam(teamid){
  var start_date=start_range;
  var due_date=due_range;
  $("#total").html(" ");
    $.ajax({
        type: "GET",
        url:`${url}/teams_spent_time.json?key=${api_key}&start_date=${start_date}&due_date=${due_date}`,
        dataType: "json",
        contentType: "application/json",
        data:{
          team_id:teamid
        },
        success: function (result, status, xhr) {
          if (result.length != 0) {
            time_entry_activities=result
            time_entry_activities.map((list)=>{
              $("#total").append(`<div class="a-div" style="display:flex;">
                           <label class="activities-label">${list.name}</label>
                            <span class="label-activity">${Number.isInteger(list.hours) ? list.hours+"H" :list.hours+"H"}</span>
                              </div>`)
            })
      
          }
        },
        error: function (xhr, status, error) {

        },
      });
    }
 // Get activity of all users when user has admin access team spent time API end

 window.disableTabindex=function(modalSelector){
  if ($(modalSelector).is(':visible')) {
    $(":tabbable").attr("tabindex", -1);
    $(modalSelector + " [tabindex='-1']").attr("tabindex", 0);
    cursorStyle = $(".modal #user-drop").css("cursor");
    if (cursorStyle === "pointer") {
        $(".modal #user-drop").attr("tabindex", 0);
    }else{
      $(".modal #user-drop").attr("tabindex", -1);
    }
    cursor2Style = $(".modal #issue-drop").css("cursor");
    if (cursor2Style === "pointer") {
        $(".modal #issue-drop").attr("tabindex", 0);
    }else{
      $(".modal #issue-drop").attr("tabindex", -1);
    }
    $("html").css("overflow", "hidden");
  } else {
    $("[tabindex]").removeAttr("tabindex");
    $("html").css("overflow", "auto");
  }
}


 function openDeleteConfirmationPopup(timeEntryId) {
  $('.Editmodal').css('z-index', '1000');
  $('#gantt_here').css({
    'z-index': '0',
    'position': 'relative'
  });
  
  // Create the modal element
  var modal = $('<div></div>').attr('id', 'deleteConfirmationModal').addClass('delete-modal');
  var modalContent = $('<div></div>').addClass('modal-content');
  var headingDiv = $('<div></div>').addClass('heading-div');
  var heading = $('<h2></h2>').addClass('delete-heading').text(`${t('label_delete_time_entry_model')}`);
  headingDiv.append(heading);

  var confirmationMessage = $('<p></p>').addClass('delete-para').text(`${t('label_delete_time_entry_text')}`);

  var buttonContainer = $('<div></div>').addClass('button-container');

  // Create the Cancel button
  var cancelButton = $('<button></button>').attr('id', 'cancel-btn').text(`${t('Cancel')}`);
  cancelButton.on('click', closeDeleteConfirmationPopup);

  // Create the Delete button
  var deleteButton = $('<button></button>').attr('id', 'delete-btn').text(`${t('delete')}`);
  deleteButton.on('click', function() {
    deleteTimeEntry(timeEntryId);
    closeDeleteConfirmationPopup();
  });

  buttonContainer.append(cancelButton, deleteButton);
  modalContent.append(headingDiv, confirmationMessage, buttonContainer);
  modal.append(modalContent);
  $('body').append(modal);
  
}

function closeDeleteConfirmationPopup() {
  $('#deleteConfirmationModal').remove();
  $('.Editmodal').css('z-index', '');
  $('#gantt_here').css({
    'z-index': '',
    'position': ''
  });
  
}


