



function create_custom_dropdowns() {
    $('#dynamic_select').each(function (i, select) {
        if (!$(this).next().hasClass('dropdown-select')) {
            $(this).after('<div id="issue-drop" class="dropdown-select wide  ' + ($(this).attr('class') || '') + '" tabindex="0"><span  id="current-issue" class="current"></span><div class="list"><ul></ul></div></div>');
            var dropdown = $(this).next();
            var options = $(select).find('option');
            var selected = $(this).find('option:selected');
            dropdown.find('.current').html(selected.data('display-text') || selected.text());
            options.each(function (j, o) {
                var display = $(o).data('display-text') || '';
                dropdown.find('ul').append('<li class="option ' + ($(o).is(':selected') ? 'selected' : '') + '" data-value="' + $(o).val() + '" data-display-text="' + display + '">' + $(o).html() + '</li>');
            });
        }
    });
    $('#dynamic_select_user').each(function (i, select) {
        if (!$(this).next().hasClass('dropdown-select')) {
            $(this).after('<div id="user-drop" class="dropdown-select wide ' + ($(this).attr('class') || '') + '" tabindex="0"><span  id="current-user" class="current"></span><div class="list"><ul></ul></div></div>');
            var dropdown = $(this).next();
            var options = $(select).find('option');
            var selected = $(this).find('option:selected');
            dropdown.find('.current').html(selected.data('display-text') || selected.text());
            options.each(function (j, o) {
                var display = $(o).data('display-text') || '';
                dropdown.find('ul').append('<li class="option ' + ($(o).is(':selected') ? 'selected' : '') + '" data-value="' + $(o).val() + '" data-display-text="' + display + '">' + $(o).html() + '</li>');
            });
        }
    });
    $('#team_member_commitment').each(function (i, select) {
        if (!$(this).next().hasClass('dropdown-select_commit')) {
            $(this).after('<div id="commit-drop" class="dropdown-select_commit wide ' + ($(this).attr('class') || '') + '" tabindex="0"><span  id="current-commitment" class="current"></span><div class="list"><ul></ul></div></div>');
            var dropdown = $(this).next();
            var options = $(select).find('option');
            var selected = $(this).find('option:selected');
            dropdown.find('.current').html(selected.data('display-text') || selected.text());
            options.each(function (j, o) {
                var display = $(o).data('display-text') || '';
                dropdown.find('ul').append('<li class="option ' + ($(o).is(':selected') ? 'selected' : '') + '" data-value="' + $(o).val() + '" data-display-text="' + display + '">' + $(o).html() + '</li>');
            });
        }
    });
    $('#edit_commitment').each(function (i, select) {
        if (!$(this).next().hasClass('dropdown-select')) {
            $(this).after('<div id="commit_edit-drop" class="dropdown-select wide ' + ($(this).attr('class') || '') + '" tabindex="0"><span  id="current_edit-commitment" class="current"></span><div class="list"><ul id="mySelect_commit"></ul></div></div>');
            var dropdown = $(this).next();
            var options = $(select).find('option');
            var selected = $(this).find('option:selected');
            dropdown.find('.current').html(selected.data('display-text') || selected.text());
            options.each(function (j, o) {
                var display = $(o).data('display-text') || '';
                dropdown.find('ul').append('<li class="option ' + ($(o).is(':selected') ? 'selected' : '') + '" data-value="' + $(o).val() + '" data-display-text="' + display + '">' + $(o).html() + '</li>');
            });
        }
    });




    $('#team_member_member_id').each(function (i, select) {
        if (!$(this).next().hasClass('dropdown-select')) {
            $(this).after('<div id="team-drop" class="dropdown-select wide ' + ($(this).attr('class') || '') + '" tabindex="0"><span  id="current-user"     class="current"></span><div class="list"><ul></ul></div></div>');
            var dropdown = $(this).next();
            var options = $(select).find('option');
            var selected = $(this).find('option:selected');
            dropdown.find('.current').html(selected.data('display-text') || selected.text());
            options.each(function (j, o) {
                var display = $(o).data('display-text') || '';
                dropdown.find('ul').append('<li class="option ' + ($(o).is(':selected') ? 'selected' : '') + '" data-value="' + $(o).val() + '" data-display-text="' + display + '">' + $(o).html() + '</li>');
            });
        }
    });

    $('#user-drop ul').before('<div class="dd-search"><input id="txtSearchValueuser" autocomplete="off" onkeyup="filter()" class="dd-searchbox" type="text"></div>');
    $('#issue-drop ul').before('<div class="dd-search"><input id="txtSearchValueissue" autocomplete="off" onkeyup="filterIssues()" class="dd-searchbox" type="text"></div>');
    $('#team-drop ul').before('<div class="dd-search"><input id="txtSearchValuepeople" autocomplete="off" onkeyup="filterPeople()" class="dd-searchbox" type="text"></div>');

}

// Event listeners

// Open/close
$(document).on('click', '.dropdown-select', function (event) {
    if($(event.target).hasClass('dd-searchbox')){
        return;
    }
    $('.dropdown-select').not($(this)).removeClass('open');
    $(this).toggleClass('open');
    if ($(this).hasClass('open')) {
        $(this).find('.option').attr('tabindex', 0);
        $(this).find('.selected').focus();
    } else {
        $(this).find('.option').removeAttr('tabindex');
        $(this).focus();
    }
});
$(document).on('click', '.dropdown-select_commit', function (event) {
    if($(event.target).hasClass('dd-searchbox')){
        return;
    }
    $('.dropdown-select_commit').not($(this)).removeClass('open');
    $(this).toggleClass('open');
    if ($(this).hasClass('open')) {
        $(this).find('.option').attr('tabindex', 0);
        $(this).find('.selected').focus();
    } else {
        $(this).find('.option').removeAttr('tabindex');
        $(this).focus();
    }
});
// Close when clicking outside
$(document).on('click', function (event) {
    if ($(event.target).closest('.dropdown-select').length === 0) {
        $('.dropdown-select').removeClass('open');
        $('.dropdown-select .option').removeAttr('tabindex');
    }
    event.stopPropagation();
});
$(document).on('click', function (event) {
    if ($(event.target).closest('.dropdown-select_commit').length === 0) {
        $('.dropdown-select_commit').removeClass('open');
        $('.dropdown-select_commit .option').removeAttr('tabindex');
    }
    event.stopPropagation();
});


function filterPeople(){
    var valThis = $('#txtSearchValuepeople').val();
    if(valThis.length!=0)
    {
    $.ajax({
        type: "GET",
        url: `${url}/find_members.json?key=${api_key}`,
        dataType: 'json',
        async:false,
        contentType: "application/json",
        data: {
          name: valThis.trim(),
        },
        success: function (result, status, xhr) {
            $(".dropdown-select ul").html(" ");
            if (Array.isArray(result) && result.length != 0)
            {
                result.map((i)=>{
            $(".dropdown-select ul").append('<li class="option ' + ($(i).is(':selected') ? 'selected' : '') + '" data-value="' + i.id + '">' + i.firstname+" "+i.lastname + '</li>')
              })
            }
        },
        error: function (xhr, status, error) {
        }
        });
      }
         else{
        $(".dropdown-select ul").html( " ");
        if( Users.length!=0){
            Users.map((i)=>{
              $(".dropdown-select ul").append('<li class="option ' + ($(i).is(':selected') ? 'selected' : '') + '" data-value="' + i.id + '">' + i.firstname+" "+i.lastname + '</li>')
            })
          }
    }
};

function filterProject(){
    var valThis = $('#txtSearchValueproject').val();
    if(valThis.length!=0)
    {
    $.ajax({
        type: "GET",
        url: `${url}/search_users_projects.json?key=${api_key}`,
        dataType: 'json',
        async:false,
        contentType: "application/json",
        data: {
          name: valThis.trim(),
        },
        success: function (result, status, xhr) {
   
            $("#project-drop ul").html(" ");
            $("#project-drop ul").append('<li class="option ' + ($(i).is(':selected') ? 'selected' : '') + '" data-value="' + 0 + '">' + 'Please select' + '</li>')
            if (Array.isArray(result) && result.length != 0)
            {
                result.map((i)=>{
                    $("#project-drop ul").append('<li onclick="getTracker($(this))" value="' + i.id + '"  class="option ' + ($(i).is(':selected') ? 'selected' : '') + '" data-value="' + i.id + '">' + i.name + '</li>')
              })
            }
        
        },
        error: function (xhr, status, error) {
        }
        });
      }
         else{
        $("#project-drop ul").html( " ");
        $("#project-drop ul").append('<li class="option ' + ($(i).is(':selected') ? 'selected' : '') + '" data-value="' + 0 + '">' + 'Please select' + '</li>')
        if(Projects.length!=0){
            Projects.map((i)=>{
              $("#project-drop ul").append('<li onclick="getTracker($(this))"  value="' + i.id + '"  class="option ' + ($(i).is(':selected') ? 'selected' : '') + '" data-value="' + i.id + '">' + i.name + '</li>')
            })
          }
    }

};
function getProjectactivity(project_id)
{
    var category=null;
    $.ajax({
        type: "GET",
        url: `${url}/projects/${project_id}/issue_categories.json?key=${api_key}`,
        dataType: 'json',
        async:false,
        contentType: "application/json",
        success: function (result, status, xhr) {
            $("#select_category").html(" ");
            category=result.issue_categories;
           if (category.length != 0) {
            category.map((i)=>{
                $("#select_category").append(`<option value=${i.id} id=${i.id}>${i.name}</option>`);
          
              })
         }
         
        },
        error: function (xhr, status, error) {
            $("#select_activity").html(" ");
        }
        });
        return category; 
}
function getProjectTimeentry(project_id){
    var activity=null;
    $.ajax({
        type: "GET",
        url: `${url}/projects/${project_id}.json?include=time_entry_activities&key=${api_key}`,
        dataType: 'json',
        async:false,
        contentType: "application/json",
        success: function (result, status, xhr) {
            $("#select_activity").html(" ");
            activity=result.project.time_entry_activities;
            time_entry_activities=result.project.time_entry_activities;
          let project_time_entry=result.project.time_entry_activities;
           if (project_time_entry.length != 0) {
            time_entry_activities=project_time_entry;
            project_time_entry.map((i)=>{
                $("#select_activity").append(`<option value=${i.id} id=${i.id}>${i.name}</option>`);
          
              })
         }
        
        },
        error: function (xhr, status, error) {
            $("#select_activity").html(" ");
        }
        });
        return activity;
}

// Option click
$(document).on('click', '#issue-drop .option', function (event) {
    $(this).closest('.list').find('.selected').removeClass('selected');
    $(this).addClass('selected');
    var subject=$(this).children().last().text();
    var user_id=$(this).data("value");
    let category_id=$(this).data("category");
    $(this).closest('.dropdown-select').find('.current').text(subject);
    $(this).closest('.dropdown-select').find('.current').attr("value",user_id);
    $(this).closest('.dropdown-select').find('.current').attr("project",$(this).data("project"));
    $(this).closest('.dropdown-select').prev('select').val($(this).data('value')).trigger('change');
      getProjectTimeentry($(this).data("project"))
    category= getProjectactivity($(this).data("project"));
   
        if(budgetauditPluginExists)
            {
                 $("#select_category").html(" ");
                $("#select_category").append(`<option selected  value="0" >Select Category</option>`);
               if(category.length!=0)
               {
                 category.map((i)=>{
                   if(category_id!=null&&i.id==category_id)
                    {
                    
                      $("#select_category").append(`<option selected  value=${i.id} id=${i.id}>${i.name}</option>`);
                    }
                    else{
                      $("#select_category").append(`<option  value=${i.id} id=${i.id}>${i.name}</option>`);
                    }
                
                 })
                }
            }
    
});
$(document).on('click', '#user-drop .option', function (event) {
    $(this).closest('.list').find('.selected').removeClass('selected');
    $(this).addClass('selected');
    var text = $(this).data('display-text') || $(this).text();
    var user_id=$(this).data("value");
    $(this).closest('.dropdown-select').find('.current').text(text);
    $(this).closest('.dropdown-select').find('.current').attr("value",user_id);
    $(this).closest('.dropdown-select').prev('select').val($(this).data('value')).trigger('change');
});
$(document).on('click', '.dropdown-select_commit .option', function (event) {
    $(this).closest('.list').find('.selected').removeClass('selected');
    $(this).addClass('selected');
    var text = $(this).data('display-text') || $(this).text();
    var user_id=$(this).data("value");
    $(this).closest('.dropdown-select_commit').find('.current').text(text);
    $(this).closest('.dropdown-select_commit').find('.current').attr("value",user_id);
    $(this).closest('.dropdown-select_commit').prev('select').val($(this).data('value')).trigger('change');
});
// Keyboard events
$(document).on('keydown', '.dropdown-select', function (event) {
    var focused_option = $($(this).find('.list .option:focus')[0] || $(this).find('.list .option.selected')[0]);
    // Space or Enter
    //if (event.keyCode == 32 || event.keyCode == 13) {
    if (event.keyCode == 13) {
        if ($(this).hasClass('open')) {
            focused_option.trigger('click');
        } else {
            $(this).trigger('click');
        }
        return false;
        // Down
    } else if (event.keyCode == 40) {
        if (!$(this).hasClass('open')) {
            $(this).trigger('click');
        } else {
            focused_option.next().focus();
        }
        return false;
        // Up
    } else if (event.keyCode == 38) {
        if (!$(this).hasClass('open')) {
            $(this).trigger('click');
        } else {
            var focused_option = $($(this).find('.list .option:focus')[0] || $(this).find('.list .option.selected')[0]);
            focused_option.prev().focus();
        }
        return false;
        // Esc
    } else if (event.keyCode == 27) {
        if ($(this).hasClass('open')) {
            $(this).trigger('click');
        }
        return false;
    }
});

$(document).ready(function () {
    create_custom_dropdowns();
});



$(function() {
  // bind change event to select
  $('#dynamic_select').on('change', function() {
    return false;
  });
  $('#dynamic_select_user').on('change', function() {
    return false;
  });
  $('#team_member_member_id').on('change', function() {
    return false;
  });
  $('#edit_commitment').on('change', function() {
    return false;
  });
});

