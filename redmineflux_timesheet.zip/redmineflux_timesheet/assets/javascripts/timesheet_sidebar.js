

// Modal to create a new team
$(document).ready(function(){
  $('#searchUser').blur();
  let mainDiv = document.getElementById("main");
  mainDiv.classList.add("timesheet-sidebar");

    $('.link-timesheet-team').click(function(event){
     
      // event.preventDefault();
      $('.timesheet-team').show();
      $('.team-bg').show();

    });
    $('#team_close, .closeTeamTimesheet').click(function(event){
      event.preventDefault();
      $('#timesheet_team_name').val("");
      $('.timesheet-team').hide();
      $('.team-bg').hide();
    });   

    // modal to add members

    $('.addteammembers').click(function(event){
      event.preventDefault();
      $('.addmembers').show();
      $('.team-bg').show();

    });
    $('#team_close, .closemember').click(function(event){
      event.preventDefault();
      $('.addmembers').hide();
      $('.team-bg').hide();
    }); 

    // update team modal 
     $('.edit-timesheet-team').click(function(event){
      event.preventDefault();
      $('.update-team').show();
      $('.team-bg').show();
    });

     $('#team_close, .closeTeamTimesheet').click(function(event){
      event.preventDefault();
      $('.update-team').hide();
      $('.team-bg').hide();
    }); 





// var timehseetButton = document.getElementById("submitTimesheet");
// (timehseetButton).addEventListener("click", function(event) {
//   event.preventDefault();
//   $.ajax({
//     url: "/submit_timesheet/notification",
//     type: "POST",
//     data: {},
//     success: function(response) {
//       console.log("timehseet method called");
//     },
//     error: function(xhr) {
//       console.log(xhr.responseText);
//     }
//   });
// });

  
});


// Update team members details

// function showEditModal(team_id,memberid){
   
//   console.log(team_id, memberid, roles )
//   var allRoles = roles;
//   var teamId = team_id;
//   var memberId = memberid;
  
//   $(".context-menu-popup").css("zIndex", "1040");
//   let body_div = document.getElementsByClassName(
//     "has-main-menu  controller-timesheet_members action-index"
//   );
 
//   var menu = document.createElement("div");
//   menu.className = "update-members";
//   menu.id = "modal" ;
 

//   menu.innerHTML = `
//   <div class = "close_head"  style="display:flex; justify-content: space-between;">
//   <h2 class = "team">Update Team</h2>
//     <img class = "closeTeamTimesheet" style="cursor:pointer; width:16px; margin-top:-14px;" src="/plugin_assets/redmineflux_timesheet/images/cross.svg"  onclick ="closeTeam();">
// </div>
// <div class="modal-update">
//     <label>Role</label><br>  
//     <select name="timesheet_team[name]" id="update_team_name" class="teamInput"></select><br><br> 
//     <div id="team-buttons">
//         <button class = "new_team", id= "new_team"  onclick= "updateTeamName();" >Update Team</button>
//         <button id= "team_close", class= "team_close" onclick="closeTeam();" >Cancel</button>
//      </div>
// </div>

//   `;
//   body_div[0].appendChild(menu);
//    var teamInput = document.getElementById("update_team_name");

//    roles.split(',').map(function(item) {
//     var optionElement = document.createElement("option");
//     console.log(item.id, item.name)
//     optionElement.value = item.id;
//     optionElement.text = item.name;
//     teamInput.add(optionElement);

//   });


// }


 



// end 


// add members to team API 

function addTimesheetTeamMembers(teamid){
  var teamId = teamid;
  var url = window.location.origin;

  var user_id = $('#add_members_timesheet').val()

 console.log(teamId, user_id)
  $.ajax({
    type: "POST",
    url: `${url}/timesheet_teams/${teamId}/timesheet_members.json?key=${api_key}`,
    dataType: "json",
    contentType: "application/json",
    
    data: JSON.stringify({
      user_ids: user_id, team_id: parseInt(teamId)
    }),
    success: function (result, status, xhr){
     window.location.reload();
      // toastr["success"]("Member added successfully");
  
    }, error: function(xhr, status, error){
      // toastr["error"]("Member can not be added");
     
    } 
  });
  }

var url = window.location.origin;
function deleteMember(memberid, team_id){
  var memberId = memberid;
  var teamId = team_id;
  $.ajax({
    type: "DELETE",
    url: `${url}/timesheet_teams/${teamId}/timesheet_members/${memberId}.json?key=${api_key}`,
    dataType: "json",
    async:   false,
    contentType: "application/json",
    success: function (result, status, xhr){
  
    }, error: function(xhr, status, error){
     
    } 
  });

}

// Update Team 
function closeUpdateTeamModal(){
  let modal = document.getElementById("update_team_modal");
  let overlay = document.getElementById("update_team_overlay");
  modal.style.display = "none";
  
  setTimeout(() => {
    modal.classList.remove("show_team_modal");
    overlay.classList.remove("show_team_modal");
    $("[tabindex]").removeAttr("tabindex");
    $("html").css("overflow", "auto");

  }, 1);
}
function updateTeam(){
  let name = document.getElementById("update_timesheet_name").value;
  
    if (name.length === 0){
      let danger = document.getElementById("updateteam-name-error");
      danger.style.display = "block";
    
    }else{
    
      let modal = document.getElementById("update_team_modal");
      let overlay = document.getElementById("update_team_overlay");
      modal.style.display = "none";
   
      modal.classList.remove("show_team_modal");
      overlay.classList.remove("show_team_modal");
      $("[tabindex]").removeAttr("tabindex");
    $("html").css("overflow", "auto");
      
      // window.location.reload();
   }
}



function closeTeam() {
  $('.update-team').css('display', 'none');
  $('.team-bg').hide();
}

// search members

function searchMembers(){

  let query_string = $("#addTeamMember").val();
  $.ajax({
    type: "GET",
    url: `${url}/search_timesheet_users.json?key=${api_key}`,
    dataType: "json",
    async:   false,
    contentType: "application/json",
    data: {
      name: query_string.trim(),
    },
    success: function (result, status, xhr){
      
      $("#addteam_members").html(" ");
      if( query_string.length !=0 ){
        result.forEach((p) => {
          $("#addteam_members").append(`<div class="random-div" style="display:flex; flex-direction:row; gap:11px;">
          <div  style="display:flex;" >
             <input class="teamMembers" id="timesheet_member_user_id_${p.id}"  name=${p.firstname + " " + p.lastname
                  } value=${p.id} type="checkbox"/>
           </div>
           <div style="display:flex;">
             <span class="span-watcher">${p.firstname + " " + p.lastname}</span>
             </div>
             </div> 
             `);
        });
      
       
      } else if (query_string.length ==0){
        $.ajax({
          type: 'GET',
          url: `${url}/timesheet_members.json?key=${api_key}`,
          dataType: 'json',
          async: false,
          contentType: 'application/json',
          success: function(data, status, xhr){
            console.log(data);
            data.forEach((p) => {
              $("#addteam_members").append(`<div class="random-div" style="display:flex; flex-direction:row; gap:11px;">
              <div  style="display:flex;" >
                 <input class="teamMembers" id="timesheet_member_user_id_${p.id}"  name=${p.firstname + " " + p.lastname
                      } value=${p.id} type="checkbox"/>
               </div>
               <div style="display:flex;">
                 <span class="span-watcher">${p.firstname + " " + p.lastname}</span>
                 </div>
                 </div> 
                 `);
            });

          }, error: function(xhr, status,error){

          }
        })
      }
    
    }, 
    error: function(xhr, status, error){
   
    } 
});

}

// export pdf code

$(document).ready(function() {
  $("#loader_wrapper").hide();

  $(".timesheet_pdf_export a").click(function(event) {
    event.preventDefault();
    $("#loader_wrapper").show();

    var link = $(this).attr('href');
    var downloadLink = document.createElement('a');
    downloadLink.href = link;
    downloadLink.download = 'timesheet_approval.pdf';

    document.body.appendChild(downloadLink);
    setTimeout(function() {
      downloadLink.click();
      document.body.removeChild(downloadLink);
      $("#loader_wrapper").hide();
    }, 3000); 
  });
});
