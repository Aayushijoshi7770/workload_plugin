module RedminefluxTimesheet
module Patches
  module TimeEntryPatch
    def self.included(base)
      base.extend(ClassMethods)

      base.send(:include, InstanceMethods)
      base.class_eval do
      

        validate :check_for_backdated_spent_on
        validate :check_for_backdated_time
        before_destroy :check_for_backdated_spent_on
        before_destroy :check_for_backdated_time
      end
    end

    module ClassMethods
      def backdate_blocker_days
        return nil unless backdated_days_configured?
        Setting.plugin_redmineflux_timesheet['days'].to_i
      end

      def backdate_blocker_days_ago
        return nil if backdate_blocker_days.nil?
        backdate_blocker_days.days.ago
      end

      def backdated_days_configured?
        Setting.plugin_redmineflux_timesheet['days'].present?
      end

      def backdated_time_configured?
        Setting.plugin_redmineflux_timesheet['time'].present?
      end 

    end

    module InstanceMethods
      def check_for_backdated_time
        return true unless self.class.backdated_time_configured? 
        
        unless User.current.admin? 
          unless spent_on == Date.today

            @input_time = Setting.plugin_redmineflux_timesheet['time'] 
            user_time = ActiveSupport::TimeZone['Asia/Kolkata'].parse(@input_time)
            @utc_user_time = user_time.utc.strftime("%H:%M")
            @current_time = Time.now.utc
            @server_time = @current_time.strftime("%H:%M")
           
            if (@utc_user_time < @server_time)
              errors.add(:base, "Time log is not allowed after #{Setting.plugin_redmineflux_timesheet['time']} ") if (spent_on < Date.today)
            end 

          end 
        end 

      end 

      def check_for_backdated_spent_on
        return true unless self.class.backdated_days_configured?
        return true unless backdated?
        unless User.current.admin? 
          unless allowed_to_backdate?
            errors.add :spent_on,  "Time log is not allowed for past #{Setting.plugin_redmineflux_timesheet['days'].to_i} day" 
          end
        end 
      end

      def allowed_to_backdate?
        self.class.backdate_blocker_days && User.current.allowed_to?(:backdate_time, project)
      end

      def backdated?
        spent_on.beginning_of_day < self.class.backdate_blocker_days.days.ago.beginning_of_day
      end
    end
  end
end
end