# Plugin's routes
# See: http://guides.rubyonrails.org/routing.html


delete 'remove_user/:user_id', to: 'timesheet_teams#remove_user', as: 'remove_user'

get 'custom/filters', to: 'timesheet_reports#custom_filters'

resources :timesheet_reports

post 'create_reports', to: "timesheet_reports#create"


delete 'delete_reports/:id', to: "timesheet_reports#destroy"
get 'update_grids/dimentions', to: "timesheet_reports#update_reports_chart_dimensions"
get 'get_all_reports', to: "timesheet_reports#get_all_reports"
put 'update_setting/:id' , to: "timesheet_reports#update_setting"

# namespace :timesheet do
#     get 'reports', to: 'reports#index', as: 'reports'
#     resources :reports
# end
resources :timesheet_approvals, only: [:index]
resources :timesheet_teams, only: [:index, :destroy]
resources :approval_levels

get 'approve_timesheet', to: "timesheet_approvals#approve"
get 'reject/timesheet', to: "timesheet_approvals#reject"
put 'unsubmit/timesheet', to: "submit_timesheet#unsubmit_timesheet"

get 'timesheet/selected/team_data', to: 'timesheets#timesheet_team'
get 'teams_spent_time', to: 'timesheets#team_total_spent_time'
get 'selected/team', to: 'submit_timesheet#selected_team'
post 'create/team', to: 'submit_timesheet#create_team'
get 'timesheet_approvals/reject', to: 'timesheet_approvals#reject'


get 'timesheet_report', to: 'timesheet_reports#users_report'

get 'timesheet', to: 'timesheets#index'

get 'timesheet/view', to: 'timesheets#show'


get 'users_timesheets', to: 'timesheets#users_timesheet'
get 'search_user_issues', to: 'timesheets#timesheet_issues'
get 'users_assigned_issues', to: 'timesheets#assigned_issues'

get 'search_timesheet_users', to: 'timesheets#search_users'
post 'submit_timesheet', to: 'submit_timesheet#create'
get 'users_submitted_timesheet', to: 'submit_timesheet#index'
get 'activities_total_spent', to: 'timesheets#total_spent_time'
get 'timesheet_permissions', to: 'timesheets#timesheet_permissions'
# get 'timesheet/:user_id/:start_date/:end_date', to: 'timesheets#index'

get '/chart/show', to: 'timesheet_reports#show'
get 'timesheet/history/:id', to: 'timesheet_logs#show', as: 'timesheet_history'

# route to redirect from approval dashboard to gantt dashboard
get 'timesheet/:user_id/:start_date/:end_date', to: 'timesheets#index'


# update the value of dropdown preference
post "/update_timesheetdropdown_preference", to: "timesheets#update_dropdown_preference"


resources :timesheet_teams do
  get 'delete', on: :member, as: :delete
end

resources :timesheet_teams do
    member do
      get :new_remove_user
    end
end

resources :approval_levels do
  get 'delete', on: :member
end

# export pdf code
resources :timesheet_approvals do
  collection do
    get 'export_pdf', to: 'timesheet_approvals#export_pdf'
  end
end

resources :timesheet_teams do
  collection do
    delete 'destroy'
  end
end
