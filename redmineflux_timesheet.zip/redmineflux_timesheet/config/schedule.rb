set :environment, "production"

every 1.day, at: '3:30 pm' do
    rake "timesheet:send_reminder"
  end 


