# Redmine Timesheet Plugin 
# Online URL : https://www.redmineflux.com/knowledge-base/plugins/timesheet/ 

The Redmine Timesheet Plugin is a powerful plugin  that enhances time tracking and reporting capabilities within Redmine, a popular project management and issue tracking system. This plugin enables users to efficiently record their time spent on tasks, and gain valuable insights into project progress and resource utilization.

![Timesheet Plugin](Timesheet.png)

## Installation

To install the Redmine Timesheet Plugin , follow these steps:

1.  Make sure you have a working installation of Redmine

2.  Get the plugins source code from Redmineflux.

3.  Run the following command to install the required dependencies:
    `sh     gem install will_paginate`

    ``` sh
    gem install whenever
    ```

    ``` sh
    bundle install 
    ```

4.  Run DB migrations

    -   For production

    ``` sh
    RAILS_ENV=production bundle exec rails  redmine:plugins:migrate 
    ```

    -   For development \`\`\`sh RAILS_ENV=development bundle exec rails
        redmine:plugins:migrate

5.  Restart Redmine server to load the plugin `sh     Rails s`

## Usage

The Redmine Timesheet Plugin provides several features to facilitate
time tracking. Here's an overview of the main functionalities:

## Time Logging

-   ### Log Time:

    Easily record the time spent on specific tasks or projects directly
    within Redmine. Include a brief description and select the relevant
    issue, project, or activity

-   ### Add/Edit Time Entries:

    Edit or add time entries retroactively to ensure accurate and
    up-to-date records.

-   ### Delete Time Entries:

    Delete time entries with the Timesheet plugin to manage issues.

## User Managment

-   ### User Permissions:

    Configure access levels and permissions for different user roles.
    Control who can log time or manage settings.

-   ### Filtering:

    Filter out data according to teams if user is admin. View time
    entries of specific date range and search issues and users easily.

-   ### Submit Timesheet:

    Disable Submit Timesheet button once timesheet is submitted for a
    specific range
