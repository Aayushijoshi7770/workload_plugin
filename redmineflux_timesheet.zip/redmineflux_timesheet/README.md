# Redmine Timesheet Plugin 
# Online URL : https://www.redmineflux.com/knowledge-base/plugins/timesheet/ 

The Redmine Timesheet Plugin is a powerful plugin  that enhances time tracking and reporting capabilities within Redmine, a popular project management and issue tracking system. This plugin enables users to efficiently record their time spent on tasks, and gain valuable insights into project progress and resource utilization.


![Timesheet Plugin](Timesheet.png)


## Installation 

To install the Redmine Timesheet Plugin , follow these steps:

1. Make sure you have a working installation of Redmine 
2. Get the plugins source code from Redmineflux.

     
3. Run the following command to install the required dependencies:
    ```sh
    gem install will_paginate 
    ```

    ```sh
    gem install whenever
    ``` 

    ```sh
    bundle install 
    ```
4. Run DB migrations 
    
    * For production 
    ```sh
    RAILS_ENV=production bundle exec rails  redmine:plugins:migrate 
    ```
    * For development 
    ```sh
    RAILS_ENV=development bundle exec rails redmine:plugins:migrate 

5. Restart Redmine server to load the plugin 
    ```sh
    Rails s 
    ```

# Getting Started
**Step 1** Enable REST API
  - Login as a administrator.
  - Navigate to **Administration** tab from top menu.
  - Click on **Settings** and find the **API** tab and enable the rest API.

**Step 2** Enable Submit timesheet frequency from plugin configuration
  - Login as a administrator.
  - Navigate to **Administration** tab from top menu.
  - Click on **Plugins** and find the **Redmineflux Timesheet Plugin**, click on the configuration link.
  - In Submit timesheet frequency tab select the value of your preference.
  - Click on **Apply** to apply the changes.
  - The default value of frequency will be **Weekly**.
  
**Step 3** Enable Unsubmit timesheet from plugin configuration
  - Login as a administrator.
  - Navigate to **Administration** tab from top menu.
  - Click on **Plugins** and find the **Redmineflux Timesheet Plugin**, click on the configuration link.
  - From the unsubmit timesheet tab check the check box if you want to allow users to unsubmit the timesheet.
  - Click on **Apply** to apply the changes.
  - In the functionality, user is not able to unsubmit the timesheet, once it is submitted.

**Step 4** Enable Start of Week 
  - Login as an administrator.
  - Navigate to the **Administration** tab from the top menu.
  - Click on Plugins and find the Redmineflux Timesheet Plugin, then click on the configuration link.
  - Locate the **Start of Week** or similar setting within the plugin configuration.
  - Enable the feature that allows users to select their preferred starting day for time tracking within a seven-day period.
  - Ensure users have the option to manually set the start of the week from any day within the week for their time entries.
  - Save or Apply the settings to confirm the customization option for users to choose their own starting day for time   logging.

**Step 5** Using the Reports Section

#### Accessing Reports:
  - When you enter the timesheet, you'll find the report section on the sidebar if allowed.
  - Click on the reports icon to open and access the reports.

#### Filtering Data:
  - By default, there's a date filter available. You can adjust it to view different date ranges.
  - On the right side, use the **Add Filter** and **Custom Filter** options to select specific criteria for data display.

#### Applying Filters:
  - Once you've chosen your filters, simply click the **Apply** button.
  - Your data will then be presented in two formats: a donut chart and a bar chart.

#### Grouping Data:
  - Customize how your data is presented by grouping it according to projects, dates, trackers, or statuses.
  - If no specific group-by selection is made, the system defaults to displaying data based on the user's default grouping preference.

**Step 6** Approve/Reject Timesheet
  - To approve or reject a timesheet, the user must have the "Manage Timesheet" permission. This permission ensures that only authorized users can perform actions related to timesheet approval and rejection.

**Step 7** Add approval level to Team 
  - Login to your redmine instance with valid credentials 
  - Access the teams tab from left sidebar 
  - Click on any team name 
  - Click on **Add Approval Level** button to add new approval
  - Inter the name of level, select the user to be reported and choose the level 
  - Click create to add level.


# Usage
 
The Redmine Timesheet Plugin provides several features to facilitate time tracking. Here's an overview of the main functionalities:

## Time Logging 

 * ### Log Time:  
   Easily record the time spent on specific tasks or projects directly within Redmine. Include a brief description and select the relevant issue, project, or activity
 * ### Add/Edit Time Entries:
   Edit or add time entries retroactively to ensure accurate and up-to-date records.
 * ### Delete Time Entries:
   Delete  time entries with the Timesheet plugin to manage  issues.
   

## User Managment 

 * ### User Permissions:
   Configure access levels and permissions for different user roles. Control who can log time or manage settings.
 * ### Filtering:
   Filter out data according to teams if user is admin. View time entries of specific date range and search issues and users easily.
 * ### Submit Timesheet:
   Disable Submit Timesheet button once timesheet is submitted for a specific range

## Reports

 * ### Drag and Drop Charts:
   Users have the flexibility to drag and drop specific charts to desired positions within the interface. This feature allows customization of the dashboard view based on preference.
 * ### Resize Chart Size:
   The Reports section enables users to resize chart elements, providing control over the display and emphasis on particular data sets. Resize charts for better visibility and focus on essential information.


# Uninstallation  
To uninstall the Redmineflux Timesheet Plugin, follow these steps: 
  - Navigate to the Plugins directory in Redmine. 
  - Delete the entire Gantt Chart directory from Redmine/plugins directory. This step removes the plugin files from your Redmine installation. 
  - If the plugin required a migration, run the following command to downgrade your database (make a db backup before) 

  ```sh
     Bundle exec rake redmine:plugins:migrate Name=plugin name VERSION=0  RAILS_ENV=production 
  ```

  - Restart the Redmine server to see the changes. 
  - This will uninstall the Redmineflux Timesheet Plugin from Redmine

# Version Compatibility  
  Redmine Versions 
  - 4.0.x, 4.1.x, 4.2.x 
  - 5.0.x 
  - 6.0.x(coming soon) 

**Library Credits**

This Redmienflux Gantt Chart plugin is built using the Gantt Chart library developed by Zehntech Technologies Pvt. Ltd.
  
  [Timesheet](https://github.com/zehntech/zt-gantt/)