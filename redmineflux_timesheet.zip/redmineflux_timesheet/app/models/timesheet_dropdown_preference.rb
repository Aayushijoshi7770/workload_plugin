class TimesheetDropdownPreference < ActiveRecord::Base
end
