class TimesheetQuery < ActiveRecord::Base
    validates :filters, presence: true
end
