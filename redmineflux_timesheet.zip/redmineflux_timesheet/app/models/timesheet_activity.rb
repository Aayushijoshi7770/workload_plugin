class TimesheetActivity < ActiveRecord::Base
    belongs_to :submit_timesheet


end
