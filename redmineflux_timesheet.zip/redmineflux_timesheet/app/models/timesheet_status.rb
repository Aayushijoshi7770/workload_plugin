class TimesheetStatus < ActiveRecord::Base
    belongs_to :submit_timesheet, class_name: 'SubmitTimesheet'
    has_many :approval_levels
    belongs_to :user
    enum status: { pending: 0, approved: 1, rejected: 2, submitted: 4, unsubmit: 5 }
end
