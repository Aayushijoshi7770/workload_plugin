class TimesheetReminder < ActionMailer::Base
    layout 'mailer'
    default from: Setting.mail_from
   
    def self.default_url_options
        ::Mailer.default_url_options
    end 

    def reject_timesheet_notification(user, start_date, end_date, comment)
        @comment = comment
        @user = User.find(user)
        @start_date = start_date
        @end_date = end_date
        mail(to: @user.mail, subject: "Timesheet Rejection Notification")
    end 

    def admin_approval(admin, user, timesheet)
        @cc_user = user
        @approver = admin
        @start_date = timesheet.start_date
        @end_date = timesheet.end_date
        @activities = timesheet.timesheet_activities
        mail(to: @approver.mail, subject: "Timesheet Submission Notification", cc: @cc_user.mail)
    end 

    def timesheet_submission_notification(approver, user, timesheet)
        @cc_user = user
        @approver = approver
        @start_date = timesheet.start_date
        @end_date = timesheet.end_date
        @activities = timesheet.timesheet_activities
        mail(to: @approver.mail, subject: "Timesheet Submission Notification", cc: @cc_user.mail)
    end 

    def timesheet_approval_notification(approver, user, timesheet)
        @user = user 
        @approver = approver 
        @start_date = timesheet.start_date
        @end_date = timesheet.end_date
        @activities = timesheet.timesheet_activities
        # @level = level
        mail(to: @user.mail, subject: "Timesheet Approval Notification", cc: @approver.mail)
    end 

    def reminder_email(user)
        @user = user
        mail(to: @user.mail, subject: 'Action Required: Timesheet must be filled by EOD')
    end

end
