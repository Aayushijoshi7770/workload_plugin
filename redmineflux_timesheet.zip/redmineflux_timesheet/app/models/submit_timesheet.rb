class SubmitTimesheet < ActiveRecord::Base
    belongs_to :user
    belongs_to :team
    has_many :timesheet_statuses, dependent: :destroy
    has_many :timesheet_activities, dependent: :destroy
    has_many :timesheet_journals, foreign_key: 'submit_timesheet_id', dependent: :destroy
    accepts_nested_attributes_for :timesheet_activities, allow_destroy: true, update_only: true
    enum status: { pending: 0, approved: 1, rejected: 2, submitted: 4, unsubmit: 5 }
    enum level_status: { level_one: 1, level_two: 2, level_three: 3, level_four: 4, level_five: 5}
    validates_presence_of :user_id
    validates_presence_of :submitted_by
    validates_presence_of :submitted
    validates_presence_of :start_date
    validates_presence_of :end_date
    validates_presence_of :hours
    after_create :associate_timesheet_status
    after_update :associate_timesheet_status
    
    def can_approve?(timesheet)
      user = User.find_by(:id => User.current.id) 
      roles = user.roles.to_a  
    

      if timesheet.timesheet_statuses.last&.approval_level_id.nil? && User.current.admin?
        return true
      else  
        approval_level_id = timesheet.timesheet_statuses.order(created_at: :asc).last.approval_level_id 
    

        approval = ApprovalLevel.find_by_id(approval_level_id) if approval_level_id.present?
        puts "approval_timesheet #{approval} "
        if approval.present? 
          approver = roles.find { |role| role['id'] == approval.role }.present? 
          return approver
        end 
       
      end 
    end 

    def timesheet_status(timesheet)
      user = User.find_by(:id => User.current.id) 
      roles = user.roles.to_a 
      role_ids = roles.map(&:id)
      approval = ApprovalLevel.find_by(role: role_ids)

      if roles.any? { |role| role.permissions.include?(:manage_timesheet) } && !approval.present?
        if timesheet.timesheet_statuses.any? {|status| status.status == "rejected" }
          return "rejected"
        elsif timesheet.timesheet_statuses.all? {|status| status.status == "approved" }
          return "approved"
        else
          return "waiting for approval"
        end
      else
      if timesheet.timesheet_statuses.any? {|status| status.status == "approved" && status.approval_level_id.nil? } 
        return "approved"
      elsif timesheet.timesheet_statuses.any? {|status| status.status == "submitted" && status.approval_level_id.nil? && roles.any? { |role| role.permissions.include?(:manage_timesheet) } && !User.current.admin? } 
        return "waiting for approval"
      elsif timesheet.timesheet_statuses.any? {|status| status.status == "rejected" && status.approval_level_id.nil? } 
        return "rejected"
      elsif (!approval.present? && User.current.admin? && timesheet.timesheet_statuses.all? {|status| status.status == "approved" }) || roles.any? { |role| role.permissions.include?(:manage_timesheet) } && approval.present? && timesheet.timesheet_statuses.all? {|status| status.status == "approved" }
        return "approved"
      elsif !approval.present? && User.current.admin? && timesheet.timesheet_statuses.all? {|status| status.status == "rejected" } || approval.present? && timesheet.timesheet_statuses.any?{|status| status.status == "rejected" }
        return "rejected"
      elsif approval.present? && timesheet.submitted_by == User.current.id && timesheet.timesheet_statuses.all? {|status| status.status == "approved" }
        return "approved"
      elsif approval.present? && timesheet.submitted_by == User.current.id && timesheet.timesheet_statuses.all? {|status| status.status == "rejected" }
        return "rejected"
      elsif current_user_is_next_level_approver(timesheet,approval) || (User.current.admin? && timesheet.timesheet_statuses.any? {|status| status.status == "submitted"} && approval.nil?) 
        return "waiting for approval"
      else 
        status = timesheet.timesheet_statuses.where(approval_level_id: approval.id).last if approval.present?
        return status.status if status.present?
      end 

    end
    end 
  
  def can_approve?(timesheet)
    user = User.find_by(:id => User.current.id) 
    roles = user.roles.to_a  
    if timesheet.timesheet_statuses.last&.approval_level_id.nil? && User.current.admin?
      return true
    else  
      approval_level_id = timesheet.timesheet_statuses.order(created_at: :asc).last.approval_level_id 
  
      approval = ApprovalLevel.find_by_id(approval_level_id) if approval_level_id.present?
      if approval.present? 
        approver = roles.find { |role| role['id'] == approval.role }.present? 
        return approver
      end 
     
    end 
  end 



  def current_user_is_next_level_approver(timesheet,approval)
    status = !timesheet.timesheet_statuses.where(approval_level_id: approval.id).exists? if approval.present?
    return status
  end 

  def associate_timesheet_status
    if self.status == 'submitted'
      if !(ApprovalLevel.exists?)
        user = User.find(self.user_id)
        TimesheetStatus.create(:status => self.status, :user => user, :submit_timesheet_id => self.id)
      elsif current_user_is_approver?
        set_next_approval_level
      else
        min_approval_level = ApprovalLevel.order(:level).first
        TimesheetStatus.create(:status => self.status, :user => user, :submit_timesheet_id => self.id, :approval_level_id => min_approval_level.id)
      end
    end
  end

  def current_user_is_approver?
    user = User.find_by(:id => self.user_id) 
    roles = user.roles.to_a  
    is_approver = ApprovalLevel.where(role: roles).exists?
  end 

  def set_next_approval_level 
    user = User.find_by(:id => self.user_id)
    roles = user.roles.to_a
   
    max_level = ApprovalLevel.where(role: roles).maximum(:level)
    
    next_level_number = max_level + 1 if max_level.present?
    next_level = ApprovalLevel.find_by("level >= ?", next_level_number)
    if next_level.present?
      TimesheetStatus.create(:status => 'submitted', :user => user, :submit_timesheet_id => self.id, :approval_level_id => next_level.id)
    else
      TimesheetStatus.create(:status => 'submitted', :user => user, :submit_timesheet_id => self.id)
    end 
  end 


  def create_next_level(timesheet)
    approval_id = timesheet.timesheet_statuses.last.approval_level_id
    current_level = ApprovalLevel.find_by_id(approval_id)
    if current_level
      next_level = ApprovalLevel.find_by("level > ?", current_level.level)
      if next_level.present?
        user = User.find(self.user_id)
        TimesheetStatus.create(:status => 'submitted', :user => user, :submit_timesheet_id => timesheet.id, :approval_level_id => next_level.id)
      else
        timesheet.timesheet_statuses.all.update(status: 'approved')
      end
    end
  end 
  
     
end