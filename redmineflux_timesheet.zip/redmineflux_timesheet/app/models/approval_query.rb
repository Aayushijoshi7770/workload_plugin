class ApprovalQuery < ActiveRecord::Base
end
