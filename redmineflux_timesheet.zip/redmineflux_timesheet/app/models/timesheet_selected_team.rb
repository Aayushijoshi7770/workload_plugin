class TimesheetSelectedTeam < ActiveRecord::Base
    validates :team_id, presence: true 
end
