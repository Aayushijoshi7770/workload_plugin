class Team < ActiveRecord::Base
  validates :name, presence: true, uniqueness: { scope: :parent_id }, length: { maximum: 52 }

  has_many :team_users
  has_many :users, through: :team_users, dependent: :destroy
  has_many :submit_timesheets

  def remove_user(user)
    if users.include?(user)
      users.delete(user)
      save
      true
    else
      false
    end
  end

  def all_descendants
    descendants = []
    children = Team.where(parent_id: id)
    children.each do |child|
      descendants << child
      descendants.concat(child.all_descendants)
    end
    descendants
  end
  
end