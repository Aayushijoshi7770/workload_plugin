class TimesheetChangelog < ActiveRecord::Base
    enum status: { pending: 0, approved: 1, rejected: 2, submitted: 4, unsubmit: 5 }
    enum level_status: { level_one: 1, level_two: 2, level_three: 3, level_four: 4, level_five: 5}
end