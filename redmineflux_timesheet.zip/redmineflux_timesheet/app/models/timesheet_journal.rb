class TimesheetJournal < ActiveRecord::Base
    belongs_to :submit_timesheet
end
