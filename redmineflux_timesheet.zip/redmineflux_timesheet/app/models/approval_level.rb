class ApprovalLevel < ActiveRecord::Base
    belongs_to :timesheet_status
    validates :name, presence: :true, uniqueness: true, length: {maximum: 255}
    # validates :name, presence: true, uniqueness: { scope: :team_id }, length: { maximum: 255 }
    enum status: { pending: 0, approved: 1, rejected: 2, submitted: 4, unsubmit: 5 }
    validates :level, :role, presence: true 
    belongs_to :approver, class_name: 'User'
    validate :unique_level_within_approval
    validate :unique_user_within_level
    validate :approval_level_sequence
    before_destroy :check_associated_timesheets, :check_level_sequence
    validate :roles_must_have_permission
  
    def check_level_sequence
      existing_levels = ApprovalLevel.order(:level)
      maximum_available_level = existing_levels.maximum(:level)
      if maximum_available_level != level
        errors.add(:base, l(:label_approval_should_in_sequence))
        throw :abort
      end
    end
    def add_user_to_team
      return unless self.team && self.user
     
      team = Team.find(self.team.id)
      user = User.find(self.user)
      team.users << user unless team.users.include?(user)
    end

    private

    def check_associated_timesheets
      is_associated = TimesheetStatus.where(approval_level_id: id).exists?
      if is_associated
        errors.add(:base, l(:label_can_not_delete_approval_level))
        throw :abort
      end
    end 

    def approval_level_sequence
      existing_levels = ApprovalLevel.order(:level)
      if level.present?
        current_level = existing_levels.find_by(id: id)&.level || level
        expected_next_level = existing_levels.last&.level ? existing_levels.last.level + 1 : 1
        maximum_available_level = existing_levels.maximum(:level)
    
        if new_record?
          unless level == expected_next_level
            existing_level = ApprovalLevel.where(level: level).where.not(id: id).first
            if existing_level
              return
            else
              errors.add(:level, l(:label_should_be_unique_in_sequence))
            end
          end
        elsif level_changed?
          unless level <= maximum_available_level
            errors.add(:level, l(:label_should_be_unique_in_sequence))
          end
        end
      end
    end
    
    def unique_level_within_approval
      existing_level = ApprovalLevel.where(level: level).where.not(id: id).first
      if existing_level
        errors.add(:level, l(:label_role_should_unique_in_level))
      end
    end

    def unique_user_within_level
      existing_user = ApprovalLevel.where(role: role).where.not(id: id).first
      if existing_user
        errors.add(:role, l(:label_role_should_unique_in_level))
      end
    end

    def roles_must_have_permission
      roles_with_permission = Role.where.not(position: 0).select { |role| role.has_permission?(:manage_timesheet) }
      if roles_with_permission.empty?
        errors.add(:base, l(:label_no_role_permission_manage_timesheet))
      end
    end

end
