class TimesheetLogsController < ApplicationController
  before_action :require_login
 
  # def show
  #   @user = User.find(params[:id])
  #   @timesheets = SubmitTimesheet.where(user_id: @user.id)
    
  #   @timesheet_changelogs = []
  
  #   @timesheets.each do |timesheet|
  #     timesheet_changelogs = timesheet.timesheet_journals
  #     @timesheet_changelogs.concat(timesheet_changelogs)
  #   end
  #   @timesheet_changelogs.sort_by! { |changelog| changelog.created_on || Time.at(0) }.reverse!

  #   # respond_to do |format|
  #   #   format.html 
  #   #   format.api{ render json:  @timesheet_changelogs}
  #   # end 
  # end

  def show
    @timesheet_start_date = params[:timesheet_start_date]
    @timesheet_end_date = params[:timesheet_end_date]
    if @timesheet_start_date && @timesheet_end_date  
      @user = User.find(params[:id])
      @timesheets = SubmitTimesheet.where(user_id: @user.id, start_date: @timesheet_start_date..@timesheet_end_date)
      @timesheet_changelogs = TimesheetChangelog.where(timesheet_id: @timesheets.pluck(:id)).order(created_at: :desc)
    end
  end


end
