class SubmitTimesheetController < ApplicationController
    # before_action :require_login
    skip_before_action :verify_authenticity_token, only: [:create]
    accept_api_auth :create, :index, :create_team, :selected_team, :unsubmit_timesheet
    helper :timesheet_approvals

    def new 
      @timesheet = SubmitTimesheet.new
    end 


    def create

        submit_timesheet_params = params.require(:submit_timesheet).permit(:user_id, :hours, :start_date, :end_date, timesheet_activities_attributes: [:activity_id, :hours, :activity_name]).merge(
            submitted: true,
            submitted_by: params[:submit_timesheet][:user_id],
            reject_end_date: params[:submit_timesheet][:end_date],
            reject_start_date:  params[:submit_timesheet][:start_date]
          )
       
        user_id = submit_timesheet_params[:user_id]
        submit_timesheet_params[:hours] = parse_hours_from_params(submit_timesheet_params[:hours])
       
        @start_date = submit_timesheet_params[:start_date]
        @end_date = submit_timesheet_params[:end_date]
        timesheet_activities_attributes = submit_timesheet_params[:timesheet_activities_attributes]
        
        @id= submit_timesheet_params[:user_id]
        @user = User.find_by(:id =>@id)
       
        @timesheet_exist1 = SubmitTimesheet.where(:user_id => @id).where.not("start_date > ? OR end_date < ?", @end_date, @start_date).exists?
        @timesheet_exist2 = SubmitTimesheet.where(:user_id => @id).where.not("start_date > ? OR end_date < ?", @end_date, @start_date).exists?
        
        rejected_timesheet = SubmitTimesheet.where(user_id:  @id).where(reject_start_date: @start_date..@end_date, reject_end_date: @start_date..@end_date, status: 2).or(SubmitTimesheet.where(user_id: @id, reject_start_date:@start_date..@end_date, reject_end_date: @start_date..@end_date, status: 0)).exists?
        unsubmitted_timesheet =  SubmitTimesheet.where(user_id:  @id, start_date: @start_date..@end_date, end_date: @start_date..@end_date, status: 5).exists?
        if (rejected_timesheet)
            @rejected_timesheet = SubmitTimesheet.find_by(user_id: @id, reject_start_date: @start_date..@end_date, reject_end_date: @start_date..@end_date)
           
            @rejected_timesheet.timesheet_statuses.destroy_all
            @rejected_timesheet.status = :submitted
            if  @rejected_timesheet.update(submit_timesheet_params.except(:timesheet_activities_attributes))
              
                # notify_approver( @rejected_timesheet, @user)
                update_nested_attributes(@rejected_timesheet, timesheet_activities_attributes)
                render json: { timesheet: @rejected_timesheet, message: "Timesheet submitted successfully" }
            else  
                render json: { errors: @rejected_timesheet.errors.full_messages }, status: :unprocessable_entity
            end 
        elsif(unsubmitted_timesheet)
            @unsubmitted = SubmitTimesheet.find_by(user_id:  @id, start_date: @start_date..@end_date, end_date: @start_date..@end_date, status: 5)
           
            @unsubmitted.timesheet_statuses.destroy_all
            @unsubmitted.status = :submitted
            if @unsubmitted.update(submit_timesheet_params.except(:timesheet_activities_attributes))
              
            
              # notify_approver(@unsubmitted, @user)
              update_nested_attributes(@unsubmitted, timesheet_activities_attributes)
              render json: { timesheet: @unsubmitted, message: "Timesheet submitted successfully" }
            else  
                render json: { errors: @unsubmitted.errors.full_messages }, status: :unprocessable_entity
            end 
        elsif (@timesheet_exist1 ||  @timesheet_exist2)
            render :json => "Timesheet is already submitted for the selected date", status: :unprocessable_entity
        else  
            @timesheet = SubmitTimesheet.new(submit_timesheet_params) 
            @timesheet.status = :submitted
            if @timesheet.save
              # notify_approver(@timesheet, @user)
                render json: { timesheet: @timesheet, message: "Timesheet submitted successfully" }, status: :created 
            else  
                render json: @timesheet.errors, status: :unprocessable_entity
            end
        end 
    end 
    
 

    # def notify_approver(timesheet, user)
    #   teamId = user.team_id if user.team_id.present?
    #   @team = Team.find(teamId) if teamId.present?
      
    #   if @team.present?
    #     approval_levels = @team.approval_levels
    #     if approval_levels.any?
    #       min_level = approval_levels.order(:level).pluck(:level).min 
         
    #       approver_id = approval_levels.find_by(level: min_level).user
    #       approver = User.find(approver_id)
    #       send_submission_notification(approver,user, timesheet)
    #     else
    #       admin = User.active.where(admin: true).first
    #       send_approval_notification(admin, user, timesheet)
    #     end
    #   end 
    # end 

    # def send_approval_notification(admin, user, timesheet)
    #   begin 
    #     TimesheetReminder.admin_approval(admin,user,timesheet).deliver_now
    #   rescue => e
    #     Rails.logger.error "Error sending approval notification: #{e.message}"
    #   end 
    # end 

    # def send_submission_notification(approver,user, timesheet)
    #   begin
    #     TimesheetReminder.timesheet_submission_notification(approver, user, timesheet).deliver_now
    #   rescue => e
    #     Rails.logger.error "Error sending approval notification: #{e.message}"
    #   end 
    # end 

    def unsubmit_timesheet
      respond_to do |format|
        if params[:user_id].present? && params[:start_date].present? && params[:end_date].present?
          user_id = params[:user_id]
          start_date = params[:start_date]
          end_date = params[:end_date]
          date = Date.today
          @user = User.find(user_id)
          @timesheet = SubmitTimesheet.find_by(user_id: user_id, start_date: start_date, end_date: end_date)
    
          if @timesheet
            if @timesheet.update(status: 5, updated_at: date)
              if @timesheet.timesheet_statuses.update_all(status: 5, updated_at: date)
                format.api { render json: { timesheet: @timesheet, message: "Timesheet unsubmitted successfully", status: :ok } }
              else
                format.api { render json: { message: "Update failed" }, status: :unprocessable_entity }
              end
            else
              format.api { render json: { message: "Update failed" }, status: :unprocessable_entity }
            end
          else
            format.api { render json: "Timesheet is already unsubmitted for this date range" , status: :not_found }
          end
        else
          format.api { render json: { message: "Invalid parameters" }, status: :unprocessable_entity }
        end
      end
    end
      
    
 
    def parse_hours_from_params(hours)
        if hours.include?(':')
          hours, minutes = hours.split(':').map(&:to_i)
          decimal_hours = hours + (minutes / 60.0)
          decimal_hours
        else  
            return hours 
        end
        
    end
      
    def find_status(timesheet)
      if(timesheet.can_approve?(timesheet) && !(timesheet.status == "rejected")) && (timesheet.timesheet_statuses.any? { |status| status.status != "approved" && status.approval_level_id.nil?}) && (timesheet.timesheet_statuses.any? { |status| status.status != "approved"})
        return {status: "submitted", level_status: "submitted"}
      else 
        user = User.find_by(:id => User.current.id) 
        roles = user.roles.to_a 
        role_ids = roles.map(&:id)
        approval = ApprovalLevel.find_by(role: role_ids)
        max_level = ApprovalLevel.maximum(:level)
        max_level_record = ApprovalLevel.find_by(level: max_level) if max_level.present?
        max_level_id = max_level_record.id if max_level_record
      
        if timesheet.timesheet_statuses.any? {|status| status.status == "approved" && status.approval_level_id.nil? } || (timesheet.timesheet_statuses.where(approval_level_id: max_level_id, status: "approved" ).exists?)
          return {status: "approved", level_status: timesheet.timesheet_statuses.last.status}
        elsif timesheet.timesheet_statuses.any? {|status| status.status == "submitted" && status.approval_level_id.nil? && roles.any? { |role| role.permissions.include?(:manage_timesheet) } && !User.current.admin? } || (timesheet.submitted_by == User.current.id && timesheet.timesheet_statuses.any? {|status| status.status == "submitted"})
          status = timesheet.timesheet_statuses.any? {|status| status.status == "approved" } ? "approved" : timesheet.timesheet_statuses.last.status
          return {status: "waiting for approval", level_status: status}
        elsif timesheet.timesheet_statuses.any? {|status| status.status == "rejected" && status.approval_level_id.nil? } 
          return {status: "rejected", level_status: timesheet.timesheet_statuses.last.status}
        elsif (!approval.present? && User.current.admin? && timesheet.timesheet_statuses.all? {|status| status.status == "approved" }) || (roles.any? { |role| role.permissions.include?(:manage_timesheet) } && approval.present? && timesheet.timesheet_statuses.all? {|status| status.status == "approved" })
          return {status: "approved", level_status: timesheet.timesheet_statuses.last.status}
        elsif !approval.present? && User.current.admin? && timesheet.timesheet_statuses.all? {|status| status.status == "rejected" } || approval.present? && timesheet.timesheet_statuses.any?{|status| status.status == "rejected" } || (timesheet.timesheet_statuses.all?{|status| status.status == "rejected"} && timesheet.submitted_by == User.current.id)
          return {status: "rejected", level_status: timesheet.timesheet_statuses.last.status}
        elsif approval.present? && timesheet.submitted_by == User.current.id && timesheet.timesheet_statuses.all? {|status| status.status == "approved" } 
          return {status: "approved", level_status: timesheet.timesheet_statuses.last.status}
        elsif approval.present? && timesheet.submitted_by == User.current.id && timesheet.timesheet_statuses.all? {|status| status.status == "rejected" } 
          return {status: "rejected", level_status: timesheet.timesheet_statuses.last.status}
        elsif timesheet.current_user_is_next_level_approver(timesheet,approval) || (User.current.admin? && timesheet.timesheet_statuses.any? {|status| status.status == "submitted"} && approval.nil?) 
          status = timesheet.timesheet_statuses.any? {|status| status.status == "approved" } ? "approved" : timesheet.timesheet_statuses.last.status
          return {status: "waiting for approval", level_status: status}
        elsif timesheet.status == "unsubmit"
          return {status: "unsubmit", level_status: "unsubmit"}
        else 
          status = timesheet.timesheet_statuses.where(approval_level_id: approval.id).last if approval.present?
          level_status = timesheet.timesheet_statuses.any? {|status| status.status == "approved" } ? "approved" : timesheet.timesheet_statuses.last.status
          return {status: status.status, level_status: level_status} if status.present?
        end 
      end 
    end 


    def index 
      userId = params[:user_id]
      start_date = params[:start_date]
      due_date = params[:due_date]
    
      if userId.present? && start_date.present? && due_date.present?
        @timesheet = SubmitTimesheet.find_by(user_id: userId, start_date: start_date..due_date, end_date: start_date..due_date)
        if @timesheet.present?
          t = @timesheet
          date_range = (t.start_date..t.end_date).to_a if t.start_date.present? && t.end_date.present?
          status_info = find_status(@timesheet)
          @timesheet_data = {
            id: t.id,
            user_id: t.user_id,
            status: status_info[:status],
            level_status: status_info[:level_status],
            submitted_by: t.submitted_by,
            start_date: t.start_date,
            end_date: t.end_date,
            date_range: date_range || []
          }
          
          render json: @timesheet_data
        else  
          render json: []
        end  
      else  
        render json: {error: "User id, start date and end date are required"}, status: :unprocessable_entity
      end
    end
        
    def create_team
        @team_id = params[:team_id]
        if @team_id.present?
            @selected_team = TimesheetSelectedTeam.where(user_id: User.current.id).exists?
            respond_to do |format|
                if @selected_team
                    @team = TimesheetSelectedTeam.where(user_id: User.current.id).update(team_id: @team_id)
                    format.api{render :json => @team}
                else 
                    @team = TimesheetSelectedTeam.create(team_id: @team_id, user_id: User.current.id) 
                    format.api{render :json => @team}
                end 
            end 
         
        end 
    end 

    def selected_team
        @team = TimesheetSelectedTeam.where(user_id: User.current.id)
        respond_to do |format|
            format.api{ render :json => @team}
        end 
    end 


    private 
    def submit_timesheet_params     
        submit_timesheet = JSON.parse(params[:submit_timesheet])
        timesheet_attributes = {
          user_id: submit_timesheet['user_id'],
          start_date: submit_timesheet['start_date'],
          end_date: submit_timesheet['end_date'],
          hours: submit_timesheet['hours'],
          submitted_by: submit_timesheet['user_id']
        }
        submit_timesheet[:hours] = parse_hours_from_params(submit_timesheet[:hours])
        timesheet_activities_attributes = submit_timesheet['timesheet_activities_attributes']
      
        timesheet_attributes.merge(
          timesheet_activities_attributes: timesheet_activities_attributes,
          submitted: true,
          reject_end_date: submit_timesheet['end_date'],
          reject_start_date: submit_timesheet['start_date'],
        )
        params.require(:submit_timesheet).permit(:user_id, :status, :level_status, :start_date, :end_date, :hours, timesheet_activities_attributes: [:id, :activity_id, :hours, :activity_name])
    end


    def update_nested_attributes(timesheet, nested_attributes)
      return unless nested_attributes
    
      nested_attributes.each do |attributes|
        if (existing_activity = timesheet.timesheet_activities.find_by(activity_id: attributes[:activity_id]))
          existing_activity.update(attributes)
        else
          timesheet.timesheet_activities.create(attributes)
        end
      end
    end

    
      
   
end
