class ApprovalLevelsController < ApplicationController
  before_action :require_login
  before_action :require_admin

  def index 
    @approval_levels = ApprovalLevel.order(:level)
  end 

  def new
    @approval = ApprovalLevel.new 
    # @team_id = params[:team_id]

    @approval_levels = ["1", "Level One", "2", "Level Two", "3", "Level Three", "4", "Level Four", "5","Level Five"]
  end

  # def create 
  #   @approval = ApprovalLevel.new(approval_level_params)
  #   @team = Team.find(params[:approval_level][:team_id])
  #   @team.approval_levels << @approval
     
  #   if @approval.save 
  #     flash[:notice] = "Approval level created successfully"
  #     redirect_to  :back
  #   else  
  #     flash[:error] = @approval.errors.full_messages.join("</br>")
  #     redirect_to :back
  #   end 
  #   respond_to do |format|
  #     format.html
  #     format.js
  #   end
  # end 

  def create 
    
    @approval = ApprovalLevel.new(approval_level_params)
   
    # role = Role.find(params[:approval_level][:role])
    # @team = Team.find(params[:approval_level])
    # @team.approval_levels << @approval
    
    
    respond_to do |format|
      if @approval.save 
        flash[:notice] = l(:label_approval_level_created_success)
        format.html { redirect_to :back }
        format.js { render js: "window.location = '/approval_levels'" }
      else  
        flash[:error] = @approval.errors.full_messages.join("</br>")
        format.html
        format.js { render 'error.js.erb', locals: { error_message: flash[:error] }, status: :unprocessable_entity }
      end 
    end
  end

  def edit
    @approval = ApprovalLevel.find(params[:id])
    # @team_id = params[:team_id]
    @approval_levels = ["1", "Level One", "2", "Level Two", "3", "Level Three", "4", "Level Four", "5","Level Five"]
  end

  # def update 
  #   @approval = ApprovalLevel.find(params[:id])
  #   @team = Team.find(params[:approval_level][:team_id])
  #   @team.approval_levels << @approval
  #   if @approval.update(approval_level_params)
  #     flash[:notice] = "Approval level updated successfully"
  #     redirect_to :back 
  #   else 
  #     flash[:error] = @approval.errors.full_messages.join("</br>")
  #     redirect_to :back
  #   end 
  #   respond_to do |format|
  #     format.html
  #     format.js
  #   end
  # end 

  def update 
    @approval = ApprovalLevel.find(params[:id])
    # @team = Team.find(params[:approval_level][:team_id])
    # @team.approval_levels << @approval
  
    respond_to do |format|
      if @approval.update(approval_level_params)
        flash[:notice] = l(:label_approval_level_updated_success)
        format.html { redirect_to :back }
        format.js { render js: "window.location = '/approval_levels'" }
      else 
        flash[:error] = @approval.errors.full_messages.join("</br>")
        format.html
        format.js { render 'error.js.erb', locals: { error_message: flash[:error] }, status: :unprocessable_entity }
      end 
    end
  end


  def delete
    @approval = ApprovalLevel.find(params[:id])
    respond_to do |format|
      format.js
    end
  end 

  def destroy
    @approval = ApprovalLevel.find(params[:id])
  
    respond_to do |format|
      if @approval.destroy
        flash[:notice] = l(:label_approval_level_deleted_success)
        format.html { redirect_to :back }
        format.js { render js: "window.location = '/approval_levels'" }
      else  
        flash[:error] = @approval.errors.full_messages.join("</br>")
        format.html
        format.js { render 'error.js.erb', locals: { error_message: flash[:error] }, status: :unprocessable_entity }
      end 
    end
  end

  # def destroy
  #   @approval = ApprovalLevel.find(params[:id])
  #   if @approval.destroy
  #     flash[:notice] = "Approval level deleted successfully"
  #     redirect_to :back 
  #   else  
  #     flash[:error] = @approval.errors.full_messages.join(",")
  #     redirect_to :back
  #   end 
  # end 

  private 
  def approval_level_params 
    params.require(:approval_level).permit(:name,:user,:role, :level).merge(created_by: User.current.id)
  end 

end
