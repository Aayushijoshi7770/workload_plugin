class TimesheetTeamsController < ApplicationController
  before_action :require_login
  accept_api_auth :index
  helper :approval_levels

  def index
    user = User.find_by(:id =>User.current.id)
    roles = user.roles.to_a 
    respond_to do |format|
      if roles.any? { |role| role.permissions.include?(:manage_timesheet) }  && !User.current.admin?
        teamId = TeamUser.where(user_id: user.id).pluck(:team_id)
        @teams =  Team.where(id: teamId) if teamId.present?
        format.html
        format.api{ render json: @teams}
      else  
        @teams = Team.all
        format.html
        format.api{ render json: @teams}
      end 
    end

    @hierarchical_teams = build_hierarchy(@teams)
   
  end

  def new
    @team = Team.new
  end



  # def create 
  #   @team = Team.new(team_params)
  #   user_ids = Array(params[:user_ids]).reject(&:empty?) 
  #   @users = User.find(user_ids)

  #   @users.each do |u|
  #     @team.users << u 
  #   end 
  #   if @team.save 
  #     flash[:notice] = "Team created successfully"
  #     redirect_to :back 
  #   else  
  #     flash[:error] = @team.errors.full_messages.join("</br>")
  #     redirect_to :back 
  #   end 
  #   respond_to do |format|
  #     format.html
  #     format.js
  #   end
   
  # end 

  def create                                                                                                 
    @team = Team.new(team_params)
    user_ids = Array(params[:user_ids]).reject(&:empty?) 
    @users = User.find(user_ids)
    @team.parent_id = params[:team][:parent_id].present? ? params[:team][:parent_id] : 0

    @team.users << @users
    # @users.each do |u|
    #   @team.users << u 
    # end 
  
    respond_to do |format|
      if @team.save 
        flash[:notice] = l(:notice_successful_create)
        format.html { redirect_to :back }
        format.js { render js: "window.location = '/timesheet_teams'" }
      else  
        flash[:error] = @team.errors.full_messages.join("</br>")
        format.html
        format.js { render 'error.js.erb', locals: { error_message: flash[:error] }, status: :unprocessable_entity }
      end 
    end
  end

  def edit
    @team = Team.find(params[:id])
  end

  # def update
  #   @team = Team.find(params[:id])
  #   if @team.update(team_params)
  #     flash[:notice] = "Team updated successfully"
  #     redirect_to :back 
  #   else  
  #     flash[:error] = @team.errors.full_messages.join("</br>")
  #     redirect_to :back 
  #   end 
  #   respond_to do |format|
  #     format.html
  #     format.js
  #   end
   
  # end 

  def update
    @team = Team.find(params[:id])
    parent_id = params[:team][:parent_id].present? ? params[:team][:parent_id] : 0
    @team.parent_id = parent_id
  
    respond_to do |format|
      if @team.update(team_params.except(:parent_id).merge(parent_id: parent_id))
        flash[:notice] = l(:notice_successful_update_team)
        format.html { redirect_to :back }
        format.js { render js: "window.location = '/timesheet_teams'" }
      else
        flash[:error] = @team.errors.full_messages.join("</br>")
        format.html
        format.js { render 'error.js.erb', locals: { error_message: flash[:error] }, status: :unprocessable_entity }
      end
    end
  end

  def show
    @team = Team.find(params[:id])
  end

  # def destroy 
  #   @team = Team.find(params[:id])
  #   if @team.destroy 
  #     selected_team = TimesheetSelectedTeam.find_by(team_id: @team.id)
  #     selected_team.present? ? selected_team.destroy : selected_team
    
  #     flash[:notice] = "Team deleted successfully"
  #     redirect_to :back 
  #   else  
  #     flash[:error] = @team.errors.full_messages.join("</br>")
  #     redirect_to timesheet_teams_path
  #   end 
  # end 



  def delete
    @team = Team.find(params[:id])
  end
  def destroy
    team_ids = params[:team_ids]
  
    respond_to do |format|
      begin
        ActiveRecord::Base.transaction do
          valid_team_ids = Array(team_ids).map(&:to_i).reject { |id| id <= 0 }
          teams = Team.where(id: valid_team_ids)
          sorted_teams = teams.sort_by { |team| -team_depth(team) }
          sorted_teams.each do |team|
            destroy_descendants(team)
            approval_query = ApprovalQuery.find_by(team_id: team.id)
            approval_query.destroy if approval_query.present?
            team.destroy!
            selected_team = TimesheetSelectedTeam.find_by(team_id: team.id)
            selected_team.destroy if selected_team.present?
          end
        end
        flash[:notice] = l(:notice_successful_delete)
        format.api { render json: { message: "Teams deleted successfully" }, status: :ok }
      rescue => e
        format.js { render json: e.message, status: :unprocessable_entity }
      end
    end
  end
  
  def team_depth(team)
    depth = 0
    current_team = team
    while current_team.parent_id.present? && current_team.parent_id != 0
      depth += 1
      current_team = Team.find(current_team.parent_id)
    end
    depth
  end
  
  
  
  
  
  # def remove_user
  #   @team = Team.find(params[:team_id])
  #   @user = User.find(params[:user_id])
  
  #   if @team.remove_user(@user)
  #     flash[:notice] = "User removed from the team successfully."
  #   else
  #     flash[:error] = "User not found in the team."
  #   end
  
  #   redirect_to :back
  # end
  
  def new_remove_user
    @team = Team.find(params[:id])
    @user = User.find(params[:user_id])
    respond_to do |format|
      format.js
    end
  end
  

  def remove_user
    @team = Team.find(params[:team_id])
    @user = User.find(params[:user_id])
  
    if @team.remove_user(@user)
      flash[:notice] = "User removed from the team successfully."
    else
      flash[:error] = "User not found in the team."
    end

    respond_to do |format|
      format.html { redirect_to :back }
      format.js { render js: "window.location = '/timesheet_teams'" }
    end
  end



  private

  def destroy_descendants(team)
    child_teams = Team.where(parent_id: team.id)
    child_teams.each do |child|
      destroy_descendants(child)
      approval_query = ApprovalQuery.find_by(team_id: child.id)
      approval_query.destroy if approval_query.present?
      selected_team = TimesheetSelectedTeam.find_by(team_id: child.id)
      selected_team.destroy if selected_team.present?
      child.destroy
    end
  end

  def team_params 
    params.require(:team).permit(:name, {user_ids: []}, :parent_id).merge(created_by: User.current.id)
  end 


  def build_hierarchy(teams)
    nested_teams = []

    teams.each do |team|
      if team.parent_id == 0
        nested_teams  << build_team_tree(team)
      end
    end

    nested_teams
  end
  
  def build_team_tree(team)
    {
      team: team,
      subteam: @teams.select { |child_team| child_team.parent_id == team.id }
                               .map { |child_team| build_team_tree(child_team) }
    }
  end

end
