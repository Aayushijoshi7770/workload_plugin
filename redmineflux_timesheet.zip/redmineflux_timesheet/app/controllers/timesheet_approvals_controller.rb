class TimesheetApprovalsController < ApplicationController
  before_action :get_dates
  before_action :require_login
  include TimesheetApprovalsHelper
 # Start export pdf code
  require 'rbpdf'


  def export_pdf
    @time_entry_activity_export = TimeEntryActivity.all
    @teams_export = Team.all
    @team_id_export = params[:team_id]
    @start_date = params[:start_date] || @period_start
    @end_date = params[:end_date] || @period_end
    team_name = nil
    if @team_id_export.present?
      @users = User.where(team_id: @team_id_export)
      team_name = Team.find_by(id: @team_id_export)&.name
    else
      @users = User.all
    end

    @user_ids_query = params[:user_ids]
    @approved_query = params[:approved_]
    @approved_by_ids = params[:approved_by_ids]
    @rejected_by_ids = params[:rejected_by_ids]
    @approved_rejected = params[:approved_rejected]
    @updated_at = params[:updated_at]

    table_heading = table_header_data(@users, @time_entry_activity_export)
    table_body = table_row_data(@users, @time_entry_activity_export, @team_id_export, @start_date, @end_date, @user_ids_query, @approved_query, @approved_by_ids, @rejected_by_ids, @approved_rejected, @updated_at)

    pdf = RBPDF.new('L', 'mm', 'A4')
    pdf.set_font('helvetica', '', 12)
    pdf.set_print_header(false)
    pdf.set_print_footer(false)
    pdf.add_page

    # Set table title styling
    pdf.set_text_color(51, 51, 102)
    pdf.set_font_size(12)
    pdf.cell(0, 0, team_name || 'Timesheet', 0, 0, 'C')
    pdf.ln(5)

    # Add start and end date on the left side
    formatted_date_range = "#{Date.parse(@start_date).strftime('%d/%m/%Y')} - #{Date.parse(@end_date).strftime('%d/%m/%Y')}"
    pdf.set_text_color(102, 102, 153)
    pdf.set_font_size(8)
    pdf.cell(0, 0, formatted_date_range, 0, 0, 'L')
    pdf.ln(5)

    # Calculate total table width based on column widths
    total_table_width = pdf.get_page_width - pdf.get_margins['left'] - pdf.get_margins['right']

    # Calculate column widths based on header and data
    column_widths = []
    table_heading.each do |header|
      column_widths << pdf.get_string_width(header)
    end
    table_body.each do |row|
      row.each_with_index do |cell, index|
        width = pdf.get_string_width(cell.to_s)
        column_widths[index] = width if width > column_widths[index]
      end
    end

    # Adjust column widths to fit page width
    total_column_widths = column_widths.sum
    column_widths.map! { |width| width * (total_table_width / total_column_widths) }

    # Set thead styling
    pdf.set_fill_color(153, 153, 204)
    pdf.set_text_color(255, 255, 255)
    pdf.set_draw_color(102, 102, 153)
    pdf.set_line_width(0.3)
    pdf.set_font('', 'B')
    table_heading.each_with_index do |header, index|
      pdf.cell(column_widths[index], 7, header, 1, 0, 'C', 1)
    end
    pdf.ln

    # Set tbody styling
    pdf.set_fill_color(255)
    pdf.set_text_color(0)
    pdf.set_draw_color(204, 204, 204)
    pdf.set_line_width(0.1)
    pdf.set_font('', '')
    table_body.each do |row|
      row.each_with_index do |cell, index|
        pdf.cell(column_widths[index], 6, cell.to_s, 1, 0, 'C')
      end
      pdf.ln
    end

    send_data pdf.output, filename: 'timesheet_data.pdf', type: 'application/pdf', disposition: 'attachment'
  end

    # end export pdf code


    def index
      @time_entry_activity = Enumeration.where(type: "TimeEntryActivity", active: true, project_id: nil)
      @teams = Team.all
      @allteam=Team.all
      @team_id = params[:team_id]
      current_user = User.current
  
      if ApprovalQuery.where(user_id: current_user.id).exists?
        @approval_query = ApprovalQuery.find_by(user_id: User.current.id)
        @approval_query.update(team_id: @team_id, start_date: @period_start, end_date: @period_end)
      else
        @approval_query = ApprovalQuery.create!(team_id: @team_id, start_date: @period_start, end_date: @period_end, user_id: current_user.id)
      end
  
      user = User.find_by(id: current_user.id)
      roles = user.roles.to_a
      @selected_team = @approval_query.team_id
  
      if roles.any? { |role| role.permissions.include?(:manage_timesheet) } && !User.current.admin?
        teamIds = TeamUser.where(user_id: user.id).pluck(:team_id)
        if teamIds.present?
          if @selected_team.present?
            @teams = [Team.find(@selected_team)]
            @allteam=Team.where(id: teamIds)
          else
            @teams = Team.where(id: teamIds)
            @allteam=Team.where(id: teamIds)
          end
          userIds = @teams.flat_map { |team| team.users.ids }
          @users = User.where(id: userIds, status: 1)
        else
          @users = User.none
        end
      else
        if @team_id.present?  && Team.exists?(@team_id)
          @team = Team.find(@team_id) if @selected_team
          @user_ids = @team.users.ids
  
          @users = User.where(id: @user_ids, status: 1)
          getsubteam(@team)
          @users = User.where(id: @team_members, status: 1, type: "User")
        else
          @users = User.where(status: 1)
        end
      end
      if params[:query].present?
        query = "%#{params[:query].downcase}%"
        @users = @users.where("LOWER(firstname) LIKE :query OR LOWER(lastname) LIKE :query OR LOWER(firstname || ' ' || lastname) LIKE :query", query: query)
      end
      
      @users = @users.paginate(page: params[:page], per_page: 25)
  
      @hierarchical_teams = build_hierarchy(@allteam)
  
      if @users.present?
        @users_with_approval = @users.select do |user|
          timesheet = submittedTimesheet(user, @period_start, @period_end)
          timesheet.present? && timesheet.can_approve?(timesheet) && timesheet.timesheet_statuses.order(created_at: :asc).last.status == 'submitted'
        end
      else
        @users_with_approval = []
      end
    end
    


  def approve
    period_start = params[:params_start_date]
    period_end = params[:params_end_date]
    approver = User.find(User.current.id)

    if params[:checked_user_ids].present?
        checked_user_ids = params[:checked_user_ids].split(',')

        checked_user_ids.each do |user_id|
            @user = User.find(user_id)
            @timesheet = SubmitTimesheet.find_by(user_id: user_id, start_date: period_start..period_end, end_date: period_start..period_end)

            if @timesheet.present?
                @current_approval = @timesheet.timesheet_statuses.order(created_at: :asc).last
                @current_data = @current_approval.update(status: 'approved', updated_at: Date.today, user: approver)
                create_changelog(@current_approval)
                if ApprovalLevel.exists?
                    @timesheet.create_next_level(@timesheet)
                end
                flash[:notice] = "Timesheet has been approved successfully."
            else
                flash[:error] = "Timesheet not found for user ID: #{user_id}."
            end
        end
    else
        user_id = params[:user_id]
        @user = User.find(user_id)
        @timesheet = SubmitTimesheet.find_by(user_id: user_id, start_date: period_start..period_end, end_date: period_start..period_end)

        if @timesheet.present?
            @current_approval = @timesheet.timesheet_statuses.order(created_at: :asc).last
             @current_data = @current_approval.update(status: 'approved', updated_at: Date.today, user: approver)
             create_changelog(@current_approval)
            if ApprovalLevel.exists?
                @timesheet.create_next_level(@timesheet)
            end
            flash[:notice] = "Timesheet has been approved successfully."
        else
            flash[:error] = "Timesheet not found for user ID: #{user_id}."
        end
    end

    redirect_to :back
end

  # def send_submission_notification(approver,user, timesheet)
  #   begin
  #     TimesheetReminder.timesheet_submission_notification(approver, user, timesheet).deliver_now
  #   rescue => e
  #     Rails.logger.error "Error sending approval notification: #{e.message}"
  #   end
  # end

  # def approval_notification(approver,user, timesheet)
  #   begin
  #     TimesheetReminder.timesheet_approval_notification(approver, user, timesheet).deliver_now
  #   rescue => e
  #     Rails.logger.error "Error sending approval notification: #{e.message}"
  #   end
  # end


  def reject
    comment = params[:comment]
    users = Array(params[:user])  # Ensure users is an array
    start_date = params[:start_date]
    end_date = params[:end_date]
    date = Date.today

    if users.present?
      users.each do |user_id|
        @timesheet = SubmitTimesheet.where(user_id: user_id)
                                     .where("(start_date BETWEEN ? AND ?) OR (end_date BETWEEN ? AND ?)", start_date, end_date, start_date, end_date)
                                     .first
        @user = User.find(user_id)

        if @timesheet
          if @timesheet.update(updated_at: date, status: 2, reject_comment: comment, rejected_by: User.current.id)
            @timesheet.timesheet_statuses.each do |status|
              status.update(status: 'rejected', updated_at: Date.today, user: @user, comments: comment)
            end

            last_status = @timesheet.timesheet_statuses.order(created_at: :asc).last
            create_changelog(last_status)

            flash[:notice] = "Timesheet for User #{user_id} has been rejected successfully."
          else
            flash[:alert] = "Failed to update approval status for User #{user_id}."
          end
        else
          flash[:alert] = "No timesheet found for User #{user_id}."
        end
      end
    else
      flash[:alert] = "No users selected for rejection."
    end

  redirect_to:back
    end


  def get_dates
    @current_day = params.fetch(:day, Date.today).to_date
    @setting_frequency = Setting.plugin_redmineflux_timesheet['frequency']
    @week_start = Setting.plugin_redmineflux_timesheet['week_start'] || ["Monday"]

    if @setting_frequency.present?
      if params[:day].present? && @setting_frequency.include?("Monthly")
        @period_start = @current_day.beginning_of_month
        @period_end = @current_day.end_of_month
      elsif params[:day].present? && @setting_frequency.include?("Weekly") && @week_start.present?
        @period_start = @current_day.beginning_of_week(start_day(@week_start))
        @period_end = @current_day.end_of_week(start_day(@week_start))
      elsif params[:day].present?
        @period_start = @current_day.beginning_of_week
        @period_end = @current_day.end_of_week
      elsif @setting_frequency.include?("Monthly")
        @period_start = @current_day.beginning_of_month
        @period_end = @current_day.end_of_month
      elsif params[:start_date].present? && params[:end_date].present?

        @period_start = params[:start_date].to_date
        @period_end = params[:end_date].to_date
      else
        @period_start = @current_day.beginning_of_week(start_day(@week_start))
        @period_end = @current_day.end_of_week(start_day(@week_start))
      end
    else
      @period_start = @current_day.beginning_of_week(start_day(@week_start))
      @period_end = @current_day.end_of_week(start_day(@week_start))
    end
  end


end

private

def getsubteam(team)
  @child_team = Team.find_by(parent_id: @team.id)
  if  @child_team.present?
   @team_members = @child_team.users.ids
    # Get users from the selected team
    @team_members += @team.users.ids
    # Get users from all subteams recursively
    def get_subteam_users(team)
      subteam_users = []
      subteams = Team.where(parent_id: team.id)
      subteams.each do |subteam|
        subteam_users += subteam.users.ids
        subteam_users += get_subteam_users(subteam)
      end
      subteam_users
    end

    @team_members += get_subteam_users(@team)
  else
    @team_members = @team.users.ids
  end

  @team_members.uniq!
end

def build_hierarchy(teams)
  nested_teams = []

  teams.each do |team|
    if team.parent_id == 0
      nested_teams  << build_team_tree(team)
    end
  end

  nested_teams
end

def build_team_tree(team)
  {
    team: team,
    subteam:  @allteam.select { |child_team| child_team.parent_id == team.id }
                             .map { |child_team| build_team_tree(child_team) }
  }
end

def start_day(week_start)
  start_days_symbols = week_start.map { |day| day.downcase.to_sym }
  valid_days = %i[sunday monday tuesday wednesday thursday friday saturday]
  start_day_symbol = start_days_symbols.find { |day| valid_days.include?(day) }
  start_day_symbol ||= :monday
end

def create_changelog(timesheet_status)
  timesheet = SubmitTimesheet.find(timesheet_status.submit_timesheet_id)
  TimesheetChangelog.create!(
    level_id: timesheet_status.approval_level_id,
    status_id: timesheet_status.status_before_type_cast,
    approved_by: User.current.id,
    comment: timesheet_status.comments,
    timesheet_id: timesheet_status.submit_timesheet_id,
    submitted_by: timesheet.submitted_by,
    timesheet_start_date: timesheet.start_date,
    timesheet_end_date: timesheet.end_date,
    submitted_day_date: timesheet.created_at.to_date,
    rejected_day_date: (timesheet_status.status_before_type_cast == 2 ? Date.today : nil)
  )
end

 # start export pdf code

def table_header_data(users, time_entry_activity_export)
  # Filter time_entry_activity to include only those matching the specific conditions
  relevant_activities = Enumeration.where(type: "TimeEntryActivity", active: true, project_id: nil)

  table_headers = ["Sr No", "Name"]
  relevant_activities.each { |activity| table_headers << activity.name }
  table_headers.concat(["Total Hours", "Time Period", "Status" ,"History"])
  table_headers
end

def table_row_data(users, time_entry_activity_export, team_id_export, start_date, end_date, user_ids_query, approved_query, approved_by_ids, rejected_by_ids, approved_rejected, updated_at)
  table_data = []

  # Fetch filtered users based on team_id or all users if team_id is not present
  filtered_users = if team_id_export.present?
                     team_users = TeamUser.where(team_id: team_id_export)
                     team_user_ids = team_users.pluck(:user_id)
                     User.where(id: team_user_ids).pluck(:id, :firstname, :lastname)
                   else
                     User.pluck(:id, :firstname, :lastname)
                   end

  # Apply roles and permissions filtering
  current_user = User.current
  user_roles = current_user.roles.to_a
  can_manage_timesheets = user_roles.any? { |role| role.permissions.include?(:manage_timesheet) } || current_user.admin?
 # Ensure filtered_users is an array, even if empty
 filtered_users ||= []

 if can_manage_timesheets
  if current_user.admin?
    # Admins can see all users
    managed_user_ids = filtered_users.map { |user_info| user_info[0] }
  else
    # Only show users that belong to the teams managed by the current user
    team_ids_managed = TeamUser.where(user_id: current_user.id).pluck(:team_id)
    managed_user_ids = TeamUser.where(team_id: team_ids_managed).pluck(:user_id)
  end
  filtered_users.select! { |user_info| managed_user_ids.include?(user_info[0]) }
else
  # Non-managers can only see their own data
  filtered_users.select! { |user_info| user_info[0] == current_user.id }
end

# Ensure time_entry_activity_export is an array, even if empty
time_entry_activity_export ||= []

  # Apply user_ids filter
  if user_ids_query.present?
    operator = user_ids_query[:operator]
    user_ids_values = user_ids_query[:values].map(&:to_i)

    if team_id_export.present?
      common_user_ids = if operator == "="
                          team_user_ids & user_ids_values
                        elsif operator == "!"
                          team_user_ids - user_ids_values
                        else
                          team_user_ids
                        end
      filtered_users = filtered_users.select { |user_info| common_user_ids.include?(user_info[0]) }
      filtered_users = [] if operator == "!*"
    else
      filtered_users = filtered_users.select { |user_info| user_ids_values.include?(user_info[0]) } if operator == "="
      filtered_users = filtered_users.reject { |user_info| user_ids_values.include?(user_info[0]) } if operator == "!"
    end
  end

  # Apply approved_query filter
  if approved_query.present?
    approved_user_ids = submitted_user_ids_with_approval(approved_query, @user, start_date, end_date)
    filtered_users = filtered_users.select { |user_info| approved_user_ids.include?(user_info[0]) }
  end

  # Apply approved_rejected filter
  if approved_rejected.present? && approved_rejected[:from].present? && approved_rejected[:to].present?
    from_date = approved_rejected[:from]
    to_date = approved_rejected[:to]
    approval_rejected_user_ids = submitted_user_approval_rejected(@user, from_date, to_date)
    filtered_users = filtered_users.select { |user_info| approval_rejected_user_ids.include?(user_info[0]) }
  end

  # Apply approved_by_ids filter
  if approved_by_ids.present? && approved_by_ids[:operator].present? && approved_by_ids[:values].present?
    approved_by_operator = approved_by_ids[:operator]
    approved_by_values = approved_by_ids[:values]
    approved_by_user_ids = submitted_user_approval_ids(approved_by_operator, approved_by_values, @user, start_date, end_date)
    filtered_users = filtered_users.select { |user_info| approved_by_user_ids.include?(user_info[0]) }
  end

  # Apply rejected_by_ids filter
  if rejected_by_ids.present? && rejected_by_ids[:operator].present? && rejected_by_ids[:values].present?
    rejected_by_operator = rejected_by_ids[:operator]
    rejected_by_values = rejected_by_ids[:values]
    rejected_by_user_ids = submitted_user_rejected_ids(rejected_by_operator, rejected_by_values, @user, start_date, end_date)
    filtered_users = filtered_users.select { |user_info| rejected_by_user_ids.include?(user_info[0]) }
  end

  # Apply updated_at filter
  if updated_at.present? && updated_at[:from].present? && updated_at[:to].present?
    updated_from = updated_at[:from]
    updated_to = updated_at[:to]
    updated_at_user_ids = submitted_user_updated_at(@user, start_date, end_date, updated_from, updated_to)
    filtered_users = filtered_users.select { |user_info| updated_at_user_ids.include?(user_info[0]) }
  end

  # Apply the new condition to filter TimeEntryActivity records
  relevant_activities = time_entry_activity_export.select do |activity|
    activity.type == "TimeEntryActivity" && activity.active == true && activity.project_id.nil?
  end

  filtered_users.each_with_index do |user_info, index|
    row_data = [index + 1, "#{user_info[1]} #{user_info[2]}"]

    # Fetch user
    user_id = user_info[0]
    user = User.find_by(id: user_id)

    if user.present?
      # Fetch timesheet for the user within the specified period
      timesheet = SubmitTimesheet.find_by(user_id: user_id, start_date: start_date..end_date, end_date: start_date..end_date)

      if timesheet.present?
        activity_hours = Hash.new(0.0)

        timesheet.timesheet_activities.each do |activity|
          if relevant_activities.map(&:id).include?(activity.activity_id)
            activity_hours[activity.activity_id] += activity.hours
          end
        end

        relevant_activities.each do |activity|
          row_data << format_hours(activity_hours[activity.id])
        end

        # Calculate total hours and format them
        total_hours_in_decimal = activity_hours.values.sum
        total_hours = total_hours_in_decimal.positive? ? format_hours(total_hours_in_decimal) : "0:00"

        row_data << total_hours
        row_data << "#{timesheet.start_date.strftime("%d/%m/%y")} - #{timesheet.end_date.strftime("%d/%m/%y")}"

        last_status = timesheet.timesheet_statuses.order(created_at: :asc).last
        if last_status
          action_status = case last_status.status
                          when 'submitted'
                            if timesheet.can_approve?(timesheet)
                              "Approve / Reject"
                            else
                              "Waiting for approval"
                            end
                          when 'approved'
                            "Approved"
                          when 'rejected'
                            "Rejected"
                          else
                            "Pending"
                          end
        else
          action_status = "Pending"
        end

        row_data << action_status

        # Add history link
        row_data << "Show"
      else
        relevant_activities.length.times { row_data << "0:00" }
        row_data.concat(["0:00", ""])
        row_data << "Pending"
        row_data << "Show"
      end
    else
      relevant_activities.length.times { row_data << "0:00" }
      row_data.concat(["0:00", ""])
      row_data << "User not found"
      row_data << "Show"
    end

    table_data << row_data
  end

  table_data
end


def format_hours(decimal_hours)
  # Check if the input is already a formatted string
  if decimal_hours.is_a?(String)
    return decimal_hours
  end

  total_minutes = (decimal_hours * 60).round
  hours = total_minutes / 60
  minutes = total_minutes % 60
  "%d:%02d" % [hours, minutes]
end

 # end export pdf code
