class TimesheetReportsController < ApplicationController
  include QueriesHelper
  before_action :require_login
  helper :queries

  accept_api_auth :create , :destroy , :get_all_reports , :update_reports_chart_dimensions , :update_setting

  def index
    
   @queries = TimesheetQuery.where(user_id: User.current.id)
   

   @custom_filter = ["","Team", "Role","Group" , "Category", "Required Vs filled", "Percent Filled"]

   if Setting.plugin_redmineflux_timesheet['approval_workflow'].present?
    @custom_filter -= ["Status" ,"Submission Status" ]
  else
    @custom_filter += ["Status" ,"Submission Status"]
  end


    @group_by = {
      "" => "",
      "Project" => "project_id",
      "Date" => "spent_on",
      "Activity" => "activity_id",
      "Status" => "status_id",
      "Tracker" => "tracker_id",
      "Category" => "category_id"
    } 
 
 
    if params[:project_id].present?
      @project = Project.find(params[:project_id])
      @query = query_class.new
      @query.user = User.current
      @query.project = @project
      @query.build_from_params(params)
    else
      @query = query_class.new
      @query.user = User.current
      @query.project = @project if @project
      @query.build_from_params(params)
    end

    
  end

  def get_all_reports 
    @queries  = TimesheetQuery.where(user_id: User.current.id)
    respond_to do |format|
        format.api {render :json => @queries }
    end 
 end 

  def create
    filters = params[:filters]
    group_by = params[:group_by]
    height = params[:Height]
    width = params[:Width]
    grid_x_axis = params[:grid_x_axis]
    grid_y_axis = params[:grid_y_axis]
    chart_type = params[:chart_type]
    query_name = params[:query_name]
    user_id = User.current.id
    if filters.present?
      timesheet_query = TimesheetQuery.create(filters: filters, user_id: user_id ,group_by: group_by , Height: height , Width: width , grid_x_axis: grid_x_axis , grid_y_axis: grid_y_axis , chart_type: chart_type , query_name: query_name)
    
      if timesheet_query.save
        render json: timesheet_query, status: :created
      else
        render json: timesheet_query.errors, status: :unprocessable_entity
      end
    end
  end

  def destroy
    grid_id = params[:id]
  
    if grid_id.present?
      @grid = TimesheetQuery.find_by(id: grid_id)
  
      if @grid.present?
        @grid.destroy
      else
        render json: { error: "Grid not found" }, status: :not_found
      end
    else
      render json: { error: "Missing required parameters" }, status: :unprocessable_entity
    end
  end

  def update_reports_chart_dimensions
    grid_id = params[:id]
    height = params[:Height]
    width = params[:Width]
    grid_x_axis = params[:grid_x_axis]
    grid_y_axis = params[:grid_y_axis]
  
    if grid_id.present?
      @grid_reports = TimesheetQuery.find_by(id: grid_id)
  
      if @grid_reports.present?
        @grid_reports.update(Height: height, Width: width, grid_x_axis: grid_x_axis, grid_y_axis: grid_y_axis)
        render json: @grid_reports, status: :ok
      else
        render json: { error: "Grid not found" }, status: :not_found
      end
    else
      render json: { error: "Missing required parameters: grid_id" }, status: :unprocessable_entity
    end
  end

  def update_setting
    grid_id = params[:id]
    chart_type = params[:chart_type]
  
    if grid_id.present?
      @grid = TimesheetQuery.find_by(id: grid_id)
  
      if @grid.present?
        @grid.update(chart_type: chart_type)
        render json: @grid
      else
        render json: { error: "Grid not found" }, status: :not_found
      end
    else
      render json: { error: "Missing required parameters" }, status: :unprocessable_entity
    end
  end


  def custom_filters 
    name = params[:name]
  
    if name.present?
      case name
      when 'Team'
        @options = Team.all
      when 'Role'
        @options = Role.where.not(position: 0) 
      when 'Percent Filled'
        @options = options = {''=>'','is' => 'is','>=' => '>=','<=' => '<=','between' => 'between'}
      when 'Group'
        @options = Group.where(type: "Group")
      when 'Status'
        @options = SubmitTimesheet.statuses
      when 'Category'
        @options = IssueCategory.all
    end 
  end
    respond_to do |format|
      format.html { render partial: 'form_filter', locals: { options: @options, name: name } }
      # format.js
  end 
end

  def query_class
    Query.get_subclass(params[:type] || 'TimeEntryQuery')
  end

  def show
    @filter_data = eval(params[:filters])
    @grid_id = params[:grid_id]
    @group_by = params[:group_by]
    @chart_type = params[:chart_type]
    @query_name = params[:query_name]
    @exapted_users = Setting.plugin_redmineflux_timesheet['exapted_users']
    puts "exapted_users #{@exapted_users}"
    if @exapted_users.present?
      @exapted_userss = @exapted_users.map(&:to_i)
    end
    

    @label = []
    @data = []
    
    query = TimeEntry.all
  
    replace_me_with_user_id(@filter_data)
    replace_mine_with_project_ids(@filter_data)

    role_filter = @filter_data['role_id']
    role_ids = role_filter['values'] if role_filter.present?

    group_filter = @filter_data['group_id']
    group_ids = group_filter['values'] if group_filter.present?
  
    team_filter = @filter_data['team_id']
    team_ids = team_filter['values'] if team_filter.present?

    status_filter = @filter_data['status_id']
    status_ids = status_filter['values'] if status_filter.present?

    percent_filter = @filter_data['percent_Filled_id']
    percentage_values = percent_filter['values'] if percent_filter.present?
    percentage_operator = percent_filter['operator'] if percent_filter.present?


    user_filter = @filter_data['User']
    project_filter = @filter_data['Project']
    if user_filter.present? && user_filter['values'].present?
      user_ids_filter = user_filter['values'].map(&:to_i)
    else
      user_ids_filter = User.active.pluck(:id)
    end

    if project_filter.present? && project_filter['values'].present?
      project_ids = project_filter['values'].map(&:to_i)
      users_in_projects = []
      project_ids.each do |project_id|
        project_users = Project.find(project_id).members.pluck(:user_id)
        users_in_projects += project_users
      end
      user_ids_filter &= users_in_projects.uniq
    end
  

    if team_ids.present?
      start_date = end_date = nil
      team_ids.map(&:to_i).each do |team_id|
        
        @team = Team.find(team_id)
        team_members = @team.users.pluck(:id)
        team_members -= @exapted_userss if @exapted_userss.present? 
        team_query = query.where(user_id: team_members)
      
  
        if @filter_data['Date'].present?
          date_filter = @filter_data['Date']
          operator = date_filter['operator']
          values = date_filter['values'].map(&:to_date)
          team_query, start_date, end_date = apply_date_filter(team_query, operator, values)
        end
  
        if @filter_data['Project'].present?
          project_filter = @filter_data['Project']
          operator = project_filter['operator']
          values = project_filter['values']
          team_query = apply_project_filter(team_query, operator, values)
        end

        if @filter_data['Issue'].present?
          issue_filter = @filter_data['Issue']
          operator = issue_filter['operator']
          values = issue_filter['values']
          team_query = apply_issues_filter(team_query, operator, values)
        end
        
        if @filter_data['Author'].present?
          author_filter = @filter_data['Author']
          operator = author_filter['operator']
          values = author_filter['values']
          team_query = apply_author_filter(team_query, operator, values)
        end
        
        if @filter_data['Activity'].present?
          activity_filter = @filter_data['Activity']
          operator = activity_filter['operator']
          values = activity_filter['values']
          team_query = apply_activity_filter(team_query, operator, values)
        end
        
        if @filter_data['Hours'].present?
          hours_filter = @filter_data['Hours']
          operator = hours_filter['operator']
          values = hours_filter['values']
          team_query = apply_hours_filter(team_query, operator, values)
        end
        
        
        if @filter_data['Comment'].present?
          comment_filter = @filter_data['Comment']
          operator = comment_filter['operator']
          values = comment_filter['values']
          team_query = apply_comment_filter(team_query, operator, values)
        end


        total_hours = team_query.sum(:hours)
  
        team_name = Team.find(team_id).name
        @label << @team.name
        @data << total_hours.round(2)
      end

      render partial: 'timesheet_reports/render_chart_for_teams', locals: {
        grid_id: @grid_id,
        label: @label,
        data: @data,
        start_date: start_date,
        chart_type:  @chart_type,
        end_date: end_date
      }

     elsif @query_name == "Submission Status"
      start_date = end_date = nil
      users_data = []

      if user_ids_filter.present? && @exapted_users.present?
        exapted_user_ids = @exapted_users.map(&:to_i)
        user_ids_filter -= exapted_user_ids
      end

      user_ids_filter.each do |user_id|
        user_data = { user_id: user_id, submitted_count: 0, rejected_count: 0, approved_count: 0 }
        user = User.find_by(id: user_id)
        submit_timesheets = SubmitTimesheet.where(user_id: user_id)
        if @filter_data['Date'].present?
          date_filter = @filter_data['Date']
          operator = date_filter['operator']
          values = date_filter['values'].map(&:to_date)
          submit_timesheets, start_date, end_date = apply_start_end_date_filter(submit_timesheets, operator, values)
        end

        if start_date.present? && end_date.present?
          puts "start_date:::: #{start_date}, end_date: #{end_date}"
          submit_data = submit_timesheets.where(status: [1,4])
          submit_timesheets_rejected = SubmitTimesheet.where(
            user_id: user_id,
            status: 2,
            reject_start_date: start_date..end_date,
            reject_end_date: start_date..end_date
          )
          submit_data += submit_timesheets_rejected
        else
          submit_data = submit_timesheets.where(status: [1,2, 4])
        end

        submit_data.each do |timesheet|
          case timesheet.status
          when 'rejected'
            user_data[:rejected_count] += 1
          when 'submitted'
            user_data[:submitted_count] += 1
          when 'approved'
            user_data[:approved_count] += 1
          end
        end

        if user.present?
          users_data << {
            user_id: user_id,
            user_name: user.name,
            submitted_count: user_data[:submitted_count],
            rejected_count: user_data[:rejected_count],
            approved_count: user_data[:approved_count],
          }
        end
      end

      render partial: 'timesheet_reports/render_chart_for_submitted_Vs_Rejected', locals: {
        grid_id: @grid_id,
        users_data: users_data,
        start_date: start_date,
        chart_type: @chart_type,
        end_date: end_date
      }

    elsif @query_name == "Required Vs filled"
      original_start_date = original_end_date = nil
      work_hours_setting = Setting.plugin_redmineflux_timesheet['work_hours']
    
      puts "work_hours_setting #{work_hours_setting}"
    
      if work_hours_setting && !work_hours_setting.all?(&:empty?)
        work_hours = work_hours_setting.first
        @user_required_hours_per_day = work_hours
      else
        @user_required_hours_per_day = 8.5
      end
    
      puts "user_required_hours_per_day  #{ @user_required_hours_per_day}"
      @non_working_day = Setting.non_working_week_days.map(&:to_i) if Setting.non_working_week_days
      @non_working_day ||= [] 
      full_week = [1,2,3,4,5,6,7] # Full week
      left_working_days = full_week - @non_working_day

      puts "left_working_days #{left_working_days}"
    
      required_filled_data = []
    
      if user_ids_filter.present? && @exapted_users.present?
        exapted_user_ids = @exapted_users.map(&:to_i)
        user_ids_filter -= exapted_user_ids
      end
    
      user_ids_filter.each do |user_id|
        user = User.find_by(id: user_id)
        next unless user
    
        user_required_daily_basis_hours = @user_required_hours_per_day.to_f 
    
        require_vs_filled_query = TimeEntry.where(user_id: user_id)
    
        if @filter_data['Date'].present?
          date_filter = @filter_data['Date']
          operator = date_filter['operator']
          values = date_filter['values'].map(&:to_date)
          require_vs_filled_query, original_start_date, original_end_date = apply_date_filter(require_vs_filled_query, operator, values)
        end
    
        start_date = original_start_date
        end_date = original_end_date
  
    
        if @filter_data['Project'].present?
          project_filter = @filter_data['Project']
          operator = project_filter['operator']
          values = project_filter['values']
          require_vs_filled_query = apply_project_filter(require_vs_filled_query, operator, values)
        end

        if @filter_data['Issue'].present?
          issue_filter = @filter_data['Issue']
          operator = issue_filter['operator']
          values = issue_filter['values']
          team_query = apply_issues_filter(team_query, operator, values)
        end
        
        if @filter_data['Author'].present?
          author_filter = @filter_data['Author']
          operator = author_filter['operator']
          values = author_filter['values']
          team_query = apply_author_filter(team_query, operator, values)
        end
        
        if @filter_data['Activity'].present?
          activity_filter = @filter_data['Activity']
          operator = activity_filter['operator']
          values = activity_filter['values']
          team_query = apply_activity_filter(team_query, operator, values)
        end
        
        if @filter_data['Hours'].present?
          hours_filter = @filter_data['Hours']
          operator = hours_filter['operator']
          values = hours_filter['values']
          team_query = apply_hours_filter(team_query, operator, values)
        end
        
        
        if @filter_data['Comment'].present?
          comment_filter = @filter_data['Comment']
          operator = comment_filter['operator']
          values = comment_filter['values']
          team_query = apply_comment_filter(team_query, operator, values)
        end

    
        if start_date && end_date

          total_days = (end_date - start_date).to_i + 1
          puts "total_days:: #{total_days}"
        
          working_days = 0
        
          (start_date..end_date).each do |date|
            working_days += 1 if left_working_days.include?((date.wday - 1) % 7 + 1)
          end
        
          puts "working_days #{working_days}"
        
          if working_days <= 0
            required_filled_data << {
              user_name: user.name,
              required_hours: 0,
              filled_hours: 0
            }
            next
          end
        end
    
        filled_hours = require_vs_filled_query.sum(:hours).round(2)
        time_entries_count = require_vs_filled_query.count
    
        required_hours = user_required_daily_basis_hours * working_days
    
        required_filled_data << {
          user_name: user.name,
          required_hours: required_hours.round(2),
          filled_hours: filled_hours
        }
      end
    
      render partial: 'timesheet_reports/render_chart_for_required_Vs_filled', locals: {
        grid_id: @grid_id,
        required_filled_data: required_filled_data,
        chart_type: @chart_type,
        start_date: original_start_date,
        end_date: original_end_date
      }

      
    elsif percentage_values.present?
      original_start_date = original_end_date = nil
      user_percentage_data = []

      if user_ids_filter.present? && @exapted_users.present?
        exapted_user_ids = @exapted_users.map(&:to_i)
        user_ids_filter -= exapted_user_ids
      end
    
      time_entries = TimeEntry.where(user_id: user_ids_filter)
      non_working_day = Setting.non_working_week_days.map(&:to_i) if Setting.non_working_week_days
      non_working_day ||= [] 
      full_week = [1,2,3,4,5,6,7] # Full week
      left_working_days = full_week - non_working_day
      

      puts "left_working_days #{left_working_days}"
    
      # Apply date filter if available
      if @filter_data['Date'].present?
        date_filter = @filter_data['Date']
        operator = date_filter['operator']
        values = date_filter['values'].map(&:to_date)
        time_entries, original_start_date, original_end_date = apply_date_filter(time_entries, operator, values)
      end
    
      start_date = original_start_date
      end_date = original_end_date

    
      # Apply project filter if available
      if @filter_data['Project'].present?
        project_filter = @filter_data['Project']
        operator = project_filter['operator']
        values = project_filter['values']
        time_entries = apply_project_filter(time_entries, operator, values)
      end
    
      total_time_spent = time_entries.group(:user_id).sum(:hours)
    
      work_hours_setting = Setting.plugin_redmineflux_timesheet['work_hours']
    
      if work_hours_setting && !work_hours_setting.all?(&:empty?)
        work_hours = work_hours_setting.first
        expected_hours_per_day = work_hours.to_f
      else
        expected_hours_per_day = 8.5
      end
    
      puts "expected_hours_per_day:: #{expected_hours_per_day}"
    
      added_users = Set.new
    
      total_time_spent.each do |user_id, time_spent|
        working_days = 0
        if start_date && end_date
          (start_date..end_date).each do |date|
            working_days += 1 if left_working_days.include?((date.wday - 1) % 7 + 1)
          end
        end
      
        total_expected_time = working_days * expected_hours_per_day
        puts "total_expected_time:: #{total_expected_time}"
      
        filled_percentage = total_expected_time.positive? ? (time_spent / total_expected_time) * 100 : 0
    
        percentage_values.map(&:to_i).each do |percentage_value|
          case percentage_operator
          when 'is'
            next unless filled_percentage.round == percentage_value
          when '>='
            next unless filled_percentage.round >= percentage_value
          when '<='
            next unless filled_percentage.round <= percentage_value
          when 'between'
            lower_percentage_value, upper_percentage_value = percentage_values.map(&:to_i)
            next unless filled_percentage.round >= lower_percentage_value && filled_percentage.round <= upper_percentage_value
          end
    
          next if added_users.include?(user_id)
    
          user = User.find_by(id: user_id)
          user_percentage_data << {
            user_name: user&.name, 
            percentage: filled_percentage.to_i
          }
    
          added_users << user_id
        end
      end
    
      render partial: 'timesheet_reports/render_chart_for_percentage_with_users', locals: {
        grid_id: @grid_id,
        label: @label,
        data: user_percentage_data,
        chart_type: @chart_type,
        start_date: original_start_date,
        end_date: original_end_date
      }
   
    
    elsif status_ids.present?
      start_date = end_date = nil
      @status_counts = {}
    
      status_ids.map(&:to_i).each do |status_id|
        submit_timesheets = SubmitTimesheet.where(status: status_id)
    
        if @filter_data['Date'].present?
          date_filter = @filter_data['Date']
          operator = date_filter['operator']
          values = date_filter['values'].map(&:to_date)
          submit_timesheets, start_date, end_date = apply_start_end_date_filter(submit_timesheets, operator, values)
        end
    
        @status_counts[status_id] = submit_timesheets.count
    
        status_name = SubmitTimesheet.statuses.key(status_id)
    
        @label << status_name
        @data << @status_counts[status_id] 
      end
    
      render partial: 'timesheet_reports/render_chart_for_status', locals: {
        grid_id: @grid_id,
        label: @label,
        data: @data,
        chart_type: @chart_type,
        start_date: start_date,
        end_date: end_date
      }

    elsif role_ids&.size.to_i > 1
      start_date = end_date = nil
      role_ids.map(&:to_i).each do |role_id|
      
        role_members = MemberRole.where(role_id: role_id).pluck(:member_id)
        user_ids = Member.where(id: role_members).pluck(:user_id)
        user_ids -= @exapted_userss if @exapted_userss.present? 
        role_query = query.where(user_id: user_ids)
    
        if @filter_data['Date'].present?
          date_filter = @filter_data['Date']
          operator = date_filter['operator']
          values = date_filter['values'].map(&:to_date)
          role_query, start_date, end_date = apply_date_filter(role_query, operator, values)
        end
    
        if @filter_data['Project'].present?
          project_filter = @filter_data['Project']
          operator = project_filter['operator']
          values = project_filter['values']
          role_query = apply_project_filter(role_query, operator, values)
        end

        if @filter_data['Issue'].present?
          issue_filter = @filter_data['Issue']
          operator = issue_filter['operator']
          values = issue_filter['values']
          role_query = apply_issues_filter(role_query, operator, values)
        end
        
        if @filter_data['Author'].present?
          author_filter = @filter_data['Author']
          operator = author_filter['operator']
          values = author_filter['values']
          role_query = apply_author_filter(role_query, operator, values)
        end
        
        if @filter_data['Activity'].present?
          activity_filter = @filter_data['Activity']
          operator = activity_filter['operator']
          values = activity_filter['values']
          role_query = apply_activity_filter(role_query, operator, values)
        end
        
        if @filter_data['Hours'].present?
          hours_filter = @filter_data['Hours']
          operator = hours_filter['operator']
          values = hours_filter['values']
          role_query = apply_hours_filter(role_query, operator, values)
        end
        
        
        if @filter_data['Comment'].present?
          comment_filter = @filter_data['Comment']
          operator = comment_filter['operator']
          values = comment_filter['values']
          role_query = apply_comment_filter(role_query, operator, values)
        end
    
        total_hours = role_query.sum(:hours)
    
        role_name = Role.find(role_id).name
    
        @label << role_name
        @data << total_hours.round(2)
      end
    
      render partial: 'timesheet_reports/render_chart_for_roles', locals: {
        grid_id: @grid_id,
        label: @label,
        data: @data,
        chart_type:  @chart_type,
        start_date: start_date,
        end_date: end_date
      }

    elsif group_ids&.size.to_i > 1
      start_date = end_date = nil
      group_ids.map(&:to_i).each do |group_id|
        user_ids = Group.where(id: group_id).joins(:users).pluck(:user_id)
        user_ids -= @exapted_userss if @exapted_userss.present? 
        group_query = query.where(user_id: user_ids) 
        
        puts "user_ids:: #{group_query}"
        
        if @filter_data['Date'].present?
          date_filter = @filter_data['Date']
          operator = date_filter['operator']
          values = date_filter['values'].map(&:to_date)
          group_query, start_date, end_date = apply_date_filter(group_query, operator, values)
        end
    
        if @filter_data['Project'].present?
          project_filter = @filter_data['Project']
          operator = project_filter['operator']
          values = project_filter['values']
          group_query = apply_project_filter(group_query, operator, values)
        end

        if @filter_data['Issue'].present?
          issue_filter = @filter_data['Issue']
          operator = issue_filter['operator']
          values = issue_filter['values']
          group_query = apply_issues_filter(group_query, operator, values)
        end
        
        if @filter_data['Author'].present?
          author_filter = @filter_data['Author']
          operator = author_filter['operator']
          values = author_filter['values']
          group_query = apply_author_filter(group_query, operator, values)
        end
        
        if @filter_data['Activity'].present?
          activity_filter = @filter_data['Activity']
          operator = activity_filter['operator']
          values = activity_filter['values']
          group_query = apply_activity_filter(group_query, operator, values)
        end
        
        if @filter_data['Hours'].present?
          hours_filter = @filter_data['Hours']
          operator = hours_filter['operator']
          values = hours_filter['values']
          group_query = apply_hours_filter(group_query, operator, values)
        end
        
        
        if @filter_data['Comment'].present?
          comment_filter = @filter_data['Comment']
          operator = comment_filter['operator']
          values = comment_filter['values']
          group_query = apply_comment_filter(group_query, operator, values)
        end
        
        total_hours = group_query.sum(:hours)
    
        puts "total_hours:: #{total_hours}"
        
        group_name = Group.find(group_id).name
        @label << group_name
        @data << total_hours.round(2)
      end
    
      render partial: 'timesheet_reports/render_chart_for_groups', locals: {
        grid_id: @grid_id,
        label: @label,
        data: @data,
        chart_type:  @chart_type,
        start_date: start_date,
        end_date: end_date
      }
  
    else
      query, start_date, end_date = apply_filters(query, @filter_data)
  
      if @group_by.present?
        #Group By Tracker
        if @group_by == "tracker_id" 
          grouped_data = query.joins(:issue)
          .select("issues.tracker_id, SUM(time_entries.hours) as total_hours")
          .group("issues.tracker_id")
          .joins("INNER JOIN issues ON issues.id = time_entries.issue_id")
        #Group By Status
        elsif @group_by == "status_id"
          grouped_data = query.joins(:issue)
          .select("issues.status_id, SUM(time_entries.hours) as total_hours")
          .group("issues.status_id")
          .joins("INNER JOIN issues ON issues.id = time_entries.issue_id")
        #Group By Category
        elsif @group_by == "category_id"
          grouped_data = query.joins(:issue)
          .select("issues.category_id, SUM(time_entries.hours) as total_hours")
          .group("issues.category_id")
          .joins("INNER JOIN issues ON issues.id = time_entries.issue_id")
        else
          grouped_data = query.group(@group_by).select("#{@group_by}, SUM(hours) as total_hours")
        end
    
        grouped_data.each do |data|
          group_by_name = get_group_by_name(data, @group_by)
          if group_by_name.present?
            @label << group_by_name.to_s
            @data << data.total_hours.round(2)
          end
        end
  else
    # No group by option selected, show spent hours shows by default by users

 
# Apply the user_ids_filter to the query
users_data = query.where(user_id: user_ids_filter).group(:user_id).select('time_entries.user_id, SUM(time_entries.hours) as total_hours')
user_ids = users_data.map(&:user_id)

# Fetch user names directly
user_names = User.active.where(id: user_ids).map { |user| [user.id, "#{user.firstname} #{user.lastname}"] }.to_h

users_data.each do |data|
  user_id = data.user_id
  next if @exapted_userss.present? && @exapted_userss.include?(user_id)

  user_name = user_names[user_id]
  total_hours = data.total_hours.round(2)

  @label << user_name
  @data << total_hours
end

  end
      render partial: 'timesheet_reports/render_chart', locals: {
        grid_id: @grid_id,
        label: @label,
        data: @data,
        start_date: start_date,
        end_date: end_date,
        group_by: @group_by,
        chart_type:  @chart_type
      }
    end
  end


  
  private

  def get_group_by_name(data, group_by)
    case group_by
    when "project_id"
      project = Project.find_by(id: data.send(group_by))
      project.name if project
    when "spent_on"
      data.send(group_by).to_s
    when "activity_id"
      activity = Enumeration.find_by(id: data.send(group_by), type: "TimeEntryActivity")
      activity.name if activity
    when "status_id"
      status = IssueStatus.find_by(id: data.send(group_by))
      status.name if status
    when "category_id"
      category = IssueCategory.find_by(id: data.send(group_by))
      category.name if category
    when "tracker_id"
      tracker = Tracker.find_by(id: data.send(group_by))
      tracker.name if tracker
    else
      data.send(group_by).to_s
    end
  end

  def replace_me_with_user_id(filter_data)
    user_id = User.current.id.to_s
    filter_data.each do |key, value|
      values = value['values']
      values.map! { |v| v == 'me' ? user_id : v }
    end
  end

  def replace_mine_with_project_ids(filter_data)
    current_user = User.current
    project_ids = current_user.memberships.pluck(:project_id)
    
    filter_data.each do |key, value|
      values = value['values']
      if values.include?('mine')
        values.delete('mine')  
        values += project_ids
      end
    end
  end
  
  def apply_filters(query, filter_data)
    start_date = end_date = nil
    filter_data.each do |key, value|
      case key
      when 'Date'
        operator = value['operator']
        values = value['values']
        query, start_date, end_date = apply_date_filter(query, operator, values)
      when 'Project'
        operator = value['operator']
        values = value['values']
        query = apply_project_filter(query, operator, values)
      when 'User'
        operator = value['operator']
        values = value['values']
        query = apply_user_filter(query, operator, values)
      when 'Issue'
        operator = value['operator']
        values = value['values']
        query = apply_issues_filter(query, operator, values)
      when 'Author'
        operator = value['operator']
        values = value['values']
        query = apply_author_filter(query, operator, values)
      when 'Activity'
        operator = value['operator']
        values = value['values']
        query = apply_activity_filter(query, operator, values)
      when 'Hours'
        operator = value['operator']
        values = value['values']
        query = apply_hours_filter(query, operator, values)
      when 'team_id'
        # operator = value['operator']
        # team_ids = value['values']
        # # team_members = TeamUser.where(team_id: team_ids).pluck(:user_id)
        # @team = Team.find(team_ids)
        # team_members = @team.users.pluck(:id)
        # query = query.where(user_id: team_members)
      when 'Comment'
        operator = value['operator']
        values = value['values']
        query = apply_comment_filter(query, operator, values)
      when 'role_id'
        operator = value['operator']
        role_ids = value['values']
        role_members = MemberRole.where(role_id: role_ids).pluck(:member_id)
        user_ids = Member.where(id: role_members).pluck(:user_id)
        query = query.where(user_id: user_ids)
      when 'group_id'
        operator = value['operator']
        group_ids = value['values']
        user_ids = Group.where(id: group_ids).joins(:users).pluck(:user_id)
        query = query.where(user_id: user_ids)
      when 'percent_Filled_id'
        operator = value['operator']
        percent_Filled_id = value['values']
        query = query.where(percent_Filled_id: percent_Filled_id)
      when 'category_id'
        category_id = value['values']
        query = query.joins(:issue).where(issues: { category_id: category_id })
      when 'issue_tracker_id'
        operator = value['operator']
        values = value['values']
        query = apply_issue_tracker_filter(query, operator, values)
      when 'issue_status_id'
        operator = value['operator']
        values = value['values']
        query = apply_issue_status_filter(query, operator, values)
      when 'issue_target_version_id'
        operator = value['operator']
        values = value['values']
        query = apply_issue_target_version_filter(query, operator, values)
      when 'project_status'
        operator = value['operator']
        values = value['values']
        query = apply_project_status_filter(query, operator, values)
      when /tr_issue_cf_(\d+)/
        cf_id = $1.to_i
        values = value['values']
        operator = value['operator']
        custom_field = CustomField.find(cf_id)

        custom_field_type = custom_field.field_format

          subquery = case custom_field_type
          when 'int' , 'float'
            handle_integer_operator(cf_id, values, operator)
          when 'list'
            handle_list_operator(cf_id, values, operator)
          when 'user'
            handle_user_operator(cf_id, values, operator)
          when 'date'
            handle_date_operator(cf_id, values, operator)
          when 'text'
            handle_text_operator(cf_id, values, operator)
          when 'bool'
            handle_bool_operator(cf_id, values, operator)
          when 'version'
            handle_version_operator(cf_id, values, operator)
          else
            nil
          end
      
        query = query.joins(:issue).where(issues: { id: subquery }) 

      when /tr_project_cf_(\d+)/
        cf_id = $1.to_i
        values = value['values']
        operator = value['operator']
        custom_field = CustomField.find(cf_id)

        custom_field_type = custom_field.field_format

      
          subquery = case custom_field_type
          when 'int' , 'float'
            handle_integer_operator(cf_id, values, operator)
          when 'list'
            handle_list_operator(cf_id, values, operator)
          when 'user'
            handle_user_operator(cf_id, values, operator)
          when 'date'
            handle_date_operator(cf_id, values, operator)
          when 'text'
            handle_text_operator(cf_id, values, operator)
          when 'bool'
            handle_bool_operator(cf_id, values, operator)
          when 'version'
            handle_version_operator(cf_id, values, operator)
          else
            nil
          end
        query = query.joins(:issue).where(issues: { project_id: subquery })
      end
    end
    return query, start_date, end_date
  end

  def handle_integer_operator(cf_id, values, operator)
    case operator
    when '='
      CustomValue.where(custom_field_id: cf_id, value: values, customized_type: 'Issue').select(:customized_id)
    when '>='
      CustomValue.where("custom_field_id = ? AND value >= ? AND customized_type = ?", cf_id, values, 'Issue').select(:customized_id)
    when '<='
      CustomValue.where("custom_field_id = ? AND value <= ? AND customized_type = ?", cf_id, values, 'Issue').select(:customized_id)
    when '><'
      CustomValue.where("custom_field_id = ? AND value > ? AND value < ? AND customized_type = ?", cf_id, values[0], values[1], 'Issue').select(:customized_id)
    else
      nil
    end
  end
  
  def handle_list_operator(cf_id, values, operator)
    case operator
    when '='
      CustomValue.where(custom_field_id: cf_id, value: values, customized_type: 'Issue').select(:customized_id)
    when '!'
      CustomValue.where("custom_field_id = ? AND value != ? AND customized_type = ?", cf_id, values, 'Issue').select(:customized_id)
    when '!*'
      CustomValue.where(custom_field_id: cf_id, customized_type: 'Issue').where.not(value: values).select(:customized_id)
    when '*'
      CustomValue.where(custom_field_id: cf_id, customized_type: 'Issue').select(:customized_id)
    else
      nil
    end
  end

    
  def handle_user_operator(cf_id, values, operator)
    case operator
    when '='
      CustomValue.where(custom_field_id: cf_id, value: values, customized_type: 'Issue').select(:customized_id)
    when '!'
      CustomValue.where("custom_field_id = ? AND value IS NOT NULL AND value != '' AND customized_type = ?", cf_id, 'Issue').select(:customized_id)
    when '!*'
      CustomValue.where(custom_field_id: cf_id, customized_type: 'Issue').where.not(value: values).select(:customized_id)
    when '*'
      CustomValue.where(custom_field_id: cf_id, customized_type: 'Issue').select(:customized_id)
    else
      nil
    end
  end

  def handle_date_operator(cf_id, values, operator)
    case operator
    when '='
      CustomValue.where(custom_field_id: cf_id, value: values, customized_type: 'Issue').select(:customized_id)
    when '>='
      CustomValue.where("custom_field_id = ? AND value >= ? AND customized_type = ?", cf_id, values, 'Issue').select(:customized_id)
    when '<='
      CustomValue.where("custom_field_id = ? AND value <= ? AND customized_type = ?", cf_id, values, 'Issue').select(:customized_id)
    when '><'
      CustomValue.where("custom_field_id = ? AND value >= ? AND value <= ? AND customized_type = ?", cf_id, values[0], values[1], 'Issue').select(:customized_id)
    when '<t+'
      days = values.to_i
      CustomValue.where("custom_field_id = ? AND value >= ? AND customized_type = ?", cf_id, Date.current, 'Issue').select(:customized_id)
    when '>t+'
      days = values.to_i
      CustomValue.where("custom_field_id = ? AND value >= ? AND customized_type = ?", cf_id, Date.current + days.days, 'Issue').select(:customized_id)
    when '><t+'
      days = values.to_i
      CustomValue.where("custom_field_id = ? AND value >= ? AND value <= ? AND customized_type = ?", cf_id, Date.current, Date.current + days.days, 'Issue').select(:customized_id)
    when 't+'
      days = values.to_i
      CustomValue.where("custom_field_id = ? AND value >= ? AND value <= ? AND customized_type = ?", cf_id, Date.current, Date.current + days.days, 'Issue').select(:customized_id)
    when 'nd'
      CustomValue.where("custom_field_id = ? AND value = ? AND customized_type = ?", cf_id, Date.current + 1.day, 'Issue').select(:customized_id)
    when 't'
      CustomValue.where("custom_field_id = ? AND value = ? AND customized_type = ?", cf_id, Date.current, 'Issue').select(:customized_id)
    when 'ld'
      CustomValue.where("custom_field_id = ? AND value = ? AND customized_type = ?", cf_id, Date.current - 1.day, 'Issue').select(:customized_id)
    when 'nw'
      start_date = Date.current.beginning_of_week + 1.week
      end_date = Date.current.end_of_week + 1.week
      CustomValue.where("custom_field_id = ? AND value >= ? AND value <= ? AND customized_type = ?", cf_id, start_date, end_date, 'Issue').select(:customized_id)
    when 'w'
      start_date = Date.current.beginning_of_week
      end_date = Date.current.end_of_week
      CustomValue.where("custom_field_id = ? AND value >= ? AND value <= ? AND customized_type = ?", cf_id, start_date, end_date, 'Issue').select(:customized_id)
    when 'lw'
      start_date = Date.current.beginning_of_week - 1.week
      end_date = Date.current.end_of_week - 1.week
      CustomValue where("custom_field_id = ? AND value >= ? AND value <= ? AND customized_type = ?", cf_id, start_date, end_date, 'Issue').select(:customized_id)
    when 'l2w'
      start_date = Date.current.beginning_of_week - 2.weeks
      end_date = Date.current.end_of_week - 1.week
      CustomValue.where("custom_field_id = ? AND value >= ? AND value <= ? AND customized_type = ?", cf_id, start_date, end_date, 'Issue').select(:customized_id)
    when 'nm'
      start_date = Date.current.beginning_of_month + 1.month
      end_date = Date.current.end_of_month + 1.month
      CustomValue.where("custom_field_id = ? AND value >= ? AND value <= ? AND customized_type = ?", cf_id, start_date, end_date, 'Issue').select(:customized_id)
    when 'm'
      start_date = Date.current.beginning_of_month
      end_date = Date.current.end_of_month
      CustomValue.where("custom_field_id = ? AND value >= ? AND value <= ? AND customized_type = ?", cf_id, start_date, end_date, 'Issue').select(:customized_id)
    when 'lm'
      start_date = Date.current.beginning_of_month - 1.month
      end_date = Date.current.end_of_month - 1.month
      CustomValue.where("custom_field_id = ? AND value >= ? AND value <= ? AND customized_type = ?", cf_id, start_date, end_date, 'Issue').select(:customized_id)
    when 'y'
      start_date = Date.current.beginning_of_year
      end_date = Date.current.end_of_year
      CustomValue.where("custom_field_id = ? AND value >= ? AND value <= ? AND customized_type = ?", cf_id, start_date, end_date, 'Issue').select(:customized_id)
    when '>t-'
      days_ago = values.to_i
      start_date = Date.current - days_ago.days
      CustomValue.where("custom_field_id = ? AND value >= ? AND customized_type = ?", cf_id, start_date, 'Issue').select(:customized_id)
    when '<t-'
      days_ago = values.to_i
      start_date = Date.current - days_ago.days
      CustomValue.where("custom_field_id = ? AND value <= ? AND customized_type = ?", cf_id, start_date, 'Issue').select(:customized_id)
    when '><t-'
      end_date = Date.current
      start_date = Date.current - values.to_i.days
      CustomValue.where("custom_field_id = ? AND value >= ? AND value <= ? AND customized_type = ?", cf_id, start_date, end_date, 'Issue').select(:customized_id)
    when 't-'
      days_ago = values.to_i
      start_date = Date.current - days_ago.days
      CustomValue.where("custom_field_id = ? AND value = ? AND customized_type = ?", cf_id, start_date, 'Issue').select(:customized_id)
    when '!*'
      CustomValue.where(custom_field_id: cf_id, customized_type: 'Issue').where.not(value: values).select(:customized_id)
    when '*'
      CustomValue.where(custom_field_id: cf_id, customized_type: 'Issue').select(:customized_id)
    else
      nil
    end
  end

  def handle_text_operator(cf_id, values, operator)
    case operator
    when '='
      CustomValue.where(custom_field_id: cf_id, value: values, customized_type: 'Issue').select(:customized_id)
    when '!'
      CustomValue.where("custom_field_id = ? AND value IS NOT NULL AND value != ? AND customized_type = ?", cf_id, values, 'Issue').select(:customized_id)
    when '!~'
      CustomValue.where("custom_field_id = ? AND value IS NOT NULL AND value NOT LIKE ? AND customized_type = ?", cf_id, "%#{values}%", 'Issue').select(:customized_id)
    when '~'
      CustomValue.where("custom_field_id = ? AND value IS NOT NULL AND value LIKE ? AND customized_type = ?", cf_id, "%#{values}%", 'Issue').select(:customized_id)
    when '^'
      CustomValue.where("custom_field_id = ? AND value IS NOT NULL AND value LIKE ? AND customized_type = ?", cf_id, "#{values}%", 'Issue').select(:customized_id)
    when '$'
      CustomValue.where("custom_field_id = ? AND value IS NOT NULL AND value LIKE ? AND customized_type = ?", cf_id, "%#{values}", 'Issue').select(:customized_id)
    when '!*'
      CustomValue.where(custom_field_id: cf_id, customized_type: 'Issue').where.not(value: values).select(:customized_id)
    when '*'
      CustomValue.where(custom_field_id: cf_id, customized_type: 'Issue').select(:customized_id)
    else
      nil
    end
  end

  def handle_bool_operator(cf_id, values, operator)
    case operator
    when '='
      value = values == '1' ? 'true' : 'false'
      CustomValue.where(custom_field_id: cf_id, value: value, customized_type: 'Issue').select(:customized_id)
    when '!'
      value = values == '1' ? 'true' : 'false'
      CustomValue.where("custom_field_id = ? AND value != ? AND customized_type = ?", cf_id, value, 'Issue').select(:customized_id)
    when '!*'
      CustomValue.where(custom_field_id: cf_id, customized_type: 'Issue').where.not(value: ['true', 'false']).select(:customized_id)
    when '*'
      CustomValue.where(custom_field_id: cf_id, customized_type: 'Issue').select(:customized_id)
    else
      nil
    end
  end

  def handle_version_operator(cf_id, values, operator)
    case operator
    when '='
      CustomValue.where(custom_field_id: cf_id, value: values, customized_type: 'Issue').select(:customized_id)
    when '!'
      CustomValue.where("custom_field_id = ? AND value != ? AND customized_type = ?", cf_id, values, 'Issue').select(:customized_id)
    else
      nil
    end
  end
  


  #Project operators

  def handle_integer_operator(cf_id, values, operator)
    case operator
    when '='
      CustomValue.where(custom_field_id: cf_id, value: values, customized_type: 'Project').select(:customized_id)
    when '>='
      CustomValue.where("custom_field_id = ? AND value >= ? AND customized_type = ?", cf_id, values, 'Project').select(:customized_id)
    when '<='
      CustomValue.where("custom_field_id = ? AND value <= ? AND customized_type = ?", cf_id, values, 'Project').select(:customized_id)
    when '><'
      CustomValue.where("custom_field_id = ? AND value > ? AND value < ? AND customized_type = ?", cf_id, values[0], values[1], 'Project').select(:customized_id)
    else
      nil
    end
  end
  
  def handle_list_operator(cf_id, values, operator)
    case operator
    when '='
      CustomValue.where(custom_field_id: cf_id, value: values, customized_type: 'Project').select(:customized_id)
    when '!'
      CustomValue.where("custom_field_id = ? AND value != ? AND customized_type = ?", cf_id, values, 'Project').select(:customized_id)
    when '!*'
      CustomValue.where(custom_field_id: cf_id, customized_type: 'Project').where.not(value: values).select(:customized_id)
    when '*'
      CustomValue.where(custom_field_id: cf_id, customized_type: 'Project').select(:customized_id)
    else
      nil
    end
  end

    
  def handle_user_operator(cf_id, values, operator)
    case operator
    when '='
      CustomValue.where(custom_field_id: cf_id, value: values, customized_type: 'Project').select(:customized_id)
    when '!'
      CustomValue.where("custom_field_id = ? AND value IS NOT NULL AND value != '' AND customized_type = ?", cf_id, 'Project').select(:customized_id)
    when '!*'
      CustomValue.where(custom_field_id: cf_id, customized_type: 'Project').where.not(value: values).select(:customized_id)
    when '*'
      CustomValue.where(custom_field_id: cf_id, customized_type: 'Project').select(:customized_id)
    else
      nil
    end
  end

  def handle_date_operator(cf_id, values, operator)
    case operator
    when '='
      CustomValue.where(custom_field_id: cf_id, value: values, customized_type: 'Project').select(:customized_id)
    when '>='
      CustomValue.where("custom_field_id = ? AND value >= ? AND customized_type = ?", cf_id, values, 'Project').select(:customized_id)
    when '<='
      CustomValue.where("custom_field_id = ? AND value <= ? AND customized_type = ?", cf_id, values, 'Project').select(:customized_id)
    when '><'
      CustomValue.where("custom_field_id = ? AND value >= ? AND value <= ? AND customized_type = ?", cf_id, values[0], values[1], 'Project').select(:customized_id)
    when '<t+'
      days = values.to_i
      CustomValue.where("custom_field_id = ? AND value >= ? AND customized_type = ?", cf_id, Date.current, 'Project').select(:customized_id)
    when '>t+'
      days = values.to_i
      CustomValue.where("custom_field_id = ? AND value >= ? AND customized_type = ?", cf_id, Date.current + days.days, 'Project').select(:customized_id)
    when '><t+'
      days = values.to_i
      CustomValue.where("custom_field_id = ? AND value >= ? AND value <= ? AND customized_type = ?", cf_id, Date.current, Date.current + days.days, 'Project').select(:customized_id)
    when 't+'
      days = values.to_i
      CustomValue.where("custom_field_id = ? AND value >= ? AND value <= ? AND customized_type = ?", cf_id, Date.current, Date.current + days.days, 'Project').select(:customized_id)
    when 'nd'
      CustomValue.where("custom_field_id = ? AND value = ? AND customized_type = ?", cf_id, Date.current + 1.day, 'Project').select(:customized_id)
    when 't'
      CustomValue.where("custom_field_id = ? AND value = ? AND customized_type = ?", cf_id, Date.current, 'Project').select(:customized_id)
    when 'ld'
      CustomValue.where("custom_field_id = ? AND value = ? AND customized_type = ?", cf_id, Date.current - 1.day, 'Project').select(:customized_id)
    when 'nw'
      start_date = Date.current.beginning_of_week + 1.week
      end_date = Date.current.end_of_week + 1.week
      CustomValue.where("custom_field_id = ? AND value >= ? AND value <= ? AND customized_type = ?", cf_id, start_date, end_date, 'Project').select(:customized_id)
    when 'w'
      start_date = Date.current.beginning_of_week
      end_date = Date.current.end_of_week
      CustomValue.where("custom_field_id = ? AND value >= ? AND value <= ? AND customized_type = ?", cf_id, start_date, end_date, 'Project').select(:customized_id)
    when 'lw'
      start_date = Date.current.beginning_of_week - 1.week
      end_date = Date.current.end_of_week - 1.week
      CustomValue where("custom_field_id = ? AND value >= ? AND value <= ? AND customized_type = ?", cf_id, start_date, end_date, 'Project').select(:customized_id)
    when 'l2w'
      start_date = Date.current.beginning_of_week - 2.weeks
      end_date = Date.current.end_of_week - 1.week
      CustomValue.where("custom_field_id = ? AND value >= ? AND value <= ? AND customized_type = ?", cf_id, start_date, end_date, 'Project').select(:customized_id)
    when 'nm'
      start_date = Date.current.beginning_of_month + 1.month
      end_date = Date.current.end_of_month + 1.month
      CustomValue.where("custom_field_id = ? AND value >= ? AND value <= ? AND customized_type = ?", cf_id, start_date, end_date, 'Project').select(:customized_id)
    when 'm'
      start_date = Date.current.beginning_of_month
      end_date = Date.current.end_of_month
      CustomValue.where("custom_field_id = ? AND value >= ? AND value <= ? AND customized_type = ?", cf_id, start_date, end_date, 'Project').select(:customized_id)
    when 'lm'
      start_date = Date.current.beginning_of_month - 1.month
      end_date = Date.current.end_of_month - 1.month
      CustomValue.where("custom_field_id = ? AND value >= ? AND value <= ? AND customized_type = ?", cf_id, start_date, end_date, 'Project').select(:customized_id)
    when 'y'
      start_date = Date.current.beginning_of_year
      end_date = Date.current.end_of_year
      CustomValue.where("custom_field_id = ? AND value >= ? AND value <= ? AND customized_type = ?", cf_id, start_date, end_date, 'Project').select(:customized_id)
    when '>t-'
      days_ago = values.to_i
      start_date = Date.current - days_ago.days
      CustomValue.where("custom_field_id = ? AND value >= ? AND customized_type = ?", cf_id, start_date, 'Project').select(:customized_id)
    when '<t-'
      days_ago = values.to_i
      start_date = Date.current - days_ago.days
      CustomValue.where("custom_field_id = ? AND value <= ? AND customized_type = ?", cf_id, start_date, 'Project').select(:customized_id)
    when '><t-'
      end_date = Date.current
      start_date = Date.current - values.to_i.days
      CustomValue.where("custom_field_id = ? AND value >= ? AND value <= ? AND customized_type = ?", cf_id, start_date, end_date, 'Project').select(:customized_id)
    when 't-'
      days_ago = values.to_i
      start_date = Date.current - days_ago.days
      CustomValue.where("custom_field_id = ? AND value = ? AND customized_type = ?", cf_id, start_date, 'Project').select(:customized_id)
    when '!*'
      CustomValue.where(custom_field_id: cf_id, customized_type: 'Project').where.not(value: values).select(:customized_id)
    when '*'
      CustomValue.where(custom_field_id: cf_id, customized_type: 'Project').select(:customized_id)
    else
      nil
    end
  end

  def handle_text_operator(cf_id, values, operator)
    case operator
    when '='
      CustomValue.where(custom_field_id: cf_id, value: values, customized_type: 'Project').select(:customized_id)
    when '!'
      CustomValue.where("custom_field_id = ? AND value IS NOT NULL AND value != ? AND customized_type = ?", cf_id, values, 'Project').select(:customized_id)
    when '!~'
      CustomValue.where("custom_field_id = ? AND value IS NOT NULL AND value NOT LIKE ? AND customized_type = ?", cf_id, "%#{values}%", 'Project').select(:customized_id)
    when '~'
      CustomValue.where("custom_field_id = ? AND value IS NOT NULL AND value LIKE ? AND customized_type = ?", cf_id, "%#{values}%", 'Project').select(:customized_id)
    when '^'
      CustomValue.where("custom_field_id = ? AND value IS NOT NULL AND value LIKE ? AND customized_type = ?", cf_id, "#{values}%", 'Project').select(:customized_id)
    when '$'
      CustomValue.where("custom_field_id = ? AND value IS NOT NULL AND value LIKE ? AND customized_type = ?", cf_id, "%#{values}", 'Project').select(:customized_id)
    when '!*'
      CustomValue.where(custom_field_id: cf_id, customized_type: 'Project').where.not(value: values).select(:customized_id)
    when '*'
      CustomValue.where(custom_field_id: cf_id, customized_type: 'Project').select(:customized_id)
    else
      nil
    end
  end

  def handle_bool_operator(cf_id, values, operator)
    case operator
    when '='
      value = values == '1' ? 'true' : 'false'
      CustomValue.where(custom_field_id: cf_id, value: value, customized_type: 'Project').select(:customized_id)
    when '!'
      value = values == '1' ? 'true' : 'false'
      CustomValue.where("custom_field_id = ? AND value != ? AND customized_type = ?", cf_id, value, 'Project').select(:customized_id)
    when '!*'
      CustomValue.where(custom_field_id: cf_id, customized_type: 'Project').where.not(value: ['true', 'false']).select(:customized_id)
    when '*'
      CustomValue.where(custom_field_id: cf_id, customized_type: 'Project').select(:customized_id)
    else
      nil
    end
  end

  def handle_version_operator(cf_id, values, operator)
    case operator
    when '='
      CustomValue.where(custom_field_id: cf_id, value: values, customized_type: 'Project').select(:customized_id)
    when '!'
      CustomValue.where("custom_field_id = ? AND value != ? AND customized_type = ?", cf_id, values, 'Project').select(:customized_id)
    else
      nil
    end
  end
  
  #End project operators

  def apply_date_filter(query, operator, values)
    start_date = end_date = nil 
    case operator
    when '='
      start_date = values[0]
      end_date = values[0]
      query = query.where('spent_on = ?', values[0])
    when '>='
      start_date = values[0]
      end_date = values[0]
      query = query.where('spent_on >= ?', values[0])
    when '<='
      start_date = values[0]
      end_date = values[0]
      query = query.where('spent_on <= ?', values[0])
    when '><'
      start_date = values[0]
      end_date = values[1]
      query = query.where('spent_on >= ? AND spent_on <= ?', values[0], values[1])
    when '>t-'
      days_ago = values[0].to_i
      start_date = Date.current - days_ago.days
      end_date = Date.current - days_ago.days
      query = query.where('spent_on >= ?', start_date)
    when '<t-'
      days_ago = values[0].to_i
      start_date = Date.current - days_ago.days
      end_date = Date.current - days_ago.days
      query = query.where('spent_on <= ?', end_date)
    when 't-'
      days_ago = values[0].to_i
      end_date = Date.current - days_ago
      start_date = end_date - (days_ago - 1).days
      query = query.where('spent_on >= ? AND spent_on <= ?', start_date, end_date)
    when '><t-'
      days_ago = values[0].to_i
      end_date = Date.current
      start_date = end_date - days_ago.days
      query = query.where('spent_on >= ? AND spent_on <= ?', start_date, end_date)
    when 't'
      start_date = Date.current
      end_date = Date.current
      query = query.where('spent_on = ?', Date.current)
    when 'ld'
      start_date =  Date.current - 1.day
      end_date =  Date.current - 1.day
      query = query.where('spent_on = ?', Date.current - 1.day)
    when 'w'
      start_date = Date.current.beginning_of_week
      end_date = Date.current.end_of_week
      query = query.where('spent_on >= ? AND spent_on <= ?', start_date, end_date)
    when 'lw'
      last_week_start_date = (Date.current - 1.week).beginning_of_week
      last_week_end_date = (Date.current - 1.week).end_of_week

      start_date = last_week_start_date
      end_date = last_week_end_date
      query = query.where('spent_on >= ? AND spent_on <= ?', last_week_start_date, last_week_end_date)
    when 'l2w'
      two_weeks_ago_start_date = (Date.current - 2.weeks).beginning_of_week
      last_week_end_date = (Date.current - 1.week).end_of_week

      start_date = two_weeks_ago_start_date
      end_date = last_week_end_date
      query = query.where('spent_on >= ? AND spent_on <= ?', two_weeks_ago_start_date, last_week_end_date)
    when 'm'
      start_date = Date.current.beginning_of_month
      end_date = Date.current.end_of_month
      query = query.where('spent_on >= ? AND spent_on <= ?', start_date, end_date)
    when 'lm'
      last_month_start_date = (Date.current - 1.month).beginning_of_month
      last_month_end_date = (Date.current - 1.month).end_of_month

      start_date = last_month_start_date
      end_date = last_month_end_date

      query = query.where('spent_on >= ? AND spent_on <= ?', last_month_start_date, last_month_end_date)
    when 'y'
      start_date = Date.current.beginning_of_year
      end_date = Date.current.end_of_year
      query = query.where('spent_on >= ? AND spent_on <= ?', start_date, end_date)
    when '!*'
      query = query.where(spent_on: nil)
    when '*'
      query
    else
     
    end
  
    return query, start_date, end_date
  end

  #Submit timesheet date range
  def apply_start_end_date_filter(query, operator, values)
    start_date = end_date = nil
    case operator
    when '='
      start_date = values[0]
      end_date = values[0]
      query = query.where('start_date = ? AND end_date = ?', values[0], values[0])
    when '>='
      start_date = values[0]
      end_date = values[0]
      query = query.where('start_date >= ?', values[0])
    when '<='
      start_date = values[0]
      end_date = values[0]
      query = query.where('end_date <= ?', values[0])
    when '><'
      start_date = values[0]
      end_date = values[1]
      query = query.where('start_date >= ? AND end_date <= ?', values[0], values[1])
    when '>t-'
      days_ago = values[0].to_i
      start_date = Date.current - days_ago.days
      end_date = Date.current - days_ago.days
      query = query.where('start_date >= ?', start_date)
    when '<t-'
      days_ago = values[0].to_i
      start_date = Date.current - days_ago.days
      end_date = Date.current - days_ago.days
      query = query.where('end_date <= ?', end_date)
    when 't-'
      days_ago = values[0].to_i
      end_date = Date.current - days_ago
      start_date = end_date - (days_ago - 1).days
      query = query.where('start_date >= ? AND end_date <= ?', start_date, end_date)
    when '><t-'
      days_ago = values[0].to_i
      end_date = Date.current
      start_date = end_date - days_ago.days
      query = query.where('start_date >= ? AND end_date <= ?', start_date, end_date)
    when 't'
      start_date = Date.current
      end_date = Date.current
      query = query.where('start_date = ? AND end_date = ?', Date.current, Date.current)
    when 'ld'
      start_date = Date.current - 1.day
      end_date = Date.current - 1.day
      query = query.where('start_date = ? AND end_date = ?', Date.current - 1.day, Date.current - 1.day)
    when 'w'
      start_date = Date.current.beginning_of_week
      end_date = Date.current.end_of_week
      query = query.where('start_date >= ? AND end_date <= ?', start_date, end_date)
    when 'lw'
      last_week_start_date = (Date.current - 1.week).beginning_of_week
      last_week_end_date = (Date.current - 1.week).end_of_week
      start_date = last_week_start_date
      end_date = last_week_end_date
      query = query.where('start_date >= ? AND end_date <= ?', last_week_start_date, last_week_end_date)
    when 'l2w'
      two_weeks_ago_start_date = (Date.current - 2.weeks).beginning_of_week
      last_week_end_date = (Date.current - 1.week).end_of_week
      start_date = two_weeks_ago_start_date
      end_date = last_week_end_date
      query = query.where('start_date >= ? AND end_date <= ?', two_weeks_ago_start_date, last_week_end_date)
    when 'm'
      start_date = Date.current.beginning_of_month
      end_date = Date.current.end_of_month
      query = query.where('start_date >= ? AND end_date <= ?', start_date, end_date)
    when 'lm'
      last_month_start_date = (Date.current - 1.month).beginning_of_month
      last_month_end_date = (Date.current - 1.month).end_of_month
      start_date = last_month_start_date
      end_date = last_month_end_date
      query = query.where('start_date >= ? AND end_date <= ?', last_month_start_date, last_month_end_date)
    when 'y'
      start_date = Date.current.beginning_of_year
      end_date = Date.current.end_of_year
      query = query.where('start_date >= ? AND end_date <= ?', start_date, end_date)
    when '!*'
      query = query.where('start_date IS NULL AND end_date IS NULL')
    when '*'
      query
    else
      query
    end
  
    return query, start_date, end_date
  end


  def apply_user_filter(query, operator, values)
    
    case operator
    when '='
      query.where(user_id: values)
    when '!'
        user_ids_to_exclude = values 
        remaining_user_ids = User.active.where.not(id: user_ids_to_exclude).pluck(:id)
        query.where(user_id: remaining_user_ids)
    when '!*'
      query.where.not(user_id: values)
    when '*'
      all_active_user_ids = User.active.pluck(:id)
      query.where(user_id: all_active_user_ids)
    else
      query
    end
  end

  def apply_author_filter(query, operator, values)
    
    case operator
    when '='
      query.where(author_id: values)
    when '!'
        user_ids_to_exclude = values 
        remaining_user_ids = User.active.where.not(id: user_ids_to_exclude).pluck(:id)
        query.where(author_id: remaining_user_ids)
    when '!*'
      query.where.not(author_id: values)
    when '*'
      all_active_user_ids = User.active.pluck(:id)
      query.where(author_id: all_active_user_ids)
    else
      query
    end
  end

  def apply_project_filter(query, operator, values)
    
    case operator
    when '='
      query.where(project_id: values)
    when '!'
      project_ids_to_exclude = values 
      remaining_project_ids = Project.active.where.not(id: project_ids_to_exclude).pluck(:id)
      query.where(project_id: remaining_project_ids)
    else
      query
    end
  end

  def apply_comment_filter(query, operator, values)
    case operator
    when '~'
      query.where('comments LIKE ?', "%#{values[0]}%")
    when '!~'
      query.where.not('comments LIKE ?', "%#{values[0]}%")
    when '^'
      query.where('comments LIKE ?', "#{values[0]}%")
    when '$'
      query.where('comments LIKE ?', "%#{values[0]}")
    when '!*'
      query.where(comments: '')
    when '*'
      query.where.not(comments: nil)
    else
      query
    end
  end


  def apply_issues_filter(query, operator, values)

    case operator
    when '='
      query.where(issue_id: values)
    when '~'
      query.where("CAST(issue_id AS TEXT) ILIKE ?", "%#{values[0]}%")
    when '!*'
      query.where.not(issue_id: values)
    when '*'
      query
    else
      query
    end
  end

  def apply_activity_filter(query, operator, values)
    case operator
    when '='
      query.where(activity_id: values)
    when '!'
      excluded_ids = values
      remaining_ids = Enumeration.where(type: "TimeEntryActivity").where.not(id: excluded_ids).pluck(:id)
      query.where(activity_id: remaining_ids)
    else
      query 
    end
  end


  def apply_hours_filter(query, operator, values)
    case operator
    when '='
      query.where(hours: values)
    when '>='
      query.where('hours >= ?', values)
    when '<='
      query.where('hours <= ?', values)
    when '><'
      query.where(hours: values[0]..values[1])
    when '!*'
      query.none
    when '*'
      query
    else
      query
    end
  end

  def apply_issue_tracker_filter(query, operator, values)
    case operator
    when '='
      query.joins(:issue).where(issues: { tracker_id: values })
    when '!'
      excluded_ids = values
      remaining_ids = Issue.where.not(tracker_id: excluded_ids).pluck(:tracker_id)
      query.joins(:issue).where(issues: { tracker_id: remaining_ids })
    else
      query
    end
  end
  
  def apply_issue_status_filter(query, operator, values)
    case operator
    when '='
      query.joins(:issue).where(issues: { status_id: values })
    when '!'
      excluded_ids = values
      remaining_ids = Issue.where.not(status_id: excluded_ids).pluck(:status_id)
      query.joins(:issue).where(issues: { status_id: remaining_ids })
    else
      query
    end
  end
  
  def apply_issue_target_version_filter(query, operator, values)
    case operator
    when '='
      query.joins(:issue).where(issues: { fixed_version_id: values })
    when '!'
      excluded_ids = values
      remaining_ids = Issue.where.not(fixed_version_id: excluded_ids).pluck(:fixed_version_id)
      query.joins(:issue).where(issues: { fixed_version_id: remaining_ids })
    else
      query
    end
  end

  def apply_project_status_filter(query, operator, values)
    case operator
    when '='
      query.joins(issue: :project).where(projects: { status: values })
    when '!'
      excluded_ids = values
      excluded_ids << 9  
      remaining_ids = Project.where.not(status: excluded_ids).distinct.pluck(:status)
      query.joins(issue: :project).where(projects: { status: remaining_ids })
    else
      query
    end
  end
  
  def timesheet_query_params
    params.require(:timesheet_query).permit(:filters , :user_id)
  end
  
end