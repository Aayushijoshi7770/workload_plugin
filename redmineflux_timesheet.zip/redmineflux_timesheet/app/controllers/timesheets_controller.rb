class TimesheetsController < ApplicationController
  before_action :require_login
  accept_api_auth :users_timesheet, :assigned_issues, :search_users, :submit_timesheet, :total_spent_time, :timesheet_issues, :timesheet_permissions, :timesheet_team, :team_total_spent_time, :update_dropdown_preference
 
  

  def index
    User.where(timesheet_color: nil).find_each do |user|
      user.update_columns(timesheet_color: random_light_color)
    end
    current_user = User.current.id
    @preference = TimesheetDropdownPreference.where(user_id: User.current.id).first_or_create(selected_option: "collapse").selected_option

    @required_spent_hours = Setting.plugin_redmineflux_timesheet['required_spent_hours'] ? format_hours(Setting.plugin_redmineflux_timesheet['required_spent_hours'].to_f) : format_hours(8.50.to_f)
  end

  def team_total_spent_time
    @start_date = params[:start_date]
    @due_date = params[:due_date]
    @team_id = params[:team_id]


    if (@start_date.present? && @due_date.present? && @team_id.present?)
      @team = Team.find(@team_id)
      @child_team = Team.find_by(parent_id: @team.id)
      if  @child_team.present? 
        @team_members = @child_team.users.ids
        # Get users from the selected team
        @team_members += @team.users.ids
        # Get users from all subteams recursively
        def get_subteam_users(team)
          subteam_users = []
          subteams = Team.where(parent_id: team.id)
          subteams.each do |subteam|
            subteam_users += subteam.users.ids
            subteam_users += get_subteam_users(subteam)
          end
          subteam_users
        end
      
        @team_members += get_subteam_users(@team)
      else
        @team_members = @team.users.ids
      end
      
      @team_members.uniq!

      if show_unassigned_issues_configured?
        # @total_hours = TimeEntry.joins(issue: :project).joins('LEFT OUTER JOIN enumerations ON time_entries.activity_id = enumerations.id')
        # .select('time_entries.activity_id, SUM(time_entries.hours) AS hours, enumerations.name AS name')
        # .where('time_entries.spent_on BETWEEN ? AND ? AND time_entries.user_id IN (?)', @start_date, @due_date, @team_members)
        # .where(issues: { assigned_to_id: @team_members })
        # .group('time_entries.activity_id, enumerations.name')
        # .limit(3) 
    
        @total_hours = TimeEntry.joins(:issue)
        .joins(:project)
        .joins('LEFT OUTER JOIN enumerations ON time_entries.activity_id = enumerations.id')
        .select('time_entries.activity_id, SUM(time_entries.hours) AS hours, enumerations.name AS name')
        .where(spent_on: @start_date..@due_date, user_id: @team_members)
        .group('time_entries.activity_id, enumerations.name')
        .limit(3)

      else 
        @total_hours = TimeEntry.joins(issue: :project).joins('LEFT OUTER JOIN enumerations ON time_entries.activity_id = enumerations.id')
        .select('time_entries.activity_id, SUM(time_entries.hours) AS hours, enumerations.name AS name')
        .where('time_entries.spent_on BETWEEN ? AND ? AND time_entries.user_id = issues.assigned_to_id', @start_date, @due_date)
        .where(issues: { assigned_to_id: @team_members })
        .group('time_entries.activity_id, enumerations.name')
        .limit(3) 
      end 

      # @total_time = @total_hours.map { |issue| { name: issue.name, hours: format_hours(issue.hours) } }
      # @total_time.push({ name: 'Total', hours: format_hours(@total_hours.sum { |order| order.hours }) })
      if @total_hours.sum { |order| order.hours }.zero?
        @total_time = []
      else
        @total_time = @total_hours.map { |issue| { name: issue.name, hours: format_hours(issue.hours) } }
        @total_time.push({ name: 'Total', hours: format_hours(@total_hours.sum { |order| order.hours }) })

      end

     
      render json:  @total_time
    else  
      render :json => :unprocessable_entity
    end 
  end 


  def total_spent_time
   
    @start_date = params[:start_date]
    @due_date = params[:due_date]
    @user_id=params[:user_id]
    if(@start_date.present? && @due_date.present? && @user_id.present?) 

      if show_unassigned_issues_configured?
        puts "Unassigned Issues Configured"
        # @total_hours = TimeEntry.joins(:issue).joins("LEFT OUTER JOIN enumerations ON time_entries.activity_id = enumerations.id").select(" time_entries.activity_id, SUM(time_entries.hours) AS hours, enumerations.name AS name ").where("(time_entries.spent_on BETWEEN ? AND ?) ", @start_date, @due_date).where("time_entries.user_id = ? OR issues.assigned_to_id = ?", User.current.id, User.current.id).group("time_entries.activity_id, enumerations.name ").limit(3).to_a
        @total_hours = TimeEntry.joins(:issue)
                        .joins("LEFT OUTER JOIN enumerations ON time_entries.activity_id = enumerations.id")
                        .select("time_entries.activity_id, SUM(time_entries.hours) AS hours, enumerations.name AS name")
                        .where("(time_entries.spent_on BETWEEN ? AND ?) AND time_entries.user_id = ?", @start_date, @due_date,  @user_id)
                        .group("time_entries.activity_id, enumerations.name")
                        .limit(3)
                        .to_a
      else 
        puts "Unassigned Issues Not Configured"
        @total_hours = TimeEntry.joins(:issue).joins("LEFT OUTER JOIN enumerations ON time_entries.activity_id = enumerations.id").select(" time_entries.activity_id, SUM(time_entries.hours) AS hours, enumerations.name AS name ").where("(time_entries.spent_on BETWEEN ? AND ?) AND issues.assigned_to_id IN (?) AND time_entries.user_id = issues.assigned_to_id", @start_date, @due_date, @user_id).group("time_entries.activity_id, enumerations.name ").limit(3).to_a 
      end  

      # @total_time = @total_hours.map { |issue| { name: issue.name, hours: format_hours(issue.hours) } }
      # @total_time.push({ name: 'Total', hours: format_hours(@total_hours.sum { |order| order.hours }) })
      if @total_hours.sum { |order| order.hours }.zero?
        @total_time = []
      else
       @total_time = @total_hours.map { |issue| { name: issue.name, hours: format_hours(issue.hours) } }
       @total_time.push({ name: 'Total', hours: format_hours(@total_hours.sum { |order| order.hours }) })
 
      end
      # render json: @total_time
      render json: { total_time: @total_time}
    else  
      render json: :unprocessable_entity
    end 

  end 

  def show
    
  end 

  
  def random_light_color
    red = SecureRandom.hex(1)
    green = SecureRandom.hex(1)
    blue = SecureRandom.hex(1)
    color = "#" + red + green + blue
    color = random_light_color if color_brightness(color) < 100
    color
  end
  
  def color_brightness(color)
    hex = color.gsub("#", "")
    brightness = (0.299*hex[0..1].hex + 0.587*hex[2..3].hex + 0.114*hex[4..5].hex)
    brightness
  end
  
  def users_timesheet
    @start_date = params[:start_date]
    @due_date = params[:due_date]
    @user_id=params[:user_id]
    page = params[:page] || 1
    per_page = params[:per_page] || 25

    if (@start_date.present? && @due_date.present? && @user_id.present?)
      
      @all_time_entries = {}  

      @users = User.where(:id =>  @user_id, :status=>1, :type=>"User")
      # @users_issues = Issue.joins("LEFT JOIN time_entries ON issues.id = time_entries.issue_id").joins("LEFT JOIN enumerations ON time_entries.activity_id = enumerations.id").joins("LEFT JOIN trackers ON issues.tracker_id = trackers.id").joins("LEFT JOIN users ON issues.assigned_to_id = users.id").select("issues.*, CONCAT(users.firstname, ' ', users.lastname) AS user_name, issues.assigned_to_id, issues.subject AS text, time_entries.id AS time_entry_id, time_entries.hours, time_entries.comments, time_entries.project_id AS project, time_entries.user_id AS user, time_entries.issue_id AS issue, time_entries.activity_id AS activity, time_entries.spent_on, time_entries.author_id, enumerations.id AS activity_id, enumerations.name AS activity_name, trackers.name AS trackers_name").where("time_entries.issue_id = issues.id AND time_entries.spent_on BETWEEN ? AND ?", @start_date, @due_date).where("issues.assigned_to_id IN (?)", @users.ids).order("time_entries.created_on DESC")
      # @users_issues =  Issue.joins("LEFT JOIN time_entries ON issues.id = time_entries.issue_id").joins("LEFT JOIN enumerations ON time_entries.activity_id = enumerations.id")
      #   .joins("LEFT JOIN trackers ON issues.tracker_id = trackers.id")
      #   .joins("LEFT JOIN users ON issues.assigned_to_id = users.id")
      #   .select("issues.*, users.firstname || ' ' || users.lastname AS user_name, issues.assigned_to_id, issues.subject AS text, time_entries.id AS time_entry_id, time_entries.hours, time_entries.comments, time_entries.project_id AS project, time_entries.user_id AS user, time_entries.issue_id AS issue, time_entries.activity_id AS activity, time_entries.spent_on, time_entries.author_id, enumerations.id AS activity_id, enumerations.name AS activity_name, trackers.name AS trackers_name")
      #   .where("time_entries.issue_id = issues.id AND time_entries.spent_on BETWEEN ? AND ?", @start_date, @due_date)
      #   .where("issues.assigned_to_id IN (?)", @users.ids)
      #   .order("time_entries.created_on DESC")
        @users_issues =  Issue.joins("LEFT JOIN time_entries ON issues.id = time_entries.issue_id").joins("LEFT JOIN enumerations ON time_entries.activity_id = enumerations.id")
          .joins("LEFT JOIN trackers ON issues.tracker_id = trackers.id")
          .joins("LEFT JOIN users ON issues.assigned_to_id = users.id")
          .joins("LEFT JOIN projects ON issues.project_id = projects.id") # Add this line
          .select("issues.*, users.firstname || ' ' || users.lastname AS user_name, issues.assigned_to_id, issues.subject AS text, time_entries.id AS time_entry_id, time_entries.hours, time_entries.comments, time_entries.project_id AS project, time_entries.user_id AS user, time_entries.issue_id AS issue, time_entries.activity_id AS activity, time_entries.spent_on, time_entries.author_id, enumerations.id AS activity_id, enumerations.name AS activity_name, trackers.name AS trackers_name")
          .where("time_entries.issue_id = issues.id AND time_entries.spent_on BETWEEN ? AND ?", @start_date, @due_date)
          .where("issues.assigned_to_id IN (?) AND time_entries.user_id = issues.assigned_to_id", @users.ids)
          .where("projects.status = ?", 1)
          .order("time_entries.created_on DESC").paginate(page: page, per_page: per_page)
      @issues = @users_issues.map{|issue| {id: issue.id, activity: issue.activity, time_format: Setting.timespan_format, parent: issue.assigned_to_id.present? ? issue.assigned_to_id : " ", user:issue.assigned_to_id.present? ? issue.assigned_to_id : " ", done_ratio: issue.done_ratio, lock_version: issue.lock_version, parent_id: issue.assigned_to_id.present? ? issue.assigned_to_id : " ", time_entry_id: issue.time_entry_id, category: issue.category, text: issue.subject, spent_on: issue.spent_on, trackers_name: issue.tracker.name, user_name: issue.assigned_to.name, activity_name: issue.activity_name, activity_id: issue.activity_id,  comments: issue.comments, hours: format_hours(issue.hours), estimated_hours: format_hours(issue.estimated_hours), tracker: issue.tracker_id, project: issue.project, subject: issue.subject, start_date: issue.start_date, due_date: issue.due_date, status: issue.status_id, assigned_to_id: issue.assigned_to_id, priority_id: issue.priority_id, author_id: issue.author_id }}
      spent_hours_sum = @users_issues.sum { |entry| entry[:hours].to_f }.round(2)
      # @issues_with_logtime = Issue.joins("LEFT JOIN time_entries ON issues.id = time_entries.issue_id").joins("LEFT JOIN enumerations ON time_entries.activity_id = enumerations.id").joins("LEFT JOIN trackers ON issues.tracker_id = trackers.id").joins("LEFT JOIN users ON issues.assigned_to_id = users.id").select("issues.*, CONCAT(users.firstname, ' ', users.lastname) AS user_name, issues.assigned_to_id, issues.subject AS text, time_entries.id AS time_entry_id, time_entries.user_id AS timelog_user_id, time_entries.hours, time_entries.comments, time_entries.project_id AS project, time_entries.user_id AS user, time_entries.issue_id AS issue, time_entries.activity_id AS activity, time_entries.spent_on, time_entries.author_id, enumerations.id AS activity_id, enumerations.name AS activity_name, trackers.name AS trackers_name").where("time_entries.issue_id = issues.id AND time_entries.spent_on BETWEEN ? AND ?", @start_date, @due_date).where("time_entries.user_id IN (?)", User.current.id).order("time_entries.created_on DESC")
      @issues_with_logtime = Issue.joins("LEFT JOIN time_entries ON issues.id = time_entries.issue_id").joins("LEFT JOIN enumerations ON time_entries.activity_id = enumerations.id")
          .joins("LEFT JOIN trackers ON issues.tracker_id = trackers.id")
          .joins("LEFT JOIN users ON issues.assigned_to_id = users.id")
          .joins("LEFT JOIN projects ON issues.project_id = projects.id")
          .select("issues.*, users.firstname || ' ' || users.lastname AS user_name, issues.assigned_to_id, issues.subject AS text, time_entries.id AS time_entry_id, time_entries.user_id AS timelog_user_id, time_entries.hours, time_entries.comments, time_entries.project_id AS project, time_entries.user_id AS user, time_entries.issue_id AS issue, time_entries.activity_id AS activity, time_entries.spent_on, time_entries.author_id, enumerations.id AS activity_id, enumerations.name AS activity_name, trackers.name AS trackers_name")
          .where("time_entries.issue_id = issues.id AND time_entries.spent_on BETWEEN ? AND ?", @start_date, @due_date)
          .where("time_entries.user_id IN (?)",  @user_id)
          .where("projects.status = ?", 1)
          .order("time_entries.created_on DESC").paginate(page: page, per_page: per_page)
      @update_issues_response =  @issues_with_logtime.map{|issue| {id: issue.id, user:issue.timelog_user_id,  parent: issue.timelog_user_id, activity: issue.activity, time_format: Setting.timespan_format, done_ratio: issue.done_ratio, lock_version: issue.lock_version, parent_id: issue.timelog_user_id, time_entry_id: issue.time_entry_id, text: issue.subject, spent_on: issue.spent_on, category: issue.category,  trackers_name: issue.tracker.name, user_name: issue.assigned_to.present? ? issue.assigned_to.name : " ", activity_name: issue.activity_name, activity_id: issue.activity_id,  comments: issue.comments, hours: format_hours(issue.hours), estimated_hours: format_hours(issue.estimated_hours), tracker: issue.tracker_id, project: issue.project, subject: issue.subject, start_date: issue.start_date, due_date: issue.due_date, status: issue.status_id, assigned_to_id: issue.assigned_to_id, priority_id: issue.priority_id, author_id: issue.author_id }}
    
      if show_unassigned_issues_configured?
        # @data = @users.map{|f| {:id => f.id, :color =>f.timesheet_color, time_format: Setting.timespan_format, :parent=>0, :text=> f.firstname + " " + f.lastname,  :type=>"project", :user_id=>f.id, :login => f.login ,  :firstname => f.firstname, :lastname => f.lastname, :admin => f.admin,:created_on => f.created_on,  :updated_on => f.updated_on, :spent_hours =>format_hours(@issues_with_logtime.where("time_entries.user_id = ? OR assigned_to_id = ?", f.id, f.id).sum(:hours).round(2)), :estimated_hours => format_hours(Issue.joins("LEFT JOIN time_entries ON issues.id = time_entries.issue_id").where("time_entries.issue_id = issues.id AND assigned_to_id =?", f.id).sum("issues.estimated_hours").round(2))}} + @issues + @update_issues_response
        @data = @users.map{|f| {:id => f.id, :color =>f.timesheet_color, time_format: Setting.timespan_format, :parent=>0, :text=> f.firstname + " " + f.lastname,  :type=>"project", :user_id=>f.id, :login => f.login ,  :firstname => f.firstname, :lastname => f.lastname, :admin => f.admin,:created_on => f.created_on,  :updated_on => f.updated_on, :spent_hours =>format_hours(@issues_with_logtime.where("time_entries.user_id = ? OR issues.assigned_to_id = ?", f.id, f.id).sum { |entry| entry[:hours].to_f }), :estimated_hours => format_hours(Issue.joins("LEFT JOIN time_entries ON issues.id = time_entries.issue_id").where("time_entries.issue_id = issues.id AND assigned_to_id =?", f.id).sum("issues.estimated_hours").round(2))}} + @update_issues_response
      else 
        @data = @users.map{|f| {:id => f.id, :color =>f.timesheet_color, time_format: Setting.timespan_format, :parent=>0, :text=> f.firstname + " " + f.lastname,  :type=>"project", :user_id=>f.id, :login => f.login ,  :firstname => f.firstname, :lastname => f.lastname, :admin => f.admin,:created_on => f.created_on,  :updated_on => f.updated_on, :spent_hours =>format_hours(@users_issues.where(assigned_to_id: f.id).sum { |entry| entry[:hours].to_f }.round(2)), :estimated_hours => format_hours(Issue.joins("LEFT JOIN time_entries ON issues.id = time_entries.issue_id").where("time_entries.issue_id = issues.id AND assigned_to_id =?", f.id).sum("issues.estimated_hours").round(2))}} + @issues 
      end 
      
      @all_time_entries[:data] = @data.uniq
      @all_time_entries[:users] = @users
     

      respond_to do |format|
        format.api do
          pagination = if show_unassigned_issues_configured?
                         { total_pages: @issues_with_logtime.total_pages, total_entries: @issues_with_logtime.total_entries }
                       else
                         { total_pages: @users_issues.total_pages, total_entries: @users_issues.total_entries }
                       end
      
          render json: { data: @all_time_entries[:data], users: @all_time_entries[:users], pagination: pagination }
        end 
      end
    else 
      render json: :unprocessable_entity
    end 
  
  end
 
  def assigned_issues
    @user_id = params[:user_id]
    if @user_id.present?
      if show_unassigned_issues_configured? 
        @issues = Issue.where(:closed_on => nil).order("created_on DESC").limit(25)
      else  
        @issues = Issue.where(:assigned_to_id => @user_id, :closed_on => nil).order("created_on DESC").limit(25)
      end 
      respond_to do |format|
        format.api { render :json => @issues}
      end 
    end 
    rescue ActiveRecord::RecordNotFound
      render 404
  end 

  def timesheet_issues 
    @id = params[:user_id]
    @parameter  = params[:parameter]
    if @id.present? && @parameter.present? 
      @str = @parameter.to_s
        respond_to do |format|
          if show_unassigned_issues_configured?
            if @str =~ /\d/
              @issues = Issue.where(:id => @str.to_i).where(:closed_on => nil).order("created_on DESC")
              format.api{ render :json => @issues}
            else 
              @issues = Issue.where("lower(subject) LIKE ?" ,"%#{@str.downcase}%").where(:closed_on => nil).order("created_on DESC")
              format.api{ render :json => @issues}
            end 
          else  
            if @str =~ /\d/
              @issues = Issue.where(:id => @str.to_i).where(:assigned_to_id => @id.to_i).where(:closed_on => nil).order("created_on DESC")
              format.api{ render :json => @issues}
            else 
              @issues = Issue.where("lower(subject) LIKE ?" ,"%#{@str.downcase}%").where(:assigned_to_id => @id.to_i).where(:closed_on => nil).order("created_on DESC")
              format.api{ render :json => @issues}
            end 
          end 

        end
    end 
    rescue ActiveRecord::RecordNotFound
      404
  end 

  def search_users
    team_id = params[:team_id]
    @name = params[:name] 
    if @name.present? && team_id.present?
      @team = Team.find(team_id)
      @user_ids = @team.users.ids
      @parameter =   params[:name].downcase
      # projects = User.current.projects.active.ids
      # @member_ids = Member.where(:project_id => projects).pluck(:user_id).flatten.uniq
        scope = User.active.select("id, firstname, lastname, firstname || ' ' || lastname AS name").where(:id => @user_ids, :status => 1, :type => "User")
        @users = scope.like(@parameter)
        respond_to do |format|
          format.api { render :json => @users } 
        end 
    else  
      render json: :unprocessable_entity
    end 
    rescue ActiveRecord::RecordNotFound
    render 404
  end 


  def timesheet_permissions
    user = User.find_by(:id =>User.current.id)
    roles = user.roles.to_a 
    @permission = {}
    @permission[:approve_timesheet] = roles.any? { |role| role.permissions.include?(:manage_timesheet) } 
    @permission[:admin] = User.current.admin?
   
    respond_to do |format|
     format.html 
     format.api { render :json => @permission, status: :ok}
    end
  end 


  def timesheet_team
    @team_id = params[:team_id]
    @start_date = params[:start_date]
    @end_date = params[:due_date]
    page = params[:user_page]
    per_page = params[:user_per_page] || 10
  
    if @team_id.present? && @start_date.present? && @end_date.present?
      @all_time_entries = {}
      @team = Team.find_by(id: @team_id)
      @child_team = Team.find_by(parent_id: @team.id)
  
      if  @child_team.present? 
        @team_members = @child_team.users.ids
        # Get users from the selected team
        @team_members += @team.users.ids
        # Get users from all subteams recursively
        def get_subteam_users(team)
          subteam_users = []
          subteams = Team.where(parent_id: team.id)
          subteams.each do |subteam|
            subteam_users += subteam.users.ids
            subteam_users += get_subteam_users(subteam)
          end
          subteam_users
        end
      
        @team_members += get_subteam_users(@team)
      else
        @team_members = @team.users.ids
      end
      
      @team_members.uniq!
  
      @members = User.where(id: @team_members, status: 1, type: "User").paginate(page: page, per_page: per_page)
      @assignees = @members.pluck(:id)

      @users_issues = Issue.joins("LEFT JOIN time_entries ON issues.id = time_entries.issue_id").joins("LEFT JOIN enumerations ON time_entries.activity_id = enumerations.id")
                     .joins("LEFT JOIN trackers ON issues.tracker_id = trackers.id")
                     .joins("LEFT JOIN users ON issues.assigned_to_id = users.id")
                     .joins("LEFT JOIN projects ON time_entries.project_id = projects.id")
                     .select("issues.*, users.firstname || ' ' || users.lastname AS user_name, issues.assigned_to_id, issues.subject AS text, time_entries.id AS time_entry_id, time_entries.hours, time_entries.comments, time_entries.project_id AS project, time_entries.user_id AS timelog_user_id, time_entries.issue_id AS issue, time_entries.activity_id AS activity, time_entries.spent_on, time_entries.author_id, enumerations.id AS activity_id, enumerations.name AS activity_name, trackers.name AS trackers_name")
                     .where("time_entries.issue_id = issues.id AND time_entries.spent_on BETWEEN ? AND ?", @start_date, @end_date)
                     .where("issues.assigned_to_id IN (?) AND time_entries.user_id = issues.assigned_to_id", @assignees)
                     .where("projects.status = ?", 1)
                     .order("time_entries.created_on DESC")
                     
      @issues = @users_issues.map{|issue| {id: issue.id, user:issue.assigned_to_id? ? issue.assigned_to_id :  " ", parent: issue.assigned_to_id? ? issue.assigned_to_id :  " " , activity: issue.activity, category: issue.category, time_format: Setting.timespan_format, done_ratio: issue.done_ratio, lock_version: issue.lock_version, parent_id: issue.assigned_to_id.present? ? issue.assigned_to_id : " ", time_entry_id: issue.time_entry_id, text: issue.subject, spent_on: issue.spent_on, trackers_name: issue.tracker.name, user_name: issue.assigned_to.name, activity_name: issue.activity_name,  activity_id: issue.activity_id, comments: issue.comments, hours: format_hours(issue.hours), estimated_hours: format_hours(issue.estimated_hours), tracker: issue.tracker_id, project: issue.project, subject: issue.subject, start_date: issue.start_date, due_date: issue.due_date, status: issue.status_id, assigned_to_id: issue.assigned_to_id, priority_id: issue.priority_id, author_id: issue.author_id }}

      @unassigned_issues = Issue.joins("LEFT JOIN time_entries ON issues.id = time_entries.issue_id").joins("LEFT JOIN enumerations ON time_entries.activity_id = enumerations.id")
          .joins("LEFT JOIN trackers ON issues.tracker_id = trackers.id")
          .joins("LEFT JOIN users ON issues.assigned_to_id = users.id")
          .joins("LEFT JOIN projects ON time_entries.project_id = projects.id")
          .select("issues.*, users.firstname || ' ' || users.lastname AS user_name, issues.assigned_to_id, issues.subject AS text, time_entries.id AS time_entry_id, time_entries.user_id AS timelog_user_id, time_entries.hours, time_entries.comments, time_entries.project_id AS project, time_entries.user_id AS timelog_user_id, time_entries.issue_id AS issue, time_entries.activity_id AS activity, time_entries.spent_on, time_entries.author_id, enumerations.id AS activity_id, enumerations.name AS activity_name, trackers.name AS trackers_name")
          .where("time_entries.issue_id = issues.id AND time_entries.spent_on BETWEEN ? AND ?", @start_date, @end_date)
          .where("time_entries.user_id IN (?)", @assignees)
          .where("projects.status = ?", 1)
          .order("time_entries.created_on DESC")

      @updated_issues_response =  @unassigned_issues.map{|issue| {id: issue.id, user:issue.timelog_user_id,  parent: issue.timelog_user_id, category: issue.category, activity: issue.activity, time_format: Setting.timespan_format, done_ratio: issue.done_ratio, lock_version: issue.lock_version, parent_id: issue.timelog_user_id, time_entry_id: issue.time_entry_id, text: issue.subject, spent_on: issue.spent_on, trackers_name: issue.tracker.name, user_name: issue.assigned_to.present? ? issue.assigned_to.name : " ", activity_name: issue.activity_name,  activity_id: issue.activity_id, comments: issue.comments, hours: format_hours(issue.hours), estimated_hours: format_hours(issue.estimated_hours), tracker: issue.tracker_id, project: issue.project, subject: issue.subject, start_date: issue.start_date, due_date: issue.due_date, status: issue.status_id, assigned_to_id: issue.assigned_to_id, priority_id: issue.priority_id, author_id: issue.author_id }}
      
      if show_unassigned_issues_configured? 
        @data = @members.map{|f| {:id => f.id, :color =>f.timesheet_color, time_format: Setting.timespan_format, :parent=>0, :text=> f.firstname + " " + f.lastname,  :type=>"project", :user_id=>f.id, :login => f.login ,  :firstname => f.firstname, :lastname => f.lastname, :admin => f.admin,:created_on => f.created_on,  :updated_on => f.updated_on, :spent_hours =>  format_hours( @unassigned_issues.where("time_entries.user_id = ?", f.id).sum(:hours).round(2)),  :estimated_hours => format_hours(Issue.joins("LEFT JOIN time_entries ON issues.id = time_entries.issue_id").where("time_entries.issue_id = issues.id AND assigned_to_id =?", f.id).sum("issues.estimated_hours").round(2))}} + @updated_issues_response
      else  
        @data = @members.map{|f| {:id => f.id, :color =>f.timesheet_color, time_format: Setting.timespan_format, :parent=>0, :text=> f.firstname + " " + f.lastname,  :type=>"project", :user_id=>f.id, :login => f.login ,  :firstname => f.firstname, :lastname => f.lastname, :admin => f.admin,:created_on => f.created_on,  :updated_on => f.updated_on, :spent_hours =>  format_hours( @users_issues.where("assigned_to_id = ? ", f.id).sum(:hours).round(2)), :estimated_hours => format_hours(Issue.joins("LEFT JOIN time_entries ON issues.id = time_entries.issue_id").where("time_entries.issue_id = issues.id AND assigned_to_id =?", f.id).sum("issues.estimated_hours").round(2))}} + @issues
      end

  
      @all_time_entries[:data] = @data.uniq
      @all_time_entries[:users] = @members
  
      respond_to do |format|
        format.api do
          pagination =  { total_pages:  @members.total_pages, total_entries:  @members.total_entries }
          render json: { data: @all_time_entries[:data], users: @all_time_entries[:users], pagination: pagination }
        end
      end
    end
  end
  
  def format_hours(hours)
    return "" if hours.blank?

    if Setting.timespan_format == 'minutes'
      h = hours.floor
      m = ((hours - h) * 60).round
      "%d:%02d" % [h, m]
    else
       hours.to_f.round(2)
    end
  end
  
  def show_unassigned_issues_configured? 
    Setting.plugin_redmineflux_timesheet['unassigned_issues'].present? 
  end 

  def update_dropdown_preference
    selected_option = params[:selected_option]
    current_user = User.current
  
    preference = TimesheetDropdownPreference.find_or_initialize_by(user_id: current_user.id)
    preference.selected_option = selected_option
    preference.save!
  
    render json: { success: true , selected_option: preference }
  end
  
end
