module TimesheetApprovalsHelper
  def get_timesheet_hours(user, start_date, end_date)
      @timesheets = SubmitTimesheet.where(user_id: user.id, start_date: start_date, end_date: end_date, status: 4).or(SubmitTimesheet.where(user_id: user.id, start_date: start_date, end_date: end_date, status: 1)).or(SubmitTimesheet.where(user_id: user.id, reject_start_date: start_date, reject_end_date: end_date, status: 2))

      total_hours = 0
      
      @timesheets.each do |timesheet|
        total_hours += timesheet.timesheet_activities.map{|activity| activity.hours || 0 }.sum 
      end
      return format_hours(total_hours)
  end 


  def submittedTimesheet(user, period_start,period_end )
    timesheet = SubmitTimesheet.where(user_id: user.id).where("(start_date BETWEEN :start AND :end) OR (end_date BETWEEN :start AND :end)", start: period_start, end: period_end).where.not(status: 'unsubmit').first
  end 

  def format_hours(hours)
    return "" if hours.blank?
    if Setting.timespan_format == 'minutes'
      h = hours.floor
      m = ((hours - h) * 60).round
      "%d:%02d" % [h, m]
    else
        hours.to_f.round(2)
    end
  end

    
end
