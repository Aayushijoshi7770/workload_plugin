module TimesheetTeamsHelper
    def member_count(team) 
        team = Team.find(team.id)
        count = team.users.count
    end 

    def render_team_hierarchy(teams, level = 0, count = 0)
        teams.map do |team|
          count += 1
          content_tag(:tr) do
            concat(content_tag(:td, count))
            concat(content_tag(:td, style: "padding-left: #{level * 20}px") do
              link_to(team[:team].name, timesheet_team_path(team[:team].id), method: :get)
            end)
            concat(content_tag(:td, "(#{team[:team].users.count})"))
            concat(content_tag(:td) do
              link_to("Edit", edit_timesheet_team_path(team[:team].id), method: :get, remote: true, class: "icon-only icon-edit") +
              link_to("Delete", delete_timesheet_team_path(team[:team].id), method: :get, remote: true, class: "icon-only icon-del")
            end)
          end +
          render_team_hierarchy(team[:children], level + 1, count)
        end.join.html_safe
      end
end
