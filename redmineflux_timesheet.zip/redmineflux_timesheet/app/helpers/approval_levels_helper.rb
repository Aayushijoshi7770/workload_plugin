module ApprovalLevelsHelper

    def level_text(level)
        case level
        when 1 then "Level One"
        when 2 then "Level Two"
        when 3 then "Level Three"
        when 4 then "Level Four"
        when 5 then "Level Five"
        end 
    end 
end
