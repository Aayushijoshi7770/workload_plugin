class CreateTeamUsers < ActiveRecord::Migration[5.2]
  def change
    create_table :team_users do |t|
      t.bigint :team_id, foreign_key: true
      t.bigint :user_id, foreign_key: true
      t.timestamps
      
    end
    add_index :team_users, :team_id, name: "index_team_user_on_team_id"
    add_index :team_users, :user_id, name: "index_team_user_on_user_id"
  end
end
