class CreateTimesheetActivities < ActiveRecord::Migration[5.2]
  def change
    create_table :timesheet_activities do |t|
      t.integer :submit_timesheet_id 
      t.integer :activity_id
      t.string :activity_name
      t.float :hours
      t.integer :user_id
      t.datetime :created_at
      t.datetime :updated_at
      # t.references :submit_timesheet, foreign_key: true
    end
    # add_index :timesheet_activities, :submit_timesheet_id, name: "submit_timesheet_id_timesheet_activity"
  end
end
