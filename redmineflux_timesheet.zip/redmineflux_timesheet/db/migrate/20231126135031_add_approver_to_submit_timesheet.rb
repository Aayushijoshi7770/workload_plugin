class AddApproverToSubmitTimesheet < ActiveRecord::Migration[5.2]
  def change
    add_column :submit_timesheets, :approved_by, :integer
    add_column :submit_timesheets, :approved_on, :datetime
  end
end
