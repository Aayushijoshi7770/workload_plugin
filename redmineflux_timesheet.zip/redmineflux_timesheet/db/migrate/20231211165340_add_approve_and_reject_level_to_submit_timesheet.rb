class AddApproveAndRejectLevelToSubmitTimesheet < ActiveRecord::Migration[5.2]
  def change
    add_column :submit_timesheets, :approved_level, :integer
    add_column :submit_timesheets, :rejected_level, :integer
  end
end
