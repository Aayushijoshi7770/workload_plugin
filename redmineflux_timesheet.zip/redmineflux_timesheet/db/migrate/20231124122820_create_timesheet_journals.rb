class CreateTimesheetJournals < (ActiveRecord::VERSION::MAJOR >= 6 ? ActiveRecord::Migration[6.1] : ActiveRecord::Migration[5.2])
  def change
    create_table :timesheet_journals do |t|
      t.integer :journal_id
      t.string :journalized_type
      t.integer :user_id
      t.string :prop_key
      t.text :old_value
      t.text :new_value
      t.datetime :created_on
      t.references :submit_timesheet, foreign_key: true
    end
    add_index :timesheet_journals, :submit_timesheet_id, name: 'timesheet_journal_submit_timesheet_id'
  end
end

