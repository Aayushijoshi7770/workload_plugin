class AddColumnGroupByToTimesheetQuery < ActiveRecord::Migration[5.2]
  def change
    add_column :timesheet_queries, :group_by, :string
    add_column :timesheet_queries, :grid_x_axis, :integer
    add_column :timesheet_queries, :grid_y_axis, :integer
    add_column :timesheet_queries, :Height, :integer
    add_column :timesheet_queries, :Width, :integer
  end
end
