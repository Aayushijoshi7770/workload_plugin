class CreateTimesheetDropdownPrefrence < (ActiveRecord::VERSION::MAJOR >= 6 ? ActiveRecord::Migration[6.1] : ActiveRecord::Migration[5.2])
  def change
    unless table_exists?(:timesheet_dropdown_preferences)
     create_table :timesheet_dropdown_preferences do |t|
       t.integer :user_id
       t.string  :selected_option
       t.timestamps
     end
    end
   end
 
   def down
     if table_exists?(:timesheet_dropdown_preferences)
       drop_table :timesheet_dropdown_preferences
     end
   end
end

