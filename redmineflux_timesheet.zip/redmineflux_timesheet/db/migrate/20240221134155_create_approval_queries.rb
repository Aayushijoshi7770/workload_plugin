class CreateApprovalQueries < (ActiveRecord::VERSION::MAJOR >= 6 ? ActiveRecord::Migration[6.1] : ActiveRecord::Migration[5.2])
  def change
    create_table :approval_queries do |t|
      t.integer :user_id
      t.integer :team_id
      t.date :start_date, default: Date.today.beginning_of_week
      t.date :end_date, default: Date.today.end_of_week
      t.timestamps
    end
  end
end
