class CreateTimesheetChangelogs < (ActiveRecord::VERSION::MAJOR >= 6 ? ActiveRecord::Migration[6.1] : ActiveRecord::Migration[5.2])
  def change
    create_table :timesheet_changelogs do |t|
      t.bigint :level_id
      t.bigint :status_id
      t.bigint :submitted_by
      t.integer :approved_by
      t.integer :timesheet_id
      t.date :timesheet_start_date
      t.date :timesheet_end_date
      t.text :comment
      t.timestamps
    end
    add_index :timesheet_changelogs, :level_id
    add_index :timesheet_changelogs, :status_id
    add_index :timesheet_changelogs, :submitted_by
    add_index :timesheet_changelogs, :approved_by
    add_index :timesheet_changelogs, :timesheet_id
  end
end
