class AddColumnChartTypeToTimesheetQuery < ActiveRecord::Migration[5.2]
  def change
    add_column :timesheet_queries, :chart_type, :string
  end
end
