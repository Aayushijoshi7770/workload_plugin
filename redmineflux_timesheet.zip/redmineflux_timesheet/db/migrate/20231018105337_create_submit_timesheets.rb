class CreateSubmitTimesheets < ActiveRecord::Migration[5.2]
  def change
    create_table :submit_timesheets do |t|
      t.integer :user_id
      t.integer :status, default: 0
      t.integer :submitted_by
      t.boolean :submitted
      t.date :start_date
      t.date :end_date
      t.float :hours
      t.datetime :created_at
      t.datetime :updated_at
      t.string :reject_comment
      t.integer :rejected_by
      t.date :reject_start_date
      t.date :reject_end_date
    end
  end
end
