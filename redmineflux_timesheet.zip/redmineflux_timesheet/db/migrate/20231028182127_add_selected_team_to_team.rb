class AddSelectedTeamToTeam < ActiveRecord::Migration[5.2]
  def change
    add_column :teams, :selected, :boolean, default: false
  end
end
