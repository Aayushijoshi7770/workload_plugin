class AddColorsToUser < ActiveRecord::Migration[5.2]
  def change
    add_column :users, :timesheet_color, :string
  end
end
