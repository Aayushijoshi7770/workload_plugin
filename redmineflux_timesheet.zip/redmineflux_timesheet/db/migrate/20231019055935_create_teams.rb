class CreateTeams < ActiveRecord::Migration[5.2]
  def change
    create_table :teams do |t|
      t.string :name
      t.integer :created_by
      t.datetime :created_at
      t.datetime :updated_at
      t.integer :updated_by
      t.boolean :selected_team, default: false 
    end
  end
end
