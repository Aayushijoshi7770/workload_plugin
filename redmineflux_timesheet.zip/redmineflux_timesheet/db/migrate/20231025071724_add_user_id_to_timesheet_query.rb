class AddUserIdToTimesheetQuery < ActiveRecord::Migration[5.2]
  def change
    add_column :timesheet_queries, :user_id, :integer
  end
end