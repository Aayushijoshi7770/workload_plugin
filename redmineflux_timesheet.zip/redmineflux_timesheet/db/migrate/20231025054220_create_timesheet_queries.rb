class CreateTimesheetQueries < ActiveRecord::Migration[5.2]
  def change
    create_table :timesheet_queries do |t|
      t.text :filters
    end
  end
end
