class AddParentIdToTeamsTable < (ActiveRecord::VERSION::MAJOR >= 6 ? ActiveRecord::Migration[6.1] : ActiveRecord::Migration[5.2])
  def change
    add_column :teams, :parent_id, :integer, default: 0
  end
end

