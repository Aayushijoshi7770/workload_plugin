class AddFieldsToApprovalLevel < (ActiveRecord::VERSION::MAJOR >= 6 ? ActiveRecord::Migration[6.1] : ActiveRecord::Migration[5.2])
  def change
    add_column :approval_levels, :status, :integer, default: 0
    add_column :approval_levels, :approved_by, :integer
    add_column :approval_levels, :approved_at, :datetime
    add_column :approval_levels, :rejected_by, :integer
    add_column :approval_levels, :rejected_at, :datetime
    add_column :approval_levels, :comment, :text
    add_column :approval_levels, :unsubmitted_by, :integer
    add_column :approval_levels, :unsubmitted_at, :datetime
  end
end
