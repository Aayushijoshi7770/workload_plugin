class AddRoleToApprovalLevel < ActiveRecord::Migration[5.2]
  def change
    add_column :approval_levels, :role, :integer
  end
end
