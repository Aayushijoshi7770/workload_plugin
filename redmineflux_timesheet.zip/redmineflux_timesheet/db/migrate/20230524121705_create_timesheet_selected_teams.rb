class CreateTimesheetSelectedTeams < ActiveRecord::Migration[5.2]
  def change
    create_table :timesheet_selected_teams do |t|
      t.integer :team_id
      t.integer :user_id
      t.string :team_name
      t.string :period
      t.date :from
      t.date :to
    end
  end
end
