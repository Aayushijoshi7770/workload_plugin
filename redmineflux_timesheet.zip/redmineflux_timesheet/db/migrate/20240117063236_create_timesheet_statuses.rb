class CreateTimesheetStatuses < ActiveRecord::Migration[5.2]
  def change
    create_table :timesheet_statuses do |t|
      t.bigint :submit_timesheet_id, foreign_key: true
      t.bigint :approval_level_id
      t.integer :status, default: 0
      t.bigint :user_id, foreign_key: true
      t.text :comments
      t.timestamps
    end
    add_index :timesheet_statuses, :submit_timesheet_id, name: 'submit_timesheet_id'
    add_index :timesheet_statuses, :approval_level_id, name: 'timesheet_approval_level_id'
    add_index :timesheet_statuses, :user_id, name: 'timesheet_user_id'
  end
end
