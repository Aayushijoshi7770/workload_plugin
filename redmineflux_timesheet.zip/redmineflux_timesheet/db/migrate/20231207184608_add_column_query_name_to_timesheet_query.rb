class AddColumnQueryNameToTimesheetQuery < ActiveRecord::Migration[5.2]
  def change
    add_column :timesheet_queries, :query_name, :string
  end
end
