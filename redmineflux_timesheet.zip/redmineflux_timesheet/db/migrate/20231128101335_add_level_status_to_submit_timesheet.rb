class AddLevelStatusToSubmitTimesheet < (ActiveRecord::VERSION::MAJOR >= 6 ? ActiveRecord::Migration[6.1] : ActiveRecord::Migration[5.2])
  def change
    add_column :submit_timesheets, :level_status, :integer, default: 1
  end
end
