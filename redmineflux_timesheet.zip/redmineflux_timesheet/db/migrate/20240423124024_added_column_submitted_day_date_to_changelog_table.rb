class AddedColumnSubmittedDayDateToChangelogTable < (ActiveRecord::VERSION::MAJOR >= 6 ? ActiveRecord::Migration[6.1] : ActiveRecord::Migration[5.2])
  def change
    add_column :timesheet_changelogs, :submitted_day_date, :date
    add_column :timesheet_changelogs, :rejected_day_date, :date
  end
end
