class AddDistributionColumnToIssueTable < (ActiveRecord::VERSION::MAJOR >= 6 ? ActiveRecord::Migration[6.1] : ActiveRecord::Migration[5.2])
  def change
    add_column :issues, :distribution, :string, default: 'equal', null: false
  end
end
