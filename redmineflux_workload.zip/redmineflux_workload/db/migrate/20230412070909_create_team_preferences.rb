class CreateTeamPreferences < (ActiveRecord::VERSION::MAJOR >= 6 ? ActiveRecord::Migration[6.1] : ActiveRecord::Migration[5.2])
  def self.up
    unless table_exists?(:team_preferences)
      create_table :team_preferences do |t|
        t.integer :user_id
        t.integer :team_id
        t.timestamps
      end
    end
  end

  def self.down
    drop_table :team_preferences if table_exists? :team_preferences
  end
end