class CreateWorkloadReports < (ActiveRecord::VERSION::MAJOR >= 6 ? ActiveRecord::Migration[6.1] : ActiveRecord::Migration[5.2])
  def change
    unless table_exists?(:workload_reports)
    create_table :workload_reports do |t|
    t.integer :grid_id
    t.text :team_name
    t.date :start_date
    t.date :end_date
    end
  end
 end
end
