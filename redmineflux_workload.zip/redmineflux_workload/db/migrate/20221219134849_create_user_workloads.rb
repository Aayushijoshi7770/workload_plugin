class CreateUserWorkloads < (ActiveRecord::VERSION::MAJOR >= 6 ? ActiveRecord::Migration[6.1] : ActiveRecord::Migration[5.2])
  def change
    unless table_exists?(:user_workloads)
    create_table :user_workloads do |t|
      t.string :name
      t.text :description
      t.float :wd0
      t.float :wd1
      t.float :wd2
      t.float :wd3
      t.float :wd4
      t.float :wd5
      t.float :wd6
      t.integer :member_id
      t.integer :created_by
      t.integer :updated_by
      t.timestamps
    end
  end
 end
end
