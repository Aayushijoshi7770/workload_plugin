class AddTeamIdsToTeamPreferences < (ActiveRecord::VERSION::MAJOR >= 6 ? ActiveRecord::Migration[6.1] : ActiveRecord::Migration[5.2])
  def change
    unless column_exists?(:team_preferences, :team_ids)
    add_column :team_preferences, :team_ids, :integer, array: true, default: []
  end
 end
end
