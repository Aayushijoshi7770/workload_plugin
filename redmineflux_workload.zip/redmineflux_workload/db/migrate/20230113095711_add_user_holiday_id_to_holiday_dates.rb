class AddUserHolidayIdToHolidayDates < (ActiveRecord::VERSION::MAJOR >= 6 ? ActiveRecord::Migration[6.1] : ActiveRecord::Migration[5.2])
  def change
    unless column_exists?(:holiday_dates, :user_holiday_id)
      add_column :holiday_dates, :user_holiday_id, :integer
    end
  end
end
