class ModifyHolidayDates < (ActiveRecord::VERSION::MAJOR >= 6 ? ActiveRecord::Migration[6.1] : ActiveRecord::Migration[5.2])
  def change
    if table_exists?(:holiday_dates)
      rename_column :holiday_dates, :date, :start_date
      add_column :holiday_dates, :end_date, :date
    end
  end
end
