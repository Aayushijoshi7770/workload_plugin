class CreateHolidaySchemes < (ActiveRecord::VERSION::MAJOR >= 6 ? ActiveRecord::Migration[6.1] : ActiveRecord::Migration[5.2])
  def change
    unless table_exists?(:holiday_schemes)
    create_table :holiday_schemes do |t|
      t.bigint "user_holiday_id", null: false
      t.bigint "user_id", null: false
      t.timestamp "created_at", null: false
      t.datetime "updated_at", null: false
    end
  end
end
end
