class AddFilterColumns < (ActiveRecord::VERSION::MAJOR >= 6 ? ActiveRecord::Migration[6.1] : ActiveRecord::Migration[5.2])
  def change
    unless column_exists?(:workload_reports, :filter_field)
      add_column :workload_reports, :filter_field, :text 
    end
    unless column_exists?(:workload_reports, :filter_operator)
      add_column :workload_reports, :filter_operator, :text 
    end
    unless column_exists?(:workload_reports, :filter_value)
      add_column :workload_reports, :filter_value, :text 
    end
  end
end