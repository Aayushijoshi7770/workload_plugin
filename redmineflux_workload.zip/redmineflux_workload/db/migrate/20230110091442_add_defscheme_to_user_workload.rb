class AddDefschemeToUserWorkload < (ActiveRecord::VERSION::MAJOR >= 6 ? ActiveRecord::Migration[6.1] : ActiveRecord::Migration[5.2])
  def change
    unless column_exists?(:user_workloads, :def_wk_scheme)
      add_column :user_workloads, :def_wk_scheme, :boolean 
    end
  end
end
