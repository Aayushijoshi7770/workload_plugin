class DefaultColor < (ActiveRecord::VERSION::MAJOR >= 6 ? ActiveRecord::Migration[6.1] : ActiveRecord::Migration[5.2])
  def self.up
   if column_exists?(:users, :color)
    User.find_each do |user|

      user.update_columns(:color => "##{"%06x" % rand(0..0xffffff)}")

    end
  end
end

  def self.down

  end
end
