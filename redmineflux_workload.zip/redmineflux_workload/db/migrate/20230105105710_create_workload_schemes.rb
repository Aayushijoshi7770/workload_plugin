class CreateWorkloadSchemes < (ActiveRecord::VERSION::MAJOR >= 6 ? ActiveRecord::Migration[6.1] : ActiveRecord::Migration[5.2])
  def change
    unless table_exists?(:workload_schemes)
    create_table :workload_schemes do |t|
      t.bigint :user_workload_id, null: false
      t.bigint :user_id, null: false
      t.timestamps null: false
    end

      add_index :workload_schemes, :user_id, name: "index_workload_schemes_on_user"
      add_index :workload_schemes, :user_workload_id, name: "index_workload_schemes_on_user_workload"
    end
  end
end
