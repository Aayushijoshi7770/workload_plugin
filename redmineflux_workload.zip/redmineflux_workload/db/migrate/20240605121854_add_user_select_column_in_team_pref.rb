class AddUserSelectColumnInTeamPref < (ActiveRecord::VERSION::MAJOR >= 6 ? ActiveRecord::Migration[6.1] : ActiveRecord::Migration[5.2])
  def change
    add_column :team_preferences, :selected_user_ids, :integer, default: nil
  end
end
