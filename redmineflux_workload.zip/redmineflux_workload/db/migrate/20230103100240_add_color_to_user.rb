class AddColorToUser < (ActiveRecord::VERSION::MAJOR >= 6 ? ActiveRecord::Migration[6.1] : ActiveRecord::Migration[5.2])
  def change
    unless column_exists?(:users, :color)
      add_column :users, :color, :string
    end
  end
end
