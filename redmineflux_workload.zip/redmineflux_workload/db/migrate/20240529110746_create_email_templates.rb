class CreateEmailTemplates < (ActiveRecord::VERSION::MAJOR >= 6 ? ActiveRecord::Migration[6.1] : ActiveRecord::Migration[5.2])
  def change
    create_table :email_templates do |t|
      t.string :template_name
      t.text :subject
      t.text :body
      t.text :footer
    end
  end
end
