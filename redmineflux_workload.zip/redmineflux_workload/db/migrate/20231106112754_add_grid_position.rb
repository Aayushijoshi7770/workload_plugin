class AddGridPosition < (ActiveRecord::VERSION::MAJOR >= 6 ? ActiveRecord::Migration[6.1] : ActiveRecord::Migration[5.2])
  def change
    unless column_exists?(:workload_reports, :grid_Xaxis)
      add_column :workload_reports, :grid_Xaxis, :integer 
    end
    unless column_exists?(:workload_reports, :grid_Yaxis)
      add_column :workload_reports, :grid_Yaxis, :integer
    end
  end
end