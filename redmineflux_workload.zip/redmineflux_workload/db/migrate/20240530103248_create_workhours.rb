class CreateWorkhours < ActiveRecord::Migration[5.2]
  def change
    create_table :workhours do |t|
      t.integer :user_id
      t.integer :issue
      t.date :date
      t.float :hours
      t.date :created_at
      t.date :updated_at
      t.integer :created_by
      t.integer :updated_by
    end
  end
end
