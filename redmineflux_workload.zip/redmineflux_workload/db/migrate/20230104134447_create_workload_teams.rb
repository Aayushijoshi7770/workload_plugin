class CreateWorkloadTeams < (ActiveRecord::VERSION::MAJOR >= 6 ? ActiveRecord::Migration[6.1] : ActiveRecord::Migration[5.2])
  def self.up
    unless table_exists?(:workload_teams)
      create_table :workload_teams do |t|
        t.string :name, :unique => true
        t.timestamps
      end
    end
  end

  def self.down
    drop_table :workload_teams if table_exists? :workload_teams
  end
end