class AddColumnsInWorkloadReport < (ActiveRecord::VERSION::MAJOR >= 6 ? ActiveRecord::Migration[6.1] : ActiveRecord::Migration[5.2])
  def change
    unless column_exists?(:workload_reports, :height)
      add_column :workload_reports, :height, :integer, default: 2
    end
    unless column_exists?(:workload_reports, :width)
      add_column :workload_reports, :width, :integer, default: 3
    end
  end
end