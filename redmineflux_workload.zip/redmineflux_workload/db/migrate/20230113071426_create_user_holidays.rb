class CreateUserHolidays < (ActiveRecord::VERSION::MAJOR >= 6 ? ActiveRecord::Migration[6.1] : ActiveRecord::Migration[5.2])
  def change
    unless table_exists?(:user_holidays)
    create_table :user_holidays do |t|
      t.string :name
      t.text :description
      t.date :holiday_date
      t.integer :member_id
      t.timestamp :created_at
      t.timestamp :updated_at
    end
  end
 end
end
