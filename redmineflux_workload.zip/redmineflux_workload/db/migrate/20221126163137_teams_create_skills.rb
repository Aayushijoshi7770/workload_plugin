class TeamsCreateSkills < (ActiveRecord::VERSION::MAJOR >= 6 ? ActiveRecord::Migration[6.1] : ActiveRecord::Migration[5.2])
  def self.up
    unless table_exists?(:skills)
      create_table :skills do |t|
        t.string :skill, :unique => true
        t.integer :user_id
        t.timestamps
      end
    end
  end

  def self.down
    drop_table :skills if table_exists? :skills
  end
end
