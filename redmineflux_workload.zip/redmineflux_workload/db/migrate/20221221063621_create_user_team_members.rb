class CreateUserTeamMembers < (ActiveRecord::VERSION::MAJOR >= 6 ? ActiveRecord::Migration[6.1] : ActiveRecord::Migration[5.2])
  def change
    unless table_exists?(:user_team_members)
    create_table :user_team_members do |t|
      t.integer :user_id
      t.integer :team_member_id

      t.timestamps
    end
  end
 end
end
