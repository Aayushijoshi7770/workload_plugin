class CreateHolidayDates < (ActiveRecord::VERSION::MAJOR >= 6 ? ActiveRecord::Migration[6.1] : ActiveRecord::Migration[5.2])
  def change
    unless table_exists?(:holiday_dates)
    create_table :holiday_dates do |t|
      t.string :name
      t.text :description
      t.date :date
      t.integer :created_at
      t.integer :updated_at
    end
  end
 end
end
