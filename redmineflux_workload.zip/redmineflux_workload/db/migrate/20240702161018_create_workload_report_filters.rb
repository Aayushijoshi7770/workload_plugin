class CreateWorkloadReportFilters < (ActiveRecord::VERSION::MAJOR >= 6 ? ActiveRecord::Migration[6.1] : ActiveRecord::Migration[5.2])
  def change
    create_table :workload_report_filters do |t|
      t.string :filter_by
      t.text :team_ids
      t.text :user_ids
      t.date :start_date
      t.date :end_date

      t.timestamps
    end
  end
end
