class AddDefaultValueToUserWorkload < (ActiveRecord::VERSION::MAJOR >= 6 ? ActiveRecord::Migration[6.1] : ActiveRecord::Migration[5.2])
  def up
    change_column :user_workloads, :wd0, :float, :default => 0 if column_exists?(:user_workloads, :wd0)
    change_column :user_workloads, :wd1, :float, :default => 0 if column_exists?(:user_workloads, :wd1)
    change_column :user_workloads, :wd2, :float, :default => 0 if column_exists?(:user_workloads, :wd2)
    change_column :user_workloads, :wd3, :float, :default => 0 if column_exists?(:user_workloads, :wd3)
    change_column :user_workloads, :wd4, :float, :default => 0 if column_exists?(:user_workloads, :wd4)
    change_column :user_workloads, :wd5, :float, :default => 0 if column_exists?(:user_workloads, :wd5)
    change_column :user_workloads, :wd6, :float, :default => 0 if column_exists?(:user_workloads, :wd6)
  end

  def down
    change_column :user_workloads, :wd0, :float, :default => nil if column_exists?(:user_workloads, :wd0)
    change_column :user_workloads, :wd1, :float, :default => nil if column_exists?(:user_workloads, :wd1)
    change_column :user_workloads, :wd2, :float, :default => nil if column_exists?(:user_workloads, :wd2)
    change_column :user_workloads, :wd3, :float, :default => nil if column_exists?(:user_workloads, :wd3)
    change_column :user_workloads, :wd4, :float, :default => nil if column_exists?(:user_workloads, :wd4)
    change_column :user_workloads, :wd5, :float, :default => nil if column_exists?(:user_workloads, :wd5)
    change_column :user_workloads, :wd6, :float, :default => nil if column_exists?(:user_workloads, :wd6)
  end 
end