class CreateSelectedTeams < (ActiveRecord::VERSION::MAJOR >= 6 ? ActiveRecord::Migration[6.1] : ActiveRecord::Migration[5.2])
  def change
    unless table_exists?(:selected_teams)
    create_table :selected_teams do |t|
      t.integer :team_id
      t.string :team_name
      t.string :period
      t.date :from_date
      t.date :to_date
    end
  end
 end
end
