class AddUserField < (ActiveRecord::VERSION::MAJOR >= 6 ? ActiveRecord::Migration[6.1] : ActiveRecord::Migration[5.2])
  def change
    unless column_exists?(:workload_reports, :users)
    add_column :workload_reports,  :users, :integer, array: true, default: []
  end
 end
end
