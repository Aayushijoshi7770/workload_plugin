class AddProjectField < (ActiveRecord::VERSION::MAJOR >= 6 ? ActiveRecord::Migration[6.1] : ActiveRecord::Migration[5.2])
  def change
    unless column_exists?(:workload_reports, :project_value)
    add_column :workload_reports,  :project_value, :integer
  end
 end
end
