class ChangeColumnField < (ActiveRecord::VERSION::MAJOR >= 6 ? ActiveRecord::Migration[6.1] : ActiveRecord::Migration[5.2])
  def up
    if column_exists?(:workload_reports, :users)
      change_column :workload_reports, :users, :text 
    end
  end

  def down
    if column_exists?(:workload_reports, :users)
      change_column :workload_reports, :users, :integer, array: true, default: []
    end
  end
end