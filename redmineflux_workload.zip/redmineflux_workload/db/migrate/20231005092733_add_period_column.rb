class AddPeriodColumn < (ActiveRecord::VERSION::MAJOR >= 6 ? ActiveRecord::Migration[6.1] : ActiveRecord::Migration[5.2])
  def change
    unless column_exists?(:workload_reports, :period_type)
      add_column :workload_reports, :period_type, :integer 
    end
    unless column_exists?(:workload_reports, :period)
      add_column :workload_reports, :period, :text 
    end
  end
end