class CreateTeamMember < (ActiveRecord::VERSION::MAJOR >= 6 ? ActiveRecord::Migration[6.1] : ActiveRecord::Migration[5.2])
  def change
    unless table_exists?(:team_members)
      create_table :team_members do |t|
        t.date :joining_date
        t.date :leaving_date
        t.integer :commitment
        t.integer :member_id
        t.integer :group_id
        t.string :skills
      end
    end
  end

  def self.down
    drop_table :team_members if table_exists? :team_members
  end
end