require_dependency 'issue'

  if Redmine::VERSION::MAJOR == 4
    require_relative './lib/patches/update_issue_patch.rb'

  elsif  Redmine::VERSION::MAJOR == 5
    require File.expand_path('./lib/patches/update_issue_patch.rb', __dir__)

  end

Redmine::Plugin.register :redmineflux_workload do
  name 'Redmineflux Workload plugin'
  author 'Redmineflux - Powered by Zehntech Technologies Inc'
  description 'The Workload plugin tracks tasks, schedules resources, and visualizes availability to prevent excessive workload.'
  version '3.0.0'
  url 'https://www.redmineflux.com/knowledge-base/plugins/workload-plugin/'
  author_url 'https://www.redmineflux.com'

  permission :manage_workload, :workload => [:index]
  menu :top_menu, :workloads, { controller: 'workloads', action: 'index'},  caption: Proc.new { I18n.t('label_workload_name') }
  settings default: {'empty' => true}, partial: 'workload_settings/settings'
  
 
end
if Redmine::VERSION::MAJOR == 4
  Rails.configuration.to_prepare do
    Issue.send(:has_many, :workhours, dependent: :destroy)
  end
elsif Redmine::VERSION::MAJOR == 5
  Rails.application.config.before_initialize do
    Issue.send(:has_many, :workhours, dependent: :destroy)
  end
end
