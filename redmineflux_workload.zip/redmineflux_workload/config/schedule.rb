send :environment, "production"
  every :day, :at => '4:00pm' do
    rake "workload_reminder:send_workload_reminder"
  end 


# set :environment, "production"

# require 'rufus-scheduler'

# scheduler = Rufus::Scheduler.new

# def frequency_to_cron(frequency)
#   case frequency
#   when 'Everyday'
#     '0 16 * * *' # Run every day at 4:00 PM
#   when 'Weekly'
#     '0 16 * * 0' # Run every monday at 4:00 PM
#   when 'Monthly'
#     '0 16 1 * *' # Run on the first day of every month at 4:00 PM
#   else
#     raise "Invalid frequency: #{frequency}"
#   end
# end

# # Load the settings from the database
# @settings = Setting.first

# # Check if settings and frequency are present
# if @settings && @settings[:frequency].is_a?(Array)
#   # Determine the frequency selected and schedule mail sending task accordingly
#   @settings[:frequency].each do |freq|
#     cron_syntax = frequency_to_cron(freq)
#     scheduler.cron cron_syntax do
#       Rake::Task["workload_reminder:send_workload_reminder"].invoke
#     end
#   end
# end

# scheduler.join # This will keep your script running
