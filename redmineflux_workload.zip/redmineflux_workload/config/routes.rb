# Plugin's routes
# See: http://guides.rubyonrails.org/routing.html


get 'user_workload/new', to: 'user_workloads#new'
resources :user_workloads

resources :user_holidays do
  resources :holiday_dates
end 


Rails.application.routes.draw do
  resources :work_hours, only: [:create, :show]
  get 'work_hours/show', to: 'work_hours#show', as: 'work_hours_show'
  get 'team/assigned/issues', to: 'workload_apis#user_issues'
  get 'search_users_projects', to: 'workload_apis#search_users_projects'
  get 'users_projects_for_issue', to: 'workload_apis#users_projects'
  get 'add_members_to_holiday_scheme', to: 'user_holidays#add_members_to_holiday_scheme'
  get 'search_holiday_scheme_users', to: 'user_holidays#search_holiday_scheme_users'
  get 'search_holiday_scheme_members', to: 'user_holidays#search_holiday_scheme_members'
  get 'add_members_to_wk_scheme', to: 'user_workloads#add_members_to_wk_scheme'
  post 'add_holiday_members', to: 'user_holidays#add_members_to_holiday'
  get 'user_workload_scheme', to: 'workload_apis#user_workload_scheme'
  # get 'user_workload_scheme', to: 'user_workloads#workload_scheme'
  get 'workload_scheme_data_with_members', to: 'user_workloads#workload_scheme_with_members'
  post 'add_workload_members', to: 'user_workloads#add_workload_members'
  get 'search_workload_scheme_users', to: 'user_workloads#search_scheme_users'
  get 'search_workload_scheme_members', to: 'user_workloads#search_workload_scheme_members'
  get 'search_unassigned_group_issues', to: 'workload_apis#search_unassigned_issues'
  get 'projects_unassigned_issues', to: 'workload_apis#unassigned_issues'
  get 'user_issues', to: 'workload_apis#user_issues_with_period'
  get 'skills_of_users', to: 'workload_apis#skills_of_users'
  get 'search_wk_users', to: 'workload_apis#search_group_users'
  get 'search_issues', to: 'workload_apis#search_group_issues'
  get 'skills_data', to: 'workload_teams#skills_data'
  post 'update_report', to: 'workload_reports#update_report'
  delete 'delete_report', to: 'workload_reports#delete_report'
  get '/get_chart_data' , to: 'workload_reports#get_chart_data'
  patch '/update_size_report/:id', to: 'workload_reports#update_size'


  resources :user_workloads do
    delete :user_delete, on: :member
  end
  resources :user_holidays do
    delete :user_delete, on: :member
  end
  # resources :peoples
  resources :workload_apis
  resources :workload_email_templates

  delete '/workload_email_templates/:id', to: 'workload_email_templates#destroy'


  get '/workload', to: 'workloads#index'
  get "/resources_clone", :to => "workloads#clone_data"
  get "/unassigned_issues", :to => "workload_apis#unassigned_issues"
  get "/resources", :to => "workloads#data"
  get "/resource_data", :to => "workloads#time"
  get '/find_users', :to => 'holidays#search_users'
  get '/find_members', :to => 'workload_apis#search_members'
  get '/workload/settings', :to => 'wk_settings#index'
  get '/workload/duration/api', :to => 'workloads#workload_group_API'
  post 'add_teams_members', to: 'workload_apis#create'
  
 
  resources :skills
  resources :workload_dashboards
  # resources :team_member_user
  # resources :workload_reports, only: [:index]
  get 'search_teams', to: 'workloads#filter_by_group'

  
  get 'search_team_users', to: 'workloads#filter_by_users'
  get 'search_unassigned_group_issues', to: 'workload_apis#search_unassigned_issues'
    get "flux_calendar/settings", :to => "workloads#calendar_settings"
    get "flux_resources/settings", :to => "workloads#resource_settings"
 
    get "flux_resources", :to => "skills#update"
  resources :workload_teams
  get 'users_with_teams', to: 'workload_teams#users_with_teams'
  delete 'delete_user_from_team', to: 'workload_teams#delete_user_from_team'
  get "team_data/:id", :to => "workload_teams#users_team_data"
  get "user_data/:id", :to => "workload_teams#user_data"
  post 'user_preferences', to: 'workload_teams#user_preferences'
  delete "delete/multiple/users" , :to => "workload_teams#delete_multiple_users"

  get "team_search_data", :to => "workload_teams#team_search_data"
  delete "delete_data", :to => "workload_teams#delete_team_data"    
  put "holiday_editing/:id", :to => "user_holidays#update"    
  put "workload_editing/:id", :to => "user_workloads#update"    
  put "holiday_date_editing/:id", :to => "holiday_dates#update"    
   put "update_members", :to => "workload_apis#update_members" 
   put "update_edit_members/:id", :to => "workload_apis#update_edit_members" 
  get "members_api", :to => "workload_apis#members_api" 
  get "wk_sk_data/:id", :to => "user_workloads#index" 
  get "wk_hd_data/:id", :to => "user_holidays#index" 
  get "wk_hd_d_data/:id", :to => "holiday_dates#index" 
  delete "wk_delete_bulk", :to => "user_workloads#delete_wk_bulk_data" 
  delete "hd_delete_bulk", :to => "user_workloads#user_hd_delete" 
  delete "delete_bulk_teams", :to => "workload_teams#delete_bulk_teams" 
  delete "delete_bulk_skills", :to => "skills#delete_bulk_skills" 
  delete "holiday_bulk_delete", :to => "user_holidays#holiday_bulk_delete" 
  delete "delete_holiday_dates", :to => "holiday_dates#delete_holiday_dates" 
  delete "bulk_hdd_user_delete", :to => "user_holidays#bulk_hdd_user_delete" 
  get "workload_permissions", :to => "workloads#workload_permissions" 
  put "workload_team_update/:id", :to => "workload_teams#update" 
  get "teams_data/:id", :to => "workload_teams#teams_data" 
  post 'team_preferences', to: 'workload_teams#team_preferences'
  get "selected_teams", :to => "workload_teams#selected_teams" 

  get "dashboard_data", :to => "workload_dashboards#workload_dashboard" 
 
  post "/update_dropdown_preference", to: "workloads#update_dropdown_preference"

# API to delete multiple teams 
delete "/delete/multiple/teams", :to=> "workload_teams#delete_multiple_team"

get 'reports/workload_report', to: 'workload_reports#workload_report', as: 'workload_report'
get 'workload_show_chart_data', to: 'workload_reports#workload_chart_data'
get 'workload_user_data', to: 'workload_reports#workload_user_data'

get 'workload_planned_hours_chart_data', to: 'workload_reports#planned_hours_chart_data'
get 'workload_available_hours_chart_data', to: 'workload_reports#available_hours_chart_data'
get 'workload_reports_table_data', to: 'workload_reports#team_hours_data'

post 'save_filter_data', to: 'workload_reports#save_filter_data'
get 'get_filter_data', to: 'workload_reports#get_filter_data'
end