require_dependency 'issue'

module Patches
    module IssuePatch
        def self.included(base)
            base.class_eval do 
                has_many(:workhours, dependent: :destroy)
                # accepts_nested_attributes_for :workhours
            end 
        end 
    end 
end 

unless Issue.included_modules.include?(Patches::IssuePatch)
    Issue.send(:include, Patches::IssuePatch)
end 