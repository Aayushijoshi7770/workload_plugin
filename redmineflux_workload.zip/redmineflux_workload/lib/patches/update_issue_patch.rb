module Patches
    module UpdateIssuePatch
      def self.included(base)
        base.class_eval do
            puts "code executed"
            safe_attributes 'distribution' 
        end
      end
    end
  end
  
  Issue.send(:include, Patches::UpdateIssuePatch)