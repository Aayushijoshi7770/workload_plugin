$(document).ready(function ()
{

$(".issue_select").click(function(){
  $(this).toggleClass("open_arrow");
})

// issue sidepanel code
  $('.menu_icon').on('click',function(){
      if($('.menu_icon').hasClass('open')){
        $('#menu').css("display","none");
          $(this).removeClass('open');
          $('#gantt_here').css("position","absolute");
          $('#gantt_here').css({
              "width":"96%",
          });
      }
      else{
        $('#menu').css("display","block");
          $(this).addClass('open');
          $('#gantt_here').css("position","absolute");
          $('#gantt_here').css({
              "width":"79.2%",
          });
      
      }
  });


// drag and drop code for issues
  const elem=document.querySelectorAll('.gantt_div');
  elem.forEach(box => {
   box.addEventListener('dragenter', dragEnter)
   box.addEventListener('dragover', dragOver);
   box.addEventListener('dragleave', dragLeave);
   box.addEventListener('drop', drop);
});

window.drag=function(ev)
{  
if(ev.target.className.match("issues-div"))
{

  var issueobj={};
let unassigned_issue=JSON.parse(localStorage.getItem("unassigned_issue"));
unassigned_issue.map((list)=>{
          if(list.id==ev.target.id)
          {
            issueobj=list;
          }
})
  ev.dataTransfer.setData('text/plain',JSON.stringify(issueobj));
  setTimeout(() => {
    ev.target.classList.add('hide');
}, 100);
}

}

function dragEnter(e) {
 e.preventDefault();
 if(e.target.className.match("gantt_task_cell ")||e.target.className.match("parent-bar-style"))
  {
     e.target.classList.add('drag-over');
  }
}

function dragOver(e) {
e.preventDefault();
if(e.target.className.match("gantt_task_cell ") || e.target.className.match("parent-bar-style"))
  {
    e.target.classList.add('drag-over');
  }

}

function dragLeave(e) {

  if(e.target.className.match("gantt_task_cell ") || e.target.className.match("parent-bar-style"))
  {
e.target.classList.remove('drag-over');
  }
}

function drop(e) {

  const id = e.dataTransfer.getData('text/plain');
  var task=JSON.parse(id)
  const draggable = document.getElementById(task.id);
  if(e.target.className.match("gantt_task_cell ") || e.target.className.match("parent-bar-style"))
  {
 
  e.target.classList.remove('drag-over');
  var task_id="i"+task.id;

  var user_id;
  var user_name;
  var cell_date;

  // console.log(e,"e target")
  if(e.target.className=="parent-bar-style"||e.target.className=="span-parent")
  { 
    // console.log("parent cell or span parent")
    user_id=e.target.dataset.userid
    user_name=e.target.dataset.username
    cell_date=e.target.dataset.celldate
  }
  else if(e.target.className.match("gantt_task_cell gantt_last_cell"))
  {
    if(e.target.classList[2]=="weekoff")
    {
      // console.log(e,"gantt last cell child ")
      user_id=e.target.classList[4];
      cell_date=e.target.classList[3];
      user_name=e.target.classList[6];
    }
    else{
      // console.log(e,"gantt last cell parent ")
      user_id=e.target.classList[4];
      cell_date=e.target.classList[3];
      user_name=e.target.classList[5];
    }
 
  }

  else if (e.target.className.match("gantt_task_cell weekend_workload"))
  {
    if(e.target.classList[2]=="task")
    {
      // console.log(e,"gantt task cell task weekend workload")
      user_id=e.target.classList[4];
      cell_date=e.target.classList[3];
      user_name=e.target.classList[6];
    }
    else{
      // console.log(e,"gantt task cell issue weekend workload")
      user_id=e.target.classList[3];
      cell_date=e.target.classList[2];
      user_name=e.target.classList[4];
    }



  }

  else if(e.target.className.match("gantt_task_cell weekoff"))
  {
    // console.log(e,"gantt task cell week off")
    user_id=e.target.classList[3];
    cell_date=e.target.classList[2];
    user_name=e.target.classList[5];
  }
  else if (e.target.className.match("gantt_task_cell open-popup"))
  {
    // console.log(e,"gantt task cell open-popup")
    user_id=e.target.classList[3];
    cell_date=e.target.classList[2];
    user_name=e.target.classList[4]
  }


  let content={
    "start_date":cell_date,
    "due_date":cell_date,
    "assigned_to_id":parseInt(user_id)
  }
  function changedFormat(date) {
    var today = new Date(date);
    var dd = String(today.getDate()).padStart(2, "0");
    var mm = String(today.getMonth() + 1).padStart(2, "0"); //January is 0!
    var yyyy = today.getFullYear();
    return  today = yyyy + "-" + mm + "-" + dd;
  }
  $.ajax({
    type: "PUT",
    url: `${url}/issues/${task.id}.json?key=${api_key}`,
    dataType: "json",
    contentType: "application/json",
    async: false,
    data: JSON.stringify({
      issue: content,
    }),
    success: function (result, status, xhr) {
toastr["success"]("Issue dropped successfully");
var d_date  = new Date(cell_date);
d_date.setDate(d_date.getDate() + 1);
d_date=changedFormat(d_date);
// console.log(typeof user_id,"user id  before add")
      var taskId = gantt.addTask({
        id:task_id,
        text:task.text,
        subject:task.text,
        estimated_hours:task.estimated_hours != null  ? task.estimated_hours+"h" : 0+"h",
        row_height:50,
        bar_height:40,
        start_date:cell_date,
        s_date:cell_date,
        assigned_to_id:user_id,
        assigned_to:user_name,
        description:task.description,
        parent:parseInt(user_id),
        project:{
          name:task.project_name
        },
        due_date:cell_date,
        end_date:d_date,
        tracker:{
          name:task.tracker.name
        }
    }, parseInt(user_id));
    gantt.open(user_id);
    
    let Task=gantt.getTask(task_id);

    let objectDate = new Date(d_date);
    // objectDate.setDate(objectDate.getDate() + 1);
   let day = objectDate.getDate();
   let month = objectDate.getMonth();
   let year = objectDate.getFullYear();

   let objectStartDate=new Date(cell_date);
    let sday = objectStartDate.getDate();
   let smonth = objectStartDate.getMonth();
   let syear = objectStartDate.getFullYear();


    gantt.eachTask(function(list){
      if(list.parent==0)
        {
          if(list.id===parseInt(Task.parent))
          {
            gantt.updateTask(task_id,{id:task_id, 
               wk_scheme:list.wk_scheme,
               holiday:list.holiday,   text:task.text,
               subject:task.text,
               estimated_hours:task.estimated_hours != null  ? task.estimated_hours+"h" : 0+"h",
               row_height:50,
               bar_height:40,
               start_date:new Date(syear,smonth,sday),
               s_date:cell_date,
               assigned_to_id:user_id,
               assigned_to:user_name,
               description:task.description,
               parent:parseInt(user_id),
               project:{
                 name:task.project_name
               },
               due_date:cell_date,
               end_date: new Date(year,month,day),
               tracker:{
                 name:task.tracker.name
               }
              },parseInt(Task.parent))
              gantt.refreshTask(parseInt(Task.parent),0);
          }
     
        }
  });

  resource_data.data.push(gantt.getTask(task_id));
  gantt.render();
 
       },
    error: function (xhr, status, error) {
      // draggable.classList.remove('hide');
        if(xhr.status == 422){
           let content = JSON.parse(xhr.responseText).errors;
          content.map((i)=>{
            if(i==="Due date must be greater than start date")
            {
              toastr["error"]("Start date could not be greater than due date");
            }
            else if(i==="Assignee is invalid")
            {
              toastr["error"]("User is not a member of project to  which this issue belongs please check project setting");
            }
            else{
              toastr["error"](i);
            }
         })
       }
       else if(xhr.status == 403)
       {
           toastr["error"]("You don't have permissions");
       } 
    },
  });
}
else{
  draggable.classList.remove('hide');
}

  }



// add drop on gantt timline area
  document.addEventListener("click", function(evnt){
    var user_id;
    var user_name;
    var cell_date;

    if(evnt.target.className=="parent-bar-style")
    {
      user_id=evnt.target.dataset.userid;
      user_name=evnt.target.dataset.username;
      cell_date=evnt.target.dataset.celldate;
    
    }
    else if(evnt.target.className.match("gantt_last_cell"))
    {
      user_id=evnt.target.classList[4];
      user_name=evnt.target.classList[5];
      cell_date=evnt.target.classList[3];
   
    }
    else {
      user_id=evnt.target.classList[3];
      user_name=evnt.target.classList[4];
      cell_date=evnt.target.classList[2];

    }
    var classes=evnt.target.parentElement.className;
    // console.log(evnt.target.parentElement,"parent")
   if(classes.match("parent")||evnt.target.parentElement.className=="gantt_task_line sub_task gantt_bar_task gantt_dependent_task gantt_selected"||evnt.target.parentElement.className=="gantt_task_row parent gantt_selected"||evnt.target.className=="parent-bar-style")
   {
    var issue_dropdown = $('#issue-drop')
    issue_dropdown.prop('disabled',false);
    $('#issue-drop').css("opacity","revert");
    $('#issue-drop').css("cursor","pointer");

    var user_dropdown = $('#user-drop')
     user_dropdown.prop('disabled', true);
    $('#user-drop').css("opacity","0.7");
    $('#user-drop').css("cursor","default");

    $(".gantt_tooltip").css("display","none");
    $("#txtSearchValueissue").val(" ");
    $("#current-issue").attr("user_id",user_id)
    getIssues(user_id);
    $("#current-issue").removeAttr("value");
        $("#issue-error-div").css("display","none");
        $("#estimated-error-div").css("display","none");
      $("#estimated_hour").val("0h");
      $("#current-issue").html("Search issues...");
       $("#due_date").val(" ");
       $(".text-area-res").val(" ");
        $("#current-user").html(user_name);
        $("#to").css("display","none");
        $("#plan").css("display","none");
        $("#watchers-input").removeAttr("checked");
        $("#current-user").attr("value",user_id);
    let body_div = document.getElementsByClassName("has-main-menu controller-workloads action-index");
    let modal= document.getElementsByClassName("modal");
    let div = document.createElement("div");
           div.className = "div-modal";
           div.style.display = "block";
           body_div[0].appendChild(div);
           body_div[0].appendChild(modal[0]);
           $("#start_date").val(cell_date);
           $('.modal').show();
   }
  })

// show today date in popup code
var today = new Date();
var dd = String(today.getDate()).padStart(2, "0");
var mm = String(today.getMonth() + 1).padStart(2, "0"); //January is 0!
var yyyy = today.getFullYear();
today = yyyy + "-" + mm + "-" + dd;
$("#start_date").val(today);
$("#estimated_hour").val("0h");

})
$(document).on('click', '#issue-drop', function (event) {
  $("#txtSearchValueissue").val(" ");
 var user_id= $("#current-issue").attr("user_id");
 
 getIssues(user_id);
 $("#issue-error-div").css("display","none");
 $("#estimated-error-div").css("display","none");
 


});

$(document).on('click', '#current-user', function (event) {
  $("#txtSearchValueuser").val(" ");
  getUsers();

});
// when user click on project list in workload plugin .....
$(document).on('click', '#project-drop', function (event) {
  $("#txtSearchValueproject").val(" ");

  getProjects();
 
});
$(document).on('click', '#version-drop', function (event) {
  $("#txtSearchValueversion").val(" ");
let oldversion=JSON.parse(localStorage.getItem("versions"));
if(oldversion!=null)
{

   if(oldversion.length>0)
   $("#version-drop ul").html(" ");

      const projects = {};
      oldversion.forEach(item => {
          const projectName = item.project.name;
          if (!projects[projectName]) {
              projects[projectName] = [];
          }
          projects[projectName].push(item);
      });
      
      // Generate HTML
      const ulElement = $('#version-drop ul');
      const projectNames = Object.keys(projects);
      
      if (projectNames.length === 1) {
          // If there is only one project group, append <li> directly
          const projectName = projectNames[0];
          projects[projectName].forEach(version => {
              const listItem = $('<li>')
                  .attr('value', version.id)
                  .attr('data-value', version.id)
                  .addClass('option')
                  .text(version.name);
              ulElement.append(listItem);
          });
      } else {
          // If there are multiple project groups, create <strong> for each
          projectNames.forEach(projectName => {
              const projectHeader = $('<strong>').attr('label', projectName).addClass('opt-version').text(projectName);
              ulElement.append(projectHeader);
              projects[projectName].forEach(version => {
                  const listItem = $('<li>')
                      .attr('value', version.id)
                      .attr('data-value', version.id)
                      .addClass('option')
                      .text(version.name);
                  ulElement.append(listItem);
              });
          });
      }
    
}


});





// show plan time popup code
function showPopup(){
  $("#date-inputs").html("");
  $("#date-inputs").css("display","none");
  $(".workhour-error").css("display","none");
  $(".workhour-div").css("display","none");
  let plantimeDiv=document.getElementById('plan-time-div');
  $("#watchers-input")[0].checked=true;
  // let checkbox=document.getElementById('watchers-input');
  // checkbox.style.display='none';
  plantimeDiv.style.marginBottom='20px';

  var issue_dropdown = $('#issue-drop')
    issue_dropdown.prop('disabled',false);
    $('#issue-drop').css("opacity","revert");
    $('#issue-drop').css("cursor","pointer");

    var user_dropdown = $('#user-drop')
      user_dropdown.prop('disabled', false);
      $('#user-drop').css("opacity","revert");
      $('#user-drop').css("cursor","pointer");
    
    $("#current-issue").attr("user_id",login_user_id);
    $(".gantt_tooltip").css("display","none");
    $("#current-issue").html("Search issues...");
    $("#current-issue").removeAttr("value");
    $("#due_date").val(" ");
    $("#start_date").val("");
    $(".text-area-res").val(" ");
    $("#issue-error-div").css("display","none");
    $("#estimated-error-div").css("display","none");
    $("#current-user").html(login_user);
    // $("#to").css("display","none");
    // $("#plan").css("display","none");
    $("#watchers-input").removeAttr("checked");
    $("#current-user").attr("value",login_user_id);
    $('.modal').show();

    let modal= document.getElementsByClassName("modal");
    let body_div = document.getElementsByClassName("has-main-menu controller-workloads action-index");
    let div = document.createElement("div");
    div.className = "div-modal";
    div.style.display = "block";
    body_div[0].appendChild(div);
    body_div[0].appendChild(modal[0]);


    $("#estimated_hour").val("0h");

    disableTabindex();
 }


// js for disable background tab and scroll

function disableTabindex() {
  if ($('.modal').is(':visible')) {
    $(":tabbable").attr("tabindex", -1);
    $('#team_dropdown').find('input, select').prop('disabled', true);
    $(".modal [tabindex='-1']").attr("tabindex", 0);
    function setTabIndex(elementId) {
      var cursorStyle = $(".modal " + elementId).css("cursor");
      if (cursorStyle === "pointer") {
        $(".modal " + elementId).attr("tabindex", 0);
      } 
      else if (cursorStyle === "default") {
        $(".modal " + elementId).attr("tabindex", -1);
      }
    }
  
  setTabIndex("#user-drop");
  setTabIndex("#issue-drop");

  $("html").css("overflow", "hidden");
  }
  else{
    $("[tabindex='-1']").attr("tabindex", 0);
    $("html").css("overflow", "auto");
    $('#team_dropdown').find('input, select').prop('disabled', false);
  }
}