



$(document).ready(function () {

  // Hide and show Settings popup 
  $('#btn-settings').click(function () {
    $('.modal-holiday').show();
  });
  $('.modal-holiday .close').click(function () {
    $('.modal-holiday').hide();
  });



  // popup
  $('.holiday #members').click(function () {
    $('.modal-search').show();

  });



});

var url = window.location.origin;

// searchUser
function SearchUser() {
  $("#search-user-id").keyup(function () {
    var api_key = '<%= User.current.api_key %>';
    var url = window.location.origin;
    let query_string = $("#search-user-id").val();
    $.ajax({
      type: "GET",
      url: url + `/find_users.json?key=${api_key}`,
      dataType: "json",
      contentType: 'application/json',
      data: {
        name: query_string.trim()
      },
      success: function (result, status, xhr) {
        // console.log(result);
      }
    });
  });

}


// $("#sidebar").append(`<div  class="sidebar-reports ">
// <a  class="btn-reports" id="btn-reports"  ></a></div>`)







window.closeDialog = function () {
  $(':input#wk-users').val('');
  $("#members-input").prop("checked", false);
  $('#scheme-members').hide();
  $('.modal').hide();
  $(".workload-scheme").hide();
  $('.div-modal').hide();
  $('#main.nosidebar #sidebar').show();
  $('#main #sidebar').show();
}






function getDays() {
  $("#dynamic_select_day").on('change', function () {
    var dayoff = $(this).val();
    return dayoff;
  });

}


// Send User Workload id to Workload Scheme to get data according to that

function userWorkload(id) {
  var wkid = id
  $(`.def-wk-scheme${wkid}`).css('display', 'none');

  $.ajax({
    type: "GET",
    url: `${url}/user_workload_scheme.json&sheme_id=${wkid}?key=${api_key}`,
    dataType: "json",
    contentType: "application/json",

    // data: JSON.stringify({
    //   user_id: wkid, workload_id: parseInt(scheme_id)
    // }),
    success: function (result, status, xhr) {


    }, error: function (xhr, status, error) {

    }
  });

}


// holiday schemes 

function closeDialogPlan() {
  $(':input#wk-users').val('');
  $("#members-input").prop("checked", false);
  $('.modal').hide();
  $(".holiday-scheme").hide();
  $('.div-modal').hide();
  $('#main.nosidebar #sidebar').show();
  $('#main #sidebar').show();
  $('#scheme-members').hide();
  $('#wk-scheme').html(" ");
  disableTabindex();
}

function disableTabindex() {
  if ($('.modal, .modal-wk_sk_memb, .modal-wk_hd_memb, .deleteModal').is(':visible')) {
    $(":tabbable").attr("tabindex", -1);
    $('#team_dropdown').find('input, select').prop('disabled', true);
    $(".modal [tabindex='-1'],.modal-wk_sk_memb [tabindex='-1'],.modal-wk_hd_memb [tabindex='-1']").attr("tabindex", 0);
    $(".deleteModal [tabindex='-1']").attr("tabindex", 0);
    function setTabIndex(elementId) {
      var cursorStyle = $(".modal " + elementId).css("cursor");
      if (cursorStyle === "pointer") {
        $(".modal " + elementId).attr("tabindex", 0);
      }
      else if (cursorStyle === "default") {
        $(".modal " + elementId).attr("tabindex", -1);
      }
    }
    setTabIndex("#user-drop");
    setTabIndex("#issue-drop");

    $("html").css("overflow-y", "hidden");
  }
  else {
    $("[tabindex='-1']").attr("tabindex", 0);
    $("html").css("overflow-y", "scroll");
    $('#team_dropdown').find('input, select').prop('disabled', false);
  }
}


function addHolidayMember(id) {
  var scheme_id = id
  let body_div = document.getElementsByClassName("has-main-menu controller-user_holidays action-new");
  let modal = document.getElementsByClassName(".holiday-scheme");
  let div = document.createElement("div");
  div.className = "div-modal";
  div.style.display = "block";
  $('#scheme-members').show();
  $(".holiday-scheme").show();

  $(".holiday-scheme").attr("id", scheme_id);
  $.ajax({
    type: "GET",
    url: `${url}/user_holidays.json?key=${api_key}`,
    dataType: "json",
    async: false,
    success: function (result, status, xhr) {
      $('#dynamic_select_holiday').html(" ");

      if (result.length != 0) {
        result.map((i) => {
          $('#dynamic_select_holiday').append(`<option  value=${i.id}>${i.name}</option>`)
        })
      }

    },
    error: function (xhr, status, error) {
      $('#dynamic_select_holiday').html(" ");
    }
  });

  $.ajax({
    type: "GET",
    url: `${url}/add_members_to_wk_scheme.json?key=${api_key}`,
    dataType: "json",
    async: false,
    success: function (result, status, xhr) {
      data = result;
      if (data.length != 0) {
        data.forEach((i) => {
          $(`#wk-scheme`).append(`<div id="wkscheme-users" class="members" ">
                <div class="wkusers" style="display:flex; flex-direction:row; gap:11px;">
                    <div class="chbox" style="display:flex;">
                      <input class="watch-input" id="members-input"  name= ${i.firstname + " " + i.lastname} value=${i.id} type="checkbox"/>
                    </div>
                    <div style="display:flex;">
                      <span class="members">${i.firstname + " " + i.lastname}</span>
                    </div>
                  </div>
                </div>
                `);
        })
      }

    },
    error: function (xhr, status, error) {

    }
  });


}



function getHolidays() {
  $("#dynamic_select_holiday").on('change', function () {
    var dayoff = $(this).val();
    return dayoff;
  });

}

function myHoliday() {

  var input, filter, table, tr, td, i, txtValue;
  input = document.getElementById("myScheme");
  filter = input.value.toUpperCase();

  tr = document.getElementsByClassName("h_search");

  for (i = 0; i < tr.length; i++) {

    td = tr[i].getElementsByTagName("td")[2];

    if (td) {

      txtValue = td.textContent || td.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
        document.querySelector(".no_data").style.display = "none";
        $(".h_list").show();
      } else {
        tr[i].style.display = "none";

        if ($(".holiday_change tbody tr:not([style='display: none;'])").length == 0) {
          $(".no_data").show();
          document.querySelector(".h_list").style.display = "none";
        }
      }
    }
  }
}
$(document).ready(function () {
  $('.cross_close_scheme_edit').on('click keypress', function (event) {
    if (event.type === 'click' || (event.type === 'keypress' && event.key === 'Enter')) {
      $('.modal-wk_sk_memb').hide();
      $('.modal-bg-scheme_edit').hide();
      $('.modal-wk_sk_memb > #flash_error').hide();
      $(' .modal-wk_sk_memb > #flash_error').html(''); 
      disableTabindex();
    }
  });
  $('.cross_close_hd_scheme_edit').click(function () {
    $('.modal-wk_hd_memb').hide();
    $('.modal-bg-hd-scheme_edit').hide();
    $('.modal-wk_hd_memb > #flash_error').hide();
    $('.modal-wk_hd_memb > #flash_error').html('');
    disableTabindex();
    // window.history.go(-1); return false;
  })
  $('.cross_close_hd_d_scheme_edit').click(function () {
    $('.modal-wk_hd_d_memb').hide();
    $('.modal-bg-hd-d-scheme_edit').hide();
    $('.modal-wk_hd_d_memb > #flash_error').hide();
    $('.modal-wk_hd_d_memb > #flash_error').html('');
    // window.history.go(-1); return false;
  })
  $('.cross_close_holiday').click(function () {
    $('.modal_holiday_edit').hide();
    $('.modal-holiday_edit').hide();
    window.history.go(-1); return false;
  })
  $('.close_edit_holiday').click(function () {
    var u_r_l = location.origin
    location.href = `${u_r_l}/skills`
  })
})



function myWorkload() {

  var input, filter, table, tr, td, i, txtValue;
  input = document.getElementById("myWscheme");
  filter = input.value.toUpperCase();

  tr = document.getElementsByClassName("w_search");

  for (i = 0; i < tr.length; i++) {

    td = tr[i].getElementsByTagName("td")[2];

    if (td) {

      txtValue = td.textContent || td.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
        document.querySelector(".no_data").style.display = "none";
        $(".w_list").show();
      } else {
        tr[i].style.display = "none";

        if ($(".workload_change tbody tr:not([style='display: none;'])").length == 0) {
          $(".no_data").show();
          document.querySelector(".w_list").style.display = "none";
        }
      }
    }
  }
}
function wk_scheme_click(id) {
  document.getElementById('scheme_edit_submit').disabled = true;
  document.getElementById('scheme_edit_submit').style.cursor = "not-allowed";
  $('.wk_name_up').removeClass('not_allowed');
  $('.wk_description_up').removeClass('not_allowed');
  localStorage.setItem("wk_scheme_id", id);
  $('.modal-wk_sk_memb').show();
  $('.modal-bg-scheme_edit').show();
  disableTabindex();

  $.ajax({
    type: "GET",
    url: `${url}/wk_sk_data/${id}.json?key=${api_key}`,
    dataType: 'json',
    async: false,
    success: function (result, status, xhr) {
      users = result

      users.forEach((value, i) => {
        $('.wk_name_up').val(value.name);
        $('.wk_description_up').val(value.description);
        $('.wk_wd0_up').val(value.wd0);
        $('.wk_wd1_up').val(value.wd1);
        $('.wk_wd2_up').val(value.wd2);
        $('.wk_wd3_up').val(value.wd3);
        $('.wk_wd4_up').val(value.wd4);
        $('.wk_wd5_up').val(value.wd5);
        $('.wk_wd6_up').val(value.wd6);
        if (value.name.toLowerCase() === "default") {
          $('.wk_name_up').attr('readonly', 'readonly');
          $('.wk_name_up').addClass('not_allowed');
          $('.wk_description_up').addClass('not_allowed');
          $('.wk_description_up').attr('readonly', 'readonly');
        } else {
          $('.wk_name_up').removeAttr('readonly');
          $('.wk_description_up').removeAttr('readonly');
        }
      })

    },
    error: function (xhr, status, error) {
    }
  });
}

function SchemeEdit() {
  var workloadId = localStorage.getItem('wk_scheme_id')
  var name = $('.wk_name_up').val();;
  var description = $('.wk_description_up').val();
  var wd0 = $('.wk_wd0_up').val();
  var wd1 = $('.wk_wd1_up').val();
  var wd2 = $('.wk_wd2_up').val();
  var wd3 = $('.wk_wd3_up').val();
  var wd4 = $('.wk_wd4_up').val();
  var wd5 = $('.wk_wd5_up').val();
  var wd6 = $('.wk_wd6_up').val();
  $.ajax({
    url: `/workload_editing/${workloadId}.json?key=${api_key}`,
    method: 'PUT',
    data: {

      name: name,
      description: description,
      wd0: wd0,
      wd1: wd1,
      wd2: wd2,
      wd3: wd3,
      wd4: wd4,
      wd5: wd5,
      wd6: wd6


    },
    success: function (response) {
      top.window.onbeforeunload = null;


      window.location.reload();
      // Handle success response
    },
    error: function (response) {
      top.window.onbeforeunload = null;
      if (response.responseJSON && response.responseJSON.error) {
        var errorMessages = response.responseJSON.error;
        var listItems = errorMessages.map(function (errorMessage) {
          return '<li>' + errorMessage + '</li>'; 
        }).join('');
        $('.modal-wk_sk_memb > #flash_error').html('<ul class="error-list">' + listItems + '</ul>').show(); 
      } 
    }
  });

}
function hd_scheme_click(id) {
   let holiday_scheme_update_button=document.getElementById('hd_scheme_edit_submit');
   if(holiday_scheme_update_button){
     holiday_scheme_update_button.disabled=true;
     holiday_scheme_update_button.style.cursor='not-allowed';
   }
  localStorage.setItem("hd_scheme_id", id);
  $('.modal-wk_hd_memb').show();
  $('.modal-bg-hd-scheme_edit').show();
  disableTabindex();

  $.ajax({
    type: "GET",
    url: `${url}/wk_hd_data/${id}.json?key=${api_key}`,
    dataType: 'json',
    async: false,
    success: function (result, status, xhr) {
      users = result

      users.forEach((value, i) => {
        $('.hd_name_up').val(value.name);
        $('.hd_description_up').val(value.description);
      })

    },
    error: function (xhr, status, error) {
    }
  });
}

function SchemeHdEdit() {
  var holidayId = localStorage.getItem('hd_scheme_id')
  var name = $('.hd_name_up').val();
  var description = $('.hd_description_up').val();
  $.ajax({
    url: `/holiday_editing/${holidayId}.json?key=${api_key}`,
    method: 'PUT',
    data: {
      name: name,
      description: description
    },
    success: function (response) {
      top.window.onbeforeunload = null;
      location.reload();
      // Handle success response
    },
    error: function (response) {
      top.window.onbeforeunload = null;
      if (response.responseJSON && response.responseJSON.error) {
        var errorMessages = response.responseJSON.error;
        var listItems = errorMessages.map(function (errorMessage) {
          return '<li>' + errorMessage + '</li>'; 
        }).join('');
        $('.modal-wk_hd_memb > #flash_error').html('<ul class="error-list">' + listItems + '</ul>').show();
      } 
    }
  });
}

function hd_d_scheme_click(id) {
  localStorage.setItem("hd_d_scheme_id", id);
  $('.modal-wk_hd_d_memb').show();
  $('.modal-bg-hd-d-scheme_edit').show();
  $.ajax({
    type: "GET",
    url: `${url}/wk_hd_d_data/${id}.json?key=${api_key}`,
    dataType: 'json',
    async: false,
    success: function (result, status, xhr) {
      users = result

      users.forEach((value, i) => {
        $('.hd_d_name_up').val(value.name);
        $('.hd_d_description_up').val(value.description);
        $('#start_date').val(value.start_date);
        $("#end_date").val(value.end_date)
      })

    },
    error: function (xhr, status, error) {
    }
  });
}
function SchemeHdDEdit() {
  var holidayId = localStorage.getItem('hd_d_scheme_id')
  var name = $('.hd_d_name_up').val();;
  var description = $('.hd_d_description_up').val();
  var start_date = $('#start_date').val();
  var end_date = $('#end_date').val();
  $.ajax({
    url: `/holiday_date_editing/${holidayId}.json?key=${api_key}`,
    method: 'PUT',
    data: {
      name: name,
      description: description,
      start_date: start_date,
      end_date: end_date
    },
    success: function (response) {
      top.window.onbeforeunload = null;
      location.reload();
      // Handle success response
    },
    error: function (response) {
      top.window.onbeforeunload = null;
      if (response.responseJSON && response.responseJSON.error) {
        var errorMessages = response.responseJSON.error;
        var listItems = errorMessages.map(function (errorMessage) {
          return '<li>' + errorMessage + '</li>'; 
        }).join('');
        $('.modal-wk_hd_d_memb > #flash_error').html('<ul class="error-list">' + listItems + '</ul>').show(); 
      } 
    }
  });

}



// function wk_scheme_ids(id) {
//   if ($('.checkbox_members:checked').length > 0) {
//     const table = $('.workload_change');
//     const checkboxIds = [];
//     table.find('td input[type="checkbox"]:checked').each(function () {
//       checkboxIds.push($(this).attr('value'));
//     });
//     // $('.modal-members-delete').show();
//     // $('.modal-bg-members_delete').show();
//     // const deleteLink = $('#wkDelete');
//     // deleteLink.on('click', function (event) {
//     //   event.preventDefault();
//     const confirmDelete = confirm("Are you sure you want to delete the selected workloads?");
//     if (confirmDelete) {
//       const checkboxdeleteIds = [];
//       table.find('td input[type="checkbox"]:checked').each(function () {
//         checkboxdeleteIds.push($(this).attr('id'));
//       });

//       $.ajax({
//         type: "DELETE",
//         url: `${url}/wk_delete_bulk.json?key=${api_key}&&id=${checkboxdeleteIds}`,
//         contentType: "application/json",
//         dataType: "json",
//       });

//       setTimeout(() => {
//         location.reload();
//       }, 500);
//     }
//     // });
//   } else {
//     const confirmDelete = confirm("Are you sure you want to delete this workload?");
//     if (confirmDelete) {
//       $.ajax({
//         type: "DELETE",
//         url: `${url}/wk_delete_bulk.json?key=${api_key}&&id=${id}`,
//         contentType: "application/json",
//         dataType: "json",
//       });

//       setTimeout(() => {
//         location.reload();
//       }, 500);
//     }
//   }
// }

function wk_scheme_ids(id) {
  if ($('.checkbox_members:checked').length > 1) {
    const table = $('.workload_change');
    const checkboxIds = [];
    table.find('td input[type="checkbox"]:checked').each(function () {
      checkboxIds.push($(this).attr('value'));
    });

    const checkboxdeleteIds = [];
    table.find('td input[type="checkbox"]:checked').each(function () {
      checkboxdeleteIds.push($(this).attr('id'));
    });
    $('#modalMessage').text("Are you sure you want to delete the selected workload scheme?");
    $('#modalheading').text("Delete Workload Scheme");
    $('#deleteWorkload').css('display', 'block');
    $('.modal-bg-members_delete').show();

    $('#confirmBtn').click(function () {
      $('#deleteWorkload').css('display', 'none');
      $('.modal-bg-members_delete').hide();
      $.ajax({
        type: "DELETE",
        url: `${url}/wk_delete_bulk.json?key=${api_key}&&id=${checkboxdeleteIds}`,
        contentType: "application/json",
        dataType: "json",
        success: function () {
          location.reload();
        },
        error: function (error) {
          console.error("Error deleting item:", error);
        }
      });
    });

    $('#cancelBtn').click(function () {
      $('#deleteWorkload').css('display', 'none');
      $('.modal-bg-members_delete').hide();
      disableTabindex();
    });
  } 
  else {
    $('#modalMessage').text("Are you sure you want to delete this workload schemes?");
    $('#modalheading').text("Delete Workload Schemes");
    $('#deleteWorkload').css('display', 'block');
    $('.modal-bg-members_delete').show();

    $('#confirmBtn').click(function () {
      $('#deleteWorkload').css('display', 'none');
      $('.modal-bg-members_delete').hide();
      $.ajax({
        type: "DELETE",
        url: `${url}/wk_delete_bulk.json?key=${api_key}&&id=${id}`,
        contentType: "application/json",
        dataType: "json",
        success: function () {
          location.reload();
        },
        error: function (error) {
          console.error("Error deleting item:", error);
        }
      });
    });

    $('#cancelBtn').click(function () {
      $('#deleteWorkload').css('display', 'none');
      $('.modal-bg-members_delete').hide();
      disableTabindex();
    });
  }
  disableTabindex();
}


//delete holiday schemes
function hd_scheme_ids(id) {
  if ($('.checkbox_holiday:checked').length > 1) {
    const table3 = $('.holiday_change');
    const checkboxIds = [];
    table3.find('td input[type="checkbox"]:checked').each(function () {
      checkboxIds.push($(this).attr('value'));
    });

    const checkboxdeleteIds3 = [];
    table3.find('td input[type="checkbox"]:checked').each(function () {
      checkboxdeleteIds3.push($(this).attr('id'));
    });

    $('#modalMessage').text("Are you sure you want to delete the selected holiday schemes?");
    $('#modalheading').text("Delete Holiday Schemes");
    $('#deleteHoliday').css('display', 'block');
    $('.modal-bg-members_delete').show();

    $('#confirmBtn').click(function () {
      $('#deleteHoliday').css('display', 'none');
      $('.modal-bg-members_delete').hide();
      $.ajax({
        type: "DELETE",
        url: `${url}/holiday_bulk_delete.json?key=${api_key}&&id=${checkboxdeleteIds3}`,
        contentType: "application/json",
        dataType: "json",
        success: function () {
          location.reload();
					window.location=window.location;
        },
        error: function (error) {
          console.error("Error deleting item:", error);
        }
      });
    });

    $('#cancelBtn').click(function () {
      $('#deleteHoliday').css('display', 'none');
      $('.modal-bg-members_delete').hide();
      disableTabindex();
    });
  } 
  else {
    $('#modalMessage').text("Are you sure you want to delete this holiday scheme?");
    $('#modalheading').text("Delete Holiday Scheme");
    $('#deleteHoliday').css('display', 'block');
    $('.modal-bg-members_delete').show();

    $('#confirmBtn').click(function () {
      $('#deleteHoliday').css('display', 'none');
      $('.modal-bg-members_delete').hide();
      $.ajax({
        type: "DELETE",
        url: `${url}/holiday_bulk_delete.json?key=${api_key}&&id=${id}`,
        contentType: "application/json",
        dataType: "json",
        success: function () {
          location.reload();
					window.location=window.location;
        },
        error: function (error) {
          console.error("Error deleting item:", error);
        }
      });
    });

    $('#cancelBtn').click(function () {
      $('#deleteHoliday').css('display', 'none');
      $('.modal-bg-members_delete').hide();
      disableTabindex();
    });
  }
  disableTabindex();
}
//delete holiday schemes end




//delete workload members
function wk_memb_scheme_ids(id) {
  if ($('.checkbox_hd_members:checked').length > 0) {
    const table1 = $('.wk_details_change2');
    const checkboxIds = [];

    table1.find('td input[type="checkbox"]:checked').each(function () {
      checkboxIds.push($(this).attr('value'));
    });

    const checkboxdeleteIds1 = [];

    table1.find('td input[type="checkbox"]:checked').each(function () {
      checkboxdeleteIds1.push($(this).attr('id'));
    });

    $('#modalMessage').text("Are you sure you want to delete the selected members?");
    $('#modalheading').text("Delete Members");
    $('#deleteHoliday').css('display', 'block');
    $('.modal-bg-members_delete').show();

    $('#confirmBtn').click(function () {
      $('#deleteHoliday').css('display', 'none');
      $('.modal-bg-members_delete').hide();
      $.ajax({
        type: "DELETE",
        url: `${url}/hd_delete_bulk.json?key=${api_key}&&id=${checkboxdeleteIds1}`,
        contentType: "application/json",
        dataType: "json",
        success: function () {
          location.reload();
					window.location=window.location;
        },
        error: function (error) {
          console.error("Error deleting item:", error);
        }
      });
    });

    $('#cancelBtn').click(function () {
      $('#deleteHoliday').css('display', 'none');
      $('.modal-bg-members_delete').hide();
      disableTabindex();
    });
  } 
  else {
    $('#modalMessage').text("Are you sure you want to delete this member?");
    $('#modalheading').text("Delete Member");
    $('#deleteHoliday').css('display', 'block');
    $('.modal-bg-members_delete').show();

    $('#confirmBtn').click(function () {
      $('#deleteHoliday').css('display', 'none');
      $('.modal-bg-members_delete').hide();
      $.ajax({
        type: "DELETE",
        url: `${url}/hd_delete_bulk.json?key=${api_key}&&id=${id}`,
        contentType: "application/json",
        dataType: "json",
        success: function () {
          location.reload();
					window.location=window.location;
        },
        error: function (error) {
          console.error("Error deleting item:", error);
        }
      });
    });

    $('#cancelBtn').click(function () {
      $('#deleteHoliday').css('display', 'none');
      $('.modal-bg-members_delete').hide();
      disableTabindex();
    });
  }
  disableTabindex();
}
//delete workload members end

//delete holiday members
function hd_membs_scheme_ids(id) {
  if ($('.checkbox_hdates_members:checked').length > 0) {
    const table5 = $('.wk_details_change1');
    const checkboxIds = [];

    table5.find('td input[type="checkbox"]:checked').each(function () {
      checkboxIds.push($(this).attr('value'));
    });

    const checkboxdeleteIds5 = [];

    table5.find('td input[type="checkbox"]:checked').each(function () {
      checkboxdeleteIds5.push($(this).attr('id'));
    });

    $('#modalMessage').text("Are you sure you want to delete the selected members?");
    $('#modalheading').text("Delete Members");
    $('#deleteHoliday').css('display', 'block');
    $('.modal-bg-hd-d-scheme_edit').show();

    $('#confirmBtn').click(function () {
      $('#deleteHoliday').css('display', 'none');
      $('.modal-bg-hd-d-scheme_edit').hide();
      $.ajax({
        type: "DELETE",
        url: `${url}/bulk_hdd_user_delete.json?key=${api_key}&&id=${checkboxdeleteIds5}`,
        contentType: "application/json",
        dataType: "json",
        success: function () {
          location.reload();
					window.location=window.location;
        },
        error: function (error) {
          console.error("Error deleting item:", error);
        }
      });
    });

    $('#cancelBtn').click(function () {
      $('#deleteHoliday').css('display', 'none');
      $('.modal-bg-hd-d-scheme_edit').hide();
      disableTabindex();
    });
  }
  else {
   
    $('#modalMessage').text("Are you sure you want to delete this member?");
    $('#modalheading').text("Delete Member");
    $('#deleteHoliday').css('display', 'block');
    $('.modal-bg-hd-d-scheme_edit').show();

    $('#confirmBtn').click(function () {
      $('#deleteHoliday').css('display', 'none');
      $('.modal-bg-hd-d-scheme_edit').hide();
      $.ajax({
        type: "DELETE",
        url: `${url}/bulk_hdd_user_delete.json?key=${api_key}&&id=${id}`,
        contentType: "application/json",
        dataType: "json",
        success: function () {
          location.reload();
					window.location=window.location;
        },
        error: function (error) {
          console.error("Error deleting item:", error);
        }
      });
    });

    $('#cancelBtn').click(function () {
      $('#deleteHoliday').css('display', 'none');
      $('.modal-bg-hd-d-scheme_edit').hide();
      disableTabindex();
    });
  }
  disableTabindex();
}
//delete holiday members end

//delete holiday dates
function hd_dates_scheme_ids(id) {
  if ($('.checkbox_hdates:checked').length > 0) {
    console.log("More checkbox")
    const table4 = $('.hdates_change');
    const checkboxIds = [];
    table4.find('td input[type="checkbox"]:checked').each(function () {
      checkboxIds.push($(this).attr('value'));
    });

    const checkboxdeleteIds4 = [];
    table4.find('td input[type="checkbox"]:checked').each(function () {
      checkboxdeleteIds4.push($(this).attr('id'));
    });
    $('#modalheading').text("Delete Holiday Dates");
    $('#modalMessage').text("Are you sure you want to delete the selected holiday dates?");
    $('#deleteHoliday').css('display', 'block');
    $('.modal-bg-hd-d-scheme_edit').show();
    $('#confirmBtn').click(function () {
    $('#deleteHoliday').css('display', 'none');
    $('.modal-bg-hd-d-scheme_edit').hide();
    var url = window.location.origin;
    var currentUrl = window.location.href;
    var urlParts = currentUrl.split('/');
    var user_holiday_id = urlParts[urlParts.length - 3];
    var form = document.getElementById('bulkdeleteForm');
    const all_Ids=checkboxdeleteIds4.join(',');
    const urlTemplate = form.getAttribute('action');
    const actionUrl=urlTemplate.replace('holiday_id_user', user_holiday_id).replace('f_id', all_Ids);
    form.setAttribute('action', actionUrl);
    form.submit();
    });
    $('#cancelBtn').click(function () {
      $('#deleteHoliday').css('display', 'none');
      $('.modal-bg-hd-d-scheme_edit').hide();
      disableTabindex();
    });
  } else {
    $('#modalheading').text("Delete Holiday Date");
    $('#modalMessage').text("Are you sure you want to delete this holiday date?");
    $('#deleteHoliday').css('display', 'block');
    $('.modal-bg-hd-d-scheme_edit').show();
    $('#confirmBtn').click(function () {
      $('#deleteHoliday').css('display', 'none');
      $('.modal-bg-hd-d-scheme_edit').hide();
      const form = document.getElementById('deleteForm_'+id);
      form.submit();
    });
    $('#cancelBtn').click(function () {
      $('#deleteHoliday').css('display', 'none');
      $('.modal-bg-hd-d-scheme_edit').hide();
      disableTabindex();
    });
  }
  disableTabindex();
}

//delete holiday dates end

const input = document.getElementById('team_name');
if (input) {
  input.addEventListener('keyup', function (event) {
    if (event.key === 'Enter') {
      document.getElementById('create_team').click();
    }
  });
}

const input1 = document.getElementById('skill_name');
if (input1) {
  input1.addEventListener('keyup', function (event) {
    if (event.key === 'Enter') {
      document.getElementById('skill_submit').click();
    }
  });
}
// $(document).ready(function(){
//   function updateEditIcons() {
//     const checkedCheckboxes = $('.checkbox_hdates:checked').length;
//     if (checkedCheckboxes > 1) {
//       $('.icon-edit').css({
//         'pointer-events': 'none',
//         'opacity': '0.5'
//       });
//     } else {
//       $('.icon-edit').css({
//         'pointer-events': 'auto',
//         'opacity': '1'
//       });
//     }
//   }
//   $('.checkbox_hdates').change(function() {
//     updateEditIcons();
//   });
//   $('#select-all-hdates-checkbox').change(function() {
//     const isChecked = $(this).is(':checked');
//     $('.checkbox_hdates').prop('checked', isChecked);
//     updateEditIcons();
//   });
//   updateEditIcons();
// })




// Function to disable bulk edit

$(document).ready(function() {
  // for workload schemes
  function checkMemberCheckBoxes() {
    var numChecked = $('.workload_change .checkbox_members:checked').length;
    if ($('.workload_change #select-all-checkbox').is(':checked')) {
        // If select all checkbox is checked, add class only if more than one checkbox is checked
        if (numChecked > 1) {
            $('.icon-edit').addClass('disable_edit');
        } else {
            $('.icon-edit').removeClass('disable_edit');
        }
    } else {
        // If select all checkbox is not checked
        if (numChecked > 1) {
            $('.workload_change .checkbox_members:checked').each(function() {
                $(this).closest('tr').find('.icon-edit').addClass('disable_edit');
            });
        } else {
            $('.workload_change .checkbox_members:not(:checked)').each(function() {
                $(this).closest('tr').find('.icon-edit').removeClass('disable_edit');
            });
        }
    }
}

  
  $(document).on('change', '.checkbox_members', function() {
    if (!this.checked && $('.workload_change #select-all-checkbox').is(':checked')) {
      $('.workload_change #select-all-checkbox').prop('checked', false);
    }
    var allChecked = $('.workload_change .checkbox_members').length === $('.workload_change .checkbox_members:checked').length;
    $('.workload_change #select-all-checkbox').prop('checked', allChecked);
    checkMemberCheckBoxes();
  });
  
  $('.workload_change #select-all-checkbox').change(function() {
    $('.workload_change .checkbox_members').prop('checked', this.checked);
    checkMemberCheckBoxes();
  });
  
  // for holiday schemes
  function checkHolidayCheckBoxes() {
    var numChecked = $('.checkbox_holiday:checked').length;
    if ($('#select-all-holiday-checkbox').is(':checked')) {
        // If select all checkbox is checked, add class only if more than one checkbox is checked
        if (numChecked > 1) {
            $('.icon-edit').addClass('disable_edit');
        } else {
            $('.icon-edit').removeClass('disable_edit');
        }
    } else {
        // If select all checkbox is not checked
        if (numChecked > 1) {
            $('.checkbox_holiday:checked').each(function() {
                $(this).closest('tr').find('.icon-edit').addClass('disable_edit');
            });
        } else {
            $('.checkbox_holiday:not(:checked)').each(function() {
                $(this).closest('tr').find('.icon-edit').removeClass('disable_edit');
            });
        }
    }
}

  
    $(document).on('change', '.checkbox_holiday', function() {
      if (!this.checked && $('#select-all-holiday-checkbox').is(':checked')) {
        $('#select-all-holiday-checkbox').prop('checked', false);
      }
      var allChecked = $('.checkbox_holiday').length === $('.checkbox_holiday:checked').length;
      $('#select-all-holiday-checkbox').prop('checked', allChecked);
      checkHolidayCheckBoxes();
    });
  
    $('#select-all-holiday-checkbox').change(function() {
      $('.checkbox_holiday').prop('checked', this.checked);
      checkHolidayCheckBoxes();
    });
  
  // for holiday dates
  function checkHolidayDatesCheckBoxes() {
    var numChecked = $('.checkbox_hdates:checked').length;
    if ($('#select-all-hdates-checkbox').is(':checked')) {
        // If select all checkbox is checked, add class only if more than one checkbox is checked
        if (numChecked > 1) {
            $('.icon-edit').addClass('disable_edit');
        } else {
            $('.icon-edit').removeClass('disable_edit');
        }
    } else {
        // If select all checkbox is not checked
        if (numChecked > 1) {
            $('.checkbox_hdates:checked').each(function() {
                $(this).closest('tr').find('.icon-edit').addClass('disable_edit');
            });
        } else {
            $('.checkbox_hdates:not(:checked)').each(function() {
                $(this).closest('tr').find('.icon-edit').removeClass('disable_edit');
            });
        }
    }
}

  
    $(document).on('change', '.checkbox_hdates', function() {
      if (!this.checked && $('#select-all-hdates-checkbox').is(':checked')) {
        $('#select-all-hdates-checkbox').prop('checked', false);
      }
      var allChecked = $('.checkbox_hdates').length === $('.checkbox_hdates:checked').length;
      $('#select-all-hdates-checkbox').prop('checked', allChecked);
      checkHolidayDatesCheckBoxes();
    });
  
    $('#select-all-hdates-checkbox').change(function() {
      $('.checkbox_hdates').prop('checked', this.checked);
      checkHolidayDatesCheckBoxes();
    });
  
  // for workload scheme members
    $(document).on('change', '.checkbox_hd_members', function() {
      if (!this.checked && $('#select-all-hd-checkbox').is(':checked')) {
        $('#select-all-hd-checkbox').prop('checked', false);
      }
      var allChecked = $('.checkbox_hd_members').length === $('.checkbox_hd_members:checked').length;
      $('#select-all-hd-checkbox').prop('checked', allChecked);
    });
  
    $('#select-all-hd-checkbox').change(function() {
      $('.checkbox_hd_members').prop('checked', this.checked);
    });
  
  // for holiday dates members
    $(document).on('change', '.checkbox_hdates_members', function() {
      if (!this.checked && $('#select-all-hdatesmembers-checkbox').is(':checked')) {
        $('#select-all-hdatesmembers-checkbox').prop('checked', false);
      }
      var allChecked = $('.checkbox_hdates_members').length === $('.checkbox_hdates_members:checked').length;
      $('#select-all-hdatesmembers-checkbox').prop('checked', allChecked);
    });
  
    $('#select-all-hdatesmembers-checkbox').change(function() {
      $('.checkbox_hdates_members').prop('checked', this.checked);
    });
  
  // for add members input
  $(document).on('change', '#select-all', function() {
    $('.watch-input').prop('checked', this.checked);
  });
  
  $(document).on('change', '.watch-input', function() {
    // If any checkbox is unchecked while select-all-checkbox is checked, uncheck select-all-checkbox
    if (!this.checked && $('#select-all').is(':checked')) {
        $('#select-all').prop('checked', false);
    }
    // Check if all individual checkboxes are checked
    var allChecked = $('.watch-input').length === $('.watch-input:checked').length;
    $('#select-all').prop('checked', allChecked);
  });
  
  });
  

//Enable delete icon only for selected rows
$(document).ready(function () {
 
  $('.checkbox_members').change(function () {
      // Get all checked checkboxes
      var checkedCheckboxes = $('.checkbox_members:checked');
      
      // Enable delete icons for all checked rows
      checkedCheckboxes.each(function () {
          $(this).closest('tr').find('.wk_tc').removeClass('disabled');
      });
      
      // Disable delete icons for all unchecked rows
      $('.checkbox_members').not(':checked').each(function () {
          $(this).closest('tr').find('.wk_tc').addClass('disabled');
      });

      // If no checkboxes are checked, enable all delete icons
      if (checkedCheckboxes.length === 0) {
          $('.wk_tc').removeClass('disabled');
      }
  });

  $('#select-all-checkbox').change(function () {
      var isChecked = $(this).is(':checked');
      $('.checkbox_members').prop('checked', isChecked).trigger('change');
  });
  $('.checkbox_members').trigger('change');

  //Workload Scheme
  $('.checkbox_hd_members').change(function () {
      // Get all checked checkboxes
      var checkedCheckboxes = $('.checkbox_hd_members:checked');
      
      // Enable delete icons for all checked rows
      checkedCheckboxes.each(function () {
          $(this).closest('tr').find('.icon-del').removeClass('disabled');
      });
      
      // Disable delete icons for all unchecked rows
      $('.checkbox_hd_members').not(':checked').each(function () {
          $(this).closest('tr').find('.icon-del').addClass('disabled');
      });

      // If no checkboxes are checked, enable all delete icons
      if (checkedCheckboxes.length === 0) {
          $('.icon-del').removeClass('disabled');
      }
  });

  $('#select-all-hd-checkbox').change(function () {
      var isChecked = $(this).is(':checked');
      $('.checkbox_hd_members').prop('checked', isChecked).trigger('change');
  });
  $('.checkbox_hd_members').trigger('change');

  //Holiday Scheme

  $('.checkbox_holiday').change(function () {
      // Get all checked checkboxes
      var checkedCheckboxes = $('.checkbox_holiday:checked');
      
      // Enable delete icons for all checked rows
      checkedCheckboxes.each(function () {
          $(this).closest('tr').find('.icon-del').removeClass('disabled');
      });

      // Disable delete icons for all unchecked rows
      $('.checkbox_holiday').not(':checked').each(function () {
          $(this).closest('tr').find('.icon-del').addClass('disabled');
      });

      // If no checkboxes are checked, enable all delete icons
      if (checkedCheckboxes.length === 0) {
          $('.icon-del').removeClass('disabled');
      }
  });
  $('#select-all-holiday-checkbox').change(function () {
    var isChecked = $(this).is(':checked');
    $('.checkbox_holiday').prop('checked', isChecked).trigger('change');
  });
  $('.checkbox_holiday').trigger('change');


  //Holiday Dates
  $('.checkbox_hdates').change(function () {
    // Get all checked checkboxes
    var checkedCheckboxes = $('.checkbox_hdates:checked');
    
    // Enable delete icons for all checked rows
    checkedCheckboxes.each(function () {
        $(this).closest('tr').find('.icon-del').removeClass('disabled');
    });

    // Disable delete icons for all unchecked rows
    $('.checkbox_hdates').not(':checked').each(function () {
        $(this).closest('tr').find('.icon-del').addClass('disabled');
    });

    // If no checkboxes are checked, enable all delete icons
    if (checkedCheckboxes.length === 0) {
        $('.icon-del').removeClass('disabled');
    }
  });
  $('#select-all-hdates-checkbox').change(function () {
  var isChecked = $(this).is(':checked');
  $('.checkbox_hdates').prop('checked', isChecked).trigger('change');
  });
  $('.checkbox_hdates').trigger('change');

  // Holiday Dates Members

  $('.checkbox_hdates_members').change(function () {
    // Get all checked checkboxes
    var checkedCheckboxes = $('.checkbox_hdates_members:checked');
    
    // Enable delete icons for all checked rows
    checkedCheckboxes.each(function () {
        $(this).closest('tr').find('.icon-del').removeClass('disabled');
    });

    // Disable delete icons for all unchecked rows
    $('.checkbox_hdates_members').not(':checked').each(function () {
        $(this).closest('tr').find('.icon-del').addClass('disabled');
    });

    // If no checkboxes are checked, enable all delete icons
    if (checkedCheckboxes.length === 0) {
        $('.icon-del').removeClass('disabled');
    }
  });
  $('#select-all-hdatesmembers-checkbox').change(function () {
  var isChecked = $(this).is(':checked');
  $('.checkbox_hdates_members').prop('checked', isChecked).trigger('change');
  });
  $('.checkbox_hdates_members').trigger('change');

});