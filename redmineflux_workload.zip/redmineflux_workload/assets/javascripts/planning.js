$(document).ready(function(){
    // Function to add planning alert class based on percentage
    function addPlanningAlertClass(percentage) {
      if (percentage > 100) {
        return "green_alert";
      } else if (percentage >= 90 && percentage <= 100) {
        return "green_alert";
      } else if (percentage >= 75 && percentage <= 89) {
        return "yellow_alert";
      } else if (percentage >= 60 && percentage <= 74) {
        return "orange_alert";
      } else {
        return "red_alert";
      }
    }
    
    
      // Get all the rows from the table body
      const tableBody = document.querySelector("tbody.planning_table");
  
      if (tableBody) {
      const rows = tableBody.querySelectorAll("tr");
    
      // Loop through each row and set the planning alert class
      rows.forEach((row) => {
        // Get the last cell (td) containing the planning percentage
        const planningCell = row.querySelector("td:last-child");
        if (planningCell) {
          // Extract the planning percentage from the cell
          const planningPercentage = parseFloat(planningCell.textContent);
    
          // Add the appropriate class to the row based on the planning percentage
          const planningAlertClass = addPlanningAlertClass(planningPercentage);
          // row.classList.add(planningAlertClass);
          planningCell.classList.add(planningAlertClass);
        }
      });
    }
  
  });