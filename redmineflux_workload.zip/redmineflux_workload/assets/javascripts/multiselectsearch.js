//Call jQuery before below code
$(document).ready((function(){
    $('.main-btn').click(function() {
        // console.log("click the")
        $('.search-description').slideToggle(100);
      });
      $('.search-description').change(function() {
        // if (this.defaultValue == this.value) {
        //   this.value = ""
        // }
        $('.main-input').hide();
        var target = $(this).children("option:selected").val();
        var toRemove = 'By ';
        var newTarget = target.replace(toRemove, '');
        console.log(newTarget,"new target");
        //remove spaces
        newTarget = newTarget.replace(/\s/g, '');
        console.log(newTarget,"new Target")
        $(".search-large").html(newTarget);
        // $('.search-description').hide();
        $('.main-input').hide();
        newTarget = newTarget.toLowerCase();
        $('.main-' + newTarget).show();
      });
      $('#main-submit-mobile').click(function() {
        $('#main-submit').trigger('click');
      });
      $(window).resize(function() {
        replaceMatches();
      });
      
      function replaceMatches() {
        var width = $(window).width();
        if (width < 516) {
          $('.main-location').attr('value', 'skills');
        } else {
          $('.main-location').attr('value', 'Search by skills');
        }
      };
      replaceMatches();
      
  
}))

// $(document).mouseup(function(e) 
// {
//     var container = $(".search-description");

//     // if the target of the click isn't the container nor a descendant of the container
//     if (!container.is(e.target) && container.has(e.target).length === 0) 
//     {
//         container.hide();
//     }
// });

function clearText(thefield) {
  console.log(thefield,"the field")
    if (thefield.defaultValue == thefield.value) {
      thefield.value = ""
    }
  }
  
  function replaceText(thefield) {
    if (thefield.value == "") {
      thefield.value = thefield.defaultValue
    }
  }
