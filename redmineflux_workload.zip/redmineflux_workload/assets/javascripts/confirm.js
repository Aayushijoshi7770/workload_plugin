document.addEventListener("DOMContentLoaded", function() {
	const urlParams = new URLSearchParams(window.location.search);
	const hideDiv = urlParams.get('hide_holiday_table');
	if (hideDiv === 'true') {
	  const divToHide = document.querySelector('.all-holiday-scheme');
	  if (divToHide) {
		divToHide.style.display = 'none';
		$('.contextual').hide();
	  }
	}
});

$(document).ready(function(){
	
    $('.cross_close_delete').click(function(){
		$('.modal-members-delete').hide();
		$('.modal-bg-members_delete').hide();
	});
    $('#deleteTeamsLink').click(function(){
		$('.modal-members-delete').show();
		$('.modal-bg-members_delete').show();
	});
    $('#deleteLink').click(function(){
		$('.modal-members-delete').show();
		$('.modal-bg-members_delete').show();
	});
    $('#deleteHolidayLink').click(function(){
		$('.modal-members-delete').show();
		$('.modal-bg-members_delete').show();
	});
    $('#deleteHdatesLink').click(function(){
		$('.change_delete').show();
		$('.modal-bg-members_delete').show();
	});
    $('#deleteHdatesMembLink').click(function(){
		$('.change_delete_memb').show();
		$('.modal-bg-members_delete').show();
	});
    $('#deleteHdLink').click(function(){
		$('.modal-members-delete').show();
		$('.modal-bg-members_delete').show();
	});
    $('#deleteLink2').click(function(){
		$('.modal-members-delete').show();
		$('.modal-bg-members_delete').show();
	});
})

function clearCheck(){
	$('.team_change').find(' input[type="checkbox"]:checked').prop('checked', false);
	$('#contextTeamsMenu').hide();
	$('.edit_memb_list').find(' input[type="checkbox"]:checked').prop('checked', false);
	$('#contextMenu0').hide();
	$('.skill_change').find(' input[type="checkbox"]:checked').prop('checked', false);
	$('#contextMenu12').hide();
	$('.workload_change ').find(' input[type="checkbox"]:checked').prop('checked', false);
	$('#contextMenu_wk').hide();
	$('.wk_details_change2 ').find(' input[type="checkbox"]:checked').prop('checked', false);
	$('#contextMenu_hd').hide();
	$('.holiday_change ').find(' input[type="checkbox"]:checked').prop('checked', false);
	$('#contextMenu_holiday').hide();
	$('.hdates_change ').find(' input[type="checkbox"]:checked').prop('checked', false);
	$('#contextMenu_hdates').hide();
	$('.wk_details_change1  ').find(' input[type="checkbox"]:checked').prop('checked', false);
	$('#contextMenu_hdates_members').hide();
	
}
function closeNewholidayModal(){
	console.log("Hello world")
    let modal = document.getElementById("new_holiday_modal");
    let overlay = document.getElementById("new_holiday_overlay");
    modal.style.display = "none";
    $("body :tabbable").removeAttr("tabindex");
    setTimeout(() => {
      modal.classList.remove("show_holiday_modal");
      overlay.classList.remove("show_holiday_modal");
    }, 1);
}

function closeeditholidayModal(){
    let modal = document.getElementById("update_holiday_modal");
    let overlay = document.getElementById("update_holiday_overlay");
    modal.style.display = "none";
    $("body :tabbable").removeAttr("tabindex");
    setTimeout(() => {
      modal.classList.remove("show_holiday_modal");
      overlay.classList.remove("show_holiday_modal");
    }, 1);
}
// document.addEventListener("DOMContentLoaded", function() {

// 	var holidayScheme = document.querySelector('.controller-holiday_dates.action-new');
// 	if (holidayScheme) {
		
	
// 	// Assuming you have a reference to the target element
// 	var targetElement = document.querySelector('.list.wk_details.wk_details_change1');

// 	// Create a new div element with the provided HTML
// 	var newElement = document.createElement('div');
// 	newElement.innerHTML = '<div id="search_member"><label for="search-input"></label><input type="text" id="search_members" placeholder="Search Members...."></div>';

// 	// Append the new element as a child of the target element
// 	targetElement.before(newElement);

// 	$('#search_members').on('input', function () {
// 	  performSearch();
// 	  // console.log('search ');
// 	});

// 	function performSearch() {
// 		var searchValue = $('#search_members').val().toLowerCase().trim();
// 		var found = false; // Variable to track if any search results were found
	  
// 		$('.d_search').each(function () {
// 		  var issueSubject = $(this).find('.member_name').text().toLowerCase();
	  
// 		  if (issueSubject.includes(searchValue)) {
// 			$(this).show();
// 			found = true; // A search result was found
// 		  } else {
// 			$(this).hide();
// 		  }
// 		});
	  
// 		// Check if no results were found
// 		if (!found && $('#no-data-message').length === 0) {
//             $(".d_list").hide();
// 			$("span.pagination .pagination").hide();
// 			$('<div id="no-data-message">No data found</div>').insertAfter('.list.wk_details.wk_details_change1');
// 		  } else if (found) {
// 			// If data is found, remove the "No data found" message if it exists
// 			$('#no-data-message').remove();
// 			$(".d_list").show();
// 			$("span.pagination .pagination").show();
// 		  }
		
// 		else {
		
// 		  // If results were found or the search input is cleared, hide the error message
// 		  $('.nodata').hide();
// 		//   $(".d_list").show();
// 		}
// 	  }
// 	}

// 	// ----------------- Worklad Scheme -----------------

// 	var worklaodScheme = document.querySelector('.controller-user_workloads.action-show');
// 	if(worklaodScheme){
// 		// Assuming you have a reference to the target element
// 		var worklaodSch = document.querySelector('.list.wk_details.wk_details_change2');

// 		// Create a new div element with the provided HTML
// 		var newItem = document.createElement('div');
// 		newItem.innerHTML = '<div id="search_member"><label for="search-input"></label><input type="text" id="search_members" placeholder="Search Members...." style="margin-bottom:10px"></div>';

// 		// Append the new element as a child of the target element
// 		worklaodSch.before(newItem);

// 		$('#search_members').on('input', function () {
// 		performSearch();
// 		// console.log('search ');
// 		});

// 		function performSearch() {
// 			var searchValue = $('#search_members').val().toLowerCase().trim();
// 			var found = false; // Variable to track if any search results were found
		  
// 			$('.d_search').each(function () {
// 			var issueSubject = $(this).find('.member_scheme').text().toLowerCase();
		  
// 			if (issueSubject.includes(searchValue)) {
// 				$(this).show();
// 				found = true; // A search result was found
// 			} else {
// 				$(this).hide();
// 			}
// 			});
		  
// 			// Check if no results were found
// 			if (!found && $('#no-data-message').length === 0) {
// 				$("span.pagination .pagination").hide();
// 				$(".d_list").hide();
// 				$('<div id="no-data-message">No data found</div>').insertAfter('.list.wk_details.wk_details_change2 ');
// 			} else if (found) {
// 				// If data is found, remove the "No data found" message if it exists
// 				$('#no-data-message').remove();
// 				$(".d_list").show();
// 				$("span.pagination .pagination").show();
// 			}
			
// 			else {
			
// 			// If results were found or the search input is cleared, hide the error message
// 			$('.nodata').hide();
	
// 			}
// 		}
// 	}
//   });