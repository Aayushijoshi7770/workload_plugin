
var holidaySchemeTableContent;
var workloadSchemeTableContent;
$(document).ready(function(){
  
var currentUrl = window.location.href;

var selectAllElement = document.getElementById('select-all');
if (selectAllElement) {
  selectAllElement.addEventListener('click', function() {
    var checkboxes = document.getElementsByClassName('watch-input');
    for (var i = 0; i < checkboxes.length; i++) {
      checkboxes[i].checked = this.checked;
    }
  });
}

var checkboxes = document.getElementsByClassName('watch-input');
for (var i = 0; i < checkboxes.length; i++) {
  checkboxes[i].addEventListener('change', function() {
    var allChecked = true;
    for (var j = 0; j < checkboxes.length; j++) {
      if (!checkboxes[j].checked) {
        allChecked = false;
        break;
      }
    }
    selectAllElement.checked = allChecked;
  });
}

  var urlParts = currentUrl.split('/');
  

  var wk_id = urlParts[urlParts.length - 1];
console.log(`wk_id`, wk_id);
  let body_div = document.getElementsByClassName("has-main-menu controller-user_workloads action-show");
  let modal= document.getElementsByClassName(".workload-scheme");
  let div = document.createElement("div");
         div.className = "div-modal";
         div.style.display = "block";              
         $('#scheme-members').show();
         $(".workload-scheme").show();
        
         $(".workload-scheme").attr("id", wk_id);
         $.ajax({
          type: "GET",
          url: `${url}/user_workloads.json?key=${api_key}`,
          dataType: "json",
          async: false,
          success: function(result, status, xhr) {
            $('#dynamic_select_day').html(" ");
        
            if(result.length!=0){
              result.map((i)=>{
                $('#dynamic_select_day').append(`<option  value=${i.id}>${i.name}</option>`)
              })
            }
      
          },
          error: function(xhr, status, error){
            $('#dynamic_select_day').html(" ");
           
          }
        });

        // $.ajax({
        //   type: "GET",
        //   url: `${url}/add_members_to_scheme.json?key=${api_key}`,
        //   dataType: "json",
        //   async: false,
        //   success: function(result, status, xhr) {
        //     data = result;
        //     if(data.length!=0){
        //       // Add a "Select All" checkbox
        //       $('#wk-scheme').append(`
        //         <div class="members">
        //           <div class="wkusers" style="display:flex; align-items:center; flex-direction:row; gap:11px;">
        //             <label class="chbox" style="display:flex; cursor:pointer; align-items:center; flex-direction:row; gap:11px; margin-left:10px;">
        //               <input style="cursor:pointer;" id="select-all" type="checkbox"/>
        //               Select All
        //             </label>
        //             <div style="display:flex;"></div>
        //           </div>
        //         </div>
        //       `);
        
        //       // Add a click event listener to the "Select All" checkbox
        //       $('#select-all').click(function() {
        //         $('.watch-input').prop('checked', this.checked);
        //       });
        
        //       data.forEach((i)=>{
        //         $('#wk-scheme').append(`
        //           <div id="wkscheme-users" class="members">
        //             <div class="wkusers" style="display:flex; align-items:center; flex-direction:row; gap:11px;">
        //               <label class="chbox" style="display:flex; cursor:pointer; align-items:center; flex-direction:row; gap:11px; margin-left:10px;">
        //                 <input style="cursor:pointer;" class="watch-input" id="members-input" value=${i.id} type="checkbox"/>
        //                 ${i.firstname + " " + i.lastname}
        //               </label>
        //               <div style="display:flex;"></div>
        //             </div>
        //           </div>
        //         `);
        //       });
        //     }
        
        //   },
        //   error: function(xhr, status, error){
           
        //   }
        // });

});
function addMembers(){
    var currentUrl = window.location.href;

  var urlParts = currentUrl.split('/');
  

  var wk_id = urlParts[urlParts.length - 1];
    scheme_id = $(".workload-scheme").attr("id");
    var url = window.location.origin;
    var wkid = []
    $.each($("input[id='members-input']:checked"), function(){
      ids = wkid.push(parseInt($(this).val()));
      console.log(wkid);  
    });
    $.ajax({
      type: "POST",
      url: `${url}/add_workload_members.json?key=${api_key}`,
      dataType: "json",
      contentType: "application/json",
      
      data: JSON.stringify({
        user_id: wkid, workload_id: parseInt(wk_id)
      }),
      success: function (result, status, xhr){
        $('.workload-scheme').css('display','none');
        $('#scheme-members').hide();
        window.location.reload();
    
      }, error: function(xhr, status, error){
        $('#scheme-members').hide();
        window.location.reload();
      } 
    });
    }
    $(document).ready(function(){
      searchWkuser = function(){
      var url = window.location.origin
      let name_string = $('#wk-users').val();
      $('input#wk-users').html(" ");
     
      if (name_string.length !=0 ){
        console.log(`name_string`, name_string)
        $.ajax({
          type: 'GET',
          url: `${url}/search_workload_scheme_users.json?key=${api_key}`,
          dataType: "json",
          contentType: "application/json",
          data: {
            name: name_string.trim(),
          },
          success: function(result, status, xhr) {
      
            
           if (result.length != 0){
            $('#wk-scheme').html(" ");
            result.forEach((i)=>{
              $('#wk-scheme').append(`<div id="wkscheme-users" class="wk-members" ">
              <div class="wkusers" style="display:flex; align-items: center;flex-direction:row; gap:11px;">
                  <label class="chbox" style="display:flex; cursor:pointer;    align-items: center;flex-direction:row; gap:11px;margin-left: 10px;">
                    <input style= "cursor: pointer;" class="watch-input" id="members-input"   value=${i.id} type="checkbox"/>
                    ${i.firstname + " " + i.lastname}
                  </label>
                  <div style="display:flex;">
                   
                  </div>
                </div>
              </div>
              `);
            })
           }
          },
      
          error: function(xhr, status, error) {
      
          },
          
        });
      
      }
      else if(name_string.length == "")
      { 
        console.log(`name_stringggg`, name_string)
        $.ajax({
          type: "GET",
          url: `${url}/add_members_to_wk_scheme.json?key=${api_key}`,
          dataType: "json",
          async: false,
          success: function(result, status, xhr) {
            data = result;
            if(data.length!=0){
              // Add a "Select All" checkbox
              $('#wk-scheme').html(" ")
              $('#wk-scheme').append(`
                <div class="members">
                  <div class="wkusers" style="display:flex; align-items:center; flex-direction:row; gap:11px;">
                    <label class="chbox" style="display:flex; cursor:pointer; align-items:center; flex-direction:row; gap:11px; margin-left:10px;">
                      <input style="cursor:pointer;" id="select-all" type="checkbox"/>
                      Select All
                    </label>
                    <div style="display:flex;"></div>
                  </div>
                </div>
              `);
        
              // Add a click event listener to the "Select All" checkbox
              $('#select-all').click(function() {
                $('.watch-input').prop('checked', this.checked);
              });
        
              data.forEach((i)=>{
                $('#wk-scheme').append(`
                  <div id="wkscheme-users" class="members">
                    <div class="wkusers" style="display:flex; align-items:center; flex-direction:row; gap:11px;">
                      <label class="chbox" style="display:flex; cursor:pointer; align-items:center; flex-direction:row; gap:11px; margin-left:10px;">
                        <input style="cursor:pointer;" class="watch-input" id="members-input" value=${i.id} type="checkbox"/>
                        ${i.firstname + " " + i.lastname}
                      </label>
                      <div style="display:flex;"></div>
                    </div>
                  </div>
                `);
              });
            }
        
          },
          error: function(xhr, status, error){
           
          }
        });
      }
      }

      searchHolidayuser = function(){
        var url = window.location.origin
        let name_string = $('#wk-users').val();
        $('input#wk-users').html(" ");
       
        if (name_string.length !=0 ){
          $.ajax({
            type: 'GET',
            url: `${url}/search_holiday_scheme_users.json?key=${api_key}`,
            dataType: "json",
            contentType: "application/json",
            data: {
              name: name_string.trim(),
            },
            success: function(result, status, xhr) {
        
              
             if (result.length != 0){
              $('#wk-scheme').html(" ");
              result.forEach((i)=>{
                $('#wk-scheme').append(`<div id="wkscheme-users" class="wk-members" ">
                <div class="wkusers" style="display:flex; align-items: center;flex-direction:row; gap:11px;">
                    <label class="chbox" style="display:flex; cursor:pointer;    align-items: center;flex-direction:row; gap:11px;margin-left: 10px;">
                      <input style= "cursor: pointer;" class="watch-input" id="members-input"   value=${i.id} type="checkbox"/>
                      ${i.firstname + " " + i.lastname}
                    </label>
                    <div style="display:flex;">
                     
                    </div>
                  </div>
                </div>
                `);
              })
             }
            },
        
            error: function(xhr, status, error) {
        
            },
            
          });
        
        }
        else if(name_string.length == "")
        { 
          $.ajax({
            type: "GET",
            url: `${url}/add_members_to_holiday_scheme.json?key=${api_key}`,
            dataType: "json",
            async: false,
            success: function(result, status, xhr) {
              data = result;
              if(data.length!=0){
                $('#wk-scheme').html(" ")
                // Add a "Select All" checkbox
                $('#wk-scheme').append(`
                  <div class="members">
                    <div class="wkusers" style="display:flex; align-items:center; flex-direction:row; gap:11px;">
                      <label class="chbox" style="display:flex; cursor:pointer; align-items:center; flex-direction:row; gap:11px; margin-left:10px;">
                        <input style="cursor:pointer;" id="select-all" type="checkbox"/>
                        Select All
                      </label>
                      <div style="display:flex;"></div>
                    </div>
                  </div>
                `);
          
                // Add a click event listener to the "Select All" checkbox
                $('#select-all').click(function() {
                  $('.watch-input').prop('checked', this.checked);
                });
          
                data.forEach((i)=>{
                  $('#wk-scheme').append(`
                    <div id="wkscheme-users" class="members">
                      <div class="wkusers" style="display:flex; align-items:center; flex-direction:row; gap:11px;">
                        <label class="chbox" style="display:flex; cursor:pointer; align-items:center; flex-direction:row; gap:11px; margin-left:10px;">
                          <input style="cursor:pointer;" class="watch-input" id="members-input" value=${i.id} type="checkbox"/>
                          ${i.firstname + " " + i.lastname}
                        </label>
                        <div style="display:flex;"></div>
                      </div>
                    </div>
                  `);
                });
              }
          
            },
            error: function(xhr, status, error){
             
            }
          });
        }
        }
      
     
      })

setTimeout(() => {
  // Store the original table content on page load
holidaySchemeTableContent = $('#tableContainer').html();
// console.log(holidaySchemeTableContent, "test table")

}, 3000);
function searchHolidaymembers() {
    var url = window.location.origin;
    let name_string = $('#holiday-scheme-search').val().trim();
    // Enhanced regex to detect repetitive or poorly formatted text
    let validNamePattern = /^[A-Za-z]+(?:\s[A-Za-z]+)*$/;
   
    // Check if the input matches the repetitive or poorly formatted pattern
   if (!validNamePattern.test(name_string)) {
    console.log("Search input contains repetitive or poorly formatted text. Aborting search.");
          // Remove existing "No data to display" message
          $('.no_data').hide();
          $(".pagination").hide();
          // Append "No data to display" message only once
          $('#tableContainer').append(`<p class="nodata no_data" style="margin-top: 70px;">No data to display</p>`);
          $(".list.wk_details.wk_details_change1").hide();
          if (name_string === "") {
      
            console.log("Search input is empty. Restoring original table content.");
            $('#tableContainer').html(holidaySchemeTableContent);
            $(".pagination").show();
          }
    return; // Abort the search if repetitive text is detected
  }
    // console.log(`Searching for: ${name_string}`);
    $('.wk_details_change1').html(" ");
    $(".pagination").show();
    // If the search field is empty, restore the original table content
    if (name_string === "") {
        console.log("Search input is empty. Restoring original table content.");
        $('#tableContainer').html(holidaySchemeTableContent);
      }
     
    else {
        // console.log(`Searching for: ${name_string}`);
              // Make the AJAX request if the input is not empty
        $.ajax({
            type: 'GET',
            url: `${url}/search_holiday_scheme_members.json?key=${api_key}`,
            dataType: "json",
            data: {
                name:name_string,
            },
            success: function(result, status, xhr) {
                var tableContent = `
                    <table class="list wk_details wk_details_change1">
                        <thead class="d_list">
                          <tr>
                            <th class="wk_td">
                              <input type="checkbox" id="select-all-hdatesmembers-checkbox"></th>
                                <th class="wk_d">S.no</th>     
                                <th>Members</th>
                                <th class="wk_d">Action</th>
                          </tr>
                        </thead>
                        <tbody>`;

                if (result.length != 0) {
                  $(".list.wk_details.wk_details_change1").show();
                  $('.no_data').hide();
                  $(".pagination").hide();
                    // console.log(`Result found:`, result);
                    result.forEach((f, index) => {
                        tableContent += `
                            <tr class="d_search">
                                <td class="wk_t"><input type="checkbox" class="checkbox_hdates_members" id="${f.id}" value="${f.id}"></td>
                                <td class="wk_td">${index + 1}</td>
                                <td class="member_name">${f.firstname} ${f.lastname}</td>
                                <td class="wk_td"><a class="icon-only icon-del" id="${f.id}" onclick="hd_membs_scheme_ids(this.id)">Delete</a></td>
                            </tr>`;
                    });
                } else {
                  // console.log(`No results found.`);
                  // Remove existing "No data to display" message
                  $('.no_data').hide();
                  $(".pagination").hide();
                  // Append "No data to display" message only once
                  $('#tableContainer').append(`<p class="nodata no_data" style="margin-top: 70px;">No data to display</p>`);
                  $(".list.wk_details.wk_details_change1").hide();
              }

                tableContent += `</tbody></table>`;
                $('.wk_details_change1').html(tableContent);
            },
            error: function(xhr, status, error) {
                console.error('Error fetching members:', error);
            },
        });
    }
}

   

setTimeout(() => {
  // Store the original table content on page load
workloadSchemeTableContent = $('#table_Container').html();
console.log(workloadSchemeTableContent, "test table")

}, 3000);
function searchWorkloadmembers() {
    var url = window.location.origin;
    let name_string = $('#workload-scheme-search').val().trim();
    console.log(`Searching for: ${name_string}`);
    
    // Enhanced regex to detect repetitive or poorly formatted text
    let validNamePattern = /^[A-Za-z]+(?:\s[A-Za-z]+)*$/;
  
  // Check if the input matches the repetitive or poorly formatted pattern
  if (!validNamePattern.test(name_string)) {
    console.log("Search input contains repetitive or poorly formatted text. Aborting search.");
          // Remove existing "No data to display" message
          $('.no_data').hide();
          $(".pagination").hide();
          // Append "No data to display" message only once
          $('#table_Container').append(`<p class="nodata no_data" style="margin-top: 70px;">No data to display</p>`);
          $(".list.wk_details.wk_details_change2").hide();
          if (name_string === "") {
      
            console.log("Search input is empty. Restoring original table content.");
            $('#table_Container').html(workloadSchemeTableContent);
            $(".pagination").show();
          }
         return; // Abort the search if repetitive text is detected
  }

    $('.wk_details_change2').html(" ");
    $(".pagination").show();
    // If the search field is empty, restore the original table content
    if (name_string === "") {
        console.log("Search input is empty. Restoring original table content.");
        $('#table_Container').html(workloadSchemeTableContent);
      } else {
        console.log(`Searching for: ${name_string}`);
             // Make the AJAX request if the input is not empty
        $.ajax({
            type: 'GET',
            url: `${url}/search_workload_scheme_members.json?key=${api_key}`,
            dataType: "json",
            data: {
                name: name_string,
            },
            success: function(result, status, xhr) {
              console.log('Received result:', result, 'Type:', typeof result);
                var tableContent = `
                    <table class="list wk_details wk_details_change2">
                        <thead class="d_list">
                         <tr><th class="wk_d">
                              <input type="checkbox" id="select-all-hd-checkbox">
                            </th>
                        <th class="wk_d">S.no</th>     
                          <th>Members</th>
                      
                            <th class="wk_d">Action</th>
                        
                          </tr>
                        </thead>
                        <tbody>`;

                  if (Array.isArray(result) && result.length > 0) {
                    $('.no_data').hide();
                    $(".pagination").hide();
                  $(".list.wk_details.wk_details_change2").show();
                    console.log(`Result found:`, result);
                    result.forEach((i, index) => {
                        tableContent += `
                            <tr class="d_search">
                                <td class="wk_td"><input type="checkbox" class="checkbox_hd_members" id="${i.id}" value="${i.id}"></td>
                                <td class="wk_td">${index + 1}</td>
                                <td class="member_scheme">${i.firstname} ${i.lastname}</td>
                                <td class="wk_td"><a class="icon-only icon-del" id="${i.id}" onclick="wk_memb_scheme_ids(this.id)">Delete</a></td>
                            </tr>`;
                    });
                  
               } else {
                  console.log(`No results found.`);
                  // Remove existing "No data to display" message
                  $('.no_data').hide();
                  $(".pagination").hide();
                  // Append "No data to display" message only once
                  $('#table_Container').append(`<p class="nodata no_data" style="margin-top: 70px;">No data to display</p>`);
                  $(".list.wk_details.wk_details_change2").hide();
              }

                tableContent += `</tbody></table>`;
                $('.wk_details_change2').html(tableContent);
            },
            error: function(xhr, status, error) {
                console.error('Error fetching members:', error);
            },
        });
    }
}
    


      function addHschemeMembers(){
        var currentUrl = window.location.href;

        var urlParts = currentUrl.split('/');
        
      
        var wk_id = urlParts[urlParts.length - 3];
        scheme_id = $(".holiday-scheme").attr("id");
        var url = window.location.origin;
        var wkid = []
        $.each($("input[id='members-input']:checked"), function(){
          ids = wkid.push(parseInt($(this).val()));
          console.log(wkid);  
        });
        $.ajax({
          type: "POST",
          url: `${url}/add_holiday_members.json?key=${api_key}`,
          dataType: "json",
          contentType: "application/json",
          
          data: JSON.stringify({
            user_id: wkid, scheme_id: parseInt(wk_id)
          }),
          success: function (result, status, xhr){
            $('.holiday-scheme').css('display','none');
            $('#scheme-members').hide();
            $('#flash_notice').css('display','block');
            window.location.reload();
          }, error: function(xhr, status, error){
            $('#scheme-members').hide();
            window.location.reload();
          } 
        });
        }


    