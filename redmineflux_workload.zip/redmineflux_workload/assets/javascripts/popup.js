// ----Create team popup start----
var api_key;
$(document).ready(function () {
	$('.cross_close_teamup').on('click keypress', function (event) {
		if (event.type === 'click' || (event.type === 'keypress' && event.key === 'Enter')) {
			$('.modal_team_edit').hide();
			$('.modal-bg_team_edit').hide();
			window.index();
		}
	});
	
	$('.close_team_edit_head  ').click(function () {
		$('.modal_team_edit').hide();
		$('.modal-bg_team_edit').hide();
		window.index();
	})
	$('.modal-link').click(function () {
		$('.modal').show();
		$('.modal-bg').show();
		window.index();
		
	});
	$('.modal .team_close ').click(function () {
		$('.modal').hide();
		$('.modal-bg').hide();
		window.index();
	})
	$('.cross_close_team').on('click keypress', function (event) {
		if (event.type === 'click' || (event.type === 'keypress' && event.key === 'Enter')) {
			$('.modal').hide();
			$('.modal-bg').hide();
			window.index();
		}
	});
	

	$('.multi-select-container').click(function () {

	});

	window.index = function handleTabindex() {
		if ($('.modal,.modal_team_edit,.deleteModal').is(':visible')) {
			$(":tabbable").attr("tabindex", -1);
			$("html").css("overflow-y", "hidden");
			//document.getElementById("team_name").focus();
			$(".modal [tabindex='-1'],.modal_team_edit [tabindex='-1']").attr("tabindex", 0);
			$(".deleteModal [tabindex='-1']").attr("tabindex", 0);
			
		} else {
			$("[tabindex='-1']").attr("tabindex", 0);
			$("html").css("overflow-y", "scroll");
		}
	}
})


// ----Create team popup end----

// ----Member info start----

$(document).ready(function () {
	$('.modal-link_info').click(function () {
		$('.modal_info').show();
		$('.modal-bg_info').show();
	});
	$('.modal .team_close').click(function () {
		$('.modal_info').hide();
		$('.modal-bg_info').hide();
	})

})

// ----Member info  end----

// ----Add Member start----

$(document).ready(function () {
	$('#add_mem').click(function () {
		$('.modal_memb').show();
		$('.modal-bg_memb').show();
	});
	$('.modal_memb .close').click(function () {
		$('.modal_memb').hide();
		$('.modal-bg_memb ').hide();
	})

})

// ----Add Member end----
// Get the <td> element containing the comma-separated values

// ----Render team page start----

// $(document).ready(function() {
// 	const table0 = $('.edit_memb_list');
// 	const contextMenu0 = $('#contextMenu0');
// 	const editLink0 = $('#editLink0');
// 	const deleteLink0 = $('#memberDelete');
// 	let selectedRow0 = null;
// // 	$('.edit_memb_list').on('change', 'input[type="checkbox"]', function() {
// // 		const selectedCheckboxes = $('tbody input[type="checkbox"]:checked, thead input[type="checkbox"]:checked');
// // 		const selectedCount = selectedCheckboxes.length;
// // 		const checkbox = $(this);
// // 		const isChecked = checkbox.prop('checked');

// // 		if (selectedCount > 1) {
// // 		  console.log("More than one checkbox is selected.");
// // 		  const selectedRow = checkbox.closest('tr');
// // 		  editLink0.attr('href', '#edit/' + selectedRow.attr('id'));

// // 		  if (checkbox.attr('id') === 'select-all-checkbox') {
// // 			// Check all checkboxes
// // 			const checkboxPos = checkbox.offset();
// // 			contextMenu0.show().offset({
// // 			  left: checkboxPos.left + checkbox.outerWidth(),
// // 			  top: checkboxPos.top
// // 			});
// // 			$('input[type="checkbox"]', table0).prop('checked', isChecked);
// // 		  } else {
// // 			checkbox.prop('checked', isChecked);

// // 			if (isChecked) {
// // 			  const checkboxPos = checkbox.offset();
// // 			  contextMenu0.show().offset({
// // 				left: checkboxPos.left + checkbox.outerWidth(),
// // 				top: checkboxPos.top
// // 			  });
// // 			} else {
// // 			  const lastSelectedCheckbox = selectedCheckboxes.last();
// // 			  if (lastSelectedCheckbox[0] === checkbox[0]) {
// // 				contextMenu0.hide();
// // 			  }
// // 			}
// // 		  }
// // 		} else {
// // 		  contextMenu0.hide();
// // 		  editLink0.attr('href', '');
// // 		}
// // 		$(document).on('click', function(event) {
// //   if (!$(event.target).closest('table').length) {
// //     $('input[type="checkbox"]', table0).prop('checked', false);
// //     contextMenu0.hide();
// //   }
// // });
// 	//   });
// 	// Get all the checkboxes






// 	editLink0.on('click', function(event) {
// 	  event.preventDefault();

// 	  const checkboxIds = [];
// 	  table0.find('td input[type="checkbox"]:checked').each(function() {
// 		checkboxIds.push($(this).attr('value'));
// 	  });
// 	//   $('#current_edit-commitment').val('')
// 	  localStorage.setItem('td_ids', checkboxIds)

// 		$('.modal-bulk_memb').show();
// 		$('.modal-bg-bulk-memb').show();

// 	  contextMenu0.hide();
// 	});
// deleteLink0.on('click', function(event) {
// 	event.preventDefault();

// 	const checkboxdeleteIds = [];
// 	table0.find('td input[type="checkbox"]:checked').each(function() {
// 		checkboxdeleteIds.push($(this).attr('id'));
// 	});
// 	console.log(checkboxdeleteIds, "dkdkdkdk");
//   //   $('#current_edit-commitment').val('')


// 	$.ajax({
// 		type: "DELETE",
// 		url: `${url}/delete_data.json?key=${api_key}&&delete_id=${checkboxdeleteIds}`,

// 		contentType: "application/json",
// 		dataType: "json",

// 	  });

// 	  setTimeout(() => {
// 		location.reload();

//   }, 500);
// 	contextMenu0.hide();
//   });

//   });

function bulkEdit() {
	const checkboxIds = [];
	const checkbox_ids = localStorage.getItem('td_ids');
	const idsArray = checkbox_ids.split(',');
	idsArray.forEach((id) => {
		checkboxIds.push(parseInt(id));
	});
	// console.log(checkboxIds, "????C")
	var url = window.location.origin;
	var currentUrl = window.location.href;
	var urlParts = currentUrl.split('/');
	var group_id = urlParts[urlParts.length - 2];
	var ids = checkboxIds;
	var commitment = $('#current_bulk-commitment').text();
	// console.log(commitment, "dmdmd");
	var joining_date = $('#join_bulk').val();
	var leaving_date = $('#leave_bulk').val();
	var role_id = $('#bulkedit_role_wk').val();
	const skills = $('#bulk_skills').val();



	if (skills === null) {

		var commaSeparatedSkills = '';
		// Handle the error here
	} else {
		const skills = $('#bulk_skills').val();

		const skillTexts = [];
		for (let i = 0; i < skills.length; i++) {
			const option = $('#bulk_skills option[value="' + skills[i] + '"]');
			const text = option.text();
			skillTexts.push(text);

		}
		var commaSeparatedSkills = skillTexts.join(', ');
	}


	// console.log(checkboxIds.split(',').map(Number),"ksksksksks>.............")

	$.ajax({
		type: "PUT",
		url: `${url}/update_members.json?key=${api_key}`,
		dataType: "json",
		contentType: "application/json",

		data: JSON.stringify({
			ids: ids, group_id: parseInt(group_id,), role_id: parseInt(role_id), commitment: parseInt(commitment), skills: commaSeparatedSkills, joining_date: joining_date, leaving_date: leaving_date
		}),
		success: function (result, status, xhr) {

			window.location.reload();

		}, error: function (xhr, status, error) {

			window.location.reload();
		}
	});

}

function clearData() {
	const table = $('.edit_memb_list');
	table.find(' input[type="checkbox"]:checked').prop('checked', false);
	$('#current_bulk-commitment').text("");
	$('#join_bulk').val("");
	$('#leave_bulk').val("");
	$('#bulk_skills').val("");
	$('#edit_skills').val("");
	$('#role_wk').val("");
}

function addMembers() {
	var currentUrl = window.location.href;
	var urlParts = currentUrl.split('/');
	var wk_id = urlParts[urlParts.length - 2];

	var url = window.location.origin;
	var tmid = $('#add_members').val();
	var commitment = $('#current-commitment').text();
	const skills = $('#team_member_skills').val();

	if (skills === null || skills.length === 0) {
		// alert('Please fill in the workload field.');
        return; // Prevent further execution
		// var commaSeparatedSkills = '';
		// Handle the error here
	} else {
		const skillTexts = [];
		for (let i = 0; i < skills.length; i++) {
			const option = $('#team_member_skills option[value=' + skills[i] + ']');
			console.log(option, "jxjxj");
			const text = option.text();
			skillTexts.push(text);
		}
		console.log(skillTexts, "jxddddddddddjxj");

		var commaSeparatedSkills = skillTexts.join(', ');
	}
	var joining_date = $('#join').val();
	var leaving_date = $('#leave').val();
	var role_id = $('#role_wk').val();

	$.ajax({
		type: "POST",
		url: `${url}/add_teams_members.json?key=${api_key}`,
		dataType: "json",
		contentType: "application/json",

		data: JSON.stringify({
			member_id: tmid, group_id: parseInt(wk_id,), commitment: commitment, role_id: parseInt(role_id), skills: commaSeparatedSkills, joining_date: joining_date, leaving_date: leaving_date
		}),
		success: function (result, status, xhr) {
			//   $('.workload-scheme').css('display','none');
			//   $('#scheme-members').hide();
			if (tmid.length != 0) {
				// window.location.reload();
				// window.location = window.location;
				history.go(0);
			}

		}, error: function (xhr, status, error) {
			//   $('#scheme-members').hide();
			// window.location.reload();
			// window.location = window.location;
			history.go(0);

		}
	});
}

// ----Render team page end----


// ----Edit general info start----

// function reply_click(clicked_id){
// 	localStorage.setItem("id", clicked_id)
//   var name_edit = document.getElementById('name_update')
// 	var name_value =  $(`#${clicked_id}`).text().trim();

// 	localStorage.setItem("grpname", name_value)
// 		setTimeout(()=>{
// 			$(document).ready(function(){
// 			$('#members_update li ').each(function() {
// 				var str = $(this).text();
// 				var matches = str.match(/\b(\w)/g);

// 				var acronym = matches.join('');

// 				$(this).prepend('<span><i>' + acronym + '</i></span>');

// 			  });
// 			  $("#members_update li span").each(function () {

// 				var hexArray = ['#FDD6D6' , '#E5FDD6', '#FDEDD6' ,'#D6F4FD' , '#FDD6D6' , '#E5FDD6', '#FDEDD6', '#D6F4FD' ]

// 				var randomColor = hexArray[Math.floor(Math.random() * hexArray.length)];

// 				$(this).css("background", randomColor);



// 			  });


// 			});
// 			},1000)

// }


// ----Update group name start----


// ----Update group name end----

// ----Edit general info end----**
function userSearch() {
	$('.pagination').hide();
	var input, filter, table, tr, td, i, txtValue;
	input = document.getElementById("myInput");
	if(input.value === ''){
		$('.pagination').show();
	}
	filter = input.value.toUpperCase();
	tr = document.getElementsByClassName("tr_user");
	for (i = 0; i < tr.length; i++) {
		td = tr[i].getElementsByTagName("td")[1];
		if (td) {
			txtValue = td.textContent || td.innerText;
			if (txtValue.toUpperCase().indexOf(filter) > -1) {
				tr[i].style.display = "";
				document.querySelector(".no_data").style.display = "none";
				$(".e_list").show();
			} else {
				tr[i].style.display = "none";

				if ($(".user_team tbody tr:not([style='display: none;'])").length == 0) {
					$(".no_data").show();
					document.querySelector(".e_list").style.display = "none";
				}
			}
		}
	}
}
function myFunction() {
	var input, filter, table, tr, td, i, txtValue;
	input = document.getElementById("myInput");
	filter = input.value.toUpperCase();

	tr = document.getElementsByClassName("t_search");;
	for (i = 0; i < tr.length; i++) {
		td = tr[i].getElementsByTagName("td")[2];
		if (td) {
			txtValue = td.textContent || td.innerText;
			if (txtValue.toUpperCase().indexOf(filter) > -1) {
				console.log("test")
				tr[i].style.display = "";
				document.querySelector(".no_data").style.display = "none";
				$(".no_data").hide();
				$(".e_list").show();
			} else {
				console.log("else test")
				tr[i].style.display = "none";

				if ($(".team_change tbody tr:not([style='display: none;'])").length == 0) {
					$(".no_data").show();
					document.querySelector(".e_list").style.display = "none";
				}
			}
		}
	}
}

function myDetails() {
	var input, filter, table, tr, td, i, txtValue;
	input = document.getElementById("myMemb");
	filter = input.value.toUpperCase();

	tr = document.getElementsByClassName("tr_data");
	for (i = 0; i < tr.length; i++) {
		td = tr[i].getElementsByTagName("td")[2];
		if (td) {
			txtValue = td.textContent || td.innerText;
			if (txtValue.toUpperCase().indexOf(filter) > -1) {
				tr[i].style.display = "";
				document.querySelector(".no_data").style.display = "none";
				$(".e_list").show();
			} else {
				tr[i].style.display = "none";

				if ($(".edit_memb_list tbody tr:not([style='display: none;'])").length == 0) {
					$(".no_data").show();
					document.querySelector(".e_list").style.display = "none";
				}
			}

		}
	}
}


// Delete team members start
function deleteDetail(detail_id) {
    var message;
	
    if ($('.checkbox_members:checked').length > 1) {
		$('#modalheading').text("Delete Members");
		message = "Are you sure you want to delete the selected members?";
        const table0 = $('.edit_memb_list');
        const checkboxdeleteIds = [];
        table0.find('td input[type="checkbox"]:checked').each(function () {
            checkboxdeleteIds.push($(this).attr('id'));
        });

        // Show the modal
        $('#deleteMember').css('display', 'block');
		$('.modal-bg-edit-memb').show();


        // When the user clicks on Yes, close the modal and delete the members
        $('#confirmBtn').click(function() {
            $('#deleteMember').css('display', 'none');
			$('.modal-bg-edit-memb').hide();
            $.ajax({
                type: "DELETE",
                url: `${url}/delete_data.json?key=${api_key}&&delete_id=${checkboxdeleteIds}`,
                contentType: "application/json",
                dataType: "json",
                success: function () {
                    location.reload();
					window.location=window.location;
                },
                error: function (error) {
                    console.error("Error deleting items:", error);
                }
            });
        });

        // When the user clicks on No, close the modal and do nothing
        $('#cancelBtn').click(function() {
        $('#deleteMember').css('display', 'none');
		$('.modal-bg-edit-memb').hide();
		window.index();
        });
    } 
	else {
		$('#modalheading').text("Delete Member");
		message = "Are you sure you want to delete this member?";
        var destroy = detail_id.getAttribute("class");

        // Show the modal
        $('#deleteMember').css('display', 'block');
		$('.modal-bg-edit-memb').show();

        // When the user clicks on Yes, close the modal and delete the member
        $('#confirmBtn').click(function() {
            $('#deleteMember').css('display', 'none');
			$('.modal-bg-edit-memb').hide();
            $.ajax({
                type: "DELETE",
                url: `${url}/delete_data.json?key=${api_key}&&delete_id=${destroy}`,
                contentType: "application/json",
                dataType: "json",
                success: function () {
					location.reload();
					window.location=window.location;
                },
                error: function (error) {
                    console.error("Error deleting item:", error);
                }
            });
        });

        // When the user clicks on No, close the modal and do nothing
        $('#cancelBtn').click(function() {
        $('#deleteMember').css('display', 'none');
		$('.modal-bg-edit-memb').hide();
		window.index();
        });
    }
	 // Set the message in the modal
	$('#modalMessage').text(message);
	window.index();
}
// Delete team members end

function edit_team(id) {
	document.getElementById('team_edit_update').disabled = true;
	document.getElementById('team_edit_update').style.cursor = "not-allowed";
	var url = window.location.origin
	
	$('.modal_team_edit').show();
	$('.modal-bg_team_edit').show();
	window.index();

	fetch(`${url}/teams_data/${id}.json?key=${api_key}`, {
		Method: "GET",
		Headers: {
			Accept: "application.json",
			"Content-Type": "application/json",

		},

		Cache: "default",
	})
		.then((response) => response.json())
		.then((result) => {
			var teams = result;
			console.log(teams);
			teams.forEach((value, i) => {
				$("#team_name_edit").val(value.name);
			});
		});
	$('#team_edit_update').click(function () {

		var team_name = $("#team_name_edit").val();

		$.ajax({
			type: "PUT",
			url: `${url}/workload_team_update/${id}.json?key=${api_key}&&name=${team_name}`,

			contentType: "application/json",
			dataType: "json",

		});
		setTimeout(() => {
			location.reload();

		}, 500);



	})
}
function team_delete(team_id, group_id) {
    $('#modalheadingTeam').text("Are you sure?");
    $('#modalMessageTeam').text('You want to remove user from this team?');
    $('#deleteUserTeam').css('display', 'block');
    $('.modal-bg_team_delete').show();
    $('#confirmteamBtn').off('click').on('click', function() {
        $('#deleteUserTeam').css('display', 'none');
        $('.modal-bg_team_delete').hide();
        var url = window.location.origin;
        $.ajax({
            url: `${url}/delete_user_from_team?key=${api_key}`,
            type: 'DELETE',
            data: {
                team_id: team_id,
                user_id: group_id,
            },
            success: function(response) {
                if (response.notice) {
					$('#flash_notice').text(response.notice).show()
                    const spanCount = $('.team_delete_' + group_id).length;
                    if (spanCount === 1) {
                        $('#user_delete_'+group_id).remove();
						$('.show_data tr.tr_data').each(function(index) {
							$(this).find('td:first').text(index + 1);
						});
						let table = document.querySelector('.list.user_team');
						if (table.querySelector('.show_data').children.length === 0) {
							table.parentNode.removeChild(table);
							$('.nodata').show();
						}
                    } else {
                        $('#team_delete_' + team_id + '_' + group_id).remove();
                    }
                } else if (response.error) {
                    alert(response.error);
                }
            },
            error: function(xhr, status, error) {
				$('#flash_error').text(response.error).show()
                console.error('Error:', error);
            }
        });
    });

    $('#cancelteamBtn').click(function() {
        $('#deleteUserTeam').css('display', 'none');
        $('.modal-bg_team_delete').hide();
        window.index();
    });
}

// Delete team start
function team_ids(id) {
	var message;
    // Set the message in the modal
    $('#modalMessage').text(message);
	
    if ($('.checkbox_teams:checked').length > 1) {
		$('#modalheading').text("Delete Teams");
		message = "Are you sure you want to delete the selected teams?";
        const table1 = $('.team_change');
        const checkboxIds = [];
        table1.find('td input[type="checkbox"]:checked').each(function () {
            checkboxIds.push($(this).attr('value'));
        });

        const checkboxdeleteIds1 = [];
        table1.find('td input[type="checkbox"]:checked').each(function() {
            checkboxdeleteIds1.push($(this).attr('id'));
        });

        // Show the modal
        $('#deleteTeam').css('display', 'block');
		$('.modal-bg_team_edit').show();
		
        // When the user clicks on and delete the teams
        $('#confirmBtn').click(function() {
            $('#deleteTeam').css('display', 'none');
			$('.modal-bg_team_edit').hide();
            $.ajax({
                type: "DELETE",
                url: `${url}/delete_bulk_teams.json?key=${api_key}&&id=${checkboxdeleteIds1}`,
                contentType: "application/json",
                dataType: "json",
                success: function () {
                    location.reload();
					window.location=window.location;
					
                },
                error: function (error) {
                    console.error("Error deleting item:", error);
                }
            });
        });

        // When the user clicks on No, close the modal and do nothing
        $('#cancelBtn').click(function() {
            $('#deleteTeam').css('display', 'none');
			$('.modal-bg_team_edit').hide();
			window.index();
        });
    } 
	else {
		$('#modalheading').text("Delete Team");
		message = "Are you sure you want to delete this team?";
        // Show the modal
        $('#deleteTeam').css('display', 'block');
		$('.modal-bg_team_edit').show();

        // When the user clicks on delete the team
        $('#confirmBtn').click(function() {
            $('#deleteTeam').css('display', 'none');
			$('.modal-bg_team_edit').hide();
            $.ajax({
                type: "DELETE",
                url: `${url}/delete_bulk_teams.json?key=${api_key}&&id=${id}`,
                contentType: "application/json",
                dataType: "json",
                success: function () {
                    location.reload();
					window.location=window.location;
                },
                error: function (error) {
                    console.error("Error deleting item:", error);
                }
            });
        });

        // When the user clicks on cancel close the modal and do nothing
        $('#cancelBtn').click(function() {
            $('#deleteTeam').css('display', 'none');
			$('.modal-bg_team_edit').hide();
			window.index();
        });
    }
	$('#modalMessage').text(message);
	window.index();
}
// Delete team end

// Function to disable bulk edit
$(document).ready(function() {
	function checkTeamCheckBoxes() {
		var numChecked = $('.checkbox_teams:checked').length;
		if ($('#select-all-teams-checkbox').is(':checked')) {
			// If select all checkbox is checked, add class only if more than one checkbox is checked
			if (numChecked > 1) {
				$('.modal-link_edit').addClass('disable_edit');
			} else {
				$('.modal-link_edit').removeClass('disable_edit');
			}
		} else {
			// If select all checkbox is not checked
			if (numChecked > 1) {
				$('.checkbox_teams:checked').each(function() {
					$(this).closest('tr').find('.modal-link_edit').addClass('disable_edit');
				});
			} else {
				$('.checkbox_teams:not(:checked)').each(function() {
					$(this).closest('tr').find('.modal-link_edit').removeClass('disable_edit');
				});
			}
		}
	}
	

	$('.checkbox_teams').change(function() {
        // If any checkbox is unchecked while select-all-teams-checkbox is checked, uncheck select-all-teams-checkbox
        if (!this.checked && $('#select-all-teams-checkbox').is(':checked')) {
            $('#select-all-teams-checkbox').prop('checked', false);
        }
		// Check if all individual checkboxes are checked
        var allChecked = $('.checkbox_teams').length === $('.checkbox_teams:checked').length;
        $('#select-all-teams-checkbox').prop('checked', allChecked);
        checkTeamCheckBoxes();
    });

	$('#select-all-teams-checkbox').change(function() {
	  $('.checkbox_teams').prop('checked', this.checked);
	  checkTeamCheckBoxes();
	});

	//for member
	$(document).on('change', '.checkbox_members', function() {
			// If any checkbox is unchecked while select-all-checkbox is checked, uncheck select-all-checkbox
			if (!this.checked && $('#select-all-checkbox').is(':checked')) {
				$('#select-all-checkbox').prop('checked', false);
			}
			// Check if all individual checkboxes are checked
			var allChecked = $('.checkbox_members').length === $('.checkbox_members:checked').length;
			$('#select-all-checkbox').prop('checked', allChecked);
		});
	
		$(document).on('change', '#select-all-checkbox', function() {
			$('.checkbox_members').prop('checked', this.checked);
	});
});
  
  
//Enable delete icon only for selected rows
$(document).ready(function () {
    $('.delete_team_confirm').removeClass('disabled');
    
    $('.checkbox_teams').change(function () {
        // Get all checked checkboxes
        var checkedCheckboxes = $('.checkbox_teams:checked');
        
        // Enable delete icons for all checked rows
        checkedCheckboxes.each(function () {
            $(this).closest('tr').find('.delete_team_confirm').removeClass('disabled');
        });
        
        // Disable delete icons for all unchecked rows
        $('.checkbox_teams').not(':checked').each(function () {
            $(this).closest('tr').find('.delete_team_confirm').addClass('disabled');
        });

        // If no checkboxes are checked, enable all delete icons
        if (checkedCheckboxes.length === 0) {
            $('.delete_team_confirm').removeClass('disabled');
        }
    });

    $('#select-all-teams-checkbox').change(function () {
        var isChecked = $(this).is(':checked');
        $('.checkbox_teams').prop('checked', isChecked).trigger('change');
    });
    $('.checkbox_teams').trigger('change');


	// for Members

	$(document).on('change', '.checkbox_members', function() {
      // Get all checked checkboxes
      var checkedCheckboxes = $('.checkbox_members:checked');
      
      // Enable delete icons for all checked rows
      checkedCheckboxes.each(function () {
          $(this).closest('tr').find('.icon-del').removeClass('disabled');
      });
      
      // Disable delete icons for all unchecked rows
      $('.checkbox_members').not(':checked').each(function () {
          $(this).closest('tr').find('.icon-del').addClass('disabled');
      });

      // If no checkboxes are checked, enable all delete icons
      if (checkedCheckboxes.length === 0) {
          $('.icon-del').removeClass('disabled');
      }
  	});

  	$('#select-all-checkbox').change(function () {
      var isChecked = $(this).is(':checked');
      $('.checkbox_members').prop('checked', isChecked).trigger('change');
 	 });
  	$('.checkbox_members').trigger('change');
});

$(document).ready(function() {
    $('.div-right #myInput, #users_with_team').on('keyup change', function() {
      fetchUsersWithTeams(1);
    });
    function fetchUsersWithTeams(page) {
      var searchQuery = $('.div-right #myInput').val();
      var selectedTeam = $('#users_with_team').val();
	  var url = window.location.origin
      $.ajax({
        url: `${url}/users_with_teams.json?key=${api_key}`,
        type: 'GET',
        dataType: 'json',
        data: {
          search: searchQuery,
          team: selectedTeam,
          page: page
        },
        success: function(response) {
          var userListHtml = '';
          if (response.users.length > 0) {
            $.each(response.users, function(index, user) {
              userListHtml += `<tr class="tr_data tr_user" id="user_delete_${user.id}">`;
              userListHtml += '<td>' + ((page - 1) * 25 + index + 1) + '</td>';
              userListHtml += '<td class="team">' + user.name + '</td>';
              userListHtml += '<td>';
              if (user.teams) {
                $.each(user.teams, function(i, team) {
                  userListHtml += `<span class="team_delete team_delete_${user.id}" style="background-color:#F2F2F2;border-radius: 20px; margin-right: 5px; padding: 4px 5px 4px 8px;" id="team_delete_${team.id}_${user.id}">${team.name}`;
                  userListHtml += '<a href="#" class="cross-user-icon" onclick="team_delete(' + team.id + ',' + user.id + ')" tabindex="0">×</a>';
                  userListHtml += '</span>';
                });
              }
              userListHtml += '</td>';
              userListHtml += '</tr>';
            });
			if ($('.show_data').length > 0) {
				$('.show_data').html(userListHtml);
			  } else {
				var tableHtml = `
				<table class="list user_team">
				  <thead class="e_list">
					<tr>
					  <th style="width:100px">
						S.No
					  </th>
					  <th>
						User Name
					  </th>
					  <th>
						Teams
					  </th>        
					</tr>
				  </thead>
				  <tbody class="show_data">
					${userListHtml} <!-- Insert userListHtml here -->
				  </tbody>
				</table>
			  `;
			  $('#userData').append(tableHtml);
			  }
            $('.nodata').hide();
            $('table.user_team').show();
          } else {
            $('.show_data').html('');
			if($('.nodata:visible').length<=0){
				$('.nodata').show();
			}
			if($('#nodatalabel:visible').length>=1){
				$('#nodatalabel').hide();
			}
            $('table.user_team').hide();
          }
          updatePagination(response.pagination);
        },
        error: function(xhr, status, error) {
          console.error('AJAX Error:', status, error);
        }
      });
    }

    $(document).on('click', '.custom-pagination a', function(e) {
      e.preventDefault();
      var nextPage = $(this).data('page');
      fetchUsersWithTeams(nextPage);
    });

    function updatePagination(pagination) {
      var paginationHtml = '<div role="navigation" aria-label="Pagination" class="pagination custom-pagination">';

      if (pagination.prev_page) {
        paginationHtml += '<a class="previous_page" aria-label="Previous Page" href="#" data-page="' + pagination.prev_page + '">← Previous</a>';
      } else {
        paginationHtml += '<span class="previous_page disabled" aria-disabled="true">← Previous</span>';
      }

      for (var i = 1; i <= pagination.total_pages; i++) {
        if (i === pagination.current_page) {
          paginationHtml += '<em class="current" aria-label="Page ' + i + '" aria-current="page">' + i + '</em>';
        } else {
          paginationHtml += '<a aria-label="Page ' + i + '" href="#" data-page="' + i + '">' + i + '</a>';
        }
      }

      if (pagination.next_page) {
        paginationHtml += '<a class="next_page" aria-label="Next Page" href="#" data-page="' + pagination.next_page + '">Next →</a>';
      } else {
        paginationHtml += '<span class="next_page disabled" aria-disabled="true">Next →</span>';
      }

      paginationHtml += '</div>';
      $('.pagination').html(paginationHtml);

      if (pagination.total_pages <= 1) {
        $('.pagination').hide();
      } else {
        $('.pagination').show();
      }
    }
});


	
