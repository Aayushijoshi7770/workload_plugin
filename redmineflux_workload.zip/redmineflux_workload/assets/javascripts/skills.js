$(document).ready(function(){
	$('.modal-skill').click(function(){
		$('.modal_skill').show();
		$('.modal-bg_skill').show();
    window.index();
	
	});
	$('.modal_skill .close_skill').click(function(){
		$('.modal_skill').hide();
		$('.modal-bg_skill').hide();
    window.index();
	
	})
	$('.cross_close_skill').on('click keypress', function(event) {
    if (event.type === 'click' || (event.type === 'keypress' && event.key === 'Enter')) {
        $('.modal_skill').hide();
        $('.modal-bg_skill').hide();
        window.index();
    }
  });

  $('.cross_close_skillup').on('click keypress', function(event) {
  if (event.type === 'click' || (event.type === 'keypress' && event.key === 'Enter')) {
      $('.modal_edit').hide();
      $('.modal-bg_edit').hide();
      $("body :tabbable").attr("tabindex", 0);
      $("html").css("overflow-y", "scroll");
      return false;
  }
  });
}); 





$(document).ready(function(){

	$('.modal_edit #close_edit').click(function(){
		var u_r_l = location.origin
		location.href = `${u_r_l}/skills`
	})
  $(window).on('load', function() {
    window.index();
  });

  window.index= function disableTabindex() {
    if ($('.modal_skill, .modal_edit, .deleteModal').is(':visible')) {
      $(":tabbable").attr("tabindex", -1);
      $(".modal_skill [tabindex='-1'], .modal_edit [tabindex='-1']").attr("tabindex", 0);
      $(".deleteModal [tabindex='-1']").attr("tabindex", 0);
      $("html").css("overflow", "hidden");
    }
    else {
      $("[tabindex='-1']").attr("tabindex", 0);
      $("html").css("overflow", "auto");
    }
  }

})

function mySkill() {
	var input, filter, table, tr, td, i, txtValue;
	input = document.getElementById("myInput_2");
	filter = input.value.toUpperCase();

	tr = document.getElementsByClassName("s_search");;
	for (i = 0; i < tr.length; i++) {
	  td = tr[i].getElementsByTagName("td")[2];
	  if (td) {
		txtValue = td.textContent || td.innerText;
		if (txtValue.toUpperCase().indexOf(filter) > -1) {
			tr[i].style.display = "";
			document.querySelector(".no_data").style.display = "none";
			$(".e_list").show();
		  } else {
			tr[i].style.display = "none";
		   
			if($(".skill_change tbody tr:not([style='display: none;'])").length == 0){
			  $(".no_data").show();
			  document.querySelector(".e_list").style.display = "none";
			}
		  }
	  }       
	}
  }
 
//   function skills_ids(id){

        
//     if ($('.checkbox_skill:checked').length > 0) {
//         const table13 = $('.skill_change');


//     const deleteLink13 = $('#skillDelete');
//         const checkboxIds = [];
//         table13 .find('td input[type="checkbox"]:checked').each(function() {
//           checkboxIds.push($(this).attr('value'));
//         });
//         // $('.modal-members-delete').show();
//         // $('.modal-bg-members_delete').show();

    
//       // deleteLink13.on('click', function(event) {
//       //   event.preventDefault();
//         const confirmDelete = confirm("Are you sure you want to delete the selected skills?");
//         if (confirmDelete) {
//             const checkboxdeleteIds13 = [];
//             table13.find('td input[type="checkbox"]:checked').each(function () {
//                 checkboxdeleteIds13.push($(this).attr('id'));
//             });

//             $.ajax({
//                 type: "DELETE",
//                 url: `${url}/delete_bulk_skills.json?key=${api_key}&&id=${checkboxdeleteIds13}`,
//                 contentType: "application/json",
//                 dataType: "json",
//             });

//             setTimeout(() => {
//                 location.reload();
//             }, 500);
//         }
//     // });
// } else {
//     const confirmDelete = confirm("Are you sure you want to delete this skill?");
//     if (confirmDelete) {
//         $.ajax({
//             type: "DELETE",
//             url: `${url}/delete_bulk_skills.json?key=${api_key}&&id=${id}`,
//             contentType: "application/json",
//             dataType: "json",
//         });

//         setTimeout(() => {
//             location.reload();
//         }, 500);
//     }
// }

// }



function skills_ids(id) {
  var message;

  if ($('.checkbox_skill:checked').length > 1) {
    $('#modalheading').text("Delete Skills");
      message = "Are you sure you want to delete the selected skills?";
      const table13 = $('.skill_change');
      const checkboxIds = [];
      table13.find('td input[type="checkbox"]:checked').each(function() {
          checkboxIds.push($(this).attr('value'));
      });

      const checkboxdeleteIds13 = [];
      table13.find('td input[type="checkbox"]:checked').each(function() {
          checkboxdeleteIds13.push($(this).attr('id'));
      });
      
      $('#deleteSkills').css('display', 'block');
      $('.modal-bg_skill').show();

      $('#confirmBtn').click(function() {
          $('#deleteSkills').css('display', 'none');
          $.ajax({
              type: "DELETE",
              url: `${url}/delete_bulk_skills.json?key=${api_key}&id=${checkboxdeleteIds13}`,
              contentType: "application/json",
              dataType: "json",
              success: function() {
                  location.reload();
              },
              error: function(error) {
                  console.error("Error deleting item:", error);
              }
          });
      });

      $('#cancelBtn').click(function() {
          $('#deleteSkills').css('display', 'none');
          $('.modal-bg_skill').hide();
          window.index();
      });
  } 
  else {
      $('#modalheading').text("Delete Skill");
      message = "Are you sure you want to delete this skill?";
      $('#deleteSkills').css('display', 'block');
      $('.modal-bg_skill').show();

      $('#confirmBtn').click(function() {
          $('#deleteSkills').css('display', 'none');
          $.ajax({
              type: "DELETE",
              url: `${url}/delete_bulk_skills.json?key=${api_key}&id=${id}`,
              contentType: "application/json",
              dataType: "json",
              success: function() {
                  location.reload();
              },
              error: function(error) {
                  console.error("Error deleting item:", error);
              }
          });
      });

      $('#cancelBtn').click(function() {
          $('#deleteSkills').css('display', 'none');
          $('.modal-bg_skill').hide();
          window.index();
      });
  }
  window.index();
  $('#modalMessage').text(message);
}


function closeUpdateSkillModal(){
  console.log("closeUpdateSkillModal");
  var newTeamModal = document.getElementById("skill_update_model");
  let overlay = document.getElementById("skill_update_back");
  newTeamModal.style.display = "none";
  overlay.style.display = "none";
  $("body :tabbable").attr("tabindex", 0);
  $("html").css("overflow-y", "scroll");
}


// Function to disable bulk edit
$(document).ready(function() {
  function checkSkillCheckBoxes() {
    var numChecked = $('.checkbox_skill:checked').length;
    if ($('#select-all-skill-checkbox').is(':checked')) {
        // If select all checkbox is checked, add class only if more than one checkbox is checked
        if (numChecked > 1) {
            $('.icon-edit').addClass('disable_edit');
        } else {
            $('.icon-edit').removeClass('disable_edit');
        }
    } else {
        // If select all checkbox is not checked
        if (numChecked > 1) {
            $('.checkbox_skill:checked').each(function() {
                $(this).closest('tr').find('.icon-edit').addClass('disable_edit');
            });
        } else {
            $('.checkbox_skill:not(:checked)').each(function() {
                $(this).closest('tr').find('.icon-edit').removeClass('disable_edit');
            });
        }
    }
}


  $('.checkbox_skill').change(function() {
    // If any checkbox is unchecked while select-all-teams-checkbox is checked, uncheck select-all-teams-checkbox
    if (!this.checked && $('#select-all-skill-checkbox').is(':checked')) {
        $('#select-all-skill-checkbox').prop('checked', false);
    }
    // Check if all individual checkboxes are checked
    var allChecked = $('.checkbox_skill').length === $('.checkbox_skill:checked').length;
    $('#select-all-skill-checkbox').prop('checked', allChecked);
    checkSkillCheckBoxes();
  });

  $('#select-all-skill-checkbox').change(function() {
    $('.checkbox_skill').prop('checked', this.checked);
    checkSkillCheckBoxes();
  });

});

//Enable delete icon only for selected rows
$(document).ready(function () {
  $('.delete_team_confirm').removeClass('disabled');
  
  $('.checkbox_skill').change(function () {
      // Get all checked checkboxes
      var checkedCheckboxes = $('.checkbox_skill:checked');
      
      // Enable delete icons for all checked rows
      checkedCheckboxes.each(function () {
          $(this).closest('tr').find('.delete_team_confirm').removeClass('disabled');
      });
      
      // Disable delete icons for all unchecked rows
      $('.checkbox_skill').not(':checked').each(function () {
          $(this).closest('tr').find('.delete_team_confirm').addClass('disabled');
      });

      // If no checkboxes are checked, enable all delete icons
      if (checkedCheckboxes.length === 0) {
          $('.delete_team_confirm').removeClass('disabled');
      }
  });

  $('#select-all-skill-checkbox').change(function () {
      var isChecked = $(this).is(':checked');
      $('.checkbox_skill').prop('checked', isChecked).trigger('change');
  });

  $('.checkbox_skill').trigger('change');
});
  

