var key;
$(document).ready(function(){
	$('.modal_memb').click(function(){
		grp_id = localStorage.getItem("id")
		$('#mem').val(grp_id)
		$('.modal-memb').show();
		$('.modal-bg-memb').show();
		disableTabindex();

	});
	$('.modal-memb .memb_close  ').click(function(){
		$('.modal-memb').hide();
		$('.modal-bg-memb').hide();
		disableTabindex();
	})
	$('.cross_close').on('click keypress', function(event) {
		if (event.type === 'click' || (event.type === 'keypress' && event.key === 'Enter')) {
			$('.modal-memb').hide();
			$('.modal-bg-memb').hide();
			disableTabindex();
		}
	});	
	$('.cross_close_details').on('click keypress', function(event) {
		if (event.type === 'click' || (event.type === 'keypress' && event.key === 'Enter')) {
			$('.modal-edit_memb').hide();
			$('.modal-bg-edit-memb').hide();
			disableTabindex();
		}
	});
	
	$('.cross_close_bulk').on('click keypress', function(event) {
		if (event.type === 'click' || (event.type === 'keypress' && event.key === 'Enter')) {
			$('.modal-bulk_memb').hide();
			$('.modal-bg-bulk-memb').hide();
			disableTabindex();
		}
	});
	
	$('.bulk_close  ').click(function(){
		$('.modal-bulk_memb').hide();
		$('.modal-bg-bulk-memb').hide();
		disableTabindex();
	})


})
// Get all rows of the table

function reset_popup(){
	$('#add_members').val(null).trigger('change');
	$('#team_member_skills').val(null).trigger('change');
	disableTabindex();
  }

function edit_click(edit){
	let team_member_update_button=document.getElementById('memb_edit_submit');
	let bulk_team_update=document.getElementById('memb_bulk_submit');
	if(bulk_team_update){
		bulk_team_update.disabled=true;
		bulk_team_update.style.cursor='not-allowed';
	}
	if(team_member_update_button){
		team_member_update_button.disabled=true;
		team_member_update_button.style.cursor='not-allowed';
	}
	
	if ($('.checkbox_members:checked').length > 0) {
		const table0 = $('.edit_memb_list');
		const checkboxIds = [];
		table0.find('td input[type="checkbox"]:checked').each(function() {
		  checkboxIds.push($(this).attr('value'));
		});
	  //   $('#current_edit-commitment').val('')
		localStorage.setItem('td_ids', checkboxIds)
  
		  $('.modal-bulk_memb').show();
		  $('.modal-bg-bulk-memb').show();
		  disableTabindex();
  
	}  else {
  
	grp_id = localStorage.getItem("id")
	var url=window.location.origin


		$('.modal-edit_memb').show();
		$('.modal-bg-edit-memb').show();
		disableTabindex();
	
		fetch(`${url}/members_api.json?key=${api_key}&&group_id=${grp_id}&&member_id=${edit}`, {
			Method: "GET",
			Headers: {
			  Accept: "application.json",
			  "Content-Type": "application/json",
		
			},
		
			Cache: "default",
		  })
			.then((response) => response.json())
			.then((result) => {
			  users = result;
			  console.log(users);
			  users.forEach((value,i) => {
				var currentSelectedOption_3 = $('#mySelect_commit li.selected');

				// If an option is currently selected, remove the selected class
				if (currentSelectedOption_3.length > 0) {
				  currentSelectedOption_3.removeClass('selected');
				}
				$("#current_edit-commitment").text(value.commitment+"%");
				var select = document.getElementById("mySelect_commit");
				var options = select.getElementsByTagName("li");
				for (var i = 0; i < options.length; i++) {
				  if (options[i].getAttribute("data-value") == value.commitment) {
					options[i].classList.add("selected");
					break;
				  }
				}
				
				console.log(	'xsxs', $("#current_edit-commitment").text())

				var newDate = new Date(value.joining_date);

				// Select the date picker
				var datePicker = document.getElementById("join_edit");
				
				// Set the value of the date picker
				datePicker.value = newDate.toISOString().split('T')[0];

				var newDate = new Date(value.leaving_date);

				// Select the date picker
				var datePicker = document.getElementById("leave_edit");
				
				// Set the value of the date picker
				datePicker.value = newDate.toISOString().split('T')[0];
						
							console.log($("#join_edit").val());


var str = value.skills
var rle = value.role_id
var arr = str.split(',').map(function(val) {
	return val.trim();
  });
  console.log(arr,"skills???????")
							
	$('#edit_skills').val(arr).trigger('change.select2');
	$('#edit_role_wk').val(rle).trigger('change.select2');
	
								
								
			  })
			})
			
		
	
		
		$('#memb_edit_submit').click(function(){
			grp_id = localStorage.getItem("id")
			var commitment = $("#current_edit-commitment").text().replace(/%/g, "");
			var skills =$("#edit_skills").val();
			console.log(skills,"sksksksksks")
			
			var joining_date = $("#join_edit").val();
			var leaving_date = $("#leave_edit").val();
			var role_id = $("#edit_role_wk").val();
			
				$.ajax({
					type: "PUT",
					url: `${url}/update_edit_members/${edit}.json?key=${api_key}&&group_id=${grp_id}&&commitment=${commitment}&skills=${skills}&role_id=${role_id}&joining_date=${joining_date}&leaving_date=${leaving_date}`,
				
					contentType: "application/json",
					dataType: "json",
				
				  });
				  setTimeout(() => {
				  location.reload();
				
			}, 500);
		})

		
}
					  
			
}
$(document).ready(function(){
$('.modal-edit_memb .memb_close').click(function(){
	$('.modal-edit_memb').hide();
	$('.modal-bg-edit-memb').hide();

})
})


function disableTabindex() {
  if ($('.modal-memb,.modal-edit_memb,.modal-bulk_memb').is(':visible')) {
    $(":tabbable").attr("tabindex", -1);
	$(".modal-memb [tabindex='-1'],.modal-edit_memb [tabindex='-1']").attr("tabindex", 0);
	$(".modal-bulk_memb [tabindex='-1']").attr("tabindex", 0);
	$("#commit-drop, #commit_edit-drop").attr("tabindex", 0);
  	$("html").css("overflow", "hidden");
  }
  else{
    $("[tabindex='-1']").attr("tabindex", 0);
    $("html").css("overflow", "auto");
  }
}


