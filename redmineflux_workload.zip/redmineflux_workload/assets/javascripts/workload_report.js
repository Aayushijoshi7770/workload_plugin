
// $(document).ready(function() {

//   // -----------------------------------filter options --------------------------
//       document.getElementById('filter_options').addEventListener('change', function () {
//           var filterValue = this.value;
//           var additionalOptionsDiv = document.getElementById('additional_options');
//           var additionalOptionFieldsDiv = document.getElementById('additional_option_fields');
//           var projectOptionFieldsDiv = document.getElementById('project_field');
          
              
//           if (filterValue === 'Available hours' || filterValue === 'Planned hours') {
//              additionalOptionsDiv.style.display = 'contents';
//              projectOptionFieldsDiv.style.display = 'none';
  
  
//           // ------------------------------on change the second field --------
            
//               document.getElementById('filter_operator').addEventListener('change', function () {
//               var selectedOption = this.value;
          
//               additionalOptionFieldsDiv.innerHTML = '';
//               additionalOptionFieldsDiv.style.display = 'contents';
              
          
//               if (selectedOption === 'is' || selectedOption === '>=' || selectedOption === '<=') {
//                   var selectHTML = '<label for="additional_option_value"></label><select name="additional_option_value" id="additional_option_value">';
//                   for (var i = 0; i <= 10; i++) {
//                       var optionValue = i * 10;
//                       selectHTML += '<option value="' + optionValue + '%">' + optionValue + '%</option>';
//                   }
//                   selectHTML += '</select>';
//                   additionalOptionFieldsDiv.innerHTML = selectHTML;
//               }
//                else if (selectedOption === 'between') {
//                   additionalOptionFieldsDiv.innerHTML = '<label for="additional_option_value_min"> Min </label> <input type="text" name="additional_option_value_min" id="additional_option_value_min" />' +
//                   '<label for="additional_option_value_max"> Max </label> <input type="text" name="additional_option_value_max" id="additional_option_value_max" />';
//               }
//                 });
  
//               }  
//               else if (filterValue === 'Project' ){
//                 projectOptionFieldsDiv.style.display = 'contents';
//                 additionalOptionsDiv.style.display = 'none';
//                 additionalOptionFieldsDiv.style.display = 'none';
//               }
//               else {
//                 additionalOptionsDiv.style.display = 'none';
//                 additionalOptionFieldsDiv.style.display = 'none';
//                 projectOptionFieldsDiv.style.display = 'none';
//               }
//             });
  
//             // $('#team_').select2();
//             // $('#Users').select2();
            
//             $('#team_').select2({
//               // closeOnSelect: false
//             });

//         $('#Users').select2({
//             // closeOnSelect: false
//         }).on('change', function(e) {
//             var data = $(this).select2('data'); 
            
//             // Check if 'All Users' is selected
//              var allUsersSelected = data.some(function(item) {
//                 return item.id === 'all';
//              });
      
//              if (allUsersSelected) {
//                  // If 'All Users' is selected, unselect and disable other options
//                  $('#Users option').each(function() {
//                    if ($(this).val() !== 'all') {
//                       $(this).prop('selected', false).prop('disabled', true);                                  
//                    }
//                  });
//             } else {
//               // If 'All Users' is not selected, enable all options
//               $('#Users option').prop('disabled', false);
//             }
      
//           // If no user is selected, enable 'All Users' option
//           if (data.length === 0) {
//               $('#Users option[value="all"]').prop('disabled', false)
//           }
//           $('#Users').trigger('change.select2');
//       });
      


//     // ----------------------------------------- Resize the chart -------------------------
//     // var grid = GridStack.init();
//     // =======================================
//     var options = {
//       auto: true,
//       float: true,
//       cellHeight: 145,
//       minWidth: 600,
//       disableOneColumnMode: true,
//       row: 3,
//       animate: true,
//       resizable: {
//         handles: "se",
//       },
//     };
  
//     var grid = GridStack.init();
//     // $(".grid-stack").gridstack(options);
  
//     //-- Get the total number of cards
//     setTimeout(() => {
//       // Get the total number of cards
//       totalCards = $(".grid-stack-item").length;
//       console.log("Total number of cards: " + totalCards);
//     }, 200);
//     //--end
  
  
//   $('.grid-stack').on('gridstack:load', function(event, items) {
//     var grid = event.target.gridstack;
  
  
   
//       var updatedOptions = {
//         rows: totalCards, 
      
//       };
//       // console.log("Total number of cards: ");
//       // console.log(grid, "Total number of cards: " + updatedOptions);
//       // Set the updated options using setGridOption method
//       grid.setGridOption(updatedOptions);
//     });
  
//     // auto scroll html page up and down while dragging card above and below of visible area of page
  
//     setTimeout(() => {
//       $(".grid-stack-item").on("drag", function (event) {
//         // to get the offset top of card
//         var cardTop = $(this).offset().top;
//         var cardBottomPosition = $(this).offset().top + $(this).outerHeight();
//         var windowHeight =
//           $(window).height() + document.documentElement.scrollTop;
  
//         //  if card offset top+card height is less than html page height + scroll top then do scroll down
//         if (cardBottomPosition > windowHeight) {
//           // Adjust the value as needed
//           // scroll down
//           document.documentElement.scrollTop += 30;
//         }
//         // if card top position is less than window scroll top then do scroll up
//         if (cardTop < document.documentElement.scrollTop) {
//           // scroll up
//           document.documentElement.scrollTop -= 30;
//         }
//       });
//     }, 200);
  
//     // logic end
//     setTimeout(() => {
//       grid.on("change", function (event, items) {
//         for (var i = 0; i < items.length; i++) {
//           var item = items[i];
//           console.log(item, "items");
  
//           grid_Xaxis = item.x;
//           grid_Yaxis = item.y;
//           width = item.w;
//           height = item.h;
//           id = item.id;
  
//           var element = document.querySelector('[gs-id="' + id + '"]');
//           var elementWidth = element.offsetWidth;
  
//           if (width <= 3) {
//             width = 3;
//           }
//           if (height <= 2) {
//             height = 2;
//           }
  
//           if (grid_Xaxis == -0 || grid_Xaxis == 0 || grid_Xaxis <= 1) {
//             grid_Xaxis = 0;
//           }
  
//           else if (grid_Xaxis == 2 || grid_Xaxis <= 4) {
//             grid_Xaxis = 3;
//           }
//           else if (grid_Xaxis == 5 || grid_Xaxis <= 7) {
//             grid_Xaxis = 6;
//           }
//           else {
//             grid_Xaxis = 9;
//           }
  
//           if (grid_Yaxis == -0) {
//             grid_Yaxis = 0;
//           }
//         // =======

//         var contents = {
//           "width": width,
//           "height": height,
//           "grid_Xaxis": grid_Xaxis,
//           "grid_Yaxis": grid_Yaxis
//         };
//         var grid_id = parseInt(id);

//         $.ajax({
//           type: "Patch",
//           url: `${url}/update_size_report/${grid_id}.json?key=${api_key}`,
//           dataType: "json",
//           contentType: 'application/json',
//            data: JSON.stringify({
//            "workload_report": contents
//          }),
//           success: function (res, status, xhr) {
//               console.log(res, 'res');
//           },
//           error: function (xhr, status, error) {
//               console.log(error);
//           }
//       });
       
//           grid.update(element, {
//             w: width, h: height
  
//           });
//         }
//       });
    
//     },200)

  
//          });
//   //  -----------------------------------------Delete Modal ---------------------
//         function Closeworkloadcontainer(grid_id) {
  
//           let background_div=document.getElementsByClassName("div-modal");
//             background_div[0].style.display="block";
      
//              if($(`#delete${grid_id}`).length===0)
//               {
//                 $("body").append(`<div  id="delete${grid_id}" class="delete-modal">
//                               <div style="display:flex; justify-content:space-between; height:47px" class="heading-div">
//                               <div  style="display:flex;">
//                               <h2 class="delete-heading"> Delete Card </h2>
//                               </div>
//                               <div onclick="ClosedeleteworkloadModal(${grid_id})" onkeypress="if (event.key === 'Enter') { ClosedeleteworkloadModal(${grid_id}) }" style="display:flex; cursor:pointer;">
//                               <img tabindex = "0" style="width:14px; margin-top: 10px; height:22px;" src="/plugin_assets/redmineflux_dashboard/images/cross.svg">
//                               </div>
//                               </div> 
//                               <p class="delete-para"> Are you  sure you want to delete this card?</p>
//                               <div style="display:flex; justify-content:center; margin-top:18px;">
//                               <div id="btn-plan" onclick="ClosedeleteworkloadModal(${grid_id})" style="display:flex;  margin-right:15px; cursor:pointer">
//                               <button  id="cancel-btn" style="cursor:pointer" class="button-plan">Cancel </button>
//                               </div>
//                               <div onclick="DeleteworkloadChart(${grid_id})" type="button" style="display:flex;  cursor:pointer">
//                               <button id="save-btn"  style="cursor:pointer" class="button-cross">Delete </button>
//                               </div>
//                               </div>
//                               </div>`);
//                }
//                else{
//                $(`#delete${grid_id}`).css("display","block");
//                }
//                window.disableTabindex();
//           }
  
//           // ---------------------------------close delete modal --------------
           
  
  
  
//      function ClosedeleteworkloadModal(grid_id) {
//       let background_div = document.getElementsByClassName("div-modal");
//       background_div[0].style.display = "none";
//       $(`#delete${grid_id}`).css("display", "none");
//     }
  
//      //  ------------------delete APi ---------
  
//     function DeleteworkloadChart(grid_id) {
//          $.ajax({
//        url: `${url}/delete_report.json?key=${api_key}`,
//        method: "DELETE",
//        data: { grid_id: grid_id }, 
//        success: function (response) {
//         //  console.log( grid_id ,'delete grid');
//         let background_div = document.getElementsByClassName("div-modal");
//         background_div[0].style.display = "none";
//         $(`#delete${grid_id}`).css("display", "none");
  
//        let elements = document.querySelectorAll(".grid-stack-item");
//        for (let i = 0; i < elements.length; i++) {
//          const element = elements[i];
//          if (element.getAttribute("gs-id") == grid_id) {
//            element.remove();
//            break;
//          }
//        }
//        window.location.reload();
//        }
//       });
//     }
//   // -----------------

//   $(document).ready(function() {
//     window.disableTabindex = function() {
//         if ($('#add_chart-modal, .delete-modal').is(':visible')) {
//           $(":tabbable").attr("tabindex", -1);
//           $("#add_chart-modal [tabindex='-1'],.delete-modal [tabindex='-1']").attr("tabindex", "0");
//           $("html").css("overflow", "hidden");
//         } 
//         else {
//           $("[tabindex='-1']").attr("tabindex", 0);
//           $("html").css("overflow", "auto");
//         }
//     }
//     window.disableTabindex();
// });
    

//   function openForm(){

//     // Remove all selected options
//     $('#team_, #Users').val(null).trigger('change');
    
//     $('#period_type_1').prop('checked', true);
//     $('#period')[0].selectedIndex = 0;
//     $('#period').removeAttr('disabled');
//     $('#from, #to').val(new Date().toISOString().slice(0, 10));
//     $('#from, #to').prop('disabled', true);

//     $('#filter_operator, #filter_options').val(null).trigger('change');
//     $('#additional_options, #additional_option_fields, #project_field').hide();

//     modal = document.getElementById("add_chart-modal");
//     overlay = document.getElementById("add_chart-overlay");
//     modal.style.display = "block"
//     window.disableTabindex();
  
//     setTimeout(() => {
//       modal.classList.add("show-modal");
//       modal.classList.add("center-modal");
//       overlay.classList.add("show-modal");
//     }, 1);
    

//   }

//   function CloseFormModal(){
//     modal = document.getElementById("add_chart-modal");
//     overlay = document.getElementById("add_chart-overlay");
//     modal.style.display = "none"
//     $('#flash_error').html('');
//     $('#flash_error').hide();
   

//     setTimeout(() => {
//       modal.classList.remove("show-modal");
//       modal.classList.remove("center-modal");
//       overlay.classList.remove("show-modal");
//       window.disableTabindex();
//     }, 1);
//   }


var start = moment().subtract(29, 'days');
var end = moment();

function cb(start, end) {
  var start_range = start.format('YYYY-MM-DD');
  var due_range = end.format('YYYY-MM-DD');

  // Make sure gantt is defined before setting its options
  if (typeof gantt !== 'undefined') {
    gantt.options.startDate = start_range;
    gantt.options.endDate = due_range;
  }

  $('#reportrange span').html(start.format('D MMM YY') + ' - ' + end.format('D MMM YY'));
}

$(document).ready(function() {

  toastr.options = {
    closeButton: true,
    debug: false,
    newestOnTop: false,
    progressBar: true,
    positionClass: "toast-top-right",
    preventDuplicates: false,
    onclick: null,
    showDuration: "100",
    hideDuration: "800",
    timeOut: "2000",
    extendedTimeOut: "1000",
    showEasing: "swing",
    hideEasing: "linear",
    showMethod: "fadeIn",
    hideMethod: "fadeOut",
  };

  var filter_teams_ids = [];
  var filter_users_ids = [];

  if (filter_data.team_ids) {
    try {
      filter_teams_ids = JSON.parse(filter_data.team_ids);
    } catch (e) {
      console.error("Error parsing team_ids:", e);
    }
  }

  if (filter_data.user_ids) {
    try {
      filter_users_ids = JSON.parse(filter_data.user_ids);
    } catch (e) {
      console.error("Error parsing user_ids:", e);
    }
  }


  var params = {
    filterBy: filter_data.filter_by || "team",   
    startDate: filter_data.start_date || moment().startOf('month').format('YYYY-MM-DD'),     
    endDate: filter_data.end_date || moment().endOf('month').format('YYYY-MM-DD'),          
  };

  if (filter_data.filter_by === 'team') {
    $('#filterCombo').val('team');
    $('#team_dropdown').show();
    $('#user_dropdown').hide();
    $('#Select_team').val(filter_teams_ids).trigger('change');
    params.teams = filter_teams_ids.map(Number);
  }else if (filter_data.filter_by === 'user') {
    $('#filterCombo').val('user');
    $('#team_dropdown').hide();
    $('#user_dropdown').show();
    $('#Select_user').val(filter_users_ids).trigger('change');
    params.users = filter_users_ids.map(Number);
  }

  getAllReportData(params);
  var filterCombo = document.getElementById('filterCombo');
  var teamDropdown = document.getElementById('team_dropdown');
  var userDropdown = document.getElementById('user_dropdown');

  setVisibility(filterCombo.value);

  filterCombo.addEventListener('change', function() {
    setVisibility(filterCombo.value);
  });

  function setVisibility(value) {
    if (value === 'team') {
      teamDropdown.style.display = 'block';
      userDropdown.style.display = 'none';
    } else if (value === 'user') {
      teamDropdown.style.display = 'none';
      userDropdown.style.display = 'block';
    }
  }


  var start = filter_data.start_date ? moment(filter_data.start_date) : moment().startOf('month');
  var end = filter_data.end_date ? moment(filter_data.end_date) : moment().endOf('month');


  $('#reportrange').daterangepicker({
    startDate: start,
    endDate: end,
    ranges: {
       'Today': [moment(), moment()],
       'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
       'Current Week':[moment().clone().isoWeekday(1),moment().clone().isoWeekday(7)],
       'Last 7 Days': [moment().subtract(6, 'days'), moment()],
       'Last 30 Days': [moment().subtract(29, 'days'), moment()],
       'This Month': [moment().startOf('month'), moment().endOf('month')],
       'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')],
       'Next Month': [moment().add(1, 'month').startOf('month'), moment().add(1, 'month').endOf('month')]
    }
  }, cb);

  cb(start, end);

  $("[data-range-key='Custom Range']").click(function() {
    $(this).addClass("active");
    $("[data-range-key='Today']").removeClass("active");
    $("[data-range-key='Current Week']").removeClass("active");
    $("[data-range-key='Next Month']").removeClass("active");
    $("[data-range-key='This Month']").removeClass("active");
    $("[data-range-key='Last Month']").removeClass("active");
    $("[data-range-key='Last 30 Days']").removeClass("active");
    $("[data-range-key='Last 7 Days']").removeClass("active");
    $("[data-range-key='Yesterday']").removeClass("active");
  });

});


function updateWorkloadReports() {
  var filterBy = $('#filterCombo').val(); 
  var selectedTeams = $('#Select_team').val();
  var selectedUsers = $('#Select_user').val();
  var selectedDates = $('#reportrange').data('daterangepicker');
  var startDate = selectedDates.startDate.format('YYYY-MM-DD');
  var endDate = selectedDates.endDate.format('YYYY-MM-DD');

  var params = {
    filterBy: filterBy, 
    startDate: startDate,
    endDate: endDate
  };

  if (filterBy === 'team') {
    if (!selectedTeams || selectedTeams.length === 0) {
      toastr.error('Please select at least one team.');
      return;
    }
    params.teams = selectedTeams;
  } else if (filterBy === 'user') {
    if (!selectedUsers || selectedUsers.length === 0) {
      toastr.error('Please select at least one user.');
      return;
    }
    params.users = selectedUsers;
  }

  $.ajax({
    url: `${window.location.origin}/save_filter_data`,
    method: "POST",
    data: JSON.stringify(params),
    contentType: "application/json",
    success: function (response) {
    },
    error: function (error) {
      console.error("Error saving filter data:", error);
    },
  });

  getAllReportData(params);

}

function showLoader() {
  let body_div = document.getElementsByClassName(
    "has-main-menu controller-workload_reports action-workload_report"
  );
  let div = document.createElement("div");
  div.className = "unknown-div";
  div.style.display = "block";
  body_div[0].appendChild(div);
  $(".circle-loader").show();
}

function hideLoader() {
  $(".circle-loader").hide();
  $(".unknown-div").css("display", "none");
}

function getAllReportData(params) {
  showLoader();

  $.when(
    $.ajax({
      url: `${window.location.origin}/workload_planned_hours_chart_data`,
      method: "GET",
      data: params,
      dataType: "html"
    }),
    $.ajax({
      url: `${window.location.origin}/workload_available_hours_chart_data`,
      method: "GET",
      data: params,
      dataType: "html"
    }),
    $.ajax({
      url: `${window.location.origin}/workload_reports_table_data`,
      method: "GET",
      data: params,
      dataType: "html"
    })
  ).done(function(plannedHoursResponse, availableHoursResponse, reportTableResponse) {
    $("#planned_hours_chart").html(plannedHoursResponse[0]);
    $("#available_hours_chart").html(availableHoursResponse[0]);
    $("#report_hours_table").html(reportTableResponse[0]);
  }).fail(function(error) {
    console.error("Error fetching data:", error);
  }).always(function() {
    hideLoader();
  });
}


