var total_pages;
var start;
var end ;
var resource_data=[];
var workload_data=[];
var is_search="";
var is_team_selected=false;
var skills="";
var is_user_selected=false;
var team="";
var is_team=[];
var is_user=[];
var start_range;
var due_range;
var team_total_pages;
var teampagenum=1;
var teamperpage=10;



$(document).ready(function () {

  var perpage=20;
  var pagenum=1;
  let isAdmin = false;

  is_team=[];

  $("#Select_users").select2({
    closeOnSelect: false
  });



  $(".workhour-div").css("margin-bottom","18px");
  // global variables
  var element = document.getElementById("gantt_here");
  window.gantt = new ztGantt(element);

   removeAjaxIndicator();
   

   $("#start_date, #due_date").on('change', function() {
    // Your code to handle the change event
    let distributionCheckbox=document.getElementById("watchers-input");
    let task=JSON.parse(localStorage.getItem("task_timesheet"));
 if(!distributionCheckbox.checked)
  {
    $("#date-inputs").html("");
    if(task.distribution=="custom")
    {
       createBox(task.workhours,task);
    }
    else{
      createBox([],task);
    }
  
  }
    // Add your additional logic here
});

  $.ajax({
    type: "GET",
    url: url + `/workload_permissions.json?key=${api_key}`,
    dataType: "json",
    async:false,
    beforeSend: function(){            
      $('.circle-loader').show();
    },
    contentType: 'application/json',
    success:function(result){
     
      if (result.admin === true) {
        isAdmin=true;
        callTeamAPI();
        $("#team_dropdown").css("display","flex");    
        $("#user_dropdown").css("display","flex");      
     }
     else if(result.manage_workload === true ){
      isAdmin=true;
      $("#team_dropdown").css("display","block");
      $("#user_dropdown").css("display","flex"); 
      callTeamAPI();
    }
    else{
     $("#team_dropdown").css("display","none");
     $("#user_dropdown").css("display","none"); 
     $("#filterCombo .team-option").remove();
     $("#filterCombo .user-option").remove();
 }
 
    },
    error:function(error)
     {
     }
   }); 

 function callTeamAPI(){
    // Call get API to get all team names
  //  return $.ajax({
  //   type: "GET",
  //   url: `${url}/team_search_data.json?key=${api_key}`,
  //   dataType: 'json',
  //   success: function (result, status, xhr) {
  //     $("#Select_team").select2({
  //       closeOnSelect: false
  //   });
  //     if(result.length!=0){
  //       result.map((i)=>{
  //           $("#Select_team").append(`<option  value=${i.id} >${i.name}</option>`)
  //       })
  //       // $('#Select_team').trigger('chosen:updated');
  //       $("#Select_team").select2({
  //         closeOnSelect: false
  //     });
  //     }
  //   },
  //   error: function (xhr, status, error) {
  //     $("#Select_team").html(" ");
  //   }
  //  }); 
 }

 function callSelectedTeamAPI(){
          //  get selected team data through api 
          // setTimeout(()=>{
          //   return $.ajax({
          //     type: "GET",
          //     url: `${url}/selected_teams.json?key=${api_key}`,
          //     dataType: 'json',
          //     success: function (result, status, xhr) {
          //        is_team=[];
          //        is_user =[];

          //        let  team_data = result.filter(item => item.team_id != 0);
          //        let  user_data = result.filter(item => item.selected_user_ids != 0);

          //        if(result.length!=0 && team_data.length!=0)
          //         {
                   
          //          team_data.forEach(item => {
          //            if (item.team_id !== null) {
          //                is_team.push(item.team_id);
          //            } 
          //           });
          //         }

          //         if(result.length!=0 && user_data.length!=0){
          //           user_data.forEach(item => {
          //             if (item.selected_user_ids !== null) {
          //                 is_user.push(item.selected_user_ids);
          //             }
                     
          //           });
          //         }



          //     },
          //     error:function(xhr,status,error)
          //     {      
          //     }
          //   })
          // },500)
   
     }

function removeAjaxIndicator() {
  $(document).bind('ajaxSend', function(event, xhr, settings) {
    if ($('.ajax-loading').length === 0 && settings.contentType != 'application/octet-stream') {
    $('#ajax-indicator').hide();   
    }
  });
  $(document).bind('ajaxStop', function() {
    $('#ajax-indicator').hide(); 
  });
}




    const dropdown = $("#detail"); 
    if (dropdown_selected_option) {
      dropdown.val(dropdown_selected_option);
      if(dropdown_selected_option==="expand")
      {
       gantt.options.collapse =false;
      }
      else{
        gantt.options.collapse = true;
      }
     
    }

    //  Gantt library options
    // gantt.options.collapse = true;
    gantt.options.weekends = ["Sat", "Sun"];
    gantt.options.fullWeek = true;
    gantt.options.todayMarker=false;

    gantt.options.weekStart = 1; // set the start of the week
    // gantt.options.sidebarWidth = 300;
    gantt.options.date_format="%Y-%m-%d";
    gantt.options.scale_height = 30;
    gantt.options.row_height = 50; 
    // gantt.options.showLightbox=false;
    gantt.templates.showLightBox = false; //to hide gantt library core lightbox on double click 


    gantt.options.exportApi = "https://zt-gantt.zehntech.net/"; 
    // gantt.options.minColWidth = 50;
                  
     // zoom level code start
      gantt.options.zoomLevel = "day";
      gantt.options.zoomConfig = {
        levels: [
        {
        name: "day",
        scale_height: 27,
        min_col_width:46,
        scales: [
          { 
            unit: "week", 
            step: 1,
            format: (t) =>{
              const { startDate: a, endDate: n, weekNum: i } = weekStartAndEnd(t);
              return ` ${gantt.formatDateToString(
                "%j %M",
                a
              )} - ${gantt.formatDateToString(
                "%j %M",
                n
              )}, ${a.getFullYear()}`;
            }
        },
        { 
            unit: "day",step: 1,  format:(t)=>{
              return `${gantt.formatDateToString("%j", t)}`
            }
        }],
        },
        {
        name: "week",
        scale_height: 27,
        min_col_width:30,
        scales: [
        { unit: "month", format: "%F, %Y" },
        {
        unit: "week",
        step: 1,
        format: function (date) {
        var dateToStr = gantt.formatDateToString("%d %M");
        var endDate = gantt.add(date, 6, "day");
        var weekNum = gantt.formatDateToString("%W",date);
        return (
        "WK" +
        weekNum 
        );
        },
        },
  
        ],
        },
        {
        name: "month",
        scale_height: 27,
        min_col_width:100,
        scales: [
          { unit: "year", step: 1, format: "%Y" },
        { unit: "month", format: "%F, %Y" },
        ],
        },
        {
        name: "year",
        scale_height: 50,
        min_col_width: 30,
        scales: [{ unit: "year", step: 1, format: "%Y" }],
        },
        {
          name: "hour",
          scale_height: 27,
          min_col_width: 700,
          scales: [
            { unit: "day", step: 1, format: "%d %M" },
            { unit: "hour", step: 1, format: "%H" },
          ],
        },
        ],
        };
        // zoom level code end
      


    

     var textFilter = `<div class="column"><div>Available</div><div>hour</div></div>`;
     var planFilter = `<div class="column"><div>Planned</div><div>hour</div></div>`;
   
    // zt gantt column code start
    gantt.options.columns = [
      {
        name: "text",
        width: 180,
        min_width: 80,
        tree: true,
        label: "Name",
        resize: true,
        template: (task) => {
         if(task.parent==0)
          {
            return `<div>${task.text}</div>`;
          }
          else if(task.is_total)
            {
              return `<div class="bold-text team_count" >${task.parent_count}</div>`;
            }
          else{
            return `<div class="two-line-name"><div class="project_name"><b>${task.project&&task.project.name}</b></div><div class="issue_name" style="margin-top:2px;">${task.text}</div></div>`
          } 
        },
      },
      {
        name: "estimated_hours",
        width: 80,
        min_width: 80,
        tree: false,
        align: "center",
        label:planFilter,
        resize: true,
        template: (task) => {
          if(task.parent==0||task.parent_id!=null)
          { 
              let estimated_hours=0;
              gantt.originalData.map((list)=>{  
              if(task.id==list.assigned_to_id)
                {
                  estimated_hours+=list.Estimation;
                }
            })
            if (Number(estimated_hours) === estimated_hours && estimated_hours % 1 !== 0) {
              estimated_hours = estimated_hours.toFixed(2);
            }
            if(task.Estimation<task.total)
            {
              return `<span style="color:red;">${estimated_hours+"h" || ""}</span>`;
            }
            else if(task.Esimtation==task.total)
            {
              return `<span>${estimated_hours+"h" || ""}</span>`;
            }
            else{
              return `<span>${estimated_hours+"h" || ""}</span>`;
            }
        
          }
          else if(task.is_total)
            {
              return `<span class="bold-text">${task.total_planned_hours.toFixed(2)+"h" || ""}</span>`;
            }
          
        }
      },
        {
          name: "available_hours",
          width: 80,
          min_width: 80,
          tree: false,
          label: textFilter,
          align: "center",
          resize: false,
          template: (task) => {
            if(task.parent==0)
            {
              return `<span>${task.available_hours+"h" || ""}</span>`;
            }
            else if(task.is_total)
              {
                return `<span class="bold-text">${task.total_available_hours.toFixed(2)+"h" || ""}</span>`;
              }
           
          },
        },
      ];
    //   Zt gantt columns end 

    // Zt gantt week start end function
    function weekStartAndEnd(t) {
        const e = t.getDay();
        let a, n;
        0 === e
          ? ((a = gantt.add(t, -6, "day")), (n = t))
          : ((a = gantt.add(t, -1 * e + 1, "day")),
            (n = gantt.add(t, 7 - e, "day")));
        return {
          startDate: a,
          endDate: n,
          weekNum: gantt.formatDateToString("%W", t),
        };
      }
    //   Zt gantt start end function end 
    
    // ZT gantt scales
    gantt.options.scales = [
        {
          unit: "week",
          step: 1,
          format: (t) => {
            const { startDate: a, endDate: n, weekNum: i } = weekStartAndEnd(t);
            return ` ${gantt.formatDateToString(
              "%j %M",
              a
            )} - ${gantt.formatDateToString(
              "%j %M",
              n
            )}, ${a.getFullYear()}`;
          },
        },
        { 
          unit: "day",step: 1,  format:(t)=>{
            return `${gantt.formatDateToString("%j", t)}`
          }
      },
      ];
    //   gantt logic end 

    //   ZT Gantt header class to show background color on  right scale 
      gantt.templates.scale_cell_class = (date, scale, scaleIndex) => {
        if(scaleIndex==1)
        {
             return "my-scale-class test"
        }
        else
        {
            return "my-scale-class default"
        }
      }
    // ZT Gantt right scale end 

      //ZT Gantt header class left side start 
      gantt.templates.grid_header_class = (columns,i) => {
          return "my-header-class test"
        }
      // ZT Gantt header class left side end 

      gantt.templates.grid_folder = (task) => {
     
        var name = task?.text?.trim().split(" ");
        var firstname = name?.[0];
        var lastname = name?.[1] ? name?.[1] : "";
        var intials =firstname?.charAt(0)?.toUpperCase() + lastname?.charAt(0)?.toUpperCase();
        if(task.is_total)
          {
             return '<div class="total-number">Total</div>';
          }
          else{
            return  `<div style="background-color:${task.color!= null ? task.color : "#87B9E4"};"  class='user_name random_${firstname.charAt(0).toUpperCase()}  '>${intials}</div>`;
          }
        
      };
       
      gantt.templates.grid_blank=(task)=>{

        if(task.parent!=0&&task.text!="TOTAL")
          {
            if(task.distribution=='custom')
              {
                return '<div class="gantt-distribution"></div>';
              }
              else{
                return '<div class="gantt-distribution-equal"></div>';
              }
      
          }
          else if(task.is_total)
            {
              return " ";
            }
          else{
            return " ";
          }
        
      }

      gantt.templates.grid_file = (task) => {

        var issue_id;
        if (task.parent != 0) {
          if(task.is_total)
            {
              return '';
            }
            else{
              var tracker_name = task.hasOwnProperty("tracker") ? task.tracker.name : " ";
              issue_id =task.id.includes("i") ? task.id.replace("i","") : task.id;
              return `<div class='gantt_tree_icon gantt_file  ${tracker_name}'><a  target="_blank" class="link-issue ${tracker_name}" href='${url}/issues/${issue_id}'>#${issue_id}</a></div>`;
            }

        }
  
      };


        // ZT Gantt tooltip code
     gantt.templates.tooltip_text = function (start, end, task) {
      if (task.parent == 0) {
        if(task.Esimtation!=0&&task.Estimation<task.total)
        {
        
          return (
            "<p class='planning-error'>"+"Planning Required !!!"+"</p>"+
            "<b>User:</b> " +
            task.text +
            "<br/><b>Start date:</b> " +
            gantt.formatDateToString("%d-%m-%y", task.issues.length!=0?start:start_range) +
            "<br/><b>Due date:</b> " +
            gantt.formatDateToString("%d-%m-%y", task.issues.length!=0?end:due_range)+
            "<br/><b>Total hour:</b> " +
             task.total+"h" 
          );
        }
        else if(task.Esimtation!=0&&task.Esimtation==task.total)
        {
          return (
            "<b>User:</b> " +
            task.text +
            "<br/><b>Start date:</b> " +
            gantt.formatDateToString("%d-%m-%y", task.issues.length!=0?start:start_range) +
            "<br/><b>Due date:</b> " +
            gantt.formatDateToString("%d-%m-%y", task.issues.length!=0?end:due_range)+
            "<br/><b>Total hour:</b> " +
             task.total+"h" 
          );
        }
        else{
          return (
            "<b>User:</b> " +
            task.text +
            "<br/><b>Start date:</b> " +
            gantt.formatDateToString("%d-%m-%y", task.issues.length!=0?start:start_range) +
            "<br/><b>Due date:</b> " +
            gantt.formatDateToString("%d-%m-%y", task.issues.length!=0?end:due_range)+
            "<br/><b>Total hour:</b> " +
             task.total+"h" 
          );
        }
     
      }
      else if(task.is_total)
        {
          return (
            "<b>TOTAL:</b> " +
            task.parent_count +
            "<br/><b>Planned hours:</b> " +
            task.total_planned_hours.toFixed(2)+"h" +
            "<br/><b>Available hours:</b> " +
            task.total_available_hours.toFixed(2)+"h"
          );
        }
       else {
        return (
          "<b>Project:</b>"+task.project&&task.project?.name+
          "<br/><b>Task:</b> " +
          task.subject +
          "<br/><b>Start date:</b> " +
          gantt.formatDateToString("%d-%m-%y", start) +
          "<br/><b>Due date:</b> " +
          gantt.formatDateToString("%d-%m-%y", end) + "<br><b>Duration:</b> " + 
          ` ${
            task.duration
          }d`+
          "<br/><b>Distribution:</b> " +`${
            task.distribution
          }`
        );
      }
    };
 

      // zt gantt timeline cell class to add css in task cell 
        gantt.templates.timeline_cell_class = (task, date) => {
          var D= changeFormat(date);
          var b_color;
          var workload_color;
           if(task.holiday&& task.holiday.length!=0)
           {
             var holiday_s=task.holiday
             for (i=0; i<holiday_s.length; i++)
             { 
               if(holiday_s[i].hasOwnProperty("dates"))
               {
                 var holiday_date=holiday_s[i].dates;
                 for(j=0; j<holiday_date.length; j++)
                 {
                  var start_date = new Date(holiday_date[j].start_date);
                  var end_date = new Date(holiday_date[j].end_date);
                  var check_date = new Date(D);
                   if(check_date >= start_date && check_date <= end_date)
                   {
                     b_color = "holiday";
  
                   }
                 }
               }
          
             }
           }
           var dt = new Date (D);
           if(task.wk_scheme&&task.wk_scheme.length!=0)
           {
             var scheme=task.wk_scheme;
             is_workload=true;
              for (i=0; i<=scheme.length; i++)
              { 
               if(scheme[i])
               {
               
                 switch (dt.getDay()) {
                   case 0:
                     day = scheme[i].wd0;
                     break;
                   case 1:
                     day = scheme[i].wd1;
                     break;
                    case 2:
                     day = scheme[i].wd2;
                     break;
                    case 3:
                      day = scheme[i].wd3;
                     break;
                   case 4:
                     day = scheme[i].wd4;
                   break;
                     case 5:
                      day = scheme[i].wd5;
                       break;
                       case 6:
                          day = scheme[i].wd6;
                      break;
                   default:
                     day = 0;
                     break;
                 }
                if(day == 0)
                 {
                   workload_color="workload_scheme"
                 }
               }
 
              }
           }
        
         if(task.parent==0)
         {
           return `open-popup ${b_color} ${workload_color}`;
         }
         else if(task.is_total)
          {
             return 'total_row';
          }
         else{
           
           return `weekoff ${b_color} ${workload_color}`;
         }
      }
      // zt gantt timeline cell class to add css in task cell end 

      // add this logic for workload scheme bug
        function getCellValue(estimated_hour, capacity,task){
        
        var c_apactiy=capacity;
      if(task.parent!=0&&task.tracker&&task.tracker.name==="Leave")
      {
        return "Leave";
      }
      else{
        var workload;
        var test = 0;
        var i=0;
        let holiday=false;
    // Set the start date and end date
    var startDate = new Date(task.start_date);
    var  endDate = new Date(task.end_date);
    // Initialize the current date to the start date
    let currentDate = startDate;
    var holiday_scheme=task.holiday

    if(task.wk_scheme&&task.wk_scheme.length!=0){
    var scheme=task.wk_scheme;

    // Loop while the current date is less than  to the end date

    while (currentDate <= endDate) {
      var dt = new Date(currentDate);
      if (dt.getDay()==0 && scheme[i].wd0 == 0) {   
        test = test+1;
      }
      else if(dt.getDay()==1 && scheme[i].wd1 == 0) {
        test = test+1;
      }
    else if(dt.getDay()==2 && scheme[i].wd2 == 0) {
        test = test+1;
      }
      else if(dt.getDay()==3 && scheme[i].wd3 == 0) {
        test = test+1;
      }
      else if(dt.getDay()==4 && scheme[i].wd4 == 0) {
        test = test+1;
      }
      else if(dt.getDay()==5 && scheme[i].wd5 == 0) {
        test = test+1;
      }
    else if(dt.getDay()==6 && scheme[i].wd6 == 0) {
        test = test+1;
      }
    
      currentDate.setDate(currentDate.getDate() + 1); // Increment the current date by one day

    }
    }

    if(task.holiday&&task.holiday.length!=0)
    {
      for(k=0; k<holiday_scheme[i].dates.length; k++)
      {
          for (l=0; l<holiday_scheme[i].dates[k].date_range.length; l++)
            {
              if(changeFormat(holiday_scheme[i].dates[k].date_range[l]) >= changeFormat(task.start_date) && changeFormat(holiday_scheme[i].dates[k].date_range[l]) <= changeFormat(task.end_date))
                {
                  test=test+1;
                }
            }
          }
      }
      
    c_apactiy=c_apactiy-test
        if(c_apactiy==0)
        {
          workload=estimated_hour
        }
        else{
        workload=estimated_hour/c_apactiy;
        }
        return workload;
      }

    }
    // function get cell value end 

    // function getHours to calculate hours for parent 
    function getHours(estimated_hour, capacity,task,parentDate){
      var c_apactiy=capacity;
      if(changeFormat(parentDate) >=changeFormat(task.start_date) && changeFormat(parentDate) <= changeFormat(task.end_date)  ){
        var workload;
        var test = 0;
        var i=0;
        // Set the start date and end date
        var startDate = new Date(task.start_date);
        var  endDate = new Date(task.end_date);
        // Initialize the current date to the start date
        let currentDate = startDate;
        var  holiday_scheme = task.holiday;
    
    if(task.wk_scheme&&task.wk_scheme.length!=0){
    var scheme=task.wk_scheme;
    // Loop while the current date is less than or equal to the end date
    
    while (currentDate <= endDate) {
      var dt = new Date(currentDate);

      if (dt.getDay()==0 && scheme[i].wd0 == 0) {
        test = test+1;
      }
      else if(dt.getDay()==1 && scheme[i].wd1 == 0) {
        test = test+1;
      }
     else if(dt.getDay()==2 && scheme[i].wd2 == 0) {
        test = test+1;
      }
      else if(dt.getDay()==3 && scheme[i].wd3 == 0) {
        test = test+1;
      }
      else if(dt.getDay()==4 && scheme[i].wd4 == 0) {
        test = test+1;
      }
      else if(dt.getDay()==5 && scheme[i].wd5 == 0) {
        test = test+1;
      }
     else if(dt.getDay()==6 && scheme[i].wd6 == 0) {
        test = test+1;
      }
    
      currentDate.setDate(currentDate.getDate() + 1); // Increment the current date by one day
    
    }
    }
  

    if(task.holiday&&task.holiday.length!=0)
    {
      for(k=0; k<holiday_scheme[i].dates.length; k++)
      {
          for (l=0; l<holiday_scheme[i].dates[k].date_range.length; l++)
            {
              if(changeFormat(holiday_scheme[i].dates[k].date_range[l]) >= changeFormat(task.start_date) && changeFormat(holiday_scheme[i].dates[k].date_range[l]) <= changeFormat(task.end_date))
                {
                  test=test+1;
                }
            }
          }
      }

       c_apactiy=c_apactiy-test
        if( c_apactiy==0)
        {
          workload=estimated_hour
        }
        else if(task.tracker.name==="Leave")
        {
          workload=0;
         }
        else{
          workload=estimated_hour/c_apactiy;
        }
  
        return workload;
        
      }else{
        return 0;
      }
      
    }
    // function to get hours for parent task end

      // zt gantt task bar text to create html of task bar
      gantt.templates.taskbar_text = function (start, end, task) {
     

        var  hours=0;
        var d_hour=0;
        var workload_not_working_day=false;
        let currentDate = new Date(start);
        let innerHTML = "";
         const taskLeft =gantt.posFromDate(start);
         var  workload;
         var b_color;
         var is_workload=false;
         const endData=new Date(end)
        while(currentDate.valueOf() <= endData.valueOf()){
          var day;
          // knowing the scale config you can get min/max dates of each column 
          let cellStart = currentDate;
          // cellStart=cellStart.setHours(0)
          const cellEnd = gantt.add(currentDate,1,"day");
          // get relative position of each column inside the task
          const cellLeft = gantt.posFromDate(cellStart) - taskLeft;
          const cellRight = gantt.posFromDate(cellEnd) - taskLeft;
          const cellWidth = cellRight - cellLeft;
     
          var cellDate= changeFormat(cellStart);
          let Estimation=task.estimated_hours.includes("h")?task.estimated_hours.replace("h",""):task.estimated_hours
          // a simple mockup for calculating cell values
          var value = getCellValue(Estimation.indexOf(".") !== -1?parseFloat(Estimation):parseInt(Estimation),task.duration,task);
          
          if(Number.isInteger(value))
          {
            d_hour=value;
          }
          else if(value=="Leave")
          {
            capacity="L"
          }
          else {
           d_hour=value.toFixed(2)
          }
           var  s_days=" ";
          var dt = new Date(cellStart);
          var holidays=changeFormat(dt);

          if(task.distribution=='custom'){  
            let dateFound=false;
             task.workhours.map((hours)=>{
              if(hours.date===changeFormat(cellStart))
                {
                  d_hour=hours.hours;
                  dateFound = true;
                }  
             });
             if (!dateFound) {
              d_hour=0;
             }
        }
          if(task.holiday&& task.holiday.length!=0)
          {
            var holiday_s=task.holiday
            for (i=0; i<holiday_s.length; i++)
            { 
              if(holiday_s[i].hasOwnProperty("dates"))
              {
                var holiday_date=holiday_s[i].dates;
                for(j=0; j<holiday_date.length; j++)
                {
                  var start_date = new Date(holiday_date[j].start_date);
                  var end_date = new Date(holiday_date[j].end_date);
                  var check_date = new Date(holidays);
                   if(check_date >= start_date && check_date <= end_date)
                   {
                     d_hour=0;   
                  }
                }
              }
            }
          }
          if(task.wk_scheme&&task.wk_scheme.length!=0)
          {
            var scheme=task.wk_scheme;
            is_workload=true;
             for (i=0; i<=scheme.length; i++)
             { 
              if(scheme[i])
              {
                 switch (dt.getDay()) {
                  case 0:
                    day = scheme[i].wd0;
                    break;
                  case 1:
                    day = scheme[i].wd1;
                    break;
                   case 2:
                    day = scheme[i].wd2;
                    break;
                   case 3:
                     day = scheme[i].wd3;
                    break;
                  case 4:
                    day = scheme[i].wd4;
                  break;
                    case 5:
                     day = scheme[i].wd5;
                      break;
                      case 6:
                         day = scheme[i].wd6;
                     break;
                  default:
                    day = 0;
                    break;
                }
               if(day == 0)
                {
                    d_hour=0;
                  workload_not_working_day=true;
                  workload="average_wk";
                }
                else if(d_hour == day &&  day !=0){
                  
                  workload="good_wk";
                }
               else if(d_hour > day)
                {
                   workload="danger_wk";
                }
                else{
                  workload="average_wk";
                }
              }
             }
          }
        if(task.parent==0)
        {                                                             
          hours = 0; 
          var parent_data=[];
          gantt.eachTask((list)=>{
            parent_data.push(list);
          })
            for(i=0; i < parent_data.length; i ++)
           {
    
            if(parent_data[i].parent!=0)
          {
            if(parent_data[i].assigned_to_id==task.id)

            {    let dateFound=false;
                 let Estimation_issue=parent_data[i].estimated_hours.includes("h")?parent_data[i].estimated_hours.replace("h",""):parent_data[i].estimated_hours
                 if(parent_data[i].distribution=='custom')
                  {
                     if(parent_data[i].workhours&&parent_data[i].workhours.length!=0)
                      {
                        parent_data[i].workhours.map((work)=>{
  
                           if(work.date==changeFormat(cellStart))
                            {
                              dateFound=true;
                             hours+=work.hours;
                            }
                         });
                      }
                  }
                  else if(parent_data[i].distribution=='equal'){
                        hours= hours + getHours(Estimation_issue.indexOf(".") !== -1?parseFloat(Estimation_issue):parseInt(Estimation_issue),parent_data[i].duration,parent_data[i],cellStart); 
                  } 
            }
          }
          }
            

          if(hours % 1 === 0 &&workload_not_working_day==false)
          {
             hours=hours;
          }
          else if(hours % 1 !== 0){
            var  hours=hours.toFixed(2)
          }
         if(task.wk_scheme&&task.wk_scheme.length!=0)
          {
            var scheme=task.wk_scheme;
            is_workload=true;
             for (i=0; i<=scheme.length; i++)
             { 
              if(scheme[i])
              {
              
                switch (dt.getDay()) {
                  case 0:
                    day = scheme[i].wd0;
                    break;
                  case 1:
                    day = scheme[i].wd1;
                    break;
                   case 2:
                    day = scheme[i].wd2;
                    break;
                   case 3:
                     day = scheme[i].wd3;
                    break;
                  case 4:
                    day = scheme[i].wd4;
                  break;
                    case 5:
                     day = scheme[i].wd5;
                      break;
                      case 6:
                         day = scheme[i].wd6;
                     break;
                  default:
                    day = 0;
                    break;
                }
  
                if(day == 0)
                {
                  var hours=0;
                  workload_not_working_day=true;
                  workload="average_wk";
                }
                else if(hours == day &&  day !=0){
                  workload="good_wk";
                }
               else if(hours > day)
                {
                   workload="danger_wk";
                }
                else{
                  workload="average_wk";
                }
              }
             }
          }
          if(task.holiday&& task.holiday.length!=0)
          {
            var holiday_s=task.holiday
            for (i=0; i<holiday_s.length; i++)
            { 
              if(holiday_s[i].hasOwnProperty("dates"))
              {
                var holiday_date=holiday_s[i].dates;
                for(j=0; j<holiday_date.length; j++)
                  {
                    var start_date = new Date(holiday_date[j].start_date);
                    var end_date = new Date(holiday_date[j].end_date);
                    var check_date = new Date(holidays);
                     if(check_date >= start_date && check_date <= end_date)
                     {
                        hours=0;   
                    }
                  }
              }
            }
          }
  
      
          if(task.issues.length==0)
          { 
            innerHTML += `<div   data-userId='${task.user_id}' data-userName='${task.text.split(" ").join("&nbsp;")}' data-cellDate='${cellDate}' class='parent-bar-style' style='background-color:${b_color}; position:absolute;left:
            ${cellLeft}px;width:${cellWidth}px;'> <span class='span-parent ${workload} '>  </span></div>`;;
          }
          else{
            innerHTML += `<div   data-userId='${task.user_id}' data-userName='${task.text.split(" ").join("&nbsp;")}' data-cellDate='${cellDate}' class='parent-bar-style' style='background-color:${b_color}; position:absolute;left:
            ${cellLeft}px;width:${cellWidth}px;'> <span class='span-parent ${workload} '> ${hours} </span></div>`;
          }

        }
        else{
         if(task.tracker&&task.tracker.name=="Leave")
          {
             var  d_hour="L" 
          }
            innerHTML += `<div   class='task-content-inner ${workload} ${s_days}' style='position:absolute;left:
            ${cellLeft}px; width:${cellWidth}px;'>${d_hour}</div>`;
                  
           }     

          currentDate = cellEnd;
        }
        return innerHTML;
      };

      // task bar function end
      //  zt gantt workload task class
       gantt.templates.task_class = (start, end, task) => {
        if(task.parent==0)
        {
             return "parent_task"
        }
        else{
          if(task.tracker&&task.tracker.name=="Leave")
            {
              return "task leave"
            }
            else{
              return "child_task"
            }
        }
      }

      // task class end   

         //  get selected team data through api 
        //  $.ajax({
        //   type: "GET",
        //   url: `${url}/selected_teams.json?key=${api_key}`,
        //   dataType: 'json',
        //   async:false,
        //   success: function (result, status, xhr) {
        //     if(result.length!=0)
        //     {
        //       is_team=result[0].team_id;
        //     }
        //   },
        //   error:function(xhr,status,error)
        //   {
             
        //   }
        // })

        start = moment().startOf('month')
        end =  moment().endOf('month')
        start_range=start.format('YYYY-MM-DD');
        due_range=end.format('YYYY-MM-DD');
        storedStart = localStorage.getItem("start_workload");
        storedEnd = localStorage.getItem("end_workload");

    function cb(start, end) {
  
        start_range=start.format('YYYY-MM-DD');
        due_range=end.format('YYYY-MM-DD');
        localStorage.setItem("start_workload", start_range);
        localStorage.setItem("end_workload", due_range);
        storedStart = localStorage.getItem("start_workload");
        storedEnd = localStorage.getItem("end_workload");
        gantt.options.startDate = start_range;
        gantt.options.endDate = due_range;
        
        $('#reportrange span').html(start.format('D MMM YY') + ' - ' + end.format('D MMM YY'));
        if(isAdmin)
        {
          //  callSelectedTeamAPI();
          restoreFilterSettings();
        }
        else{
           callUserIssuesAPI();
        }
      }
      $('#reportrange').daterangepicker({
          startDate: storedStart ? moment(storedStart) : start,
          endDate:storedEnd ? moment(storedEnd) : end,
          ranges: {
             'Today': [moment(), moment()],
             'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
             'Current Week':[moment().clone().isoWeekday(1),moment().clone().isoWeekday(7)],
             'Last 7 Days': [moment().subtract(6, 'days'), moment()],
             'Last 30 Days': [moment().subtract(29, 'days'), moment()],
             'This Month': [moment().startOf('month'), moment().endOf('month')],
             'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')],
             'Next Month': [moment().add(1, 'month').startOf('month'), moment().add(1, 'month').endOf('month')]
          }
      }, cb);
      cb(moment(storedStart ? storedStart : start), moment(storedEnd  ? storedEnd : end));
      $("[data-range-key='Custom Range']").click(function() {
        $(this).addClass("active");
        $("[data-range-key='Today']").removeClass("active");
        $("[data-range-key='Current Week']").removeClass("active");
        $("[data-range-key='Next Month']").removeClass("active");
        $("[data-range-key='This Month']").removeClass("active");
        $("[data-range-key='Last Month']").removeClass("active");
        $("[data-range-key='Last 30 Days']").removeClass("active");
        $("[data-range-key='Last 7 Days']").removeClass("active");
        $("[data-range-key='Yesterday']").removeClass("active");
    });

    // var workloadTodayFlag = JSON.parse(localStorage.getItem('workload_today_flag'));
    // document.getElementById('today').checked = workloadTodayFlag !== null ? workloadTodayFlag : true;
    // if (workloadTodayFlag != false) {
    //   gantt.options.todayMarker=true;
    // } else {
    //   gantt.options.todayMarker=false;
    // }
      


    async function callUserIssuesAPI()
       {
        perpage=20;
        pagenum=1;
          return   $.ajax({
        type: "GET",
        url: `${url}/user_issues.json?key=${api_key}&per_page=${perpage}&page=${pagenum}`,
        dataType: 'json',
        data: {
          start_date: start_range,
          due_date:due_range
        },
        beforeSend: function(){
          $('.circle-loader').show();
        },
        success: function (result, status, xhr) {
          $('.circle-loader').toggleClass('load-complete');
          $('.checkmark').toggle();
          setTimeout(() => {
            $(".unknown-div").css("display","none");
            $('.circle-loader').hide();
            }, 500);


           gantt.clearAll();
            resource_data=result
             Users=result.users;
             tasks=result.data
            resource_data.data.map((i)=>{
              if(i.parent_id!=null)
              {
                i.parent="i"+i.parent_id;
              }
               i.end_date=i.due_date!=null?i.due_date: i.s_date
               i.issue_id=i.parent==0? i.id : i.id.replace("i","")
               i.Estimation=i.estimated_hours!=null?i.estimated_hours: 0
              i.estimated_hours=i.estimated_hours!=null?i.estimated_hours+"h": "0h"
              
            })
   
            if(Users&&Users.length!=0){
              Users.map((i)=>{
                $("#dynamic_select_user").append(`<option value=${i.id} >${i.firstname+" "+i.lastname}</option>`)
              })
            }
        
            if(result.data.length==0)
              {
                $("#gantt_here").css("display","none");
                   $("#menu").css("display","none");
                   if(!$(".nodata")[0])
                   {
                    $(".second-div").after(`<p  style="margin-top:30px; margin-left:13px;" class="nodata">No data to display</p>`);
                   }
              }
              else{
                if(result.hasOwnProperty("pagination"))
                {
                  total_pages=result.pagination.total_pages;
                }
                else{
                  total_pages=1;
                }
                $(".nodata").remove();
                $("#menu").css("display","block");
                $("#gantt_here").css("display","block");
                gantt.clearAll();
                  gantt.options.data = resource_data.data;
                 

                  
                // var workloadTodayFlag = JSON.parse(localStorage.getItem('workload_today_flag'));
                // document.getElementById('today').checked = workloadTodayFlag !== null ? workloadTodayFlag : true;
                // if (workloadTodayFlag != false) {

                //   gantt.options.todayMarker=true;
                // } else {
        
                //   gantt.options.todayMarker=false;
                // }
      
           
                  gantt.render(element); 
               
                

              }
        },
        error: function (xhr, status, error) {
          $('.circle-loader').toggleClass('load-complete');
          $('.checkmark').toggle();
          setTimeout(() => {
            $(".unknown-div").css("display","none");
            $('.circle-loader').hide();
            }, 500);
        }
  });
    }
    // zt gantt before task drag event
      gantt.attachEvent("onBeforeTaskDrag", (event) => {
          var task=event.task;
          if(task.parent ==0){
              return false;     
          }
        if(task.subtask_parent.length!=0)
          {
            toastr["error"]("This is a  parent task , its duration can not be changed");
            return false;    
          }
    
          return true;        
        
      });
      // zt gantt before task drag event end

      // event to stop task bar to drop outside of applied date range.....
     gantt.attachEvent("onBeforeTaskDrop", (event) => {
          let task =event.task;
     
          if(!(changeFormat(task.start_date)>= start_range && changeFormat(task.end_date) <= due_range))
            {
              return false;
            }
         return true;
     })

      // zt gantt event to get object info
      gantt.attachEvent("onCellClick", (event) => {
        $("#date-inputs").html("");
        $("#date-inputs").css("display","none");
        $(".workhour-error").css("display","none");
        $(".workhour-div").css("display","none");
        let plantimeDiv=document.getElementById('plan-time-div');
        plantimeDiv.style.marginBottom='20px';
        let distributionCheckbox=document.getElementById('watchers-input');
        distributionCheckbox.checked=true;
        let Task=event.task;
        let cell_date=changeFormat(event.cellDate)
        if(Task.parent==0)
        {
                var issue_dropdown = $('#issue-drop')
                issue_dropdown.prop('disabled',false);
                $('#issue-drop').css("opacity","revert");
                $('#issue-drop').css("cursor","pointer");
                var user_dropdown = $('#user-drop')
                user_dropdown.prop('disabled', true);
                $('#user-drop').css("opacity","0.7");
                $('#user-drop').css("cursor","default");
                $("#txtSearchValueissue").val(" ");
                $("#current-issue").attr("user_id",Task.user_id)
                getIssues(Task.user_id);
                $("#current-issue").removeAttr("value");
                $("#issue-error-div").css("display","none");
                $("#estimated-error-div").css("display","none");
                $("#estimated_hour").val("0h");
                $("#current-issue").html("Search issues...");
                // $("#due_date").val(" ");
                $(".text-area-res").val(" ");
                $("#current-user").html(Task.text);
                // $("#to").css("display","none");
                // $("#plan").css("display","none");
                $("#watchers-input").removeAttr("checked");
                $("#current-user").attr("value",Task.user_id);
                let body_div = document.getElementsByClassName("has-main-menu controller-workloads action-index");
                let modal= document.getElementsByClassName("modal");
                let div = document.createElement("div");
                 div.className = "div-modal";
                 div.style.display = "block";
                 body_div[0].appendChild(div);
                 body_div[0].appendChild(modal[0]);
                 $("#start_date").val(cell_date);
                 $("#due_date").val(cell_date);
                //  $("#due_date").val(issue_data.due_date);
                //  $("#start_date").val(issue_data.start_date);
                 $('.modal').show();
                 disableTabindex();

        }

      });



      // onAfter task drag event to update start date and end date
      gantt.attachEvent("onAfterTaskDrag", (event) => {
        // reset the variable value
 
          // Add logic to update parent task along with children
          var task1 =event.task; 
          let parentTask=event.parentTask
          // get the child task
          var parent = gantt.getTask(task1.parent); // get the parent task
         // logic ends
          const task = gantt.getTask(task1.id);
          var issue_id=task1.id.replace("i","");
          var start_date=changeFormat(task1.start_date);
          var due_date=changeFormat(task1.end_date);
          var content={
              "start_date":start_date,
              "due_date": due_date,
            }
         if(event.mode=='resize')
         {
           $.ajax({
                  type: "PUT",
                  url: `${url}/issues/${issue_id}.json?key=${api_key}`,
                  dataType: "json",
                  contentType: "application/json",
                  async: false,
                  data: JSON.stringify({
                    issue: content,
                  }),
                  success: function (result, status, xhr) {
                    var Issue = {
                      id:task1.id, 
                      start_date:changeFormat(task1.start_date),
                      s_date: changeFormat(task1.start_date),
                      end_date: changeFormat(task1.end_date),
                      due_date:changeFormat(task1.end_date)
                    }
                    gantt.updateTaskData(Issue);
                    var parent = gantt.getTask(Issue.id); // get the parent task
                    gantt.updateTaskData(parent);
         
                    gantt.render();
                  },
                  error: function (xhr, status, error) {
                      if(xhr.status == 422){
                    let content = JSON.parse(xhr.responseText).errors;
                    content.map((i)=>{
                      if(i==="Due date must be greater than start date")
                      {
                        toastr["error"]("Start date could not be greater than due date");
                      }
                      else if(i==="Assignee is invalid")
                      {
                        toastr["error"]("User is not a member of project to  which this issue belongs please check project setting");
                      }
                      else{
                        toastr["error"](i);
                      }
                  })
                }
                else if(xhr.status == 403)
                {
                    toastr["error"]("You don't have permissions");
                } 
                  },
                });
              }
              if(event.mode=='move')
              {
                let assigned_to_id=event.parentTask.id
                content={
                  "start_date":start_date,
                  "due_date": due_date,
                  "assigned_to_id":assigned_to_id
                }
                $.ajax({
                  type: "PUT",
                  url: `${url}/issues/${issue_id}.json?key=${api_key}`,
                  dataType: "json",
                  contentType: "application/json",
                  async: false,
                  data: JSON.stringify({
                    issue: content,
                  }),
                  success: function (result, status, xhr) {
                    var Issue = {
                      id:task1.id, 
                      start_date:changeFormat(task1.start_date),
                      s_date: changeFormat(task1.start_date),            
                      end_date: changeFormat(task1.end_date),
                      due_date:changeFormat(task1.end_date),
                      parent:assigned_to_id
                    }
                    gantt.updateTaskData(Issue);
                    const objectId = task1.id;
                    // Find the  object with the matching ID
                    const objectToUpdate = resource_data.data.find(obj => obj.id == objectId);
                    // Check if the object exists in the array
                    if (objectToUpdate) {
                      // Create a new object with the updated values
                      objectToUpdate.assigned_to_id = assigned_to_id;
                      objectToUpdate.parent = assigned_to_id;
                    } 
                    // var parent = gantt.getTask(Issue.id); // get the parent task
                    const totalEstimatedHours = resource_data.data.reduce((acc, task) =>
                    {

                      if(task.parent==parentTask.id)
                      { 
                        let Esimtation=task.estimated_hours.includes("h")?+task.estimated_hours.replace("h",""):+task.estimated_hours
                        return  acc + Esimtation
                      }
                      return acc;  
                    }
                     , 0);
                     let parent={
                      id:parentTask.id,
                      estimated_hours:Number.isInteger(totalEstimatedHours)?totalEstimatedHours+"h":totalEstimatedHours.toFixed(2)+"h",
                      parent:0
                     }
                    gantt.updateTaskData(parent);
                    gantt.render();
                  },
                  error: function (xhr, status, error) {
                      if(xhr.status == 422){
                  
                    let content = JSON.parse(xhr.responseText).errors;
                    content.map((i)=>{
            
                      if(i==="Due date must be greater than start date")
                      {
                        toastr["error"]("Start date could not be greater than due date");
                      }
                      else if(i==="Assignee is invalid")
                      {
                        toastr["error"]("User is not a member of project");
                      }
                      else{
                        toastr["error"](i);
                      }
                  })
                 
                }
                else if(xhr.status == 403)
                {
                    toastr["error"]("You don't have permissions");
                } 
                cb(moment(storedStart ? storedStart : start), moment(storedEnd  ? storedEnd : end));
                  },
                });
              }
         });
        
        //  on after task drag event end

        // On task dbl click event start
        
        gantt.attachEvent("onTaskDblClick", function(event){
         $("#date-inputs").html("");
         $("#date-inputs").css("display","none");
         $(".workhour-error").css("display","none");
         $(".workhour-div").css("display","none");
         let plantimeDiv=document.getElementById('plan-time-div');
         plantimeDiv.style.marginBottom='20px';
         let distributionCheckbox=document.getElementById('watchers-input');
        //any custom logic here
        $("#issue-error-div").css("display","none");
        $("#estimated-error-div").css("display","none");
        var issue_dropdown = $('#issue-drop')
       issue_dropdown.prop('disabled', true);
       $('#issue-drop').css("opacity","0.7");
       $('#issue-drop').css("cursor","default");
       var user_dropdown = $('#user-drop')
       user_dropdown.prop('disabled', false);
      $('#user-drop').css("opacity","revert");
      $('#user-drop').css("cursor","pointer");
       var task = event.task;
  
       var startDate=changeFormat(task.start_date);
       var date  = new Date(task.end_date);
       date=changeFormat(date);
       if(task.parent==0||(task.subtask_parent&&task.subtask_parent.length!=0))
       {
        return false;
       }
       else{
       var e_time=task.estimated_hours==null ? "0h" : task.estimated_hours;
       var des=task.description==null ? "Description" : task.description;
       if(task.parent==0)
       {
        var issue_id=task.id
       }
       else{
        var issue_id=task.id.replace("i","")
       }
     
         let body_div = document.getElementsByClassName("has-main-menu controller-workloads   action-index");
         let modal= document.getElementsByClassName("modal");
         let div = document.createElement("div");
                div.className = "div-modal";
                div.style.display = "block";
                body_div[0].appendChild(div);
                body_div[0].appendChild(modal[0]);
                $('.modal').show();
                disableTabindex();
                $("#start_date").val(startDate);
                $("#due_date").val(date);
                $("#estimated_hour").val(e_time);
                $(".text-area-res").val(des);
                $("#current-issue").html(task.subject);
                $("#current-user").html(task.assigned_to);
                $("#current-user").attr("value",task.assigned_to_id);
                $("#current-issue").attr("value",issue_id);
                $("#current-issue").attr("user_id",task.assigned_to_id);
             
                $("#btn-plan").attr("value",task.id);
                // Append delete button using the function
                appendDeletePlan(issue_id);
                localStorage.setItem("task_timesheet",JSON.stringify(task));
                if(task.distribution=='custom')
                  {
                    distributionCheckbox.checked=false;
                    $(".workhour-div").css("display","flex");
                    $(".workhour-div").css("margin-bottom","18px");
                    createBox(task.workhours,task);
               
                  }
                  else{
                    distributionCheckbox.checked=true;
                  }
      
            
                document.getElementById('disable_button_update').disabled = true;
                document.getElementById('disable_button_update').style.cursor = "not-allowed";
              // Select all input fields with the class 'your-class'
              var inputs = document.querySelectorAll('.disable_detail');
              const userDropdown=document.getElementById('UserDropdown');
              userDropdown.addEventListener('click', function() {
                document.getElementById('disable_button_update').disabled = false;
                document.getElementById('disable_button_update').style.cursor = "pointer";
              })

              // Add an 'input' event listener to each input field
                inputs.forEach(function(input) {
                input.addEventListener('input', function() {
                  // Enable the button when an input field receives input
                  document.getElementById('disable_button_update').disabled = false;
                  document.getElementById('disable_button_update').style.cursor = "pointer";
                });
              });
              
        return true;
      }
      
      
    });
    // on task double click event end 
             
          // ZT gantt event on scroll of gantt vertical scroll bar 
            gantt.attachEvent("onScroll", (event) => {
                let element= $(".zt-gantt-ver-scroll");
                var scrollElement = element;
                var scrollTop = scrollElement.scrollTop();
                var scrollHeight = scrollElement.prop("scrollHeight");
                var clientHeight = scrollElement.prop("clientHeight");
                 if(scrollTop + clientHeight >= scrollHeight - 2) {
           
                            if(isAdmin)
                            {
                       
                              let serializedData = JSON.stringify(is_team); 
                              let user_serializedData = JSON.stringify(is_user);  
                             
                              if(is_team&&is_team.length!=0) 
                              { 
                                if(team_total_pages!=teampagenum)
                                  {
                                    teampagenum++;
                              $.ajax({
                                type: "GET",
                                url: `${url}/team_data/${serializedData}.json?key=${api_key}&per_page=${teamperpage}&page=${teampagenum}`,
                                dataType: 'json',
                                // async:false,
                                data: {
                                  start_date:start_range,
                                  due_date:due_range,
                                
                                },
                                beforeSend: function(){
                                  $('.circle-loader').show();
                                },
                                success: function (result, status, xhr) {
                                  $('.circle-loader').toggleClass('load-complete');
                                  $('.checkmark').toggle();
                                  setTimeout(() => {
                                    $(".unknown-div").css("display","none");
                                    $('.circle-loader').hide();
                                    }, 500);
                                    // gantt.options.collapse = false;
                                    gantt.clearAll();
                         
                    
                                    Users=result.users;
                                    tasks=result.data
                                  result.data.map((i)=>{
                                       if(i.parent_id!=null)
                                        {
                                          i.parent="i"+i.parent_id
                                        }
                                        i.end_date=i.due_date!=null? i.due_date: i.s_date
                                        i.issue_id=i.parent==0? i.id : i.id.replace("i","")
                                        i.Estimation=i.estimated_hours!=null?i.estimated_hours: 0
                                        i.estimated_hours=i.estimated_hours!=null?i.estimated_hours+"h": "0h"                          
                                    });
                                    
                             
                                    if(Users&&Users.length!=0){
                                      Users.map((i)=>{
                                        $("#dynamic_select_user").append(`<option value=${i.id} >${i.firstname+" "+i.lastname}</option>`)
                                      })
                                    }
                                
                                    if(result.data.length==0)
                                      {
                                        // element.style.display="none";
                                        $("#gantt_here").css("display","none");
                                          $("#menu").css("display","none");
                                          if(!$(".nodata")[0])
                                          {
                                            $(".second-div").after(`<p  style="margin-top:30px; margin-left:13px;" class="nodata">No data to display</p>`);
                                          }
                                      }
                                      else{
                                        $("#gantt_here").css("display","block");
                                        if(result.hasOwnProperty("pagination"))
                                        {
                                          team_total_pages=result.pagination.total_pages;
                                        }
                                        else{
                                          team_total_pages=1;
                                        }
                                           $(".nodata").remove();
                                          $("#menu").css("display","block");
                                         
                                    
                                          // var workloadTodayFlag = JSON.parse(localStorage.getItem('workload_today_flag'));
                                          // document.getElementById('today').checked = workloadTodayFlag !== null ? workloadTodayFlag : true;
                                          // if (workloadTodayFlag != false) {
                                          //   gantt.options.todayMarker=true;
                                          // } else {
                                          //   gantt.options.todayMarker=false;
                                          // }
                                             
                                          
                                         gantt.parse(result.data);
                                      
                                               let parentZeroItems = gantt.options.data.filter(i => i.parent == 0);

                                               // Calculate the total available hours, total estimation, and count of parent == 0 items
                                               let totalAvailableHours = parentZeroItems.reduce((sum, item) => sum + (item.available_hours || 0), 0);
                                               let totalPlannedHours = parentZeroItems.reduce((sum, item) => sum + item.Estimation, 0);
                             
                                               let parentZeroCount = parentZeroItems.length;
                             
                                               let total = {
                                           
                                                 text: "TOTAL",
                                                 is_total: true,
                                                 total_available_hours: totalAvailableHours,
                                                 total_planned_hours: totalPlannedHours,
                                                 parent_count: parentZeroCount
                                             };
                                           // Remove total object from array
                                          gantt.options.data =gantt.options.data.filter(item => item.text !==  "TOTAL");


                                          // Add total object back at the end
                                          gantt.options.data.push(total);
                                
                                         gantt.render();      
                                   }
                                },
                                error: function (xhr, status, error) {
                                  $('.circle-loader').toggleClass('load-complete');
                                  $('.checkmark').toggle();
                                  setTimeout(() => {
                                    $(".unknown-div").css("display","none");
                                    $('.circle-loader').hide();
                                    }, 500);
                                }
                              });
                            }
                            }
                            // else if (is_team.length === 0 && is_user && is_user != 0){

                            // }
                            else if (is_team.length === 0 && is_user.length === 0){
                              // callUserIssuesAPI();  
                              if(total_pages!=pagenum)
                                {
                                     pagenum++;
                            
                              $.ajax({
                                type: "GET",
                                url: `${url}/user_issues.json?key=${api_key}&per_page=${perpage}&page=${pagenum}`,
                                dataType: 'json',
                                data: {
                                  start_date: start_range,
                                  due_date:due_range
                                },
                                beforeSend: function(){
                                  $('.circle-loader').show();
                                },
                                success: function (result, status, xhr) {
                                  $('.circle-loader').toggleClass('load-complete');
                                  $('.checkmark').toggle();
                                  setTimeout(() => {
                                    $(".unknown-div").css("display","none");
                                    $('.circle-loader').hide();
                                    }, 500);
                                    // gantt.options.collapse = false;
                                    gantt.clearAll();
                                    resource_data=result
                                    // Issues=result.issues;
                                     Users=result.users;
                                     tasks=result.data
                                    resource_data.data.map((i)=>{
                                      if(i.parent_id!=null)
                                      {
                                        i.parent="i"+i.parent_id
                                      }
                                       i.end_date=i.due_date!=null?i.due_date: i.s_date
                                       i.issue_id=i.parent==0? i.id : i.id.replace("i","")
                                       i.Estimation=i.estimated_hours!=null?i.estimated_hours: 0
                                      i.estimated_hours=i.estimated_hours!=null?i.estimated_hours+"h": "0h"
                                      
                                    })
                                    if(Users&&Users.length!=0){
                                      Users.map((i)=>{
                                        $("#dynamic_select_user").append(`<option value=${i.id} >${i.firstname+" "+i.lastname}</option>`)
                                      })
                                    }
                                
                                    if(result.data.length==0)
                                      {
                                        $("#gantt_here").css("display","none");
                                           $("#menu").css("display","none");
                                           if(!$(".nodata")[0])
                                           {
                                            $(".second-div").after(`<p  style="margin-top:30px; margin-left:13px;" class="nodata">No data to display</p>`);
                                           }
                                      }
                                      else{
                                        if(result.hasOwnProperty("pagination"))
                                        {
                                          total_pages=result.pagination.total_pages;
                                        }
                                        else{
                                          total_pages=1;
                                        }
                                        $(".nodata").remove();
                                        $("#menu").css("display","block");
                                        $("#gantt_here").css("display","block");
                                          // gantt.options.data = resource_data.data;
                                          // var workloadTodayFlag = JSON.parse(localStorage.getItem('workload_today_flag'));
                                          // document.getElementById('today').checked = workloadTodayFlag !== null ? workloadTodayFlag : true;
                                          // if (workloadTodayFlag != false) {
                                          //   gantt.options.todayMarker=true;
                                          // } else {
                                          //   gantt.options.todayMarker=false;
                                          // }
                                          // gantt.render(element); 
                                          gantt.parse( resource_data.data);
                                          gantt.render();
                                      }
                                },
                                error: function (xhr, status, error) {
                                  $('.circle-loader').toggleClass('load-complete');
                                  $('.checkmark').toggle();
                                  setTimeout(() => {
                                    $(".unknown-div").css("display","none");
                                    $('.circle-loader').hide();
                                    }, 500);
                                }
                          });
                        }
                            }
                            } 
                            else if (is_team.length === 0 && is_user.length === 0)
                            {
                              perpage=20;
                              if(total_pages!=pagenum)
                                {
                                     pagenum++;
                            
                              $.ajax({
                                type: "GET",
                                url: `${url}/user_issues.json?key=${api_key}&per_page=${perpage}&page=${pagenum}`,
                                dataType: 'json',
                                data: {
                                  start_date: start_range,
                                  due_date:due_range
                                },
                                beforeSend: function(){
                                  $('.circle-loader').show();
                                },
                                success: function (result, status, xhr) {
                                  $('.circle-loader').toggleClass('load-complete');
                                  $('.checkmark').toggle();
                                  setTimeout(() => {
                                    $(".unknown-div").css("display","none");
                                    $('.circle-loader').hide();
                                    }, 500);
                                    // gantt.options.collapse = false;
                                    gantt.clearAll();
                                    resource_data=result
                                    // Issues=result.issues;
                                     Users=result.users;
                                     tasks=result.data
                                    resource_data.data.map((i)=>{
                                      if(i.parent_id!=null)
                                      {
                                        i.parent="i"+i.parent_id
                                      }
                                       i.end_date=i.due_date!=null?i.due_date: i.s_date
                                       i.issue_id=i.parent==0? i.id : i.id.replace("i","")
                                       i.Estimation=i.estimated_hours!=null?i.estimated_hours: 0
                                      i.estimated_hours=i.estimated_hours!=null?i.estimated_hours+"h": "0h"
                                      
                                    })
                                    if(Users&&Users.length!=0){
                                      Users.map((i)=>{
                                        $("#dynamic_select_user").append(`<option value=${i.id} >${i.firstname+" "+i.lastname}</option>`)
                                      })
                                    }
                                
                                    if(result.data.length==0)
                                      {
                                        $("#gantt_here").css("display","none");
                                           $("#menu").css("display","none");
                                           if(!$(".nodata")[0])
                                           {
                                            $(".second-div").after(`<p  style="margin-top:30px; margin-left:13px;" class="nodata">No data to display</p>`);
                                           }
                                      }
                                      else{
                                        if(result.hasOwnProperty("pagination"))
                                        {
                                          total_pages=result.pagination.total_pages;
                                        }
                                        else{
                                          total_pages=1;
                                        }
                                        $(".nodata").remove();
                                        $("#menu").css("display","block");
                                        $("#gantt_here").css("display","block");
                              

                                          // var workloadTodayFlag = JSON.parse(localStorage.getItem('workload_today_flag'));
                                          // document.getElementById('today').checked = workloadTodayFlag !== null ? workloadTodayFlag : true;
                                          // if (workloadTodayFlag != false) {
                                          //   gantt.options.todayMarker=true;
                                          // } else {
                                          //   gantt.options.todayMarker=false;
                                          // }

                                          gantt.parse(resource_data.data);
                                          gantt.render(); 
                                      }
                                },
                                error: function (xhr, status, error) {
                                  $('.circle-loader').toggleClass('load-complete');
                                  $('.checkmark').toggle();
                                  setTimeout(() => {
                                    $(".unknown-div").css("display","none");
                                    $('.circle-loader').hide();
                                    }, 500);
                                }
                          });
                        }
                  }
              
              }
     
            });
         
   
    
    function changeFormat(date) {
        var today = new Date(date);
        var dd = String(today.getDate()).padStart(2, "0");
        var mm = String(today.getMonth() + 1).padStart(2, "0"); //January is 0!
        var yyyy = today.getFullYear();
        return  today = yyyy + "-" + mm + "-" + dd;
      }  

      // full screen function 
      window.showFullscreen=function(){
        $("#menu").addClass("onfullscreen");
        gantt.requestFullScreen();
        }


    // Export Gantt chart to pdf format
    window.export_data= function(item){
    const popoverContainer = document.getElementById('export_workload');
    popoverContainer.style.display = 'block';
    // Add a click event listener to the document to close the modal when clicking outside
    document.addEventListener("click", function(event) {
      if (!item.contains(event.target) && !popoverContainer.contains(event.target)) {
        popoverContainer.style.display = "none";
      }
    });
  }
  // Add today Marker
  $("#today").change(function(e){

    if(e.target.checked)
    {
      gantt.addTodayFlag();
      localStorage.setItem("workload_today_flag", true);
    }
    else{
      gantt.removeTodayFlag();
      localStorage.setItem("workload_today_flag", false);
    }
   })

  // search task in gantt library function 
  window.searchTask=function(e) {
    let isFilter = e.target.value.trim() !== "";
    gantt.filterTask((task) => {
      if (task.parent === 0 && task.text != "TOTAL") {
        return task.text.toLowerCase().includes(e.target.value.toLowerCase())||task.id==e.target.value;
      }
       else if(task.parent != 0 && task.text != "TOTAL" ) {
        return task.subject.toLowerCase().includes(e.target.value.toLowerCase())||task.issue_id==e.target.value;
      }
    }, isFilter,true);
  }

  
  function delay(callback, ms) {
    var timer = 0;
    return function() {
      var context = this, args = arguments;
      clearTimeout(timer);
      timer = setTimeout(function () {
        callback.apply(context, args);
      }, ms || 0);
    };
  }

    // search unassigned issue function
    $('#Search').keyup(delay(function (e) {
      var valThis=this.value;
      let team_id= $('#Select_team').val();
      team_id =team_id ? team_id :[];
   if(valThis.length!=0)
    {
   $('.spinner').show();
   $.ajax({
     type: "GET",
     url: `${url}/search_unassigned_group_issues.json?key=${api_key}&team_id=${team_id}`,
     dataType: 'json',
     async:false,
     contentType: "application/json",
     data: {
       issue: valThis.trim(),
     },
     success: function (result, status, xhr) {
         setTimeout(()=>{
           $('.spinner').hide();
         },200)
          $("#sidePanel").html( " ");
   
         if (Array.isArray(result) && result.length != 0)
         {
          localStorage.setItem("unassigned_issue",JSON.stringify(result))
            result.map((i)=>{
              i.due_date=i.due_date !=null ? i.due_date : i.s_date
      
      $(".dynamic-issue").append(`<div     id=${i.id} draggable="true" ondragstart="drag(event)" class="issues-div" style="display:flex; flex-direction:column; ">
      <div  style="display:flex;"> 
         <a  href='${url}/issues/${i.id}'class="ticket ${i.tracker.name}">#${i.id} </a><span  class="i-sub">${i.text}</span>
        </div>
        <div class="project-div"  style="display:flex; justify-content:space-between;"> 
            <div style="display:flex">
              <span class="project-name">${i.project_name}</span>
               </div>
 
            <div style="display:flex">
              <span  class="e-hour" >${i.estimated_hours==null? 0+"h" : i.estimated_hours+"h"}</span>
               </div>
        </div>
  </div>`)
   })
         }
         else{
            $(".dynamic-issue").append(`<div class="error-search"><span > No matching issue found</span></div>`)
         }
     },
     error: function (xhr, status, error) {
      setTimeout(()=>{
           $('.spinner').hide();
         },200)
     }
   
     });
   }
else{
     $("#sidePanel").html( " ");
     if(unassigned_issues.length!=0){
            unassigned_issues.map((i)=>{
              i.due_date=i.due_date !=null ? i.due_date : i.s_date
     $(".dynamic-issue").append(`<div  id=${i.id} draggable="true" ondragstart="drag(event)" class="issues-div" style="display:flex; flex-direction:column; ">
     <div  style="display:flex;"> 
         <a  href='${url}/issues/${i.id}'class="ticket ${i.tracker.name}">#${i.id} </a><span  class="i-sub">${i.text}</span>
        </div>
        <div class="project-div"  style="display:flex; justify-content:space-between;"> 
            <div style="display:flex">
              <span class="project-name">${i.project_name}</span>
               </div>
 
            <div style="display:flex">
              <span  class="e-hour" >${i.estimated_hours==null? 0+"h" : i.estimated_hours+"h"}</span>
               </div>
        </div>
  </div>`)
   })
       }
       else{
          $(".dynamic-issue").append(`<div class="error-search"><span > No  issue found</span></div>`)
       }
 }
     },500));


  // function to  call PUT API on save button click 
  window.savePlan=function(){
   let isworkhours=false;
    var issue_id=$("#current-issue").attr("value")
    var estimate_time=$("#estimated_hour").val()
    var checkbox = document.getElementById("watchers-input");

    if(estimate_time.includes("h"))
    {
       estimate_time=$("#estimated_hour").val().replace("h","");
    }
    else{
       estimate_time=$("#estimated_hour").val()
    }
    if($("#estimated_hour").val()% 1 !== 0)
    {
       estimate_time= parseFloat($("#estimated_hour").val()).toFixed(2);      
    }
   
    let content={
      "description":$(".text-area-res").val(),
      "start_date":$("#start_date").val(),
      "estimated_hours":estimate_time,
      "due_date":$("#due_date").val(),
      "assigned_to_id":$("#current-user").attr("value"),
      "distribution":checkbox.checked?'equal':'custom',
    }
    // if(checkbox.checked)
    // {
    //    content.due_date=$("#due_date").val();
    // }
   
    
      if(validateData(estimate_time))
      {
        if(!checkbox.checked)
          {
            let entries = [];
            document.querySelectorAll('.box-input').forEach(input => {
              let date = input.getAttribute('data-full-date');
              let hours = parseFloat(input.value) || 0; // default to 0 if the input is empty
              entries.push({
                date: date,
                hours: hours
              });
            
            });
            let boxcontent={
              "issue": issue_id,
              "entries": entries
             }

               $.ajax({
                  type:"POST",
                  url:`${url}/work_hours.json?key=${api_key}`,
                  dataType: "json",
                  contentType: "application/json",
                  async: false,
                  data: JSON.stringify({
                    workhour: boxcontent,
                  }),
                  success: function (result, status, xhr) {
                    isworkhours=false;
                  },
                  error: function (xhr, status, error) {
                    isworkhours=true;
                     if(xhr.status == 422){
                    let content = JSON.parse(xhr.responseText).errors;
                    content.map((i)=>{
                      if(i==="Due date must be greater than start date")
                      {
                        toastr["error"]("Start date could not be greater than due date");
                      }
                      else if(i==="Assignee is invalid")
                      {
                        toastr["error"]("User is not a member of project to  which this issue belongs please check project setting");
                      }
                      else{
                        toastr["error"](i.errors[0]);
                      }
                    })
                    }
                    else if(xhr.status == 403)
                    {
                        toastr["error"]("You don't have permissions");
                    } 
                  },
               })
          }
    if(!isworkhours)
      {
      $.ajax({
          type: "PUT",
          url: `${url}/issues/${issue_id}.json?key=${api_key}`,
          dataType: "json",
          contentType: "application/json",
          async: false,
          data: JSON.stringify({
            issue: content,
          }),
          success: function (result, status, xhr) {
            var i_detail=getIssuedetail(issue_id);
    
           
                var task = {
                    id:"i"+i_detail.id, 
                    text:i_detail.subject,
                    start_date: i_detail.start_date, 
                    s_date:i_detail.start_date,
                    estimated_hours:i_detail.estimated_hours+"h",
                    Estimation:i_detail.estimated_hours!=null?i_detail.estimated_hours:0,
                    parent:i_detail.assigned_to.id,
                    assigned_to:i_detail.assigned_to.name,
   
         
                    project:{
                      id:i_detail.project.id,
                      name:i_detail.project.name      
                    },
                    tracker:{
                      id:i_detail.tracker.id,
                      name:i_detail.tracker.name
                    },
                    description:i_detail.description,
                    due_date: i_detail.due_date != null  ? i_detail.due_date:i_detail.start_date,
                  end_date:i_detail.due_date != null  ? i_detail.due_date:i_detail.start_date
                }
        
   
                if(gantt.getTask("i"+issue_id))
                {
      
                  let oldTask=gantt.getTask("i"+issue_id);
                
                  if(oldTask.parent_id !=null)
                  {
                    task.parent="i"+oldTask.parent_id
                  }
                 
                  if(oldTask.subtask_parent&&oldTask.subtask_parent.length==0)
                  {
                      if(isAdmin)
                        {
                            // callSelectedTeamAPI();
                            restoreFilterSettings();
                        }
                        else{
                            callUserIssuesAPI();
                        }
                    toastr["success"]("Planned time successfully");
                    $('.modal').hide();
                    $('.div-modal').hide();
                    disableTabindex();
                    $('.delete_plan_container').remove();
                    $('.button-cross,.button-plan').css({width: ''});

                  }
                  else{
                    $("#plan-time-error-div").css("display","flex");
                    $("#plan-time-error").html("This is parent task , it's data is same as its child tasks*");
              
                  }
  
                }
                else{
             
              if(i_detail.start_date >= start_range && i_detail.due_date <= due_range)
              {

                if(isAdmin)
                  {
                      restoreFilterSettings();
                  }
                  else{
                      callUserIssuesAPI();
                  }
                  toastr["success"]("Planned time successfully");
                 $('.modal').hide();
                $('.div-modal').hide();
                disableTabindex();
                $('.delete_plan_container').remove();
                $('.button-cross,.button-plan').css({width: ''});
              }
              else{
             
                 if(i_detail.due_date==null)
                 {
                  //  toastr["error"]("Please select a due due for planning");
                  $("#plan-time-error-div").css("display","flex");
                  $("#plan-time-error").html("This is parent task , it's data is same as its child tasks*");
                 }
                 else{
                  $("#plan-time-error-div").css("display","flex");
                  $("#plan-time-error").html("Planning should be in the given range or this is parent task*");
                 }
                
              }
                }
         
             },
          error: function (xhr, status, error) {
                      $("#spinner").css("display","none");
                      $('#hidden-text').html("Plan Time");
              if(xhr.status == 422){
             let content = JSON.parse(xhr.responseText).errors;
            content.map((i)=>{
              if(i==="Due date must be greater than start date")
              {
                toastr["error"]("Start date could not be greater than due date");
              }
              else if(i==="Assignee is invalid")
              {
                toastr["error"]("User is not a member of project to  which this issue belongs please check project setting");
              }
              else{
                toastr["error"](i);
              }
             })
            }
             else if(xhr.status == 403)
             {
                 toastr["error"]("You don't have permissions");
             } 
          },
        });
      }
  
      }
  }
  // function on saveplan click end 


  gantt.attachEvent("onCollapse", function (){
    // any custom logic here
    $("#menu").css("display","block"); 
    // if( $(".main-sidepanel").hasClass('panel_close'))
    // {
    //   $("#gantt_here").addClass('panel_open');
    // }
    $("#gantt_here").css('position','relative');
   $("#wrapper").removeClass('zt-gantt-fullScreen-wrapper');


  });

  gantt.attachEvent("onExpand", function (){
   $("#wrapper").addClass('zt-gantt-fullScreen-wrapper');
    // any custom logic here
    $("#menu").css("display","none");
    $("#gantt_here").removeClass('panel_open');
    $("#gantt_here").removeClass('panel_close');
    $("#gantt_here").css('position','absolute');
  });

// function to drag issues from right panel to drop on gantt
var originalParent = null; 
var draggedItem = null;
var previousSibling = null;
var draggItem=null;
// add a variable to check card id drop or not 
let cardDropped=false;

// drag and drop code for issues
const elem=document.querySelectorAll('.gantt_div');

elem.forEach(box => {
 box.addEventListener('dragenter', dragEnter)
 box.addEventListener('dragover', dragOver);
 box.addEventListener('dragleave', dragLeave);
 box.addEventListener('drop', drop);

});

window.drag=function(ev)
{  
if(ev.target.className.match("issues-div"))
{
var issueobj={};
let unassigned_issue=JSON.parse(localStorage.getItem("unassigned_issue"));
unassigned_issue.map((list)=>{
        if(list.id==ev.target.id)
        {
          issueobj=list;
        }
})
ev.dataTransfer.setData('text/html',JSON.stringify(issueobj));
draggedItem = ev.target;

originalParent =  ev.target.parentElement;
previousSibling =  Array.from(originalParent.children).indexOf(draggedItem); 
setTimeout(() => {
  ev.target.classList.add('hide');
}, 100);

ev.target.addEventListener('dragend', function() {
  if (draggedItem) {
    originalParent.insertBefore(draggedItem, originalParent.children[previousSibling]);
    draggedItem.classList.remove('hide');
    // Reset variables
    draggedItem = null;
    originalParent = null;
    previousSibling = null;
  }
});
}  
  // Add dragend event listener

}

function dragEnter(e) {
e.preventDefault();
if(e.target.classList.contains("zt-gantt-task-cell")||e.target.classList.contains("parent-bar-style"))
{
   e.target.classList.add('drag-over');
}
}

function dragOver(e) {
e.preventDefault();
if(e.target.classList.contains("zt-gantt-task-cell")||e.target.classList.contains("parent-bar-style"))
{
  e.target.classList.add('drag-over');
}
}

function dragLeave(e) {
if(e.target.classList.contains("zt-gantt-task-cell")||e.target.classList.contains("parent-bar-style"))
{
e.target.classList.remove('drag-over');
}
}



function drop(e) {

  e.preventDefault();
  const id = e.dataTransfer.getData('text/html');

  var task=JSON.parse(id)
  const draggable = document.getElementById(task.id);
  draggItem=draggable;
  if(e.target.classList.contains("zt-gantt-task-cell")||e.target.classList.contains("parent-bar-style"))
  {
  e.target.classList.remove('drag-over');
  var task_id="i"+task.id;
  var cell_date=e.target.getAttribute("zt-gantt-cell-date");
  var ID=e.target.getAttribute("zt-gantt-task-id");
  var taskDetail=gantt.getTask(ID.includes("i")?ID:parseInt(ID));

  let content={
    "start_date":cell_date,
    "due_date":cell_date,
    "assigned_to_id":ID.includes("i")?taskDetail.parent:parseInt(ID)
  }

  $.ajax({
    type: "PUT",
    url: `${url}/issues/${task.id}.json?key=${api_key}`,
    dataType: "json",
    contentType: "application/json",
    async: false,
    data: JSON.stringify({
      issue: content,
    }),
    success: function (result, status, xhr) {
      draggable.classList.add('hide');
      cardDropped=true;
      if(isAdmin)
        {
              // callSelectedTeamAPI();
              restoreFilterSettings();
        }
        else{
          callUserIssuesAPI();
        }
  //     var taskId = gantt.addTask({
  //       id:task_id,
  //       wk_scheme:taskDetail.wk_scheme,
  //       holiday:taskDetail.holiday,
  //       text:task.text,
  //       subject:task.text,
  //       Estimation: task.estimated_hours != null  ? task.estimated_hours : 0,
  //       estimated_hours:task.estimated_hours != null  ? task.estimated_hours+"h" : 0+"h",
  //       row_height:50,
  //       bar_height:40,
  //       start_date:cell_date,
  //       s_date:cell_date,
  //       assigned_to_id:ID.includes("i")?taskDetail.parent:parseInt(ID),
  //       assigned_to:taskDetail.text,
  //       description:task.description,
  //       subtask_parent:[],
  //       parent:ID.includes("i")?taskDetail.parent:parseInt(ID),
  //       project:{
  //         name:task.project_name
  //       },
  //       due_date:cell_date,
  //       end_date:cell_date,
  //       tracker:{
  //         name:task.tracker.name
  //       }
  //     });
   
  //     resource_data.data.push(gantt.getTask(task_id));
  //     const totalEstimatedHours = resource_data.data.reduce((acc, task) =>
  //     {
  //       if(task.parent==(ID.includes("i")?taskDetail.parent:parseInt(ID)))
  //       { 
  //         let Esimtation=task.estimated_hours.includes("h")?+task.estimated_hours.replace("h",""):+task.estimated_hours
  //         return  acc + Esimtation
  //       }
  //       return acc;
  //     }
  //     , 0);
  //  var Issues=[];

  //   let parent={
  //     id:ID.includes("i")?taskDetail.parent:parseInt(ID),
  //     estimated_hours:Number.isInteger(totalEstimatedHours)?totalEstimatedHours+"h":totalEstimatedHours.toFixed(2)+"h",
  //     parent:0,
  //     issues:Issues.push(gantt.getTask(task_id))
  //     }
  //     gantt.updateTaskData(parent);
  //     gantt.render();
      toastr["success"]("Issue dropped successfully");
 
       },
    error: function (xhr, status, error) {
      draggable.classList.remove('hide');
      cardDropped=false;
        if(xhr.status == 422){
           let content = JSON.parse(xhr.responseText).errors;
          content.map((i)=>{
            if(i==="Due date must be greater than start date")
            {
              toastr["error"]("Start date could not be greater than due date");
            }
            else if(i==="Assignee is invalid")
            {
              toastr["error"]("User is not a member of project to  which this issue belongs please check project setting");
            }
            else{
              toastr["error"](i);
            }
         })
       }
       else if(xhr.status == 403)
       {
           toastr["error"]("You don't have permissions");
       } 
    },
  });
} 
else {
  originalParent.insertBefore(draggedItem, originalParent.children[previousSibling]);
  draggedItem.classList.remove('hide');;
}



} // function to drop issue on gantt end 



// Add event listeners to the window object to prevent the default behavior for dragover and drop events
window.addEventListener('dragover', function (e) {
  e.preventDefault();
});

window.addEventListener('drop', function (e) {
  e.preventDefault();
    if (draggedItem) {
      if (cardDropped==true) {
        // Drop inside the "gantt-div," hide the card
        draggedItem.classList.add('hide');
      }else {
        // Drop anywhere else, restore to previous position
        // originalParent.insertBefore(draggedItem, previousSibling);
        originalParent.insertBefore(draggedItem, originalParent.children[previousSibling]);
        draggedItem.classList.remove('hide');
      }
      // Reset variables
      draggedItem = null;
      originalParent = null;
      previousSibling = null;
    }
});





  // // Handle dropdown change and save the preference to the database
  $("#detail").on("change", function() {
    const selectedOption = $(this).val();
      // Expand all and Collapse all functionality 
    if(selectedOption=="expand")
      {
        gantt.expandAll();
      }
      else{
        gantt.collapseAll();
      }
    $.post("/update_dropdown_preference", { selected_option: selectedOption }, function(data) {
      if (data.success) {
        // Successfully updated preference
      }
    });
  });

         // Export Gantt chart to pdf format
     window.export_data_workload= function(){
          $("#export_workload").css("display","none");

          let stylesheet =   ['https://flux4-dev.zehntech.com/plugin_assets/redmineflux_workload/stylesheets/gantt.css','https://flux4-dev.zehntech.com/plugin_assets/redmineflux_workload/stylesheets/workload.css']

          gantt.exportToPDF("Workload",stylesheet);
       }
       window.export_png_workload=function(){
        $("#export_workload").css("display","none");
        let stylesheet =   ['https://flux4-dev.zehntech.com/plugin_assets/redmineflux_workload/stylesheets/gantt.css','https://flux4-dev.zehntech.com/plugin_assets/redmineflux_workload/stylesheets/workload.css']
        gantt.exportToPNG("Workload",stylesheet);
      }
      window.export_excel_workload=function(){
        $("#export_workload").css("display","none");
        gantt.exportToExcel("Workload");
      }

      // $('#Select_team').select2().on('select2:selecting', function (e) {
      //   if ($(this).select2('data').length >= 3) {
      //     e.preventDefault();
      //     toastr["error"]("You can choose up to 3 teams");
      //   }
      // });

      $('#Select_team').select2({
        closeOnSelect: false
      }).on('select2:selecting', function (e) {
        if ($(this).select2('data').length >= 3) {
          e.preventDefault();
          toastr["error"]("You can choose up to 3 teams");
        }
      });

      $('#Select_users').select2({
        closeOnSelect: false
      }).on('select2:selecting', function (e) {
        if ($(this).select2('data').length >= 10) {
          e.preventDefault();
          toastr["error"]("You can choose up to 10 users");
        }
      });

      // call delete API to delete multiple teams 
      $("#Select_team__").on('select2:unselect', function(e) {
        var removedValue = e.params.data.id;// This will log the ID of the removed selection
        $.ajax({
          type: "DELETE",
          url: `${url}/delete/multiple/teams.json?key=${api_key}`,
          dataType: 'json',
          data: {
            team_id:removedValue,
            user_id:login_user_id
          },
          success: function (result, status, xhr) {
          },
          error:function(xhr,status,error)
          {
            
          }
        })
      });

     // on change event on multi select dropdown start 
    $("#Select_team__").on('change',(function(event){
      // event.stopPropagation();
      is_team_selected=true;
      let team_id=$(this).val()||[];

      perpage=10;
      pagenum=1;   
      if(team_id.length!=0)
      {
            var intArray = team_id.map(function(str) {
              return parseInt(str, 10); // Convert each element to an integer.
            });
         
            // Serialize the array as a JSON string
              let serializedData = JSON.stringify(intArray);  
 
            
              $.ajax({
                type: "GET",
                url: `${url}/team_data/${serializedData}.json?key=${api_key}&per_page=${perpage}&page=${pagenum}`,
                dataType: 'json',
                // async:false,
                data: {
                  start_date:start_range,
                  due_date:due_range,
                
                },
                beforeSend: function(){
                  $('.circle-loader').show();
                },
                success: function (result, status, xhr) {
                  $('.circle-loader').toggleClass('load-complete');
                  $('.checkmark').toggle();
                  setTimeout(() => {
                    $(".unknown-div").css("display","none");
                    $('.circle-loader').hide();
                    }, 500);
                    gantt.clearAll();
        
                    resource_data=result
                    Users=result.users;
                    tasks=result.data
                    resource_data.data.map((i)=>{
                       if(i.parent_id!=null)
                        {
                          i.parent="i"+i.parent_id
                        }
                        i.end_date=i.due_date!=null? i.due_date: i.s_date
                        i.issue_id=i.parent==0? i.id : i.id.replace("i","")
                        i.Estimation=i.estimated_hours!=null?i.estimated_hours: 0
                        i.estimated_hours=i.estimated_hours!=null?i.estimated_hours+"h": "0h"
                                            
                    });
           
           
                    // Filter the items where parent == 0
                  let parentZeroItems = resource_data.data.filter(i => i.parent == 0);

                  // Calculate the total available hours, total estimation, and count of parent == 0 items
                  let totalAvailableHours = parentZeroItems.reduce((sum, item) => sum + (item.available_hours || 0), 0);
                  let totalPlannedHours = parentZeroItems.reduce((sum, item) => sum + item.Estimation, 0);
                  let parentZeroCount = parentZeroItems.length;

                  let total = {
              
                    text: "TOTAL",
                    is_total: true,
                    total_available_hours: totalAvailableHours,
                    total_planned_hours: totalPlannedHours,
                    parent_count: parentZeroCount
                };
          
                
                    // Push the total object into resource_data.data
                     resource_data.data.push(total);
                       gantt.options.data = resource_data.data;
                    if(Users&&Users.length!=0){
                      Users.map((i)=>{
                        $("#dynamic_select_user").append(`<option value=${i.id} >${i.firstname+" "+i.lastname}</option>`)
                      })
                    }
                
                    if(result.data.length==0||result.data[0].text=="TOTAL")
                      {
                        $("#gantt_here").css("display","none");
                          $("#menu").css("display","none");
                          if(!$(".nodata")[0])
                          {
                            $(".second-div").after(`<p  style="margin-top:30px; margin-left:13px;" class="nodata">No data to display</p>`);
                          }
                      }
                      else{
                        $("#gantt_here").css("display","block");
                        if(result.hasOwnProperty("pagination"))
                        {
                          total_pages=result.pagination.total_pages;
                        }
                        else{
                          total_pages=1;
                        }
                           $(".nodata").remove();
                          $("#menu").css("display","block");
                          // var workloadTodayFlag = JSON.parse(localStorage.getItem('workload_today_flag'));
                          // document.getElementById('today').checked = workloadTodayFlag !== null ? workloadTodayFlag : true;
                          // if (workloadTodayFlag != false) {

                          //   gantt.options.todayMarker=true;
                          // } else {
                
                          //   gantt.options.todayMarker=false;
                          // }
                    
                          // resource_data.data.push(total);
                         gantt.render(element);  
                     
                   }
                },
                error: function (xhr, status, error) {
                  $('.circle-loader').toggleClass('load-complete');
                  $('.checkmark').toggle();
                  setTimeout(() => {
                    $(".unknown-div").css("display","none");
                    $('.circle-loader').hide();
                    }, 500);
                }
              });
    

        $.ajax({
          type: "POST",
          url: `${url}/team_preferences.json?key=${api_key}`,
          dataType: 'json',
          // async:false,
          data: {
            team_id:JSON.stringify(team_id),
            user_id:login_user_id
          },
          success: function (result, status, xhr) {

          },
          error:function(xhr,status,error)
          {
            
          }
        })
      }
      else{
        callUserIssuesAPI();
      }
  
      $(".main-sidepanel").removeClass('panel_close');
      $("#i-menu").removeClass('showsidepanel');
 
    }))

    $("#Select_users__").on('select2:unselect', function(e) {
      var removedValue = e.params.data.id;// This will log the ID of the removed selection
      $.ajax({
        type: "DELETE",
        url: `${url}/delete/multiple/users.json?key=${api_key}`,
        dataType: 'json',
        data: {
          selected_user_ids:removedValue,
          user_id:login_user_id
        },
        success: function (result, status, xhr) {
        },
        error:function(xhr,status,error)
          {
          
        }
      })
    });

    $("#Select_users__").on('change',(function(){
      is_user_selected=true;
      let users_id=$(this).val();
      perpage=10;
      pagenum=1;

      if(users_id!=null&&users_id.length!=0){

        var intArray = users_id.map(function(str) {
          return parseInt(str, 10); // Convert each element to an integer.
        });

        // Serialize the array as a JSON string
        let serializedData = JSON.stringify(intArray);

        $.ajax({
          type: "GET",
          url: `${url}/user_data/${serializedData}.json?key=${api_key}&per_page=${perpage}&page=${pagenum}`,
          dataType: 'json',
          // async:false,
          data: {
            start_date:start_range,
            due_date:due_range
          },
          beforeSend: function(){
            $('.circle-loader').show();
          },
          success: function (result, status, xhr) {
            $('.circle-loader').toggleClass('load-complete');
            $('.checkmark').toggle();
            setTimeout(() => {
              $(".unknown-div").css("display","none");
              $('.circle-loader').hide();
              }, 500);
              gantt.clearAll();
      
              resource_data=result
              Users=result.users;
              tasks=result.data
              resource_data.data.map((i)=>{
                 if(i.parent_id!=null)
                  {
                    i.parent="i"+i.parent_id
                  }
                  i.end_date=i.due_date!=null? i.due_date: i.s_date
                  i.issue_id=i.parent==0? i.id : i.id.replace("i","")
                  i.Estimation=i.estimated_hours!=null?i.estimated_hours: 0
                  i.estimated_hours=i.estimated_hours!=null?i.estimated_hours+"h": "0h"
                                      
              });
              gantt.options.data = resource_data.data;
              if(Users&&Users.length!=0){
                Users.map((i)=>{
                  $("#dynamic_select_user").append(`<option value=${i.id} >${i.firstname+" "+i.lastname}</option>`)
                })
              }
          
              if(result.data.length==0)
                {
                  $("#gantt_here").css("display","none");
                    $("#menu").css("display","none");
                    if(!$(".nodata")[0])
                    {
                      $(".second-div").after(`<p  style="margin-top:30px; margin-left:13px;" class="nodata">No data to display</p>`);
                    }
                }
                else{
                  $("#gantt_here").css("display","block");
                  if(result.hasOwnProperty("pagination"))
                  {
                    total_pages=result.pagination.total_pages;
                  }
                  else{
                    total_pages=1;
                  }
                     $(".nodata").remove();
                    $("#menu").css("display","block");
                    // var workloadTodayFlag = JSON.parse(localStorage.getItem('workload_today_flag'));
                    // document.getElementById('today').checked = workloadTodayFlag !== null ? workloadTodayFlag : true;
                    // if (workloadTodayFlag != false) {

                    //   gantt.options.todayMarker=true;
                    // } else {
                
                    //   gantt.options.todayMarker=false;
                    // }
                   gantt.render(element);      
             }
          },
          error: function (xhr, status, error) {
            $('.circle-loader').toggleClass('load-complete');
            $('.checkmark').toggle();
            setTimeout(() => {
              $(".unknown-div").css("display","none");
              $('.circle-loader').hide();
              }, 500);
          }
        });

        $.ajax({
          type: "POST",
          url: `${url}/user_preferences.json?key=${api_key}`,
          dataType: 'json',
          // async:false,
          data: {
              selected_user_ids:JSON.stringify(users_id),
            user_id:login_user_id
          },
          success: function (result, status, xhr) {

          },
          error:function(xhr,status,error)
          {
            
          }
        })

      }
      }));
 
    window.zoomLevel=function (e){
      gantt.options.zoomLevel = e.target.value;
      gantt.zoomInit(); 
    }

    function unassignAndDeleteEstimation(issue_id) {
      var data = {
        issue: {
          assigned_to_id: " ",
          estimated_hours: 0
        }
      };
      // Update the issue via AJAX request
      $.ajax({
        type: "PUT",
        url: `${url}/issues/${issue_id}.json?key=${api_key}`,
        dataType: "json",
        contentType: "application/json",
        data: JSON.stringify(data),
        async:true,
        success: function(result, status, xhr) {
          toastr["success"]("Delete Plan time successfully");

          if(isAdmin)
            {
              // callSelectedTeamAPI();
              restoreFilterSettings();
            }
            else{
              callUserIssuesAPI();
            }
          $('.deletePlan-popup').remove();
          $('.delete_plan_container').remove();
          $(".div-modal,.modal").hide();  
        },
        error: function(xhr, status, error) {
          toastr["error"]("Failed to delete plan");
      
        }
      });
    }
    

    function disableTabindex() {
      if ($('.modal').is(':visible')) {
        $(":tabbable").attr("tabindex", -1);
        $('#team_dropdown').find('input, select').prop('disabled', true);
        $(".modal [tabindex='-1']").attr("tabindex", 0);
        $("html").css("overflow", "hidden");
      }
      else{
        $("[tabindex='-1']").attr("tabindex", 0);
        $("html").css("overflow", "auto");
        $('#team_dropdown').find('input, select').prop('disabled', false);
      }
    }
    
    
    
    
    //code for delete plan
    function appendDeletePlan(issue_id) {
      if ($('.delete_plan').length === 0) {
        var deletePlanContainer = $('<div class="delete_plan_container" style="display:flex; margin-right:15px; cursor:pointer"></div>');
        var deletePlan = $('<button>Delete</button>');
        deletePlan.addClass('delete_plan');
        deletePlan.attr('value', issue_id);
        deletePlanContainer.on('click', function() {
          // Show DeletePlan popup
          deletePlanPopup(issue_id);
          $('.div-modal').css({'z-index': '999'});
          
        });
    
        // Append delete button to the modal
        deletePlanContainer.append(deletePlan);
        deletePlanContainer.insertBefore($('.modal .cancel_btn'));
        $('.button-cross,.button-plan').css({width: '100px'});
      }
     
    }
    
    function deletePlanPopup(issue_id) {
      var estimationHours = $('#estimated_hour').val();
      
      // Create DeletePlan popup message with estimation hours
      if (estimationHours === '0h' || estimationHours === '') {
        var deletePlanMessage = `Do you want to unassign this issue ?`;
      } else {
        var deletePlanMessage = `Do you want to unassign this issue and delete <b>${estimationHours}</b> estimation ?`;
      }
      // Create DeletePlan popup
      var deletePlanPopup = $(`
        <div class="deletePlan-popup">
          <p style="text-align:center">${deletePlanMessage}</p>
          <div class="btn_div"><button class="cancel-delete">Cancel</button>
          <button class="confirm-delete">Delete</button></div>
        </div>
      `);
    
      $('body').append(deletePlanPopup);
    
      // Handle delete and cancel actions
      $('.confirm-delete').on('click', function() {
        unassignAndDeleteEstimation(issue_id);
        $('.div-modal').css({'z-index': ''});
      });
    
      $('.cancel-delete').on('click', function() {
        $('.deletePlan-popup').remove();
        $('.div-modal').css({'z-index': ''});
      });
    }
    
// -------

  window.debounce = function(func, delay) {
    let debounceTimer;
    return function() {
        const context = this;
        const args = arguments;
        clearTimeout(debounceTimer);
        debounceTimer = setTimeout(() => func.apply(context, args), delay);
    }
  }

  let filterCombo = document.getElementById('filterCombo');
  let teamDropdown = document.getElementById('team_dropdown');
  let userDropdown = document.getElementById('user_dropdown');
  let applyButton = document.querySelector('.filter_apply');

  // Function to show/hide filters based on selected option
  function updateFilters() {
      const selectedValue = filterCombo.value;
      if (selectedValue === 'team') {
          teamDropdown.style.display = 'flex';
          userDropdown.style.display = 'none';
      } else if (selectedValue === 'user') {
          teamDropdown.style.display = 'none';
          userDropdown.style.display = 'flex';
      } else {
          teamDropdown.style.display = 'none';
          userDropdown.style.display = 'none';
      }
  }


  filterCombo.addEventListener('change', updateFilters);
  // applyButton.addEventListener('click', saveFilterSettings);
  updateFilters();
  // restoreFilterSettings();
  const debouncedSaveFilterSettings = debounce(saveFilterSettings, 500);
  applyButton.addEventListener('click', debouncedSaveFilterSettings);


  function saveFilterSettings() {

    let selectedValue = filterCombo.value;
    const selectedTeams = Array.from(document.getElementById('Select_team').selectedOptions).map(option => option.value);
    const selectedUsers = Array.from(document.getElementById('Select_users').selectedOptions).map(option => option.value);
    
    if (selectedValue === 'team' && selectedTeams.length === 0) {
      toastr["error"]('Please select at least one team.');
      $("#Select_users").val(null).trigger('change'); 
       return; 
    }
    else if (selectedValue === 'user' && selectedUsers.length === 0) {
    toastr["error"]('Please select at least one user.');
    $('#Select_team').val(null).trigger('change');
     return;
    }
    else {
    $.ajax({
      type: "DELETE",
      url: `${url}/delete/multiple/users.json?key=${api_key}`,
      dataType: 'json',
      data: {
        user_id:login_user_id
      },
      success: function (result, status, xhr) {
        localStorage.setItem('workload_user', login_user_id );
        // let selectedValue = filterCombo.value;
        // // localStorage.setItem('workload_filter', selectedValue);
        // const selectedTeams = Array.from(document.getElementById('Select_team').selectedOptions).map(option => option.value);
        // const selectedUsers = Array.from(document.getElementById('Select_users').selectedOptions).map(option => option.value);
        
        if (selectedValue === 'team') {
                localStorage.setItem('workload_filter', selectedValue);
                
                $("#Select_users").val(null).trigger('change'); 
               $.ajax({
                type: "POST",
                url: `${url}/team_preferences.json?key=${api_key}`,
                dataType: 'json',
                // async:false,
                data: {
                  team_id:JSON.stringify(selectedTeams),
                  user_id:login_user_id
                },
                success: function (result, status, xhr) {
                  restoreFilterSettings();
                },
                error:function(xhr,status,error)
                {
                  
                }
              });

           
        } else if (selectedValue === 'user') {
             
                  $('#Select_team').val(null).trigger('change');
                  localStorage.setItem('workload_filter', selectedValue);
                 $.ajax({
                  type: "POST",
                  url: `${url}/user_preferences.json?key=${api_key}`,
                  dataType: 'json',
                  // async:false,
                  data: {
                    selected_user_ids:JSON.stringify(selectedUsers),
                    user_id:login_user_id
                  },
                  success: function (result, status, xhr) {
                    restoreFilterSettings();
                  },
                  error:function(xhr,status,error)
                  {
                    
                  }
                 });

                
        } else if (selectedValue === 'my_workload') {
          $("#Select_users").val(null).trigger('change'); 
          $('#Select_team').val(null).trigger('change');
          localStorage.setItem('workload_filter', selectedValue);
             restoreFilterSettings();
        }
        
      },
      error:function(xhr,status,error)
        {
        
      }
    })
  }
}


        function restoreFilterSettings() {

          $.ajax({
            type: "GET",
            url: `${url}/selected_teams.json?key=${api_key}`,
            dataType: 'json',
            success: function (result, status, xhr) {
               is_team=[];
               is_user =[];

  
               if (result.length !== 0) {             
                result.forEach(item => {
                  if (item.team_id !== null) {
                    is_team.push(item.team_id);
                  } 
                  if (item.selected_user_ids !== null) {
                    is_user.push(item.selected_user_ids);
                  }
                });
              }

          var workload_user = localStorage.getItem('workload_user') ;
          const savedFilter = localStorage.getItem('workload_filter') || "my_workload" ;
          if (savedFilter && workload_user == login_user_id) {
              filterCombo.value = savedFilter;
              updateFilters();
  
                     
                  if (savedFilter === 'team') {
                      const selectTeam = document.getElementById('Select_team');
                      if (selectTeam) {
                        
                        if(is_team.length!=0){
                        var selected_teams_id = is_team.map(function(num) {
                          return num.toString(); 
                        });
                        }
                        $('#Select_team').val();
                        $('#Select_team').val(selected_teams_id).trigger('change');

                      let perpage=10;
                      let pagenum=1;

                      var teams_id_init = [];

                      if (is_team.length !== 0) {
                        teams_id_init = is_team.map(function(num) {
                          return parseInt(num, 10); 
                        });
                      }
                      let integerValuesString = JSON.stringify(teams_id_init);
                        teamperpage=10;
                        teampagenum=1
                        $.ajax({
                          type: "GET",
                          url: `${url}/team_data/${integerValuesString}.json?key=${api_key}&per_page=${teamperpage}&page=${teampagenum}`,
                          dataType: 'json',
                          // async:false,
                          data: {
                            start_date:start_range,
                            due_date:due_range,
                          
                          },
                          beforeSend: function(){
                            $('.circle-loader').show();
                          },
                          success: function (result, status, xhr) {
                            $('.circle-loader').toggleClass('load-complete');
                            $('.checkmark').toggle();
                            setTimeout(() => {
                              $(".unknown-div").css("display","none");
                              $('.circle-loader').hide();
                              }, 500);
                
                              gantt.clearAll();
                  
                              resource_data=result
                              Users=result.users;
                              tasks=result.data
                              resource_data.data.map((i)=>{
                                 if(i.parent_id!=null)
                                  {
                                    i.parent="i"+i.parent_id
                                  }
                                  i.end_date=i.due_date!=null? i.due_date: i.s_date
                                  i.issue_id=i.parent==0? i.id : i.id.replace("i","")
                                  i.Estimation=i.estimated_hours!=null?i.estimated_hours: 0
                                  i.estimated_hours=i.estimated_hours!=null?i.estimated_hours+"h": "0h"
                                                      
                              });
                     
                     
                              // Filter the items where parent == 0
                            let parentZeroItems = resource_data.data.filter(i => i.parent == 0);
          
                            // Calculate the total available hours, total estimation, and count of parent == 0 items
                            let totalAvailableHours = parentZeroItems.reduce((sum, item) => sum + (item.available_hours || 0), 0);
                            let totalPlannedHours = parentZeroItems.reduce((sum, item) => sum + item.Estimation, 0);
                            let parentZeroCount = parentZeroItems.length;
          
                            let total = {
                        
                              text: "TOTAL",
                              is_total: true,
                              total_available_hours: totalAvailableHours,
                              total_planned_hours: totalPlannedHours,
                              parent_count: parentZeroCount
                          };
          
                          
                              // Push the total object into resource_data.data
                               resource_data.data.push(total);
                                 gantt.options.data = resource_data.data;
                              if(Users&&Users.length!=0){
                                Users.map((i)=>{
                                  $("#dynamic_select_user").append(`<option value=${i.id} >${i.firstname+" "+i.lastname}</option>`)
                                })
                              }
                          
                              if(result.data.length==0||result.data[0].text=="TOTAL")
                                {
                                  $("#gantt_here").css("display","none");
                                    $("#menu").css("display","none");
                                    if(!$(".nodata")[0])
                                    {
                                      $(".second-div").after(`<p  style="margin-top:30px; margin-left:13px;" class="nodata">No data to display</p>`);
                                    }
                                }
                                else{
                                  $("#gantt_here").css("display","block");
                                  if(result.hasOwnProperty("pagination"))
                                  {
                                    team_total_pages=result.pagination.total_pages;
                                  }
                                  else{
                                    team_total_pages=1;
                                  }
                                     $(".nodata").remove();
                                    $("#menu").css("display","block");
                                    // var workloadTodayFlag = JSON.parse(localStorage.getItem('workload_today_flag'));
                                    // document.getElementById('today').checked = workloadTodayFlag !== null ? workloadTodayFlag : true;
                                    // if (workloadTodayFlag != false) {
          
                                    //   gantt.options.todayMarker=true;
                                    // } else {
                          
                                    //   gantt.options.todayMarker=false;
                                    // }
                              
                                    // resource_data.data.push(total);
                                   gantt.render(element);      
                             }
                          },
                          error: function (xhr, status, error) {
                            $('.circle-loader').toggleClass('load-complete');
                            $('.checkmark').toggle();
                            setTimeout(() => {
                              $(".unknown-div").css("display","none");
                              $('.circle-loader').hide();
                              }, 500);
                          }
                        });



                    }
                    }
                   else if (savedFilter === 'user') {
                    const selectUser = document.getElementById('Select_users');
                    if (selectUser) {
                      
                      if(is_user.length!=0){
                        var selected_users_id = is_user.map(function(num) {
                          return num.toString(); 
                        });
                        }

                        var users_ids_init = [];

                        if (is_user.length !== 0) {
                          users_ids_init = is_user.map(function(num) {
                            return parseInt(num, 10); // Convert string to integer
                          });
                        }
 

                      $("#Select_users").val(); 
                      $("#Select_users").val(selected_users_id).trigger('change');                     

                                    
                    let selected_user_json = JSON.stringify(users_ids_init);
                    // let perpage=10;
                    // let pagenum=1;

                      $.ajax({
                        type: "GET",
                        url: `${url}/user_data/${selected_user_json}.json?key=${api_key}`,
                        // async:false,
                        data: {
                          start_date:start_range,
                          due_date:due_range
                        },
                        beforeSend: function(){
                          $('.circle-loader').show();
                        },
                        success: function (result, status, xhr) {
                          $('.circle-loader').toggleClass('load-complete');
                          $('.checkmark').toggle();
                          setTimeout(() => {
                            $(".unknown-div").css("display","none");
                            $('.circle-loader').hide();
                            }, 500);
                            gantt.clearAll();
                            resource_data=result
                            Users=result.users;
                            tasks=result.data
                            resource_data.data.map((i)=>{
                               if(i.parent_id!=null)
                                {
                                  i.parent="i"+i.parent_id
                                }
                                i.end_date=i.due_date!=null? i.due_date: i.s_date
                                i.issue_id=i.parent==0? i.id : i.id.replace("i","")
                                i.Estimation=i.estimated_hours!=null?i.estimated_hours: 0
                                i.estimated_hours=i.estimated_hours!=null?i.estimated_hours+"h": "0h"
                                                    
                            });
              
                            
                                  // Filter the items where parent == 0
                                  let parentZeroItems = resource_data.data.filter(i => i.parent == 0);
              
                                  // Calculate the total available hours, total estimation, and count of parent == 0 items
                                  let totalAvailableHours = parentZeroItems.reduce((sum, item) => sum + (item.available_hours || 0), 0);
                                  let totalPlannedHours = parentZeroItems.reduce((sum, item) => sum + item.Estimation, 0);
                                  let parentZeroCount = parentZeroItems.length;
                
                                  let total = {
                              
                                    text: "TOTAL",
                                    is_total: true,
                                    total_available_hours: totalAvailableHours,
                                    total_planned_hours: totalPlannedHours,
                                    parent_count: parentZeroCount
                                };
                
                                
                            // Push the total object into resource_data.data
                            resource_data.data.push(total);
                            gantt.options.data = resource_data.data;
                            if(Users&&Users.length!=0){
                              Users.map((i)=>{
                                $("#dynamic_select_user").append(`<option value=${i.id} >${i.firstname+" "+i.lastname}</option>`)
                              })
                            }
                        
                            if(result.data.length==0)
                              {
                                $("#gantt_here").css("display","none");
                                  $("#menu").css("display","none");
                                  if(!$(".nodata")[0])
                                  {
                                    $(".second-div").after(`<p  style="margin-top:30px; margin-left:13px;" class="nodata">No data to display</p>`);
                                  }
                              }
                              else{
                                $("#gantt_here").css("display","block");
                                if(result.hasOwnProperty("pagination"))
                                {
                                  total_pages=result.pagination.total_pages;
                                }
                                else{
                                  total_pages=1;
                                }
                                   $(".nodata").remove();
                                  $("#menu").css("display","block");
                                  // var workloadTodayFlag = JSON.parse(localStorage.getItem('workload_today_flag'));
                                  // document.getElementById('today').checked = workloadTodayFlag !== null ? workloadTodayFlag : true;
                                  // if (workloadTodayFlag != false) {
              
                                  //   gantt.options.todayMarker=true;
                                  // } else {
                                  //   gantt.options.todayMarker=false;
                                  // }
                                 gantt.render(element);      
                           }
                        },
                        error: function (xhr, status, error) {
                          $('.circle-loader').toggleClass('load-complete');
                          $('.checkmark').toggle();
                          setTimeout(() => {
                            $(".unknown-div").css("display","none");
                            $('.circle-loader').hide();
                            }, 500);
                        }
                      });

                }
              }
              else if (savedFilter === 'my_workload') {
                callUserIssuesAPI();
              }
              
          } 
          else {
            filterCombo.value = "my_workload";
            callUserIssuesAPI();
          }
        },
        error:function(xhr,status,error)
        {      
        }
      });

      }



// ---
});






// code for delete plan end



