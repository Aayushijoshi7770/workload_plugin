



function create_custom_dropdowns() {
    $('#dynamic_select').each(function (i, select) {
        if (!$(this).next().hasClass('dropdown-select')) {
            $(this).after('<div id="issue-drop" class="dropdown-select wide  ' + ($(this).attr('class') || '') + '" tabindex="0"><span  id="current-issue" class="current"></span><div class="list"><ul></ul></div></div>');
            var dropdown = $(this).next();
            var options = $(select).find('option');
            var selected = $(this).find('option:selected');
            dropdown.find('.current').html(selected.data('display-text') || selected.text());
            // dropdown.find('.current').attr("value",selected.val());
            options.each(function (j, o) {
                var display = $(o).data('display-text') || '';
                dropdown.find('ul').append('<li class="option ' + ($(o).is(':selected') ? 'selected' : '') + '" data-value="' + $(o).val() + '" data-display-text="' + display + '">' + $(o).html() + '</li>');
            });
        }
    });
    // showversion();
    $("#select_version").each(function (i, select) {
        if (!$(this).next().hasClass('dropdown-select')) {

            $(this).after('<div id="version-drop" class="dropdown-select wide  ' + ($(this).attr('class') || '') + '" tabindex="0"><span  id="version" class="current"></span><div class="list"><ul></ul></div></div>');
            var dropdown = $(this).next();
            var options = $(select).find('option');
            var selected = $(this).find('option:selected');
            dropdown.find('.current').html(selected.data('display-text') || selected.text());
            options.each(function (j, o) {
                var display = $(o).data('display-text') || '';
                dropdown.find('ul').append('<li class="option ' + ($(o).is(':selected') ? 'selected' : '') + '" data-value="' + $(o).val() + '" data-display-text="' + display + '">' + $(o).html() + '</li>');
            });
        }
    });
    $('#team_member_commitment').each(function (i, select) {
        if (!$(this).next().hasClass('dropdown-select_commit')) {
            $(this).after('<div id="commit-drop" class="dropdown-select_commit wide ' + ($(this).attr('class') || '') + '" tabindex="0"><span  id="current-commitment" class="current"></span><div class="list"><ul></ul></div></div>');
            var dropdown = $(this).next();
            var options = $(select).find('option');
            var selected = $(this).find('option:selected');
            dropdown.find('.current').html(selected.data('display-text') || selected.text());
            // dropdown.find('.current').val(selected.data('display-text') || selected.text());
            options.each(function (j, o) {
                var display = $(o).data('display-text') || '';
                dropdown.find('ul').append('<li class="option ' + ($(o).is(':selected') ? 'selected' : '') + '" data-value="' + $(o).val() + '" data-display-text="' + display + '">' + $(o).html() + '</li>');
            });
        }
    });
    $('#dynamic_select_user').each(function (i, select) {
        if (!$(this).next().hasClass('dropdown-select')) {
            $(this).after('<div id="user-drop" class="dropdown-select wide ' + ($(this).attr('class') || '') + '" tabindex="0"><span  id="current-user" class="current"></span><div class="list"><ul id="UserDropdown"></ul></div></div>');
            var dropdown = $(this).next();
            var options = $(select).find('option');
            var selected = $(this).find('option:selected');
            // console.log(options,  dropdown.find('ul'),"options sddf")
            dropdown.find('.current').html(selected.data('display-text') || selected.text());
            // dropdown.find('.current').val(selected.data('display-text') || selected.text());
            options.each(function (j, o) {
                var display = $(o).data('display-text') || '';
                dropdown.find('ul').append('<li class="option ' + ($(o).is(':selected') ? 'selected' : '') + '" data-value="' + $(o).val() + '" data-display-text="' + display + '">' + $(o).html() + '</li>');
            });
        }
    });

    $('#edit_commitment').each(function (i, select) {
        if (!$(this).next().hasClass('dropdown-select')) {
            $(this).after('<div id="commit_edit-drop" class="dropdown-select wide ' + ($(this).attr('class') || '') + '" tabindex="0"><span  id="current_edit-commitment" class="current"></span><div class="list"><ul id="mySelect_commit"></ul></div></div>');
            var dropdown = $(this).next();
            var options = $(select).find('option');
            var selected = $(this).find('option:selected');
            dropdown.find('.current').html(selected.data('display-text') || selected.text());
            // dropdown.find('.current').val(selected.data('display-text') || selected.text());
            options.each(function (j, o) {
                var display = $(o).data('display-text') || '';
                dropdown.find('ul').append('<li class="option ' + ($(o).is(':selected') ? 'selected' : '') + '" data-value="' + $(o).val() + '" data-display-text="' + display + '">' + $(o).html() + '</li>');
            });
        }
    });
    $('#bulk_commitment').each(function (i, select) {

        if (!$(this).next().hasClass('dropdown-select')) {
            $(this).after('<div id="commit_bulk-drop" class="dropdown-select wide ' + ($(this).attr('class') || '') + '" tabindex="0"><span  id="current_bulk-commitment" class="current"></span><div class="list"><ul class="bulk-commit" id="mySelect_commit"></ul></div></div>');
            var dropdown = $(this).next();
            var options = $(select).find('option');
            var selected = $(this).find('option:selected');
            dropdown.find('.current_bulk').html(selected.data('display-text') || selected.text());
            // dropdown.find('.current').val(selected.data('display-text') || selected.text());
            options.each(function (j, o) {
                var display = $(o).data('display-text') || '';
                dropdown.find('ul').append('<li class="option ' + ($(o).is(':selected') ? 'selected' : '') + '" data-value="' + $(o).val() + '" data-display-text="' + display + '">' + $(o).html() + '</li>');
            });
        }
    });

    $('#dynamic_select_project').each(function (i, select) {
        if (!$(this).next().hasClass('dropdown-select')) {
            $(this).after('<div id="project-drop" class="dropdown-select wide  ' + ($(this).attr('class') || '') + '" tabindex="0"><span  id="current-project" class="current"></span><div class="list"><ul></ul></div></div>');
            var dropdown = $(this).next();
            var options = $(select).find('option');
            var selected = $(this).find('option:selected');
            dropdown.find('.current').html(selected.data('display-text') || selected.text());

            options.each(function (j, o) {
                var display = $(o).data('display-text') || '';
                dropdown.find('ul').append('<li class="option ' + ($(o).is(':selected') ? 'selected' : '') + '" data-value="' + $(o).val() + '" data-display-text="' + display + '">' + $(o).html() + '</li>');
            });
        }
    });

    $('#team_member_member_id').each(function (i, select) {
        if (!$(this).next().hasClass('dropdown-select')) {
            $(this).after('<div id="team-drop" class="dropdown-select wide ' + ($(this).attr('class') || '') + '" tabindex="0"><span  id="current-user"     class="current"></span><div class="list"><ul></ul></div></div>');
            var dropdown = $(this).next();
            var options = $(select).find('option');
            var selected = $(this).find('option:selected');
            dropdown.find('.current').html(selected.data('display-text') || selected.text());
            // dropdown.find('.current').val(selected.data('display-text') || selected.text());
            options.each(function (j, o) {
                var display = $(o).data('display-text') || '';
                dropdown.find('ul').append('<li class="option ' + ($(o).is(':selected') ? 'selected' : '') + '" data-value="' + $(o).val() + '" data-display-text="' + display + '">' + $(o).html() + '</li>');
            });
        }
    });

    $('#user-drop ul').before('<div class="dd-search"><input id="txtSearchValueuser" autocomplete="off" onkeyup="filter()" class="dd-searchbox" type="text"></div>');
    $('#issue-drop ul').before('<div class="dd-search"><input id="txtSearchValueissue" autocomplete="off" onkeyup="filterIssues()" class="dd-searchbox" type="text"></div>');
    $('#team-drop ul').before('<div class="dd-search"><input id="txtSearchValuepeople" autocomplete="off" onkeyup="filterPeople()" class="dd-searchbox" type="text"></div>');
    $('#project-drop ul').before('<div class="dd-search"><input id="txtSearchValueproject" autocomplete="off" onkeyup="filterProject()" class="dd-searchbox" type="text"></div>');
    $('#version-drop ul').before('<div class="dd-search"><input id="txtSearchValueversion" onkeyup="filterVersion()" autocomplete="off"  class="dd-searchbox" type="text"></div>');
}



// Event listeners
function filterVersion(){
        var searchValue = $('#txtSearchValueversion').val().toLowerCase().trim();
        $('#version-drop ul').each(function () {

          $(this).find('li,strong').each(function () {
          var issueSubject = $(this).text().toLowerCase();
          if (issueSubject.includes(searchValue)) {
            $(this).show();
          } else {
            $(this).hide();
          }
      });     
})
}
// Open/close
$(document).on('click', '.dropdown-select', function (event) {
    if($(event.target).hasClass('dd-searchbox')){
        return;
    }
    $('.dropdown-select').not($(this)).removeClass('open');
    $(this).toggleClass('open');
    if ($(this).hasClass('open')) {
        $(this).find('.option').attr('tabindex', 0);
        $(this).find('.selected').focus();
    } else {
        $(this).find('.option').removeAttr('tabindex');
        $(this).focus();
    }
});
$(document).on('click', '.dropdown-select_commit', function (event) {
    if($(event.target).hasClass('dd-searchbox')){
        return;
    }
    $('.dropdown-select_commit').not($(this)).removeClass('open');
    $(this).toggleClass('open');
    if ($(this).hasClass('open')) {
        $(this).find('.option').attr('tabindex', 0);
        $(this).find('.selected').focus();
    } else {
        $(this).find('.option').removeAttr('tabindex');
        $(this).focus();
    }
});
// Close when clicking outside
$(document).on('click', function (event) {
    if ($(event.target).closest('.dropdown-select').length === 0) {
        $('.dropdown-select').removeClass('open');
        $('.dropdown-select .option').removeAttr('tabindex');
    }
    event.stopPropagation();
});
$(document).on('click', function (event) {
    if ($(event.target).closest('.dropdown-select_commit').length === 0) {
        $('.dropdown-select_commit').removeClass('open');
        $('.dropdown-select_commit .option').removeAttr('tabindex');
    }
    event.stopPropagation();
});
function filter(){
    var valThis = $('#txtSearchValueuser').val();
    if(valThis.length!=0)
    {
    $.ajax({
        type: "GET",
        url: `${url}/search_wk_users.json?key=${api_key}`,
        dataType: 'json',
        async:false,
        contentType: "application/json",
        data: {
          name: valThis.trim(),
          team_id:is_team
        },
        success: function (result, status, xhr) {
            $("#user-drop ul").html(" ");
            if (Array.isArray(result) && result.length != 0)
            {
                result.map((i)=>{
                    $("#user-drop ul").append('<li class="option ' + ($(i).is(':selected') ? 'selected' : '') + '" data-value="' + i.id + '">' + i.firstname+" "+i.lastname + '</li>')
              })
            }
        
        },
        error: function (xhr, status, error) {
        }
        });
      }
         else{
        $("#user-drop ul").html( " ");
        if(Users.length!=0){
            Users.map((i)=>{
      
              $("#user-drop ul").append('<li class="option ' + ($(i).is(':selected') ? 'selected' : '') + '" data-value="' + i.id + '">' + i.firstname+" "+i.lastname + '</li>')
            })
          }
    }

};

function filterIssues(){
    var user_id=$("#dynamic_select").children(":selected").attr("id");
    var valThis = $('#txtSearchValueissue').val();
    if(valThis.length!=0)
    {
    $.ajax({
        type: "GET",
        url: `${url}/search_issues.json?key=${api_key}&user_id=${user_id}`,
        dataType: 'json',
        async:false,
        contentType: "application/json",
        data: {
            parameter:valThis,
        },
        success: function (result, status, xhr) {
            $("#issue-drop ul").html( " ");
            if (Array.isArray(result) && result.length != 0)
            {
                if(i.id==$("#current-issue").attr("value"))
                    {
                      issue_data=i;
                    } 
                result.map((i)=>{
                    $("#issue-drop ul").append(`<li class='option${($(i).is(':selected') ? 'selected' : '')}'   data-value=${i.id}  data-project=${i.project_id} ><span class="task_id_workload"> ${'#'+i.id}</span><span>${i.subject }</span></li>`)
              })
            }
        
        },
        error: function (xhr, status, error) {
        }
        });
      }
    else{
            $.ajax({
                type: "GET",
                url: `${url}/team/assigned/issues.json?user_id=${user_id}&key=${api_key}`,
                dataType: 'json',
                async:false,
                success: function (result, status, xhr) {
                $("#dynamic_select").html(" ");
                 $("#issue-drop ul").html(" ");
               if(result.length!=0){
                result.map((i)=>{
                $("#issue-drop ul").append(`<li class='option${($(i).is(':selected') ? 'selected' : '')}'   data-value=${i.id}  data-project=${i.project_id} ><span class="task_id_workload"> ${'#'+i.id}</span><span>${i.subject }</span></li>`)
                  $("#dynamic_select").append(`<option  id=${user_id} value=${i.id} >${i.subject}</option>`)
               })
               }
                },
                error: function (xhr, status, error) {
                  $("#dynamic_select").html(" ");
                      $("#issue-drop ul").html(" ");
                 if(xhr.status == 403)
                   {
                    alert("unauthorized");
                  }
                }
              });
     }
};
// Search
function filterPeople(){
    var valThis = $('#txtSearchValuepeople').val();
    if(valThis.length!=0)
    {
    $.ajax({
        type: "GET",
        url: `${url}/find_members.json?key=${api_key}`,
        dataType: 'json',
        async:false,
        contentType: "application/json",
        data: {
          name: valThis.trim(),
        },
        success: function (result, status, xhr) {
            $(".dropdown-select ul").html(" ");
            if (Array.isArray(result) && result.length != 0)
            {
                result.map((i)=>{
                    
                    $(".dropdown-select ul").append('<li class="option ' + ($(i).is(':selected') ? 'selected' : '') + '" data-value="' + i.id + '">' + i.firstname+" "+i.lastname + '</li>')
              })
            }
        
        },
        error: function (xhr, status, error) {
        }
        });
      }
         else{
        $(".dropdown-select ul").html( " ");
        if( Users.length!=0){
            Users.map((i)=>{
              // console.log( $("#dynamic_select"),"i");
              $(".dropdown-select ul").append('<li class="option ' + ($(i).is(':selected') ? 'selected' : '') + '" data-value="' + i.id + '">' + i.firstname+" "+i.lastname + '</li>')
            })
          }
//      $('.dropdown-select ul > li').each(function(){
//      var text = $(this).text();
//         (text.toLowerCase().indexOf(valThis.toLowerCase()) > -1) ? $(this).show() : $(this).hide();         
//    }); 
    }


//     $('.dropdown-select ul > li').each(function(){
//      var text = $(this).text();
//         (text.toLowerCase().indexOf(valThis.toLowerCase()) > -1) ? $(this).show() : $(this).hide();         
//    });
};

function filterProject(){
    var valThis = $('#txtSearchValueproject').val();
    // console.log(valThis,"val THis")
    // $('li[data-value="0"]').addClass('li_disable');
    let team_id= $('#Select_team').val();
  
    team_id=team_id?team_id:[];
    if(valThis.length!=0)
    {
    $.ajax({
        type: "GET",
        url: `${url}/search_users_projects.json?key=${api_key}&team_id=${team_id}`,
        dataType: 'json',
        async:false,
        contentType: "application/json",
        data: {
          name: valThis.trim(),
        },
        success: function (result, status, xhr) {
   
            $("#project-drop ul").html(" ");
            // $("#project-drop ul").append('<li class="option  ' + ($(i).is(':selected') ? 'selected' : '') + '" data-value="' + 0 + '">' + 'Please select' + '</li>')
            if (Array.isArray(result) && result.length != 0)
            {
                result.map((i)=>{
                    $("#project-drop ul").append('<li onclick="getTracker($(this)); getVersions($(this))" value="' + i.id + '"  class="option ' + ($(i).is(':selected') ? 'selected' : '') + '" data-value="' + i.id + '">' + i.name + '</li>')
              })
            }
        
        },
        error: function (xhr, status, error) {
        }
        });
      }
         else{
        $("#project-drop ul").html( " ");
        // $("#project-drop ul").append('<li class="option li_disable ' + ($(i).is(':selected') ? 'selected' : '') + '" data-value="' + 0 + '">' + 'Please select' + '</li>')
        if(Projects.length!=0){
            Projects.map((i)=>{
              // console.log( $("#dynamic_select"),"i");
              $("#project-drop ul").append('<li onclick="getTracker($(this))"  value="' + i.id + '"  class="option ' + ($(i).is(':selected') ? 'selected' : '') + '" data-value="' + i.id + '">' + i.name + '</li>')
            })
          }
    }

};

// Option click
$(document).on('click', '.dropdown-select .option', function (event) {
    $(this).closest('.list').find('.selected').removeClass('selected');
    $(this).addClass('selected');
    var text = $(this).data('display-text') || $(this).text();
    var user_id=$(this).data("value");
    var subject=$(this).children().last().text();
    // $(this).closest('.dropdown-select').find('.current').text(subject);

    $(this).closest('.dropdown-select').find('.current').text(text);
    $(this).closest('.dropdown-select').find('.current').attr("value",user_id);
    $(this).closest('.dropdown-select').prev('select').val($(this).data('value')).trigger('change');
});
// option click for issue drop 
$(document).on('click', '#issue-drop .option', function (event) {

    // code to show  selected issue comment 
    setTimeout(()=>{
        // console.log(issue_data,"issue data");
        if(Object.keys(issue_data).length!=0&&issue_data !== undefined && issue_data !== null)
        {
         let checkbox = document.getElementById("watchers-input");
         $("#due_date").val(issue_data.due_date);
         $(".text-area-res").val(issue_data.description);
         $("#start_date").val(issue_data.start_date);
         if(issue_data.estimated_hours!=null)
         {
           if(Number.isInteger(issue_data.estimated_hours))
           {
            console.log("values")
             $("#estimated_hour").val(issue_data.estimated_hours+"h")
           }
           else{
            console.log("values else")
              $("#estimated_hour").val(issue_data.estimated_hours.toFixed(2)+"h")
           }
         }
          else{
           $("#estimated_hour").val("0h");
         } 

             $("#date-inputs").html("");
            $("#date-inputs").css("display","none");
            $(".workhour-error").css("display","none");
            $(".workhour-div").css("display","none");
            let plantimeDiv=document.getElementById('plan-time-div');
            plantimeDiv.style.marginBottom='20px';
            // let issue= gantt.getTask("i"+issue_data.id);
            localStorage.setItem("task_timesheet",JSON.stringify(issue_data));

            if(issue_data.distribution=='custom')
            {
                checkbox.checked=false;
             createBox(issue_data.workhours,issue_data);
            }
            else{
                checkbox.checked=true;
            }    
            
        }
    },300)


    // end
    $(this).closest('.list').find('.selected').removeClass('selected');
    $(this).addClass('selected');
    // var text = $(this).data('display-text') || $(this).text();
    var user_id=$(this).data("value");
    var subject=$(this).children().last().text();

    $(this).closest('.dropdown-select').find('.current').text(subject);
    $(this).closest('.dropdown-select').find('.current').attr("value",user_id);
    $(this).closest('.dropdown-select').prev('select').val($(this).data('value')).trigger('change');
});
$(document).on('click', '.dropdown-select_commit .option', function (event) {
    $(this).closest('.list').find('.selected').removeClass('selected');
    $(this).addClass('selected');
    var text = $(this).data('display-text') || $(this).text();
    var user_id=$(this).data("value");
    // console.log(user_id,"userid ");
    $(this).closest('.dropdown-select_commit').find('.current').text(text);
    $(this).closest('.dropdown-select_commit').find('.current').attr("value",user_id);
    $(this).closest('.dropdown-select_commit').prev('select').val($(this).data('value')).trigger('change');
});
// Keyboard events
$(document).on('keydown', '.dropdown-select', function (event) {
    var focused_option = $($(this).find('.list .option:focus')[0] || $(this).find('.list .option.selected')[0]);
    // Space or Enter
    //if (event.keyCode == 32 || event.keyCode == 13) {
    if (event.keyCode == 13) {
        if ($(this).hasClass('open')) {
            focused_option.trigger('click');
        } else {
            $(this).trigger('click');
        }
        return false;
        // Down
    } else if (event.keyCode == 40) {
        if (!$(this).hasClass('open')) {
            $(this).trigger('click');
        } else {
            focused_option.next().focus();
        }
        return false;
        // Up
    } else if (event.keyCode == 38) {
        if (!$(this).hasClass('open')) {
            $(this).trigger('click');
        } else {
            var focused_option = $($(this).find('.list .option:focus')[0] || $(this).find('.list .option.selected')[0]);
            focused_option.prev().focus();
        }
        return false;
        // Esc
    } else if (event.keyCode == 27) {
        if ($(this).hasClass('open')) {
            $(this).trigger('click');
        }
        return false;
    }
});

$(document).ready(function () {


    create_custom_dropdowns();
});



$(function() {




  // bind change event to select
  $('#dynamic_select').on('change', function() {
    var url = $(this).val(); // get selected value
    // if (url) { // require a URL
    //   window.location = url; // redirect
    // }
    return false;
  });
  $('#dynamic_select_user').on('change', function() {
    var url = $(this).val(); // get selected value
    // if (url) { // require a URL
    //   window.location = url; // redirect
    // }
    return false;
  });
  $('#team_member_member_id').on('change', function() {
    var url = $(this).val(); // get selected value
    // if (url) { // require a URL
    //   window.location = url; // redirect
    // }
    return false;
  });
  $('#edit_commitment').on('change', function() {
    var url = $(this).val(); // get selected value
    // if (url) { // require a URL
    //   window.location = url; // redirect
    // }
    return false;
  });
  $('#bulk_commitment').on('change', function() {
    var url = $(this).val(); // get selected value
    // if (url) { // require a URL
    //   window.location = url; // redirect
    // }
    return false;
  });
});

