# Redmine Workload Plugin 

The Redmine Workload Plugin is an effective solution for managing and visualising workloads in Redmine , a popular project managment and issue tracking  tool.
Teams will find it easier to allocate work effectively and fulfill project deadlines with the help of this plugin , which offer usefull insights into resource allocation 
and project planning.


![Readmine Workload plugin](Workload.png)


## Installation 

To install the Redmine Workload Plugin , follow these steps:

1. Make sure you have a working installation of Redmine 
2. clone the codecommit repository using your credentials in Redmine plugins directory
   ```sh
   git clone https://git-codecommit.ap-south-1.amazonaws.com/v1/repos/flux_resources
   ```  
3. Run the following command to install the required dependencies:
    ```sh
    gem install will_paginate 
    ```
    ```sh
    bundle install 
    ```
4. Run DB migrations 
    
    * For production 
    ```sh
    RAILS_ENV=production bundle exec rails  redmine:plugins:migrate 
    ```
    * For development 
    ```sh
    RAILS_ENV=development bundle exec rails redmine:plugins:migrate 

5. Restart Redmine server to load the plugin 
    ```sh
    Rails s 
    ```


## Usage
 
 The Redmine Workload Plugin provides serveral features and visualize workloads effectively. Here the main features:

 * ### Resource Availability:  
   With the help of Redmine Workload Plugin one can view the availability of each team member , allowing you to identify conflicts in their schedules.
 * ### Workload Assignment:
   Assign task to team members directly from the workload interface, simplifying the distribution of work and ensuring everyone has a clear understanding of their responsibilities.
 * ### Drag-and-Drop Interface:
   Effortlessly reschedule tasks by dragging and dropping them within the workload view, enabling you to adapt quickly to changing priorities or project timelines.
 * ### Filtering: 
   Use various filters options to focus on specific users, or issues, allowing you to analyze workloads at different levels of granularity.

   