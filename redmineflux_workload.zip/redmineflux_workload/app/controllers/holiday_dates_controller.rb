class HolidayDatesController < ApplicationController
  accept_api_auth :update,:index, :delete_holiday_dates
  def index
    @holidays = HolidayDate.where(id: params[:id])
    respond_to do |format|
      format.html
      format.api { render :json => @holidays }
      format.json { render :json => @holidays }
    end 
  end

  def new
    # @holiday_date = HolidayDate.new
    @holiday = UserHoliday.find(params[:user_holiday_id])
    @holiday_date = @holiday.holiday_dates.new
    @holiday_dates = @holiday.holiday_dates.all

    @user_ids = HolidayScheme.where(:user_holiday_id => @holiday).pluck(:user_id)
    @users = User.where(:id => @user_ids).select(:firstname,:lastname,:id).paginate(page: params[:page], per_page: 20)
    @dates = @holiday.holiday_dates


    @all_holiday_user_ids = HolidayScheme.pluck(:user_id)
    @memeber_holiday_scheme = User.where(status: 1).where.not(id: @all_holiday_user_ids)
  end
  
  def create 
    @holiday = UserHoliday.find(params[:user_holiday_id])
    @holiday_date = @holiday.holiday_dates.new(params.require(:holiday_date).permit(:name, :description, :start_date,:end_date, :created_by => User.current.id, user_holiday_id: @user_holiday))
    if @holiday_date.save
      flash[:notice] = " Date was added successfully "
      respond_to do |format|
        format.html { redirect_to :back }
        format.js { render js: "window.location = '#{new_user_holiday_holiday_date_path(@holiday)}'" }
      end
    elsif @holiday_date.errors.any?
      flash[:error] = @holiday_date.errors.full_messages.join("</br>")
      respond_to do |format|
        format.html
        format.js { render 'error.js.erb', locals: { error_message: flash[:error] }, status: :unprocessable_entity }
      end
    else  
      flash[:error] = "Failed to add holiday date"
      respond_to do |format|
        format.html
        format.js { render 'error.js.erb', locals: { error_message: flash[:error] }, status: :unprocessable_entity }
      end
    end 
  end 
  def edit
    if (User.current.allowed_to?(:manage_workload, @project)) || (User.current.admin?)
      @holiday = UserHoliday.find(params[:user_holiday_id])
      @holiday_date = HolidayDate.find(params[:id])
    else   
      flash[:error] = "You are not authorized"
      redirect_to :back 
    end 
  end


  def update
    # @holiday = UserHoliday.find(params[:user_holiday_id])
    @holiday_date = HolidayDate.find(params[:id])
    puts "#{params[:holiday_date]} helowa"
    if @holiday_date.update(
          name: params[:holiday_date][:name],
          description: params[:holiday_date][:description],
          start_date: params[:holiday_date][:start_date],
          end_date: params[:holiday_date][:end_date]
        )
        flash[:notice] = 'Successfully Updated'
          respond_to do |format|
            format.html { redirect_to :back }
            format.js { render js: "window.location.reload()" }
          end
    else
      error_messages = @holiday_date.errors.full_messages.join('</br>')
      flash[:error] = error_messages.presence || 'Something went wrong'
      respond_to do |format|
        format.html
        format.js { render 'error.js.erb', locals: { error_message: flash[:error] }, status: :unprocessable_entity }
      end
    end
  end

  def show
    @holiday_date = HolidayDate.find(params[:id])
   
  
  end

  def destroy
    if (User.current.allowed_to?(:manage_workload, @project)) || (User.current.admin?)
      @holiday = UserHoliday.find(params[:user_holiday_id])
      @holiday_date = HolidayDate.find(params[:id])
      @holiday_date.destroy
      flash[:notice]='Successfully Deleted'
      redirect_to :back
    else  
      flash[:error] = "You are not authorized"
      redirect_to :back
    end 
  end 

  def delete_holiday_dates
    if (User.current.allowed_to?(:manage_workload, @project)) || (User.current.admin?)
      @holiday = UserHoliday.where(id: params[:user_holiday_id].split(',').map(&:to_i))
      @holiday_date = HolidayDate.where(id: params[:id].split(',').map(&:to_i))
      @holiday_date.destroy_all
      flash[:notice]='Successfully Deleted'
      redirect_to :back
    else  
      flash[:error] = "You are not authorized"
      redirect_to :back
    end 
  end 

end
