class WorkloadDashboardsController < ApplicationController
 # before_action :require_admin
 before_action :require_login
   
    
 def index

   @teams = WorkloadTeam.all.pluck(:name, :id)

   @group = Group.find_by(:type =>"Group", :lastname => "Zehntech-Employees") 
   if @group.present?
     @group_users = @group.users
     @user_ids = @group_users.pluck(:id)
   else 
     @user_ids = User.active.all.pluck(:id)
   end 
    
   @selected_team_id = params[:team]
   
   @team = params[:team].presence || "All Users"
   if @team ==="All Users"
       if  @group.present?
         @group_users = @group.users
         @user_ids = @group_users.pluck(:id)
         @members = User.all.where(:id=>@user_ids,:status=>1, :type=>"User")
       else  
         @members = User.all.where(:status=>1, :type=>"User")
       end 
   else 
       @selected_team = WorkloadTeam.where(:id => @team).pluck(:name, :id)
       @members = TeamMembers.where(:group_id => @team).pluck(:member_id)
   end 
  
   @period_type = params[:period_type].presence || '1'
   @period = params[:period].presence || 'Current Week'
   @from = params[:from]
   @to = params[:to]

   if @period_type == '2'
     @from = @from.to_date
     @to = @to.to_date
     @selected_start_date = params[:from]
     @selected_end_date = params[:to]
   elsif @period_type == '1' 
     @selected_date = params[:period]
     @from = @from
     @to = @to
   end 

   fromdate = session[controller_name].try(:[], :from)
   todate = session[controller_name].try(:[], :to)
    
     if ( @period_type == '1' || ( @period_type.nil? && ! @period_type.nil?)) 
       case @period.to_s

       when 'Yesterday'
         @from = Date.today 
         @to = @from - 1  
       when 'Current Week'
         @from = Date.today.beginning_of_week(:monday)
         @to = Date.today.end_of_week(:saturday)
       when 'Last Week'
         # today = Date.today 
         # @from = today - today.wday - 6
         # @to = @from + 6
         @from = (Date.today - 1.week).beginning_of_week(:monday)
         @to = (Date.today - 1.week).end_of_week(:saturday)
        
       when 'Last 7 days'
         @from = (Date.today - 1.week).beginning_of_week(:monday)
         @to = (Date.today - 1.week).end_of_week(:saturday)
        
       when 'Current Month'
         # @from = Date.civil(Date.today.year, Date.today.month, 1)
         # @to = (@from >> 1) - 1
         @from = Date.today.beginning_of_month
         @to = Date.today.end_of_month
       
       when 'Last Month'
         @from = Date.civil(Date.today.year, Date.today.month, 1) << 1
         @to = (@from >> 1) - 1
            
       when 'Last 30 days'
         @from = Date.today - 30
         @to = Date.today
        
       when 'Next Month'
         current_date = Date.today
         @from = current_date.next_month.beginning_of_month
         @to = current_date.next_month.end_of_month
         
       when 'Current Year'
         today = Date.today
         @from = Date.civil(Date.today.year, 1, 1)
         @to = Date.civil(Date.today.year, 12, 31)

       when 'Current Quarter'
         current_month = Date.today.month
         current_quarter_start = Date.today.prev_month(2).beginning_of_month
         current_quarter_end = Date.today.end_of_month
         @from = current_quarter_start
         @to = current_quarter_end

       when 'Next Quarter'
         next_quarter_start = Date.today.next_month.beginning_of_month
         next_quarter_end = Date.today.next_month(3).end_of_month
         @from = next_quarter_start
         @to = next_quarter_end
         
       end

   elsif  @period_type == '2' || ( @period_type.nil? && (!fromdate.nil? || !todate.nil?))
     begin; @from = fromdate.to_s.to_date unless fromdate.blank?; rescue; end
     begin; @to = todate.to_s.to_date unless todate.blank?; rescue; end
     if @from && @to && @from <= @to 
       
       @free_period = true
     end
   else
       # default
       # 'current_month'		
         @from = Date.today.beginning_of_month
         @to = Date.today.end_of_month
        
   end 
   

    
   if @teams.present?
     @users = User.where(:id => @members, :status =>1, :type => "User").paginate(page: params[:page], per_page: 20)
   else
     @users = User.where(:id => @user_ids, :status =>1, :type => "User").paginate(page: params[:page], per_page: 20)
   end 


   # @weeks = (@from..@to).map { |date| date.strftime('%U').to_i }.uniq
    @weeks = (@from..@to).map { |date| date.cweek }.uniq
  # Replace the current @weeks assignment with the modified version
   # @weeks = (@from..@to).map { |date| (date.beginning_of_week(:monday).strftime('%U').to_i) }.uniq
  # @weeks = (@from..@to).map { |date| "#{date.year}-#{date.cweek}" }.uniq
   @week_dates = {}
   (@from..@to).each do |date|
     # week_number = date.strftime('%U').to_i
     week_number = date.cweek
     start_date = date.beginning_of_week(:monday).strftime('%d')
     start_date_month = date.beginning_of_week(:monday).strftime('%m').to_i
     end_date = date.end_of_week(:monday).strftime('%d') 
     end_date_month = date.end_of_week(:monday).strftime('%m').to_i
   
     # Convert month number to month name
     start_month_name = Date::MONTHNAMES[start_date_month][0..2]
     end_month_name = Date::MONTHNAMES[end_date_month][0..2]


     show_week_date = "#{start_date} #{start_month_name} - #{end_date} #{end_month_name}"    
     @week_dates[week_number] = { show_week_date: show_week_date }
   end
   
   

   @data = {}
   @users.each do |user|
     @weekly_records = {}
     @issues = Issue.where(:assigned_to_id => user.id).where("start_date IS NOT NULL")
     
     (@from..@to).each do |date|
       @total_estimated_hours = 0.0
   
       @issues.each do |task|
         start_date = task.start_date
         due_date = task.due_date || start_date
         if start_date > due_date
           start_date, due_date = due_date, start_date  # Swap the dates
         end
         total_days = (start_date..due_date).count { |d| (1..5).include?(d.wday) && d.wday != 6 && d.wday != 0 }
         estimated_hours = task.estimated_hours
         
         if estimated_hours.present? && total_days > 0
           per_day_estimation = estimated_hours / total_days
           
           if date.between?(start_date, due_date) && (1..5).include?(date.wday)
             @total_estimated_hours += per_day_estimation.round(2)
           end
         end
       end
       week_number = date.cweek
     
       # @weekly_records[week_number] ||= { total_estimated_hours: 0.0 }
       @weekly_records[week_number] ||= 0.0
       @weekly_records[week_number] += @total_estimated_hours
      
     end
     total_workload = total_workload(user.id,@from,@to)
     total_planned_hours = @weekly_records.values.sum { |record| record }.round(2)
     available_hours = total_workload.merge(@weekly_records) { |_, total, planned| {:planned =>planned, :available=> total } }
     
     @data[user.name] = available_hours
   
   end
   @data
   
 end



 def total_workload(user, from, to)
   @workload_scheme = WorkloadScheme.where(:user_id => user).pluck(:user_workload_id) 
   @available_hours = UserWorkload.where(:id => @workload_scheme).pluck(:wd0, :wd1, :wd2, :wd3, :wd4, :wd5, :wd6)
   @holiday_ids = HolidayScheme.where(user_id: user).pluck(:user_holiday_id)
  #  holiday_dates = HolidayDate.where(user_holiday_id: @holiday_ids).pluck(:date)
  holiday_dates = HolidayDate.where(user_holiday_id: @holiday_ids).pluck(:start_date, :end_date).map do |start_date, end_date|
    end_date ||= start_date
    [start_date, end_date]
  end  
   
   weekly_workload = {}
   occurrences = Hash.new { |hash, key| hash[key] = Hash.new(0) }
   
  #  (from..to).each do |date|
  #    unless holiday_dates.include?(date) # exclude dates that are holidays
  #      week_number = date.strftime("%W").to_i
  #      occurrences[week_number][date.strftime("%A")] += 1
  #    end
  #  end

  (from..to).each do |date|
    is_holiday = holiday_dates.any? { |start_date, end_date| (start_date..end_date).cover?(date) }
    unless is_holiday
      week_number = date.strftime("%W").to_i
      occurrences[week_number][date.strftime("%A")] += 1
    end
  end
   
   occurrences.each do |week_number, days|
     total_workload = 0
     days.each do |day, count|
       wd_index = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"].index(day)
       total_workload += @available_hours.sum { |wd| wd[wd_index] } * count
     end
     weekly_workload[week_number] = total_workload.round(2)
   end
   
   return weekly_workload

end 
end
