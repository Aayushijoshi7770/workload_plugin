class WorkloadReportsController < ApplicationController
  before_action :require_admin
  accept_api_auth :workload_chart_data , :workload_user_data , :planned_hours_chart_data , :available_hours_chart_data , :team_hours_data , :save_filter_data , :get_filter_data



  def workload_report
    @filtel = WorkloadReportFilter.first
    team_data, active_users = fetch_team_data_and_users
    @active_users_data = active_users.map { |user| { id: user.id, name: "#{user.firstname} #{user.lastname}" } }
    @teams_data = team_data.map { |team| { id: team.id, name: team.name } }
    @total_planned_hours = 0.0
    @total_available_hours = 0.0
    @total_time_variance = 0
  end


  def planned_hours_chart_data
    start_date = params[:startDate]
    end_date = params[:endDate]
    filter_by = params[:filterBy] || 'team'
    team_ids = params[:teams]
    user_ids = params[:users]
  
    if start_date.present? && end_date.present?
      @from, @to = start_date.to_date, end_date.to_date
    else
      @from ||= Date.today.beginning_of_month
      @to ||= Date.today.end_of_month
    end
  
    if team_ids.present? || user_ids.present?
      if filter_by == 'team'
        teams_data = []
        unique_users = Set.new
        total_unique_planned_hours = 0.0
  
        @teams = team_ids.present? ? WorkloadTeam.where(id: team_ids) : WorkloadTeam.all
  
        @teams.each do |team|
          team_planned_hours = 0.0
  
          member_ids = TeamMembers.where(group_id: team.id).pluck(:member_id).uniq
          @users = User.active.where(id: member_ids)
          closed_status_ids = IssueStatus.where(is_closed: true).pluck(:id)
          project_ids = Project.where(status: [1, 5]).pluck(:id)
  
          @users.each do |user|
            user_planned_hours = Issue.where(assigned_to_id: user.id)
                                      .where.not(status_id: closed_status_ids)
                                      .where(project_id: project_ids)
                                      .where("start_date BETWEEN ? AND ? AND due_date BETWEEN ? AND ?", @from, @to, @from, @to)
                                      .sum(:estimated_hours)
                                      .round(2)
  
            unless unique_users.include?(user.id)
              total_unique_planned_hours += user_planned_hours
              unique_users.add(user.id)
            end
  
            team_planned_hours += user_planned_hours
          end
  
          teams_data << {
            team_name: team.name,
            team_id: team.id,
            planned_hours: team_planned_hours.round(2)
          }
        end
  
        @total_unique_planned_hours = total_unique_planned_hours.round(2)
        @data = teams_data
  
      elsif filter_by == 'user'
        users_data = []
  
        @users = if user_ids.present?
                   User.active.where(id: user_ids)
                 else
                   User.active
                 end
  
        closed_status_ids = IssueStatus.where(is_closed: true).pluck(:id)
        project_ids = Project.where(status: [1, 5]).pluck(:id)
  
        @users.each do |user|
          total_planned_hours = Issue.where(assigned_to_id: user.id)
                                     .where.not(status_id: closed_status_ids)
                                     .where(project_id: project_ids)
                                     .where("start_date BETWEEN ? AND ? AND due_date BETWEEN ? AND ?", @from, @to, @from, @to)
                                     .sum(:estimated_hours)
                                     .round(2)
  
          users_data << {
            user_name: user.name,
            user_id: user.id,
            planned_hours: total_planned_hours.round(2)
          }
        end
  
        @total_unique_planned_hours = users_data.sum { |data_item| data_item[:planned_hours] }.round(2)
        @data = users_data
      end
    else
      @no_selection_message = "No teams or users selected yet."
    end
  
    respond_to do |format|
      format.html { render partial: 'planned_hours_chart_show' }
    end
  end
  
  def available_hours_chart_data
    start_date = params[:startDate]
    end_date = params[:endDate]
    filter_by = params[:filterBy] || 'team'
    team_ids = params[:teams]
    user_ids = params[:users]
  
    if start_date.present? && end_date.present?
      @from, @to = start_date.to_date, end_date.to_date
    else
      @from ||= Date.today.beginning_of_month
      @to ||= Date.today.end_of_month
    end
  
    closed_status_ids = IssueStatus.where(is_closed: true).pluck(:id)
    project_ids = Project.where(status: [1, 5]).pluck(:id)
  
    if team_ids.present? || user_ids.present?
      if filter_by == 'team'
        teams_data = []
        total_unique_available_hours = 0.0
        unique_users = Set.new
  
        @teams = team_ids.present? ? WorkloadTeam.where(id: team_ids) : WorkloadTeam.all
  
        @teams.each do |team|
          total_team_available_hours = 0.0
          total_team_planned_hours = 0.0
  
          member_ids = TeamMembers.where(group_id: team.id).pluck(:member_id).uniq
          @users = User.active.where(id: member_ids)
  
          @users.each do |user|
            user_planned_hours = Issue.where(assigned_to_id: user.id)
                                      .where.not(status_id: closed_status_ids)
                                      .where(project_id: project_ids)
                                      .where("start_date BETWEEN ? AND ? AND due_date BETWEEN ? AND ?", @from, @to, @from, @to)
                                      .sum(:estimated_hours)
                                      .round(2)
  
            total_workload_hours = total_workload(user.id, @from, @to).values.sum
            user_available_hours = total_workload_hours - user_planned_hours
  
            total_team_planned_hours += user_planned_hours
            total_team_available_hours += user_available_hours
  
            unless unique_users.include?(user.id)
              total_unique_available_hours += user_available_hours
              unique_users.add(user.id)
            end
          end
  
          teams_data << {
            team_name: team.name,
            team_id: team.id,
            available_hours: total_team_available_hours.round(2)
          }
        end
  
        @total_unique_available_hours = total_unique_available_hours.round(2)
        @data = teams_data
  
      elsif filter_by == 'user'
        users_data = []
        total_all_users_available_hours = 0.0
  
        @users = if user_ids.present?
                   User.active.where(id: user_ids)
                 else
                   User.active
                 end
  
        @users.each do |user|
          user_planned_hours = Issue.where(assigned_to_id: user.id)
                                    .where.not(status_id: closed_status_ids)
                                    .where(project_id: project_ids)
                                    .where("start_date BETWEEN ? AND ? AND due_date BETWEEN ? AND ?", @from, @to, @from, @to)
                                    .sum(:estimated_hours)
                                    .round(2)
  
          total_workload_hours = total_workload(user.id, @from, @to).values.sum
          user_available_hours = total_workload_hours - user_planned_hours
  
          total_all_users_available_hours += user_available_hours
  
          users_data << {
            user_name: user.name,
            user_id: user.id,
            available_hours: user_available_hours.round(2)
          }
        end
  
        @data = users_data
        @total_all_users_available_hours = total_all_users_available_hours.round(2)
      end
    else
      @no_selection_message = "No teams or users selected yet."
    end
  
    respond_to do |format|
      format.html { render partial: 'available_hours_chart_show' }
    end
  end
  

  def team_hours_data
    start_date = params[:startDate]
    end_date = params[:endDate]
    filter_by = params[:filterBy] || 'team'
    team_ids = params[:teams]
    user_ids = params[:users]
  
    if start_date.present? && end_date.present?
      @from, @to = start_date.to_date, end_date.to_date
    else
      @from ||= Date.today.beginning_of_month
      @to ||= Date.today.end_of_month
    end
  
    if team_ids.blank? && user_ids.blank?
      @no_selection_message = "No teams or users selected yet"
    else
      data = []
  
      if filter_by == 'team'
        unique_users = Set.new
        total_unique_planned_hours = 0.0
        total_unique_available_hours = 0.0
        @teams = team_ids.present? ? WorkloadTeam.where(id: team_ids) : WorkloadTeam.all
  
        @teams.each do |team|
          total_team_planned_hours = 0.0
          total_team_hours = 0.0
  
          member_ids = TeamMembers.where(group_id: team.id).pluck(:member_id).uniq
          @users = User.active.where(id: member_ids)
          closed_status_ids = IssueStatus.where(is_closed: true).pluck(:id)
          project_ids = Project.where(status: [1, 5]).pluck(:id)
  
          @users.each do |user|
            total_planned_hours = Issue.where(assigned_to_id: user.id)
                                       .where.not(status_id: closed_status_ids)
                                       .where(project_id: project_ids)
                                       .where("start_date BETWEEN ? AND ? AND due_date BETWEEN ? AND ?", @from, @to, @from, @to)
                                       .sum(:estimated_hours)
                                       .round(2)
  
            total_workload = total_workload(user.id, @from, @to)
            total_hours = total_workload.values.sum.round(2)
            total_available_hours = total_hours - total_planned_hours
  
            total_team_planned_hours += total_planned_hours
            total_team_hours += total_hours
  
            unless unique_users.include?(user.id)
              total_unique_planned_hours += total_planned_hours
              total_unique_available_hours += total_available_hours
              unique_users.add(user.id)
            end
          end
  
          total_team_available_hours = total_team_hours - total_team_planned_hours
  
          data << {
            team_name: team.name,
            team_id: team.id,
            planned_hours: total_team_planned_hours.round(2),
            available_hours: total_team_available_hours.round(2),
            time_variance: total_team_planned_hours.zero? ? 0 : ((total_team_planned_hours - total_team_available_hours) / total_team_planned_hours * 100).round(2)
          }
        end
  
        @total_unique_planned_hours = total_unique_planned_hours.round(2)
        @total_unique_available_hours = total_unique_available_hours.round(2)
  
      elsif filter_by == 'user'
        @users = if user_ids.present?
                   User.active.where(id: user_ids)
                 else
                   User.active
                 end
  
        total_user_planned_hours = 0.0
        total_user_available_hours = 0.0
  
        closed_status_ids = IssueStatus.where(is_closed: true).pluck(:id)
        project_ids = Project.where(status: [1, 5]).pluck(:id)
  
        @users.each do |user|
          total_planned_hours = Issue.where(assigned_to_id: user.id)
                                     .where.not(status_id: closed_status_ids)
                                     .where(project_id: project_ids)
                                     .where("start_date BETWEEN ? AND ? AND due_date BETWEEN ? AND ?", @from, @to, @from, @to)
                                     .sum(:estimated_hours)
                                     .round(2)
  
          total_workload = total_workload(user.id, @from, @to)
          total_hours = total_workload.values.sum.round(2)
          total_available_hours = total_hours - total_planned_hours
  
          total_user_planned_hours += total_planned_hours
          total_user_available_hours += total_available_hours
  
          data << {
            user_name: user.name,
            user_id: user.id,
            planned_hours: total_planned_hours.round(2),
            available_hours: total_available_hours.round(2),
            time_variance: total_planned_hours.zero? ? 0 : ((total_planned_hours - total_available_hours) / total_planned_hours * 100).round(2)
          }
        end
  
        @total_unique_planned_hours = total_user_planned_hours.round(2)
        @total_unique_available_hours = total_user_available_hours.round(2)
      end
  
      @data = data
    end
  
    respond_to do |format|
      format.html { render partial: 'team_hours_table' }
    end
  end
  
  

  def workload_user_data
    @team = WorkloadTeam.find(params[:team_id])
    @team_name = @team.name
    @from ||= Date.today.beginning_of_month
    @to ||= Date.today.end_of_month
  
    member_ids = TeamMembers.where(group_id: @team.id).pluck(:member_id)
  
    user_data = member_ids.map do |member_id|
      total_planned_hours = 0.0
      total_available_hours = 0.0
  
      issues = Issue.where(assigned_to_id: member_id).where.not(start_date: nil)
  
      (@from..@to).each do |date|
        total_estimated_hours = 0.0
  
        issues.each do |task|
          start_date = task.start_date
          due_date = task.due_date || start_date
          start_date, due_date = [start_date, due_date].minmax
          total_days = (start_date..due_date).count { |d| (1..5).include?(d.wday) && d.wday != 6 && d.wday != 0 }
  
          estimated_hours = task.estimated_hours
          next unless estimated_hours.present? && total_days > 0
  
          per_day_estimation = estimated_hours / total_days
  
          if date.between?(start_date, due_date) && (1..5).include?(date.wday)
            total_estimated_hours += per_day_estimation
          end
        end
  
        total_planned_hours += total_estimated_hours
      end
  
      total_workload = total_workload(member_id, @from, @to)
      total_available_hours = total_workload.values.sum.round(2) - total_planned_hours
  
      {
        user_name: User.find(member_id).name, 
        planned_hours: total_planned_hours.round(2),
        available_hours: total_available_hours.round(2)
      }
    end
  
    @users_data = user_data
  
    respond_to do |format|
      format.html { render partial: 'workload_users_data', locals: { team_name: @team_name , from: @from, to: @to }} 
    end
  end


  def save_filter_data
    filter_by = params[:filterBy]
    team_ids = params[:teams] || ""
    user_ids = params[:users] || ""
    start_date = params[:startDate]
    end_date = params[:endDate]

    filter = WorkloadReportFilter.first_or_initialize
    filter.update(
      filter_by: filter_by,
      team_ids: team_ids,
      user_ids: user_ids,
      start_date: start_date,
      end_date: end_date
    )

    render json: { success: true }
  end

  def get_filter_data
    filter = WorkloadReportFilter.first
    render json: filter
  end


  private
  
  
    def total_workload(user, from, to)
      @workload_scheme = WorkloadScheme.where(:user_id => user).pluck(:user_workload_id) 
      @available_hours = UserWorkload.where(:id => @workload_scheme).pluck(:wd0, :wd1, :wd2, :wd3, :wd4, :wd5, :wd6)
      @holiday_ids = HolidayScheme.where(user_id: user).pluck(:user_holiday_id)
      holiday_dates = HolidayDate.where(user_holiday_id: @holiday_ids).pluck(:start_date, :end_date).map do |start_date, end_date|
        end_date ||= start_date
        [start_date, end_date]
      end  
      
      weekly_workload = {}
      occurrences = Hash.new { |hash, key| hash[key] = Hash.new(0) }
      
      (from..to).each do |date|
        is_holiday = holiday_dates.any? { |start_date, end_date| (start_date..end_date).cover?(date) }
        unless is_holiday
          week_number = date.strftime("%W").to_i
          occurrences[week_number][date.strftime("%A")] += 1
        end
      end
      occurrences.each do |week_number, days|
        total_workload = 0
        days.each do |day, count|
          wd_index = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"].index(day)
          total_workload += @available_hours.sum { |wd| wd[wd_index] } * count
        end
        weekly_workload[week_number] = total_workload.round(2)
      end
      return weekly_workload
  end 

  def fetch_team_data_and_users
    if User.current.admin?
      team_data = WorkloadTeam.all.select(:id, :name)
      team_ids = team_data.pluck(:id)
      active_users = User.active.order("firstname ASC, lastname ASC")
    elsif team_member_manage_workload_permission?
      team_ids = TeamMember.where(member_id: User.current.id).pluck(:group_id)
      team_data = WorkloadTeam.where(id: team_ids).select(:id, :name)
      team_member_ids = TeamMember.where(group_id: team_ids).pluck(:member_id).uniq
      active_users = User.where(id: team_member_ids).order("firstname ASC, lastname ASC")
    else
      team_data = []
      active_users = User.where(id: User.current.id).order("firstname ASC, lastname ASC")
    end
  
    [team_data, active_users]
  end
  
  def team_member_manage_workload_permission?
    TeamMember.where(member_id: User.current.id).exists? && @permission[:manage_workload]
  end

end
