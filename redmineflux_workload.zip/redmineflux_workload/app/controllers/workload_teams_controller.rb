class WorkloadTeamsController < ApplicationController
  accept_api_auth :delete_team_data, :team_search_data ,:teams_data, :delete_bulk_teams, :update,:skills_data, :team_preferences, :selected_teams, :users_team_data, :delete_multiple_team, :user_data,:user_preferences,:delete_multiple_users, :users_with_teams, :delete_user_from_team
 

  def index
    @teams = WorkloadTeam.all
    @team = WorkloadTeam.new

  end

  def create
    @team = WorkloadTeam.create(params.require(:workload_team).permit(:name))
  
    if @team.valid?
      @team.save
      redirect_to workload_teams_path
      flash[:notice] = "Successfully Created"
    elsif @team.errors.any?
      @team.errors.full_messages.each do |message|
        flash[:error] = message
      end
      redirect_to workload_teams_path
    else
      flash[:error] = "Team name is already taken"
      redirect_to workload_teams_path
    end
   
  end
  def edit
    # if (User.current.allowed_to?(:manage_workload, @project)) || (User.current.admin?) 
      @team = WorkloadTeam.find(params[:id])
      @available_users = available_users_for_group(@team)
    # else  
    #   flash[:error] = "You are not authorized"
    #   redirect_to :back
    # end 
  end

  def destroy
    if (User.current.allowed_to?(:manage_workload, User.current.projects.to_a)) || (User.current.admin?) 
      @team = WorkloadTeam.find(params[:id])
      @members = TeamMembers.where(group_id: params[:id])
      @team.destroy
      @members.destroy_all

      redirect_to workload_teams_path
    else  
      flash[:error] = "You are not authorized"
      redirect_to :back
    end 
  
  end
  def update
    @team = WorkloadTeam.find(params[:id])
    if @team.update(name:params[:name])
      flash[:notice] = "Successfully Updated"
    elsif @team.errors.any?
      @team.errors.full_messages.each do |message|
        flash[:error] = message
       
      end
    else
      flash[:error] = "Team name is already taken"
    #  render action: 'index'
    end
    render :json =>  @team
    respond_to do |format|
      format.html
      format.api do
        @team
      end
    end
   end


  def delete_team_data
    if (User.current.allowed_to?(:manage_workload, User.current.projects.to_a)) || (User.current.admin?) 
      @team_data = TeamMember.where(id: params[:delete_id].split(',').map(&:to_i))
      @team_data.destroy_all
      
      render :json =>  @team_data
      respond_to do |format|
        format.html
        format.api do
          @team_data
        end
      end
    else 
      flash[:error] = "You are not authorized"
      redirect_to :back
    end 
  end
   
  def team_search_data
    
  @permission = {}
  roles = User.current.roles.to_a
  @permission[:manage_workload] = roles.any? { |role| role.permissions.include?(:manage_workload) }  
  @team_data=[]
  if User.current.admin?
    @team_data = WorkloadTeam.all.select(:id, :name)
  elsif TeamMember.where(member_id: User.current.id).exists? && @permission[:manage_workload]
    team_ids = TeamMember.where(member_id: User.current.id).pluck(:group_id)
    @team_data = WorkloadTeam.where(id: team_ids).select(:id, :name)
  end

   render :json =>  @team_data
      respond_to do |format|
        format.html
        format.api do
          @team_data
        end
      end
  end



  def user_preferences
    if params[:selected_user_ids].present? && params[:user_id].present?
      # Convert the string representation of the array to an actual array
      selected_user_ids = JSON.parse(params[:selected_user_ids])
      user_id = params[:user_id]
        # Initialize an array to store success messages
      success_messages = []
      # Add new TeamPreferences records
      selected_user_ids.each do |member|
        existing_user_preference = TeamPreferences.find_or_initialize_by(selected_user_ids: member, user_id: user_id)
        # puts "check existing user preference #{existing_user_preference}"
        if existing_user_preference.persisted?
          success_messages << "User id #{member} already exists for user #{user_id}"
        elsif existing_user_preference.save
          success_messages << "Member with User_id #{member} was successfully added"
        end
      end
      
      respond_to do |format|
        format.html
        format.api do
          if success_messages.present?
            render json: { success: success_messages }, status: :ok
          else
            render json: { notice: "No new members added" }, status: :ok
          end
        end
      end
    else
      respond_to do |format|
        format.html { redirect_to some_path } # Replace with the appropriate URL
        format.api { render json: { error: "No User ID or user ID provided" }, status: :unprocessable_entity }
      end
    end
  end

  def users_team_data
    if params[:id].present? && params[:start_date].present? && params[:due_date].present?
      @start_date = Date.parse(params[:start_date])
      @due_date = Date.parse(params[:due_date])
  
      team_ids = JSON.parse(params[:id])
      @members = TeamMember.where(group_id: team_ids).pluck(:member_id).uniq
      if @members.present?
        @workload_data = {}
        @group_users = User.active.where(id: @members).order(:firstname, :lastname, :id).paginate(page: params[:page], per_page: params[:per_page])
    
     
        project_ids = Project.where(status: [1, 5]).pluck(:id)
        closed_status_id = IssueStatus.where(is_closed: true).pluck(:id)
        @issues = Issue.where(assigned_to_id:  @group_users.ids).where.not(status_id: closed_status_id)
                        .where(project_id: project_ids)
                        .where("#{Issue.table_name}.start_date BETWEEN ? AND ? AND #{Issue.table_name}.due_date BETWEEN ? AND ?",
                               @start_date, @due_date, @start_date, @due_date)
                   
  
        @data = @group_users.map do |user|
          @workload_ids = WorkloadScheme.where(user_id: user.id).pluck(:user_workload_id)
          @holiday_ids = HolidayScheme.where(user_id: user.id).pluck(:user_holiday_id)
          wd_values = UserWorkload.where(id: @workload_ids).pluck(:wd0, :wd1, :wd2, :wd3, :wd4, :wd5, :wd6)
          hd_values = HolidayDate.where(user_holiday_id: @holiday_ids).pluck(:start_date, :end_date).map do |start_date, end_date|
            end_date ||= start_date
            [start_date, end_date]
          end  
  
          occurrences = Hash.new(0)
          (@start_date..@due_date).each do |date|
            is_holiday = hd_values.any? { |start_date, end_date| (start_date..end_date).cover?(date) }
            unless is_holiday
              occurrences[date.strftime("%A")] += 1
            end
          end
  
          total_workload = 0
          occurrences.each do |day, count|
            wd_index = %w[Sunday Monday Tuesday Wednesday Thursday Friday Saturday].index(day)
            total_workload += wd_values.sum { |wd| wd[wd_index] } * count
          end
  
          {available_hours: (total_workload - @issues.where(assigned_to_id: user.id).sum(:estimated_hours)).round(2),total: total_workload.round(2),wk_scheme: user_workload_scheme(user.id),holiday: user_holiday_scheme(user.id),id: user.id,color: user.color,parent: 0,text: "#{user.firstname} #{user.lastname}",row_height: 50,bar_height: 40,type: "project",user_id: user.id,login: user.login,firstname: user.firstname,lastname: user.lastname,admin: user.admin,created_on: user.created_on,updated_on: user.updated_on,issues: @issues.where(assigned_to_id: user.id),estimated_hours: @issues.where(assigned_to_id: user.id).sum(:estimated_hours).round(2)}end + @issues.map do |issue|{id: "i#{issue.id}",holiday: user_holiday_scheme(issue.assigned_to_id),tracker: issue.tracker,project: issue.project,subject: issue.subject,description: issue.description, distribution:issue.distribution, workhours: user_workload(issue.id,issue.start_date,issue.due_date), due_date: issue.due_date,category_id: issue.category,status_id: issue.status,assigned_to_id: issue.assigned_to_id,wk_scheme: user_workload_scheme(issue.assigned_to_id),assigned_to: issue.assigned_to.name,s_date: issue.start_date,parent: issue.assigned_to_id,priority_id: issue.priority_id,fixed_version_id: issue.fixed_version_id,author_id: issue.author_id,lock_version: issue.lock_version,row_height: 50,bar_height: 40,text: issue.subject,created_on: issue.created_on,updated_on: issue.updated_on,start_date: issue.start_date,done_ratio: issue.done_ratio,end_date: issue.due_date,estimated_hours: issue.estimated_hours.present? ? issue.estimated_hours.round(2) : 0,parent_id: issue.parent_id,root_id: issue.root_id,lft: issue.lft,rgt: issue.rgt,type: "issue",subtask_parent: @issues.where(parent_id: issue.id).select(:id),is_private: issue.is_private,closed_on: issue.closed_on}end

  
        @workload_data[:data] = @data
        @workload_data[:users] = @group_users
  
        render json: { data: @workload_data[:data], users: @workload_data[:users], pagination: { total_pages: @group_users.total_pages, total_entries: @group_users.total_entries } }
      else
        render json: { data: [], users: [], issues: [] }
      end
    else
      render json: :unprocessable_entity, status: 404
    end
  end
  

  def user_workload(issueid,start_date,due_date)
    if issueid.present?
      workhours=Workhour.where(:issue_id => issueid).where(:date => start_date..due_date)
       return workhours
    end
  end


def user_workload_scheme(user)
  if user.present? 
    wk_scheme = WorkloadScheme.where(:user_id => user).pluck(:user_workload_id).uniq
    users_scheme = UserWorkload.where(:id => wk_scheme)

    return users_scheme
    render :json => users_scheme
  end 

end 

# def user_holiday_scheme(user)
#   if user.present? 
#     id = HolidayScheme.where(:user_id => user).pluck(:user_holiday_id).uniq
#     @holiday = UserHoliday.where(:id => id)
#     @holiday_scheme = @holiday.map{|h| {:id => h.id, :name => h.name, :description=> h.description, :created_at=>h.created_at, :updated_at =>h.updated_at, :dates => h.holiday_dates }}
#   end 
# end 
def user_holiday_scheme(user)
  if user.present?
    id = HolidayScheme.where(user_id: user).pluck(:user_holiday_id).uniq
    @holiday = UserHoliday.where(id: id)
    @holiday_scheme = @holiday.map do |h|
      dates = h.holiday_dates.map do |date|
        {
          id: date.id,
          name: date.name,
          description: date.description,
          created_at: date.created_at,
          updated_at: date.updated_at,
          start_date: date.start_date,
          end_date: date.end_date || date.start_date,
          date_range: (date.start_date..(date.end_date || date.start_date)).to_a.map(&:to_s),
          user_holiday_id: date.user_holiday_id
        }
      end
      {
        id: h.id,
        name: h.name,
        description: h.description,
        created_at: h.created_at,
        updated_at: h.updated_at,
        dates: dates
      }
    end
  end
end


def get_dates
  current_day = Date.today
  @period_start = current_day.beginning_of_month
  @period_end = current_day.end_of_month
end
def delete_bulk_teams
  if (User.current.allowed_to?(:manage_workload, User.current.projects.to_a)) || (User.current.admin?) 
    @team = WorkloadTeam.where(id: params[:id].split(',').map(&:to_i))
    @members = TeamMembers.where(group_id: params[:id].split(',').map(&:to_i))
    @team.destroy_all
    @members.destroy_all
    flash[:notice] = "Team deleted successfully."
    render :json => @members
    respond_to do |format|
      format.html
      format.api do
        @workload_data
      end
    end
  else  
    flash[:error] = "You are not authorized"
    redirect_to :back
  end 

end
def teams_data
  @workload_data =  WorkloadTeam.where(id: params[:id])
  render :json => @workload_data
  respond_to do |format|
    format.html
    format.api do
      @workload_data
    end
  end
end
def skills_data
  @users = {}
  if params[:group_id].present?
    # member_id = JSON.parse(params[:member_id])
    group_id = params[:group_id]
    @group_users = TeamMember.where(:group_id => group_id).map(&:member_id).flatten.uniq
    @members = User.order(:firstname).where(:id => @group_users).map{|f| {:id => f.id, :name => f.firstname + " " + f.lastname, :combine => TeamMember.where(:member_id => f.id, :group_id => group_id).map{|t| {:id => t.id ,:skills => t.skills , :role => Role.where(id: t.role_id).pluck(:name).join, :commitment => t.commitment, :joining_date => t.joining_date, :leaving_date => t.leaving_date}}}}
  @users[:data] = @members
  render :json => @users
        respond_to do |format|
          format.html
          format.api do
            @users
          end 
        end
      end
end

def team_preferences

  if params[:team_id].present? && params[:user_id].present?
    # Convert the string representation of the array to an actual array
    new_team_ids = JSON.parse(params[:team_id])
    user_id = params[:user_id]
    # Initialize an array to store success messages
    success_messages = []
    # Add new TeamPreferences records
    new_team_ids.each do |member|
      existing_team_preference = TeamPreferences.find_or_initialize_by(team_id: member, user_id: user_id)
      
      if existing_team_preference.persisted?
        success_messages << "Team id #{member} already exists for user #{user_id}"
      elsif existing_team_preference.save
        success_messages << "Member with team_id #{member} was successfully added"
      end
    end
    
    respond_to do |format|
      format.html
      format.api do
        if success_messages.present?
          render json: { success: success_messages }, status: :ok
        else
          render json: { notice: "No new members added" }, status: :ok
        end
      end
    end
  else
    respond_to do |format|
      format.html { redirect_to some_path } # Replace with the appropriate URL
      format.api { render json: { error: "No team ID or user ID provided" }, status: :unprocessable_entity }
    end
  end
end

def delete_multiple_users
  # if params[:user_id].present? && params[:selected_user_ids].present?
  if params[:user_id].present?
    user_id=params[:user_id]
    # selected_user_ids=params[:selected_user_ids]
    # deleteuser=TeamPreferences.where(user_id: user_id, selected_user_ids: selected_user_ids).destroy_all
    deleteuser=TeamPreferences.where(user_id: user_id).destroy_all
      render json: {success: deleteuser}, status: :ok
  end
end

def delete_multiple_team
  if params[:team_id].present? && params[:user_id].present?
    team_id=params[:team_id]
    user_id=params[:user_id]
    deleteteam=TeamPreferences.where(user_id: user_id, team_id: team_id).destroy_all
      render json: {success: deleteteam}, status: :ok
  end
end

def selected_teams
   @team_preferences = TeamPreferences.where(user_id: User.current.id)
  # @team_preferences = TeamPreferences.where(user_id: User.current.id).where.not(team_id: nil)
  render :json => @team_preferences
  respond_to do |format|
    format.html
    format.api do
      @team_preferences
    end 
  end
end

def users_with_teams
  @teams = WorkloadTeam.all
  @team = params[:team].presence || "All Teams"
  search_query = params[:search].presence || ""

  if @team == "All Teams"
    group_ids = WorkloadTeam.all.pluck(:id)
    group_users = TeamMember.where(group_id: group_ids).pluck(:member_id).uniq
    users_query = User.active.where(id: group_users).order(:firstname)
  else
    @selected_team_id = params[:team]
    team = WorkloadTeam.find_by(name: @team)
    team_users = TeamMember.where(group_id: team.id).pluck(:member_id).uniq
    users_query = User.active.where(id: team_users).order(:firstname)
  end
  if search_query.present?
    users_query = users_query.where(
      Arel::Nodes::NamedFunction.new('LOWER', [User.arel_table[:firstname]])
        .concat(Arel::Nodes.build_quoted(' '))
        .concat(Arel::Nodes::NamedFunction.new('LOWER', [User.arel_table[:lastname]]))
        .matches("%#{search_query.downcase}%")
    )
  end
  @paginated_users =users_query.paginate(page: params[:page], per_page: 25)
  @users_with_teams = @paginated_users.map do |user|
    {
      id: user.id,
      name: "#{user.firstname} #{user.lastname}",
      teams: TeamMember.where(member_id: user.id, group_id: @team == "All Teams" ? group_ids : [team.id])
                       .map { |team_member| WorkloadTeam.find(team_member.group_id) }
    }
  end
  respond_to do |format|
    format.html
    format.json { render json: { users: @users_with_teams, pagination: pagination_details } }
  end
end



def user_data
  
  if params[:start_date].blank? || params[:due_date].blank?
    render json: { error: "Start date and due date must be present" }, status: :unprocessable_entity
      return
  end

  if params[:start_date].present? && params[:due_date].present?
     date_format = /\A\d{4}-\d{2}-\d{2}\z/
    
     if params[:start_date].match(date_format).nil? || params[:due_date].match(date_format).nil?
      render json: { error: "Invalid date format" }, status: :unprocessable_entity
      return
    end

    if params[:id].present?
      begin
        @user_ids = JSON.parse(params[:id])
      rescue JSON::ParserError
        render json: { error: "Invalid user ID format" }, status: :unprocessable_entity
        return
      end
    else
      @user_ids = [User.current.id]
    end

    unless @user_ids.is_a?(Array) && @user_ids.all? { |id| id.is_a?(Integer) }
      render json: { error: "User IDs must be an array of integers" }, status: :unprocessable_entity
      return
    end
  
    valid_user_ids = User.where(id: @user_ids, status: 1, type: "User").pluck(:id)
    invalid_user_ids = @user_ids - valid_user_ids
  
    if invalid_user_ids.any?
      render json: { error: "Invalid users: #{invalid_user_ids.join(', ')}" }, status: :unprocessable_entity
      return
    end

    @start_date = Date.parse(params[:start_date])
    @due_date = Date.parse(params[:due_date])


    if @user_ids.present?
      @workload_data = {}
      @users = User.where(id: @user_ids, status: 1, type: "User")

      project_ids =  Project.where(status: [1, 5]).pluck(:id)
      @all_issues = Issue.where(project_id: project_ids, assigned_to_id: @users)

      closed_status_id = IssueStatus.where(is_closed: true).pluck(:id)
      @issues = Issue.where(assigned_to_id: @user_ids)
                     .where.not(status_id: closed_status_id)
                     .where(project_id: project_ids)
                     .where("(#{Issue.table_name}.start_date BETWEEN ? AND ?) AND (#{Issue.table_name}.due_date BETWEEN ? AND ?)",
                            @start_date, @due_date, @start_date, @due_date)
                

      @data = @users.map do |user|
        @workload_ids = WorkloadScheme.where(user_id: user.id).pluck(:user_workload_id)
        @holiday_ids = HolidayScheme.where(user_id: user.id).pluck(:user_holiday_id)
        wd_values = UserWorkload.where(id: @workload_ids).pluck(:wd0, :wd1, :wd2, :wd3, :wd4, :wd5, :wd6)
        hd_values = HolidayDate.where(user_holiday_id: @holiday_ids).pluck(:start_date, :end_date).map do |start_date, end_date|
          end_date ||= start_date
          [start_date, end_date]
        end  

        total_workload = 0


        occurrences = Hash.new(0)
        (@start_date..@due_date).each do |date|
          is_holiday = hd_values.any? { |start_date, end_date| (start_date..end_date).cover?(date) }
          unless is_holiday
            occurrences[date.strftime("%A")] += 1
          end
        end

        occurrences.each do |day, count|
          wd_index = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"].index(day)
          total_workload += wd_values.sum { |wd| wd[wd_index] } * count
        end

        available_hours = (total_workload - @issues.where(assigned_to_id: user.id).sum(:estimated_hours).round(2)).round(2)

        {available_hours: available_hours, total: total_workload.round(2), wk_scheme: user_workload_scheme(user.id), holiday: user_holiday_scheme(user.id), id: user.id, color: user.color, parent: 0, skills: TeamMember.where(member_id: user.id).pluck(:skills).flatten.uniq.map { |s| s.split(',') }.flatten.uniq, text: "#{user.firstname} #{user.lastname}", row_height: 50, bar_height: 40, type: "project", user_id: user.id, login: user.login, firstname: user.firstname, lastname: user.lastname, admin: user.admin, created_on: user.created_on, updated_on: user.updated_on, issues: @issues.where(assigned_to_id: user.id), estimated_hours: @issues.where(assigned_to_id: user.id).sum(:estimated_hours).round(2) } end

      @data += @issues.map do |issue|
        { id: "i#{issue.id}", holiday: user_holiday_scheme(issue.assigned_to_id), tracker: issue.tracker, project: issue.project, subject: issue.subject, description: issue.description, due_date: issue.due_date, category_id: issue.category, status_id: issue.status, wk_scheme: user_workload_scheme(issue.assigned_to_id), assigned_to_id: issue.assigned_to_id, assigned_to: User.find_by_id(issue.assigned_to_id).try(:name), s_date: issue.start_date, parent: issue.assigned_to_id, priority_id: issue.priority_id, fixed_version_id: issue.fixed_version_id, author_id: issue.author_id, lock_version: issue.lock_version, row_height: 50, bar_height: 40, text: issue.subject, created_on: issue.created_on, updated_on: issue.updated_on, start_date: issue.start_date, done_ratio: issue.done_ratio, end_date: issue.due_date, estimated_hours: issue.estimated_hours.present? ? issue.estimated_hours.round(2) : 0, parent_id: issue.parent_id, root_id: issue.root_id, lft: issue.lft, distribution:issue.distribution, workhours: user_workload(issue.id,issue.start_date,issue.due_date), rgt: issue.rgt, type: "issue", subtask_parent: @issues.where(parent_id: issue.id).select(:id), is_private: issue.is_private, closed_on: issue.closed_on}
      end

      @workload_data[:data] = @data
      @workload_data[:users] = @users



      render json: @workload_data
    else
      render json: { error: "No user IDs provided" }, status: :unprocessable_entity
    end
  else
    render json: { error: "Start date and due date must be present" }, status: :unprocessable_entity
  end

end


  def delete_user_from_team
    if (User.current.allowed_to?(:manage_workload, User.current.projects.to_a)) || (User.current.admin?)
      if params[:user_id].present? && params[:team_id].present?
        @user_id = params[:user_id]
        @group_id = params[:team_id]
        @team = TeamMember.where(member_id: @user_id, group_id: @group_id).first
        if @team.present?
          @team.destroy
          render json: { notice: 'Successfully deleted.' }, status: :ok
        else
          render json: { error: 'Team not found.' }, status: :not_found
        end
      end
    else
      render json: { error: 'You are not authorized.' }, status: :forbidden
    end
  end



private

def pagination_details
  {
    current_page: @paginated_users.current_page,
    total_pages: @paginated_users.total_pages,
    next_page: @paginated_users.next_page,
    prev_page: @paginated_users.current_page > 1 ? @paginated_users.current_page-1 : nil,
    total_count: @paginated_users.total_entries
  }
end

def available_users_for_group(group_id)
  existing_member_ids = TeamMember.where(group_id: group_id).pluck(:member_id)
  if existing_member_ids.any?
    User.where.not(id: existing_member_ids).order(:firstname).where(status: 1)
  else
    User.order(:firstname).where(status: 1)
  end
end


end
