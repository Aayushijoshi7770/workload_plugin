class WorkloadApisController < ApplicationController
  before_action :get_dates
  accept_api_auth :user_issues_with_period, :search_group_users, :search_group_issues ,:unassigned_issues, :search_unassigned_issues, :users_projects, :search_users_projects, :user_issues , :skills_of_users , :update_members,:members_api,:search_members,:update_edit_members,:create


  # def user_issues_with_period
  #   if params[:start_date] && params[:due_date].present?
  #     # take start date and end date parameter
  #       @start_date = params[:start_date]
  #       @due_date = params[:due_date]
  #       @user_id = User.current.id
  #       @workload_data = {}
  #       @user = User.where(:id =>  @user_id, :status=>1, :type=>"User")
  #       project_ids = User.where(:id => @user, :status=>1, :type=>"User").map{|f|f.projects.active.ids}.flatten
  #       @all_issues = Issue.where(project_id: project_ids).where(assigned_to_id: @user )
  #       # @group_issues = @all_issues.map{|f| { :id=>f.id,  :estimated_hours=>f.estimated_hours.present? ? f.estimated_hours.round(2) : 0, :project_name=>f.project.name ,  :text=>f.subject,  :project_id=>f.project.id, :due_date=>f.due_date, :start_date=>f.start_date, :s_date=>f.start_date, :row_height=>50, :bar_height=>40, :end_date=>f.due_date,  :subject=>f.subject,   :type=>"issue", :tracker => f.tracker}}
  #       closed_status_id = IssueStatus.where(is_closed: true).pluck(:id)
  #       @issues = Issue.where(:assigned_to_id =>  @user_id).where.not(status_id: closed_status_id).where(:project_id => project_ids).where("(#{Issue.table_name}.start_date BETWEEN ? AND ?) AND (#{Issue.table_name}.due_date BETWEEN ? AND ?)",  @start_date, @due_date, @start_date, @due_date).paginate(:page => params[:page], :per_page => params[:per_page])
  #       @data =  @user.map{ |f| 
  #         @workload_ids = WorkloadScheme.where(user_id: f.id).pluck(:user_workload_id)                              
  #         @holiday_ids = HolidayScheme.where(user_id: f.id).pluck(:user_holiday_id)
  #         wd_values = UserWorkload.where(id: @workload_ids).pluck(:wd0, :wd1, :wd2, :wd3, :wd4, :wd5, :wd6)
  #         hd_values = hd_values = HolidayDate.where(user_holiday_id: @holiday_ids).pluck(:date)
  #         total_workload = 0
  #         occurrences = Hash.new(0)
  #         (Date.parse(@start_date)..Date.parse(@due_date)).each do |date|
  #           unless hd_values.include?(date) # exclude dates that are holidays
  #             occurrences[date.strftime("%A")] += 1        
  #           end
  #         end
  #      occurrences.each do |day, count|
  #         wd_index = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"].index(day)
  #         total_workload += wd_values.sum { |wd| wd[wd_index] } * count
  #     end
  #     { available_hours: (total_workload - @issues.where(:assigned_to_id=>f.id).sum(:estimated_hours).round(2)).round(2), total: (total_workload).round(2),:wk_scheme => user_workload_scheme(f.id), :holiday=> user_holiday_scheme(f.id), :id => f.id, :color=>f.color,  :parent=>0,  :skills=> TeamMember.where(:member_id => f.id).pluck(:skills).flatten.uniq.map{|s|(s.split(",")).map{|i|i}}.flatten.uniq,  :text=> f.firstname + " " + f.lastname, :row_height=>50, :bar_height=>40, :type=>"project", :user_id=>f.id, :login => f.login ,  :firstname => f.firstname, :lastname => f.lastname, :admin => f.admin,:created_on => f.created_on ,  :updated_on => f.updated_on, :issues=>@issues.where(:assigned_to_id=>f.id), :estimated_hours => @issues.where(:assigned_to_id=>f.id).sum(:estimated_hours).round(2)}} + @issues.map{|f| {:id =>"i"+f.id.to_s,   :holiday=> user_holiday_scheme(f.assigned_to_id), :tracker => f.tracker,:project => f.project,:subject => f.subject,:description => f.description, :due_date => f.due_date, :category_id => f.category,:status_id => f.status, :wk_scheme => user_workload_scheme(f.assigned_to_id), :assigned_to_id => f.assigned_to_id, :assigned_to => User.find_by_id(f.assigned_to_id).firstname + " " + User.find_by_id(f.assigned_to_id).lastname, s_date: f.start_date, :parent=> f.assigned_to_id, :priority_id => f.priority_id, :fixed_version_id => f.fixed_version_id, :author_id => f.author_id,:lock_version => f.lock_version, :row_height=>50, :bar_height=>40,  :text=>f.subject, :created_on => f.created_on,:updated_on => f.updated_on, :start_date => f.start_date,:done_ratio => f.done_ratio, :end_date=>f.due_date, :estimated_hours =>f.estimated_hours.present? ? f.estimated_hours.round(2) : 0 , :parent_id => f.parent_id, :root_id => f.root_id, :lft => f.lft, :rgt => f.rgt, :type=>"issue", :subtask_parent => @issues.where(parent_id: f.id).select(:id), :is_private => f.is_private, :closed_on => f.closed_on}}
  #      @workload_data[:data] = @data
  #      @workload_data[:users] = @user
  #      if @issues.present?
  #       @workload_data[:pagination] = { total_pages: @issues.total_pages, total_entries: @issues.total_entries }
  #     else
  #       @workload_data[:pagination] = { total_pages: 0, total_entries: 0 }
  #     end
  #     #  @workload_data[:issues] = @group_issues  
  #       render :json => @workload_data
  #       respond_to do |format|
  #         format.html
  #           format.api do
  #             @workload_data
  #           end
  #         end
  #     end
  # end

  def user_issues_with_period
    if params[:start_date] && params[:due_date].present?
      @start_date = Date.parse(params[:start_date])
      @due_date = Date.parse(params[:due_date])
      @user_id = User.current.id
      @workload_data = {}
      @user = User.where(id: @user_id, status: 1, type: "User")
      project_ids = Project.where(status: [1, 5]).pluck(:id)
      @all_issues = Issue.where(project_id: project_ids, assigned_to_id: @user_id)
      closed_status_id = IssueStatus.where(is_closed: true).pluck(:id)
      @issues = Issue.where(assigned_to_id: @user_id).where.not(status_id: closed_status_id)
                     .where(project_id: project_ids)
                     .where("#{Issue.table_name}.start_date BETWEEN ? AND ? AND #{Issue.table_name}.due_date BETWEEN ? AND ?", @start_date, @due_date, @start_date, @due_date)
                     .paginate(page: params[:page], per_page: params[:per_page])
  
        @data = @user.map do |f|
        @workload_ids = WorkloadScheme.where(user_id: f.id).pluck(:user_workload_id)
        @holiday_ids = HolidayScheme.where(user_id: f.id).pluck(:user_holiday_id)
        wd_values = UserWorkload.where(id: @workload_ids).pluck(:wd0, :wd1, :wd2, :wd3, :wd4, :wd5, :wd6)
        hd_values = HolidayDate.where(user_holiday_id: @holiday_ids).pluck(:start_date, :end_date).map do |start_date, end_date|
          end_date ||= start_date
          [start_date, end_date]
        end  
  
        occurrences = Hash.new(0)
        (@start_date..@due_date).each do |date|
          is_holiday = hd_values.any? { |start_date, end_date| (start_date..end_date).cover?(date) }
          unless is_holiday
            occurrences[date.strftime("%A")] += 1
          end
        end
  
        total_workload = 0
        occurrences.each do |day, count|
          wd_index = %w[Sunday Monday Tuesday Wednesday Thursday Friday Saturday].index(day)
          total_workload += wd_values.sum { |wd| wd[wd_index] } * count
        end
       
  
        {available_hours: (total_workload - @issues.where(assigned_to_id: f.id).sum(:estimated_hours).round(2)).round(2),total: total_workload.round(2),wk_scheme: user_workload_scheme(f.id),holiday: user_holiday_scheme(f.id),id: f.id,color: f.color,parent: 0,skills: TeamMember.where(member_id: f.id).pluck(:skills).flatten.uniq.map { |s| s.split(",") }.flatten.uniq,text: "#{f.firstname} #{f.lastname}",row_height: 50,bar_height: 40,type: "project",user_id: f.id,login: f.login,firstname: f.firstname,lastname: f.lastname,admin: f.admin,created_on: f.created_on,updated_on: f.updated_on,issues: @issues.where(assigned_to_id: f.id),estimated_hours: @issues.where(assigned_to_id: f.id).sum(:estimated_hours).round(2)}end + @issues.map do |issue|{id: "i#{issue.id}",holiday: user_holiday_scheme(issue.assigned_to_id),tracker: issue.tracker,project: issue.project,subject: issue.subject, distribution:issue.distribution, workhours: user_workload(issue.id,issue.start_date,issue.due_date), description: issue.description,due_date: issue.due_date,category_id: issue.category,status_id: issue.status,wk_scheme: user_workload_scheme(issue.assigned_to_id),assigned_to_id: issue.assigned_to_id,assigned_to: "#{User.find_by_id(issue.assigned_to_id).firstname} #{User.find_by_id(issue.assigned_to_id).lastname}",s_date: issue.start_date,parent: issue.assigned_to_id,priority_id: issue.priority_id,fixed_version_id: issue.fixed_version_id,author_id: issue.author_id,lock_version: issue.lock_version,row_height: 50,bar_height: 40,text: issue.subject,created_on: issue.created_on,updated_on: issue.updated_on,start_date: issue.start_date,done_ratio: issue.done_ratio,end_date: issue.due_date,estimated_hours: issue.estimated_hours.present? ? issue.estimated_hours.round(2) : 0,parent_id: issue.parent_id,root_id: issue.root_id,lft: issue.lft,rgt: issue.rgt,type: "issue",subtask_parent: @issues.where(parent_id: issue.id).select(:id),is_private: issue.is_private,closed_on: issue.closed_on}
end
  
      @workload_data[:data] = @data
      @workload_data[:users] = @user
      @workload_data[:pagination] = if @issues.present?
                                      { total_pages: @issues.total_pages, total_entries: @issues.total_entries }
                                    else
                                      { total_pages: 0, total_entries: 0 }
                                    end
  
      render json: @workload_data
      respond_to do |format|
        format.html
        format.api { @workload_data }
      end
    end
  end

  def user_workload(issueid, start_date, due_date)
    if issueid.present? && start_date.present? && due_date.present?
      begin
        start_date = Date.parse(start_date.to_s)
        due_date = Date.parse(due_date.to_s)
        workhours = Workhour.where(issue_id: issueid).where(date: start_date..due_date)
        return workhours
      rescue ArgumentError => e
        Rails.logger.error "Invalid date format: #{e.message}"
        return []
      end
    else
      Rails.logger.error "Missing issueid, start_date, or due_date"
      return []
    end
  end

  def user_workload_scheme(user)
    if user.present? 
      wk_scheme = WorkloadScheme.where(:user_id => user).pluck(:user_workload_id).uniq
      users_scheme = UserWorkload.where(:id => wk_scheme)

      return users_scheme
      render :json => users_scheme
    end 
  end 

  # def user_holiday_scheme(user)
  #   if user.present? 
  #     id = HolidayScheme.where(:user_id => user).pluck(:user_holiday_id).uniq
  #     @holiday = UserHoliday.where(:id => id)
  #     @holiday_scheme = @holiday.map{|h| {:id => h.id, :name => h.name, :description=> h.description, :created_at=>h.created_at, :updated_at =>h.updated_at, :dates => h.holiday_dates }}
  #   end 
  # end 

  def user_holiday_scheme(user)
    if user.present?
      id = HolidayScheme.where(user_id: user).pluck(:user_holiday_id).uniq
      @holiday = UserHoliday.where(id: id)
      @holiday_scheme = @holiday.map do |h|
        dates = h.holiday_dates.map do |date|
          {
            id: date.id,
            name: date.name,
            description: date.description,
            created_at: date.created_at,
            updated_at: date.updated_at,
            start_date: date.start_date,
            end_date: date.end_date || date.start_date,
            date_range: (date.start_date..(date.end_date || date.start_date)).to_a.map(&:to_s),
            user_holiday_id: date.user_holiday_id
          }
        end
        {
          id: h.id,
          name: h.name,
          description: h.description,
          created_at: h.created_at,
          updated_at: h.updated_at,
          dates: dates
        }
      end
    end
  end


# Search API of users for a perticular group 

  def search_group_users
    team_id = params[:team_id] 
    if params[:name] && team_id.present?
      @parameter =   params[:name].downcase
      @member_ids = TeamMember.where(:group_id => team_id).map(&:member_id).flatten.uniq
      if @member_ids.present?
        scope = User.select("id, firstname, lastname, (firstname || ' ' || lastname) AS name").where(:id =>  @member_ids, :status => 1)
        @users = scope.like(@parameter)
        render :json =>   @users
        respond_to do |format|
          format.html 
          format.api do 
            @users
          end 
        end 
      else  
       return nil
      end 
    end 
    rescue ActiveRecord::RecordNotFound
    render 404
  end


# Search issues API for particular groups issues

  def search_group_issues
    @id = params[:user_id]
    @parameter  = params[:parameter]
    if @id.present? && @parameter.present? 
    str = @parameter.to_s
    closed_status_id = IssueStatus.where(is_closed: true).pluck(:id)
      respond_to do |format|
        if str =~ /\d/
          @issues = Issue.where(:id => str.to_i).where(:assigned_to_id => @id).where.not(status_id: closed_status_id)
          @issues=   @issues.map do |issue| {id: issue.id,holiday: user_holiday_scheme(issue.assigned_to_id),tracker: issue.tracker,project: issue.project, project_id:issue.project.id,subject: issue.subject, distribution:issue.distribution, workhours: user_workload(issue.id,issue.start_date,issue.due_date), description: issue.description,due_date: issue.due_date,category_id: issue.category,status_id: issue.status,wk_scheme: user_workload_scheme(issue.assigned_to_id),assigned_to_id: issue.assigned_to_id,assigned_to: "#{User.find_by_id(issue.assigned_to_id).firstname} #{User.find_by_id(issue.assigned_to_id).lastname}",s_date: issue.start_date,parent: issue.assigned_to_id,priority_id: issue.priority_id,fixed_version_id: issue.fixed_version_id,author_id: issue.author_id,lock_version: issue.lock_version,row_height: 50,bar_height: 40,text: issue.subject,created_on: issue.created_on,updated_on: issue.updated_on,start_date: issue.start_date,done_ratio: issue.done_ratio,end_date: issue.due_date,estimated_hours: issue.estimated_hours.present? ? issue.estimated_hours.round(2) : 0,parent_id: issue.parent_id,root_id: issue.root_id,lft: issue.lft,rgt: issue.rgt,type: "issue",is_private: issue.is_private,closed_on: issue.closed_on}end
          format.api{ render :json => @issues}
        else 
          @issues = Issue.where("lower(subject) LIKE ?" ,"%#{str.downcase}%").where(:assigned_to_id => @id).where.not(status_id: closed_status_id)
          @issues=   @issues.map do |issue| {id: issue.id,holiday: user_holiday_scheme(issue.assigned_to_id),tracker: issue.tracker,project: issue.project, project_id:issue.project.id,subject: issue.subject, distribution:issue.distribution, workhours: user_workload(issue.id,issue.start_date,issue.due_date), description: issue.description,due_date: issue.due_date,category_id: issue.category,status_id: issue.status,wk_scheme: user_workload_scheme(issue.assigned_to_id),assigned_to_id: issue.assigned_to_id,assigned_to: "#{User.find_by_id(issue.assigned_to_id).firstname} #{User.find_by_id(issue.assigned_to_id).lastname}",s_date: issue.start_date,parent: issue.assigned_to_id,priority_id: issue.priority_id,fixed_version_id: issue.fixed_version_id,author_id: issue.author_id,lock_version: issue.lock_version,row_height: 50,bar_height: 40,text: issue.subject,created_on: issue.created_on,updated_on: issue.updated_on,start_date: issue.start_date,done_ratio: issue.done_ratio,end_date: issue.due_date,estimated_hours: issue.estimated_hours.present? ? issue.estimated_hours.round(2) : 0,parent_id: issue.parent_id,root_id: issue.root_id,lft: issue.lft,rgt: issue.rgt,type: "issue",is_private: issue.is_private,closed_on: issue.closed_on}end
          format.api{ render :json => @issues}
        end 
      end
    end 
    rescue ActiveRecord::RecordNotFound
      404
  end


  def unassigned_issues
    # initialize with empty array
    issue_details = []
    # get single or multiple team id from parameters
    @params_team_id= params[:team_id].to_s.split(',').map(&:to_i)
    @user_id = User.current.id
    @group_id = TeamMember.where(member_id: @user_id).map(&:group_id).flatten.uniq
    @members = TeamMember.where(group_id: @group_id).map(&:member_id).flatten.uniq
    closed_status_id = IssueStatus.where(is_closed: true).pluck(:id)

    if @params_team_id.present?

      @params_team_id.each do |team_id|
      @params_members = TeamMember.where(group_id: team_id).map(&:member_id).flatten.uniq
      @project_ids = User.where(:id =>  @params_members, :status=>1, :type=>"User").map{|f|f.projects.active.ids}.flatten
      @issues = Issue.where(:project_id =>@project_ids).where.not(status_id: closed_status_id).order(created_on: :desc).where(:assigned_to_id => nil).limit(25)
      issue_details = issue_details.concat(@issues.map{|issue| {:id=> issue.id, :estimated_hours=> issue.estimated_hours.present? ? issue.estimated_hours.round(2) : 0, :project_name => issue.project.name, :text => issue.subject, 
      :project_id => issue.project_id, :due_date => issue.due_date, :end_date => issue.due_date, :s_date => issue.start_date, :row_height => 50, :bar_height => 40,
      :type => "issue",   :description=>issue.description, :tracker => issue.tracker, :assigned_to_id => issue.assigned_to}} )
      end
    
  else 
    if User.current.admin?  
      @projects = Project.where(:status => 1)
      @issues = Issue.where(:project_id => @projects).where.not(status_id: closed_status_id).order(created_on: :desc).where(:assigned_to_id => nil).limit(25)
      issue_details = @issues.map{|issue| {:id=> issue.id, :estimated_hours=> issue.estimated_hours.present? ? issue.estimated_hours.round(2) : 0, :project_name => issue.project.name, :text => issue.subject, 
      :project_id => issue.project_id, :due_date => issue.due_date, :end_date => issue.due_date, :s_date => issue.start_date, :row_height => 50, :bar_height => 40,
      :type => "issue",   :description=>issue.description, :tracker => issue.tracker, :assigned_to_id => issue.assigned_to}}
    else  
      @projects = User.current.projects.active.ids.to_a
      @issues = Issue.where(:project_id => @projects).where.not(status_id: closed_status_id).order(created_on: :desc).where(:assigned_to_id => nil).limit(25)
      issue_details = @issues.map{|issue| {:id=> issue.id, :estimated_hours=> issue.estimated_hours.present? ? issue.estimated_hours.round(2) : 0, :project_name => issue.project.name, :text => issue.subject, 
      :project_id => issue.project_id, :due_date => issue.due_date, :end_date => issue.due_date, :s_date => issue.start_date, :row_height => 50, :bar_height => 40,
      :type => "issue",   :description=>issue.description, :tracker => issue.tracker, :assigned_to_id => issue.assigned_to}}
    end 
  end
    render :json => issue_details  
    respond_to do |format|
      format.api do 
        issue_details 
      end 
    end 
  end

   #  search_unassigned_issues API which returns a list of unassigned issues of that projects of group in which current user is present
 
   def search_unassigned_issues
    @value = params[:issue]
    @params_team_id= params[:team_id].to_s.split(',').map(&:to_i)
    searched_issues = []
    if @value.present?
      @str = @value.to_s
      @user_id = User.current.id
      @group_id = TeamMember.where(member_id: @user_id).map(&:group_id).flatten.uniq
      @members = TeamMember.where(group_id: @group_id).map(&:member_id).flatten.uniq
      closed_status_id = IssueStatus.where(is_closed: true).pluck(:id)
       if  @params_team_id.present?
        @params_team_id.each do |team_id|
        @params_members = TeamMember.where(group_id: team_id).map(&:member_id).flatten.uniq
        project_ids = User.where(:id =>  @params_members, :status=>1, :type=>"User").map{|f|f.projects.active.ids}.flatten
        if @str =~ /\d/
          issues = Issue.where(:project_id => project_ids).where(:assigned_to_id => nil).where(:id =>@str.to_i).where.not(status_id: closed_status_id)
          searched_issues = issues.map{|issue| {:id=> issue.id, :estimated_hours=> issue.estimated_hours.present? ? issue.estimated_hours.round(2) : 0, :project_name => issue.project.name, :text => issue.subject, 
                          :project_id => issue.project_id, :due_date => issue.due_date, :end_date => issue.due_date, :s_date => issue.start_date, :row_height => 50, :bar_height => 40,
                          :type => "issue",  :description=>issue.description, :tracker => issue.tracker, :assigned_to_id => issue.assigned_to}}
        else  
          issues = Issue.where(:project_id => project_ids).where.not(status_id: closed_status_id).where(:assigned_to_id => nil).where("lower(subject) LIKE ?" ,"#{@str.downcase}%")
          searched_issues = issues.map{|issue| {:id=> issue.id, :estimated_hours=> issue.estimated_hours.present? ? issue.estimated_hours.round(2) : 0, :project_name => issue.project.name, :text => issue.subject, 
          :project_id => issue.project_id, :due_date => issue.due_date, :end_date => issue.due_date, :s_date => issue.start_date, :row_height => 50, :bar_height => 40,
          :type => "issue",  :description=>issue.description, :tracker => issue.tracker, :assigned_to_id => issue.assigned_to}}
        end 
      end

      else
        if User.current.admin?
          @projects = Project.all  
          if @str =~ /\d/
            issues = Issue.where(:project_id => @projects).where(:assigned_to_id => nil).where(:id =>@str.to_i).where.not(status_id: closed_status_id)
            searched_issues = issues.map{|issue| {:id=> issue.id, :estimated_hours=> issue.estimated_hours.present? ? issue.estimated_hours.round(2) : 0, :project_name => issue.project.name, :text => issue.subject, 
                            :project_id => issue.project_id, :due_date => issue.due_date, :end_date => issue.due_date, :s_date => issue.start_date, :row_height => 50, :bar_height => 40,
                            :type => "issue",   :description=>issue.description, :tracker => issue.tracker, :assigned_to_id => issue.assigned_to}}
          else  
            issues = Issue.where(:project_id => @projects).where(:assigned_to_id => nil).where("lower(subject) LIKE ?" ,"#{@str.downcase}%").where.not(status_id: closed_status_id)
            searched_issues = issues.map{|issue| {:id=> issue.id, :estimated_hours=> issue.estimated_hours.present? ? issue.estimated_hours.round(2) : 0, :project_name => issue.project.name, :text => issue.subject, 
                            :project_id => issue.project_id, :due_date => issue.due_date, :end_date => issue.due_date, :s_date => issue.start_date, :row_height => 50, :bar_height => 40,
                            :type => "issue",  :description=>issue.description,  :tracker => issue.tracker, :assigned_to_id => issue.assigned_to}}
          end 
        else

        @projects = User.current.projects.ids.to_a
        if @str =~ /\d/
          issues = Issue.where(:project_id => @projects).where(:assigned_to_id => nil).where(:id =>@str.to_i).where.not(status_id: closed_status_id)
          searched_issues = issues.map{|issue| {:id=> issue.id, :estimated_hours=> issue.estimated_hours.present? ? issue.estimated_hours.round(2) : 0, :project_name => issue.project.name, :text => issue.subject, 
                          :project_id => issue.project_id, :due_date => issue.due_date, :end_date => issue.due_date, :s_date => issue.start_date, :row_height => 50, :bar_height => 40,
                          :type => "issue",   :description=>issue.description, :tracker => issue.tracker, :assigned_to_id => issue.assigned_to}}
        else  
          issues = Issue.where(:project_id => @projects).where(:assigned_to_id => nil).where("lower(subject) LIKE ?" ,"#{@str.downcase}%").where.not(status_id: closed_status_id)
          searched_issues = issues.map{|issue| {:id=> issue.id, :estimated_hours=> issue.estimated_hours.present? ? issue.estimated_hours.round(2) : 0, :project_name => issue.project.name, :text => issue.subject, 
                          :project_id => issue.project_id, :due_date => issue.due_date, :end_date => issue.due_date, :s_date => issue.start_date, :row_height => 50, :bar_height => 40,
                          :type => "issue",  :description=>issue.description,  :tracker => issue.tracker, :assigned_to_id => issue.assigned_to}}
        end 
      end
      end 
    end 
    render :json => searched_issues
      respond_to do |format|
        format.api do 
          searched_issues
        end 
      end 
    rescue ActiveRecord::RecordNotFound
      render 404
 
  end 
  
  def users_projects
    current_user = User.current.id
    @params_team_id=params[:team_id].to_s.split(',').map(&:to_i)
    team_id = TeamMember.where(member_id: current_user).map(&:group_id).flatten.uniq
    @team_members = TeamMember.where(group_id: team_id).map(&:member_id).flatten.uniq
    respond_to do |format|
      project_data = { data: [] } 
   
      if  @params_team_id.present?
        @params_team_id.each do |id|
        @params_team_members = TeamMember.where(group_id: id).map(&:member_id).flatten.uniq
        @project_ids = User.all.where(:id =>  @params_team_members, :status=>1, :type=>"User").map{|f|f.projects.active.ids}.flatten.uniq
        @projects = Project.where(:id => @project_ids).paginate(:page => params[:page], :per_page => params[:per_page])
        project_data[:data].concat(@projects)
        format.api { render :json =>{:data => project_data[:data],  pagination: { total_pages:  @projects.total_pages,total_entries:  @projects.total_entries }}}
        end
      else 
        if User.current.admin?
          @projects = Project.where(status: [1, 5]).paginate(:page => params[:page], :per_page => params[:per_page])
          project_data[:data] = @projects
          format.api { render :json => {:data => project_data[:data],  pagination: { total_pages:  @projects.total_pages,total_entries:  @projects.total_entries }}}
      
    
       else
        @project_ids = User.current.projects.active.ids.flatten.uniq
        @projects = Project.where(:id => @project_ids).paginate(:page => params[:page], :per_page => params[:per_page])
        project_data[:data] = @projects
        format.api { render :json => {:data => project_data[:data],  pagination: { total_pages:  @projects.total_pages,total_entries:  @projects.total_entries }}}
       end 

      end

    end 
  rescue ActiveRecord::RecordNotFound
    render 404
  end 

  def search_users_projects
    str = params[:name]
    @params_team_id=params[:team_id].to_s.split(',').map(&:to_i)
    current_user = User.current.id
    team_id = TeamMember.where(member_id: current_user).map(&:group_id).flatten.uniq
    @team_members = TeamMember.where(group_id: team_id).map(&:member_id).flatten.uniq
    if str.present?
      respond_to do |format|
        @searched_projects =  [] 
        if @params_team_id.present?
           @params_team_id.each do|id|
            @params_team_members = TeamMember.where(group_id: id).map(&:member_id).flatten.uniq
          @project_ids = User.all.where(:id => @params_team_members, :status=>1, :type=>"User").map{|f|f.projects.active.ids}.flatten
          projects_within_team = Project.all.where(:id => @project_ids).where("lower(name) LIKE ?", "%#{str.downcase}%")
          @searched_projects.concat(projects_within_team)
          format.api { render :json => @searched_projects}
           end
        else  
          if User.current.admin?
            @project_ids = Project.all
            @searched_projects = Project.all.where(:id => @project_ids).where("lower(name) LIKE ?", "%#{str.downcase}%")
            format.api { render :json =>@searched_projects}
          else
            @project_ids = User.current.projects.active.ids
            @searched_projects = Project.all.where(:id => @project_ids).where("lower(name) LIKE ?", "%#{str.downcase}%")
            format.api { render :json =>@searched_projects}
          end
         
        end 
      end 
    end 
  rescue ActiveRecord::RecordNotFound
    render 404
  end 

  def user_issues
    user_id = params[:user_id]
    if user_id.present?
      projects = User.where(:id => user_id).map{|f|f.projects.active.ids}.flatten.uniq
      closed_status_id = IssueStatus.where(is_closed: true).pluck(:id)
      # issues = Issue.where(:project_id => projects, :assigned_to_id => user_id, :closed_on => nil)
      issues = Issue.where(:project_id => projects, :assigned_to_id => user_id).where.not(status_id: closed_status_id).limit(50)
      issues=   issues.map do |issue| {id: issue.id,holiday: user_holiday_scheme(issue.assigned_to_id),tracker: issue.tracker,project: issue.project, project_id:issue.project.id,subject: issue.subject, distribution:issue.distribution, workhours: user_workload(issue.id,issue.start_date,issue.due_date), description: issue.description,due_date: issue.due_date,category_id: issue.category,status_id: issue.status,wk_scheme: user_workload_scheme(issue.assigned_to_id),assigned_to_id: issue.assigned_to_id,assigned_to: "#{User.find_by_id(issue.assigned_to_id).firstname} #{User.find_by_id(issue.assigned_to_id).lastname}",s_date: issue.start_date,parent: issue.assigned_to_id,priority_id: issue.priority_id,fixed_version_id: issue.fixed_version_id,author_id: issue.author_id,lock_version: issue.lock_version,row_height: 50,bar_height: 40,text: issue.subject,created_on: issue.created_on,updated_on: issue.updated_on,start_date: issue.start_date,done_ratio: issue.done_ratio,end_date: issue.due_date,estimated_hours: issue.estimated_hours.present? ? issue.estimated_hours.round(2) : 0,parent_id: issue.parent_id,root_id: issue.root_id,lft: issue.lft,rgt: issue.rgt,type: "issue",is_private: issue.is_private,closed_on: issue.closed_on}end
      respond_to do |format|
        format.api { render :json => issues}
      end 
    end 
    rescue ActiveRecord::RecordNotFound
      render 404
  end 


  #controller Team Mamber User APIs

  def skills_of_users
    if params[:skills].present?
      @parameter =   params[:skills].downcase

      @user_id = User.current.id
    @group_id = TeamMember.where(member_id: @user_id).map(&:group_id).flatten.uniq
    @members = TeamMember.where(group_id: @group_id).map(&:member_id).flatten.uniq
    if @group_id.present?
      @group_users_plan =  User.where(:id => @members, :status=>1, :type=>"User")
      @workload_data = {}
      @skills_users = TeamMember.where("lower(skills) LIKE ?","%#{@parameter}%").pluck(:member_id)


      @users =  @members

    @skills_data = @skills_users.select{|x| @users.to_enum.include?(x)}
      @group_users =  User.where(:id => @skills_data, :status=>1, :type=>"User").limit(25)
      @all_issues = Issue.where(assigned_to_id: @skills_data).limit(25)
      @group_issues=@all_issues.map{|f| { :id=>f.id , :subject=>f.subject , :estimated_hours=>f.estimated_hours, :project_name=>f.project.name , :project_id=>f.project.id}}
      @issues = Issue.where(assigned_to_id: @skills_data).where("(#{Issue.table_name}.start_date BETWEEN ? AND ?) AND (#{Issue.table_name}.due_date BETWEEN ? AND ?)", @period_start,@period_end,@period_start,@period_end).limit(25)
      @data = @group_users.map{|f| {:wk_scheme => user_workload_scheme(f.id), :holiday=> user_holiday_scheme(f.id),:id => f.id, :color=>f.color,  :parent=>0,  :skills=> TeamMember.where(:member_id => f.id).pluck(:skills),  :text=> f.firstname + " " + f.lastname, :row_height=>50, :bar_height=>40, :type=>"user", :user_id=>f.id, :login => f.login ,  :firstname => f.firstname, :lastname => f.lastname, :admin => f.admin,:created_on => f.created_on , :start_date=>"2022-08-11",  :updated_on => f.updated_on, :issues=>@issues.where(:assigned_to_id=>f.id), :estimated_hours => @issues.where(:assigned_to_id=>f.id).sum(:estimated_hours).round(2)}} + @issues.map{|f| {:id =>"i"+f.id.to_s,:holiday=> user_holiday_scheme(f.assigned_to_id),:tracker => f.tracker,:project => f.project,:subject => f.subject,:description => f.description, :due_date => f.due_date, :category_id => f.category,:status_id => f.status, :assigned_to_id => f.assigned_to_id,:wk_scheme => user_workload_scheme(f.assigned_to_id), :assigned_to => User.find_by_id(f.assigned_to_id).firstname + " " + User.find_by_id(f.assigned_to_id).lastname, s_date: f.start_date, :parent=> f.assigned_to_id, :priority_id => f.priority_id, :fixed_version_id => f.fixed_version_id, :author_id => f.author_id,:lock_version => f.lock_version, :row_height=>50, :bar_height=>40,  :text=>f.subject, :created_on => f.created_on,:updated_on => f.updated_on, :start_date => f.start_date,:done_ratio => f.done_ratio, :end_date=>f.due_date, :estimated_hours =>f.estimated_hours , :parent_id => f.parent_id, :root_id => f.root_id, :lft => f.lft, :rgt => f.rgt, :type=>"issue", :is_private => f.is_private, :closed_on => f.closed_on}}
      @workload_data[:data] = @data  
      @workload_data[:users] = @group_users_plan  
      @workload_data[:issues] = @group_issues    
      # @workload_data[:users] = @group_users
      # @workload_data[:issues] = @group_issues  
  render :json =>  {data: @workload_data[:data],  users:  @workload_data[:users], issues: @workload_data[:issues] }
      respond_to do |format|
      format.html
      format.api do
        @workload_data
      end
    end
    else

      @workload_data = {}
      @user = User.where(:id => id, :status=>1, :type=>"User").limit(25)
      @all_issues = Issue.where(assigned_to_id: @users).limit(25)
      @group_issues=@all_issues.map{|f| { :id=>f.id , :subject=>f.subject , :estimated_hours=>f.estimated_hours, :project_name=>f.project.name , :project_id=>f.project.id}}
      @issues = Issue.where(:assigned_to_id => id).where("(#{Issue.table_name}.start_date BETWEEN ? AND ?) AND (#{Issue.table_name}.due_date BETWEEN ? AND ?)", @period_start,@period_end,@period_start,@period_end).limit(25)
      @data =  @user.map{|f| {:id => f.id, :color=>f.color, :parent=>0, :text=>f.firstname + " " + f.lastname, :row_height=>50, :bar_height=>40, :type=>"user", :user_id=>f.id, 
      :login => f.login ,  :firstname => f.firstname, :lastname => f.lastname, :admin => f.admin,:created_on => f.created_on ,  :start_date=>"2022-08-11",  
      :updated_on => f.updated_on, :issues=>@issues.where(:assigned_to_id=>f.id), :estimated_hours => @issues.where(:assigned_to_id=>f.id).sum(:estimated_hours).round(2) }}+ @issues.map{|f| {:id => "i" + f.id.to_s, :assigned_to => User.find_by_id(f.assigned_to_id).firstname + " " + User.find_by_id(f.assigned_to_id).lastname , :tracker => f.tracker,:project => f.project,:subject => f.subject,:description => f.description, :due_date => f.due_date, :category_id => f.category,:status_id => f.status, :assigned_to_id => f.assigned_to_id,  s_date:f.start_date, :parent=> f.assigned_to_id, :end_date=>f.due_date, :priority_id => f.priority_id, :fixed_version_id => f.fixed_version_id, :author_id => f.author_id,:lock_version => f.lock_version, :row_height=>50, :bar_height=>40,  :text=>f.subject, :created_on => f.created_on,:updated_on => f.updated_on, :start_date => f.start_date,:done_ratio => f.done_ratio, :estimated_hours =>f.estimated_hours, :parent_id => f.parent_id, :root_id => f.root_id, :lft => f.lft, :rgt => f.rgt, :type=>"issue", :is_private => f.is_private, :closed_on => f.closed_on}}
      
      @workload_data[:data] = @data
   
      @workload_data[:data] = []
      # @workload_data[:users] = @user
      # @workload_data[:issues] = @group_issues  
      render :json => @workload_data
      respond_to do |format|
      format.html
      format.api do
        @workload_data
      end
    end
    end 
    end
   end

   def get_dates
    current_day = Date.today
    @period_start = current_day.beginning_of_month
    @period_end = current_day.end_of_month
  end 




  #PEOPLES CONTROLLER APIS

  def create
    @parameter_1 = params[:member_id]
    @parameter_2 = params[:group_id]
    if (@parameter_1 && @parameter_2).present?
      @parameter_1.each do |member|

    @team = TeamMember.new(member_id: member, role_id: params[:role_id], group_id: @parameter_2, skills: params[:skills], commitment: params[:commitment], joining_date: params[:joining_date], leaving_date: params[:leaving_date])
    
    if @team.valid?
      @team.save 
      flash[:notice] = "Member was successfully added"
      # render :json => @team
      respond_to do |format|
        format.html
        format.api do
          @team
        end 
      end
    elsif @team.errors.any?
    @team.errors.full_messages.each do |message|
      flash[:error] = message     
    end
    else  
      flash[:error] = "Member already exists"

    end 
  end
  end

end


# def create
#   @parameter_1 = params[:member_id]
#   @parameter_2 = params[:group_id]
  
#   if (@parameter_1 && @parameter_2).present?
#     @parameter_1.each do |member|
#       @team = TeamMember.new(
#         member_id: member,
#         role_id: params[:role_id],
#         group_id: @parameter_2,
#         skills: params[:skills],
#         commitment: params[:commitment],
#         joining_date: params[:joining_date],
#         leaving_date: params[:leaving_date]
#       )

#       if @team.valid?
#         @team.save
#         flash[:notice] = "Member was successfully added"
#         render json: { message: flash[:notice], success: true }
#         return  
#       elsif @team.errors.any?
#         errors = @team.errors.full_messages
#         render json: { message: errors, success: false }, status: :unprocessable_entity
#         return  
#       else  
#         render json: { message: "Member already exists", success: false }, status: :unprocessable_entity
#         return 
#       end 
#     end
#   end
# end






  def update_members
    @people = TeamMember.where(group_id: params[:group_id]).where(member_id: params[:ids])

      @people.each do |person|
          if params[:role_id].present?
            person.update(role_id: params[:role_id])
        end
          if params[:skills].present?
            person.update(skills: params[:skills])
        
          end
          if params[:commitment].present?
            person.update(commitment: params[:commitment])
        
        end
        if params[:joining_date].present?
          person.update(joining_date: params[:joining_date])
      
        end
        if params[:leaving_date].present?
          person.update(leaving_date: params[:leaving_date])
      
        end
        if person.save
          flash[:notice] = "Successfully updated"
        else
          flash[:error] = person.errors.full_messages.join(", ")
        end
      end
  
    
    respond_to do |format|
      format.html
      format.json { render json: @people.to_json }
      format.api { render json: @people.to_json }
    end
  end

  def members_api
      if params[:group_id] && params[:member_id].present?
          @parameter_1 = params[:group_id]
          @parameter_2 = params[:member_id]

      @users = TeamMember.where(:group_id => @parameter_1).where(:member_id => @parameter_2)
      render :json => @users
      respond_to do |format|
        format.html
        format.api do
          @users
        end 
      end
    end
  end

   def search_members
    if User.present?
      if params[:name].present?
        @parameter =   params[:name].downcase
        @users = User.logged.where("lower(firstname) LIKE ? OR lower(lastname) LIKE ?", "%#{@parameter}%","%#{@parameter}%")
        render :json => @users
        respond_to do |format|
          format.html
          format.api do
            @users
          end
        end        
      end
    end
  rescue ActiveRecord::RecordNotFound
    render 404
  end  

  def update_edit_members
    @people = TeamMember.find_by(group_id: params[:group_id], member_id: params[:id])
  
    if @people
      if @people.update(skills: params[:skills],role_id: params[:role_id], commitment: params[:commitment], joining_date: params[:joining_date], leaving_date: params[:leaving_date])
        flash[:notice] = "Successfully updated"
      else
        flash[:error] = @people.errors.full_messages.join(", ")
      end
    else
      flash[:error] = "Team member not found"
    end
  
    respond_to do |format|
      format.html
      format.json { render json: @people.to_json }
      format.api { render json: @people.to_json }
    end
  end



end
