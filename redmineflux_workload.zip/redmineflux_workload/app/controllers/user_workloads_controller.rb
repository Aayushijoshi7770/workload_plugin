class UserWorkloadsController < ApplicationController
  before_action :week_dates
  accept_api_auth :index, :add_workload_members, :search_scheme_users, :workload_scheme_with_members, :workload_scheme, :update, :delete_wk_bulk_data, :user_hd_delete, :add_members_to_wk_scheme , :search_workload_scheme_members

  def index
    @workloads = UserWorkload.where(id: params[:id])
 
    respond_to do |format|
      format.html
      format.api { render :json => @workloads }
      format.json { render :json => @workloads }
    end 
  end

  def new 
    @workloads = UserWorkload.all
    @workload = UserWorkload.new
  end
  
  def create  
    @workload = UserWorkload.new(params.require(:user_workload).permit(:name, :description, :wd0, :wd1, :wd2, :wd3, :wd4, :wd5, :wd6))
    if @workload.save 
      flash[:notice] = "Workload scheme added successfully"
      redirect_to :back
    elsif @workload.errors.any?
      @workload.errors.full_messages.each do |message|
    message_without_wd = message.gsub(/Wd\d+/, { "Wd0" => "Value", "Wd1" => "Value", "Wd2" => "Value", "Wd3" => "Value", "Wd4" => "Value", "Wd5" => "Value", "Wd6" => "Value"  })
  
    if message.include?("Wd")
      flash[:error] = message_without_wd
    else
      flash[:error] = message
    end
      end
    
      redirect_to :back
      # redirect_to user_workload_path(@workload)
    else  
      flash[:error] = "Failed to save workload"
      render :action => 'new'
    end 

  end 

  def add_workload_members
    @users = params[:user_id] 
    workload_id = params[:workload_id]
    if (@users.present? && workload_id.present?)
      @users.each do |user|
        @scheme = WorkloadScheme.new(:user_workload_id => workload_id, :user_id => user)
        if @scheme.save  
          flash[:notice] = "Workload member added successfully"
          
        else  
          flash[:error] = "Member already exists in some scheme"
        end 
      end 

    end 

  end

  def show
    @workload = UserWorkload.find(params[:id])
    @user_ids = WorkloadScheme.where(:user_workload_id => @workload).pluck(:user_id)
    @users = User.where(:id => @user_ids).select(:firstname, :lastname,:id).paginate(page: params[:page], per_page: 20)

    @wk_id = params[:id]
    @all_workload_user_ids = WorkloadScheme.pluck(:user_id)
    @memeber_workload_scheme = User.where(status: 1).where.not(id: @all_workload_user_ids)



  end

  def edit
    if (User.current.allowed_to?(:manage_workload, User.current.projects.to_a)) || (User.current.admin?) 
      @workload = UserWorkload.find(params[:id])
    else
      flash[:error] = "You are not authorized"
      redirect_to :back
    end 
  end

  def update
    @workload = UserWorkload.find(params[:id])
    if @workload.update(
      name: params[:name],
      description: params[:description],
      wd0: params[:wd0],
      wd1: params[:wd1],
      wd2: params[:wd2],
      wd3: params[:wd3],
      wd4: params[:wd4],
      wd5: params[:wd5],
      wd6: params[:wd6]
    )
      flash[:notice] = 'Successfully Updated'
      render json: @workload, status: :ok
    elsif @workload.errors.any?
      error_messages = @workload.errors.full_messages.map do |message|
        if message.include?("Wd")
          message.gsub(/Wd\d+/, "Value")
        else
          message
        end
      end
      render json: { error: error_messages }, status: :unprocessable_entity
    else
      render json: { error: 'Something went wrong' }, status: :unprocessable_entity
    end
  end

  def destroy
    if (User.current.allowed_to?(:manage_workload, User.current.projects.to_a)) || (User.current.admin?)  
      @workload = UserWorkload.find(params[:id])
      if @workload.delete  
        @workload_scheme = WorkloadScheme.where(:user_workload_id => @workload)
        @workload_scheme.each do |s|
          s.destroy
        end 
        @workload.destroy
        redirect_to :back
        flash[:notice] = "Workload has been deleted" 
      else  
        flash[:error] = "Failed to delete"
        render :action => "delete"
      end
    else 
      flash[:error] = "You are not allowed to perform this action" 
      redirect_to :back
    end 
  end 

  def user_delete
    @user = WorkloadScheme.where(user_id: params[:id])
    @user.destroy_all 
    redirect_to :back
    flash[:notice] = "Workload member has been deleted" 
    
  end

  def search_scheme_users
    name = params[:name]
    if name.present?
      @parameter = params[:name].downcase
      @all_workload_user_ids = WorkloadScheme.pluck(:user_id)
      scope = User.select("id, firstname, lastname, (firstname || ' ' || lastname) AS name").where(:status =>1).where.not(id: @all_workload_user_ids)
      @user = scope.like(@parameter)
      render :json => @user
      respond_to do |format|
        format.html
        format.api do 
          @user
        end 
      end 
    else  
      return nil
    end 
  rescue ActiveRecord::RecordNotFound
    render 404
  end 

  def search_workload_scheme_members
    if params[:name].present?
      @parameter = "%#{params[:name].downcase}%"
      @all_workload_user_ids = WorkloadScheme.pluck(:user_id)
  
      @user = User.where(id: @all_workload_user_ids, status: 1)
                  .where("LOWER(CONCAT(firstname, ' ', lastname)) LIKE ?", @parameter)
                  .select("id, firstname, lastname, CONCAT(firstname, ' ', lastname) AS name")
   
      render json: @user
    else
      render json: { error: "Name parameter is missing" }, status: :unprocessable_entity
    end
  rescue ActiveRecord::RecordNotFound
    render json: { error: "Record not found" }, status: :not_found
  end
  
  
  



  


  def add_members_to_wk_scheme
    @all_workload_user_ids = WorkloadScheme.pluck(:user_id)
    @users = User.all.where(:status => 1).where.not(id: @all_workload_user_ids)
    respond_to do |format|
      format.api {render :json => @users }
    end 
  end 

  def workload_params
    (params.require(:user_workload).permit(:name, :description, :wd0, :wd1, :wd2, :wd3, :wd4, :wd5, :wd6))
  end 

  def week_dates
    current_day = Date.today
    @week_start = current_day.beginning_of_week
    @week_end = current_day.end_of_week
  end 

  def workload_scheme_with_members
    @workload = UserWorkload.find(params[:id])
    if @workload.present?
      @wk_scheme = []
      @user_ids = WorkloadScheme.where(:user_workload_id => @workload).pluck(:user_id)
      @users = User.where(:id => @user_ids, :status =>1).select(:id, :firstname, :lastname)
      @wk_scheme.push(@workload)
      @wk_scheme = @wk_scheme+@users
      render :json => @wk_scheme
      respond_to do |format|
        format.html
        format.api do
          @wk_scheme
        end 
      end 
    end
  rescue ActiveRecord::RecordNotFound
    render 404 
  end 

  # def workload_scheme
  #   wk_scheme = params[:scheme_id]
  #   return nil if wk_scheme.blank?
  #   @wk_scheme = UserWorkload.where(:id => wk_scheme)
  #   @users = WorkloadScheme.where(:user_workload_id => wk_scheme).select(:user_id).uniq
  #   render :json => @wk_scheme+@users
  # end 

 
  def delete_wk_bulk_data
    if (User.current.allowed_to?(:manage_workload, User.current.projects.to_a)) || (User.current.admin?)  
      @workload = UserWorkload.find(params[:id])
      if @workload  
        @workload_scheme = WorkloadScheme.where(:user_workload_id => @workload)
        @workload_scheme.each do |s|
          s.destroy
        end 
        @data = UserWorkload.where(id: params[:id].split(',').map(&:to_i))
        @data.destroy_all

        flash[:notice] = "Workload has been deleted" 
      else  
        flash[:error] = "Failed to delete"
    
      end
      
      render :json => @data
      respond_to do |format|
        format.html
        format.api do
          @workload
        end 
      end 
    else 
      flash[:error] = "You are not allowed to perform this action" 
      redirect_to :back
    end 
  end
  def user_hd_delete
    @user = WorkloadScheme.where(user_id: params[:id].split(',').map(&:to_i))
    @user.destroy_all 

    flash[:notice] = "Workload members has been deleted" 
    render :json => @user
    respond_to do |format|
      format.html
      format.api do 
        @user
      end 
    end 
  end
end
