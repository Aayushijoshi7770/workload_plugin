class SkillsController < ApplicationController
  accept_api_auth :delete_bulk_skills
 

  def index
    @skills = Skill.order(created_at: :desc)
    @skill = Skill.new
  end
  def new
    @skill = Skill.new

  end
  
   
  def create
    @skill = Skill.create(params.require(:skill).permit(:skill))
  
    if @skill.valid?
      @skill.save
      flash[:notice] = "Succefully Created"
      redirect_to skills_path
    elsif @skill.errors.any?
      @skill.errors.full_messages.each do |message|
      flash[:error] = message
     end
      redirect_to skills_path
    else
      flash[:error] = "skill name is already taken"
      redirect_to skills_path
    end
  end

  def show
    @skill = Skill.find(params[:id])
  end

  def edit
    # if (User.current.allowed_to?(:manage_workload, @project)) || (User.current.admin?)
      @skill = Skill.find(params[:id])
    # else  
    #   flash[:error] = "You are not authorized"
    # end 
  end

#   def update
#     @name = Skill.where(id: params[:id]).pluck(:skill).join
#     @skill = Skill.find(params[:id])
#     if @skill.update(params.require(:skill).permit(:skill))
#       posts = TeamMember.all
#       posts.each do |post|
       
#         post.skills = post.skills = post.skills.gsub(/\b#{@name}\b(,|$)/, params[:skill][:skill ]+',')
#         post.save
# end
#       flash[:notice] = "Succefully created"
#       respond_to do |format|
#         flash[:notice] = "Successfully created"
#         format.html { redirect_to :back }
#         format.js { render js: "window.location = '/skills'" }
#       end
#     elsif @skill.errors.any?
#       @skill.errors.full_messages.each do |message|
#         flash[:error] = message
#         redirect_to skills_path
#       end
#     else
#       flash[:error] = "skill name is already taken"
#       redirect_to skills_path
#     end
#    end

  def update
    @name = Skill.where(id: params[:id]).pluck(:skill).join
    @skill = Skill.find(params[:id])
    
    if @skill.update(params.require(:skill).permit(:skill))
      TeamMember.all.each do |post|
        post.skills = post.skills.gsub(/\b#{@name}\b(,|$)/, params[:skill][:skill ]+',')
        post.save
      end
      flash[:notice] = "Successfully Updated."
    elsif @skill.errors.any?
      @skill.errors.full_messages.each do |message|
        flash[:error] = message
      end
    else
      flash[:error] = "Skill name is already taken"
    end

    respond_to do |format|
      format.html { redirect_to :back }
      format.js { render js: "window.location = '/skills'" }
    end
  end

   

   def destroy
    if (User.current.allowed_to?(:manage_workload, User.current.projects.to_a)) || (User.current.admin?)
      @skill = Skill.find(params[:id])
      @name = Skill.where(id: params[:id]).pluck(:skill).join
      @skill.destroy
      posts = TeamMember.all
      posts.each do |post|
        post.skills = post.skills = post.skills.gsub(/\b#{@name}\b(,|$)/, "")
        post.save
      end
      redirect_to skills_path
    else   
      flash[:error] = "You are not authorized"
      redirect_to :back
    end 
  end


  def delete_bulk_skills
    skill_ids = params[:id].split(',').map(&:to_i)
    skills = Skill.where(id: skill_ids).pluck(:skill)
    TeamMember.all.each do |team_member|
      skills.each do |skill|
        regex = /\s*,?\s*\b#{Regexp.escape(skill)}(?:\s+\w+)*\s*(?:,|$)\s*/i
        team_member.skills = team_member.skills.gsub(regex, "")
      end
      team_member.skills = team_member.skills.gsub(/,\s*$/, "") # Remove any trailing comma or whitespace
      team_member.save
    end
    Skill.where(id: skill_ids).destroy_all
    flash[:notice] = "Skill deleted Successfully."
      render :json =>  @skill
      respond_to do |format|
        format.html 
        format.api do
          @skill         
         end
      end
    
    end 
end
