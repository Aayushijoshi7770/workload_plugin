class WorkloadsController < ApplicationController
   before_action :require_login
   before_action :get_dates
   accept_api_auth :data
   accept_api_auth :user_issues_with_period
   accept_api_auth :data ,:group_projects_issues ,:filter_by_group  , :filter_by_users , :workload_group_API,:workload_permissions, :update_dropdown_preference
   after_action :create_default_record


   
   # accept_api_auth :group_projects_issues
 
   def index
  
    @permission = set_permissions
    @team_data, @active_users = fetch_team_data_and_users

     User.where(color: nil).find_each do |user|
       user.update_columns(color: random_light_color)
             
     end
     current_user = User.current.id
     @preference = DropdownPreference.where(user_id: User.current.id).first_or_create(selected_option: "collapse").selected_option
    
   
     # no data
   end

   def random_light_color
     # Generate a random hex code between 0 and F for each color channel
     red = SecureRandom.hex(1)
     green = SecureRandom.hex(1)
     blue = SecureRandom.hex(1)
   
     # Combine the color channels into a single hex code
     color = "#" + red + green + blue
   
     # check if the color is light enough, if not generate another one
     color = random_light_color if color_brightness(color) < 100
     color
   end
   def color_brightness(color)
     hex = color.gsub("#", "")
     brightness = (0.299*hex[0..1].hex + 0.587*hex[2..3].hex + 0.114*hex[4..5].hex)
     brightness
   end
 
 
 # Get issues of all the group users in which current user is available 
 def data
   if  User.current.groups.where("lastname LIKE ?", "%" + 'workload' + "%").present?
     @workload_data = {}
     @users = User.current.groups.where("lastname LIKE ?", "%" + 'workload' + "%").map(&:user_ids).flatten.uniq
     @group_users =  User.where(:id => @users, :status=>1, :type=>"User").limit(25)
     project_ids = User.current.groups.map{|g|g.projects.active.ids}.flatten
     @all_issues = Issue.where(project_id: project_ids).where(assigned_to_id: @users )
     @group_issues = @all_issues.map{|f| { :id=>f.id,  :estimated_hours=>f.estimated_hours.present? ? f.estimated_hours.round(2) : 0, :project_name=>f.project.name ,  :text=>f.subject,  :project_id=>f.project.id, :due_date=>f.due_date, :start_date=>f.start_date, :s_date=>f.start_date, :row_height=>50, :bar_height=>40, :end_date=>f.due_date,  :subject=>f.subject,   :type=>"issue", :tracker => f.tracker}}
     @issues = Issue.where(assigned_to_id: @users).where("(#{Issue.table_name}.start_date BETWEEN ? AND ?) OR (#{Issue.table_name}.due_date BETWEEN ? AND ?)", @period_start,@period_end,@period_start,@period_end)
     @data = @group_users.map{|f| {:id => f.id, :color=>f.color,  :parent=>0,    :text=> f.firstname + "  " + f.lastname, :row_height=>50, :bar_height=>40, :type=>"user", :user_id=>f.id, :login => f.login ,  :firstname => f.firstname, :lastname => f.lastname, :admin => f.admin,:created_on => f.created_on , :start_date=>"2022-08-11",  :updated_on => f.updated_on, :estimated_hours => @issues.where(:assigned_to_id=>f.id).sum(:estimated_hours).round(2)}} + @issues.map{|f| {:id =>"i"+f.id.to_s,:tracker => f.tracker,:project => f.project,:subject => f.subject,:description => f.description, :due_date => f.due_date, :category_id => f.category,:status_id => f.status, :assigned_to_id => f.assigned_to_id, :assigned_to => User.find_by_id(f.assigned_to_id).firstname + " " + User.find_by_id(f.assigned_to_id).lastname, s_date: f.start_date, :parent=> f.assigned_to_id, :priority_id => f.priority_id, :fixed_version_id => f.fixed_version_id, :author_id => f.author_id,:lock_version => f.lock_version, :row_height=>50, :bar_height=>40,  :text=>f.subject, :created_on => f.created_on,:updated_on => f.updated_on, :start_date => f.start_date,:done_ratio => f.done_ratio, :end_date=>f.due_date, :estimated_hours =>f.estimated_hours.present? ? f.estimated_hours.round(2) : 0 , :parent_id => f.parent_id, :root_id => f.root_id, :lft => f.lft, :rgt => f.rgt, :type=>"issue", :is_private => f.is_private, :closed_on => f.closed_on}}
     @workload_data[:data] = @data
     @workload_data[:users] = @group_users
     @workload_data[:issues] = @group_issues  
     render :json => @workload_data
     respond_to do |format|
     format.html
     format.api do
       @workload_data
     end
    end
    else
     id = User.current.id
     @workload_data = {}
     @user = User.where(:id => id, :status=>1, :type=>"User")
     project_ids = User.current.groups.map{|g|g.projects.active.ids}.flatten
     @all_issues = Issue.where(project_id: project_ids).where(assigned_to_id: @user )
     @group_issues=@all_issues.map{|f| { :id=>f.id,  :estimated_hours=>f.estimated_hours.present? ? f.estimated_hours.round(2) : 0, :project_name=>f.project.name ,  :text=>f.subject,  :project_id=>f.project.id, :due_date=>f.due_date, :start_date=>f.start_date, :s_date=>f.start_date, :row_height=>50, :bar_height=>40, :end_date=>f.due_date,  :subject=>f.subject,   :type=>"issue", :tracker => f.tracker}}
     @issues = Issue.where(:assigned_to_id => id).where("(#{Issue.table_name}.start_date BETWEEN ? AND ?) OR (#{Issue.table_name}.due_date BETWEEN ? AND ?)", @period_start,@period_end,@period_start,@period_end)
     @data =  @user.map{|f| {:id => f.id, :color=>f.color,  :parent=>0,   :text=> f.firstname + "  " + f.lastname, :row_height=>50, :bar_height=>40, :type=>"user", :user_id=>f.id, :login => f.login ,  :firstname => f.firstname, :lastname => f.lastname, :admin => f.admin,:created_on => f.created_on , :start_date=>"2022-08-11",  :updated_on => f.updated_on, :estimated_hours => @issues.where(:assigned_to_id=>f.id).sum(:estimated_hours).round(2)}} + @issues.map{|f| {:id =>"i"+f.id.to_s,:tracker => f.tracker,:project => f.project,:subject => f.subject,:description => f.description, :due_date => f.due_date, :category_id => f.category,:status_id => f.status, :assigned_to_id => f.assigned_to_id, :assigned_to => User.find_by_id(f.assigned_to_id).firstname + " " + User.find_by_id(f.assigned_to_id).lastname, s_date: f.start_date, :parent=> f.assigned_to_id, :priority_id => f.priority_id, :fixed_version_id => f.fixed_version_id, :author_id => f.author_id,:lock_version => f.lock_version, :row_height=>50, :bar_height=>40,  :text=>f.subject, :created_on => f.created_on,:updated_on => f.updated_on, :start_date => f.start_date,:done_ratio => f.done_ratio, :end_date=>f.due_date, :estimated_hours =>f.estimated_hours.present? ? f.estimated_hours.round(2) : 0 , :parent_id => f.parent_id, :root_id => f.root_id, :lft => f.lft, :rgt => f.rgt, :type=>"issue", :is_private => f.is_private, :closed_on => f.closed_on}}
     @workload_data[:data] = @data
     @workload_data[:users] = @user
     @workload_data[:issues] = @group_issues  
      render :json => @workload_data
      respond_to do |format|
      format.html
      format.api do
       @workload_data
      end
    end
   end 
 end
 
 def user_workload_scheme(user)
   # scheme_id = params[:scheme_id]
   if user.present? 
     wk_scheme = WorkloadScheme.where(:user_id => user).pluck(:user_workload_id).uniq
     users_scheme = UserWorkload.where(:id => wk_scheme)
 
     return users_scheme
     render :json => users_scheme
   end 
 
 end 
 
 def workload_group_API
   if params[:start_date] && params[:due_date].present?
     @start_date = params[:start_date]
     @due_date = params[:due_date]
     @page = params[:page]
     @per_page = params[:per_page]
     @user_id = User.current.id
     @group_id = TeamMember.where(member_id: @user_id).map(&:group_id).flatten.uniq
     @members = TeamMember.where(group_id: @group_id).map(&:member_id).flatten.uniq
     if @group_id.present?
      @workload_data = {}
      @users =  @members
      @group_users =  User.where(:id => @users, :status=>1, :type=>"User").paginate(:page => @page, :per_page =>@per_page )
      @group_users_plan =  User.where(:id => @users, :status=>1, :type=>"User")
      project_ids = User.where(:id => @users, :status=>1, :type=>"User").map{|f|f.projects.active.ids}.flatten
      @all_issues = Issue.where(project_id: project_ids).where(assigned_to_id: @users )
      @group_issues = @all_issues.map{|f| { :id=>f.id,  :estimated_hours=>f.estimated_hours.present? ? f.estimated_hours.round(2) : 0, :project_name=>f.project.name ,  :text=>f.subject,  :project_id=>f.project.id, :due_date=>f.due_date, :start_date=>f.start_date, :s_date=>f.start_date, :row_height=>50, :bar_height=>40, :end_date=>f.due_date,  :subject=>f.subject,   :type=>"issue", :tracker => f.tracker}}
      @issues = Issue.where(assigned_to_id: @group_users).where(:project_id => project_ids).where("(#{Issue.table_name}.start_date BETWEEN ? AND ?) OR (#{Issue.table_name}.due_date BETWEEN ? AND ?)", @start_date, @due_date, @start_date, @due_date)
       @data = @group_users.map{|f| { :wk_scheme => user_workload_scheme(f.id), :id => f.id, :color=>f.color,  :parent=>0,  :skills=> TeamMember.where(:member_id => f.id).pluck(:skills),  :text=> f.firstname + "  " + f.lastname, :row_height=>50, :bar_height=>40, :type=>"project", :user_id=>f.id, :login => f.login ,  :firstname => f.firstname, :lastname => f.lastname, :admin => f.admin,:created_on => f.created_on ,  :updated_on => f.updated_on, :estimated_hours => @issues.where(:assigned_to_id=>f.id).sum(:estimated_hours).round(2)}} + @issues.map{|f| {:id =>"i"+f.id.to_s, :wk_scheme => user_workload_scheme(f.assigned_to_id), :tracker => f.tracker,:project => f.project,:subject => f.subject,:description => f.description, :due_date => f.due_date, :category_id => f.category,:status_id => f.status, :assigned_to_id => f.assigned_to_id,  :wk_scheme => user_workload_scheme(f.assigned_to_id), :assigned_to => User.find_by_id(f.assigned_to_id).firstname + " " + User.find_by_id(f.assigned_to_id).lastname, s_date: f.start_date, :parent=> f.assigned_to_id, :priority_id => f.priority_id, :fixed_version_id => f.fixed_version_id, :author_id => f.author_id,:lock_version => f.lock_version, :row_height=>50, :bar_height=>40,  :text=>f.subject, :created_on => f.created_on,:updated_on => f.updated_on, :start_date => f.start_date,:done_ratio => f.done_ratio, :end_date=>f.due_date, :estimated_hours =>f.estimated_hours.present? ? f.estimated_hours.round(2) : 0 , :parent_id => f.parent_id, :root_id => f.root_id, :lft => f.lft, :rgt => f.rgt, :type=>"issue", :is_private => f.is_private, :closed_on => f.closed_on}}
      @workload_data[:data] = @data
       @workload_data[:users] =  @group_users_plan
      @workload_data[:issues] = @group_issues  
    render :json => {data: @workload_data[:data],  users:  @workload_data[:users], issues: @workload_data[:issues] }
    respond_to do |format|
    format.html
    format.api do
    @workload_data
   end
      end
   else
     @page = params[:page]
     @per_page = params[:per_page]
     id = User.current.id
     @user_id = User.current.id
     @group_id = TeamMember.where(member_id: @user_id).map(&:group_id).flatten.uniq
     @members = TeamMember.where(group_id: @group_id).map(&:member_id).flatten.uniq
      @workload_data = {}
     @user = User.where(:id => id, :status=>1, :type=>"User").limit(25)
     @user_paln = User.where(:id => id, :status=>1, :type=>"User")
     project_ids = User.where(:id => @user, :status=>1, :type=>"User").map{|f|f.projects.active.ids}.flatten
     @all_issues = Issue.where(project_id: project_ids).where(assigned_to_id: @user )
     @group_issues = @all_issues.map{|f| {  :id=>f.id,  :estimated_hours=>f.estimated_hours.present? ? f.estimated_hours.round(2) : 0, :project_name=>f.project.name ,  :text=>f.subject,  :project_id=>f.project.id, :due_date=>f.due_date, :start_date=>f.start_date, :s_date=>f.start_date, :row_height=>50, :bar_height=>40, :end_date=>f.due_date,  :subject=>f.subject,   :type=>"issue", :tracker => f.tracker}}
     @issues = Issue.where(:assigned_to_id => id).where(:project_id => project_ids).where("(#{Issue.table_name}.start_date BETWEEN ? AND ?) OR (#{Issue.table_name}.due_date BETWEEN ? AND ?)",  @start_date, @due_date, @start_date, @due_date)
     @data =  @user.map{|f| { :id => f.id, :wk_scheme => user_workload_scheme(f.id), :color=>f.color,   :parent=>0,  :skills=> TeamMember.where(:member_id => f.id).pluck(:skills),  :text=> f.firstname + "  " + f.lastname, :row_height=>50, :bar_height=>40, :type=>"project", :user_id=>f.id, :login => f.login ,  :firstname => f.firstname, :lastname => f.lastname, :admin => f.admin,:created_on => f.created_on ,  :updated_on => f.updated_on, :estimated_hours => @issues.where(:assigned_to_id=>f.id).sum(:estimated_hours).round(2)}} + @issues.map{|f| {:id =>"i"+f.id.to_s,:tracker => f.tracker,:project => f.project,:subject => f.subject,:description => f.description, :due_date => f.due_date, :category_id => f.category,:status_id => f.status, :wk_scheme => user_workload_scheme(f.assigned_to_id), :assigned_to_id => f.assigned_to_id, :assigned_to => User.find_by_id(f.assigned_to_id).firstname + " " + User.find_by_id(f.assigned_to_id).lastname, s_date: f.start_date, :parent=> f.assigned_to_id, :priority_id => f.priority_id, :fixed_version_id => f.fixed_version_id, :author_id => f.author_id,:lock_version => f.lock_version, :row_height=>50, :bar_height=>40,  :text=>f.subject, :created_on => f.created_on,:updated_on => f.updated_on, :start_date => f.start_date,:done_ratio => f.done_ratio, :end_date=>f.due_date, :estimated_hours =>f.estimated_hours.present? ? f.estimated_hours.round(2) : 0 , :parent_id => f.parent_id, :root_id => f.root_id, :lft => f.lft, :rgt => f.rgt, :type=>"issue", :is_private => f.is_private, :closed_on => f.closed_on}}
     @workload_data[:data] = @data
     @workload_data[:users] = @user_plan
      @workload_data[:issues] = @group_issues
     render :json => {data: @workload_data[:data],  users:  @workload_data[:users], issues: @workload_data[:issues] }
     respond_to do |format|
       format.html do
       end
         format.api do
        @workload_data
       end
       end
     end  
   end
 end
 
   def group_projects_issues 
     if User.current.groups.present?
       @user = User.current
       @groups = @user.groups.givable
       @issues = {}
       @users_data = []
   
       @groups.each do |group|
         @g_users = group.users.active.ids
         @projects =  group.projects
         @p_users = @projects.map{|p| p.users.ids }
         @g_users = @g_users.uniq
         @p_users = @p_users.flatten.uniq
         @users_data << (@g_users.concat(@p_users).uniq)
       end 
       @user_detail = User.where(:id=>@users_data)
       @users_issue = Issue.where(:assigned_to_id=>@users_data)
       @issues[:data] = @user_detail + @users_issue
       render :json =>  @issues
       respond_to do |format|
         format.html 
         format.api do
           @issues
         end 
       end 
     else  
       @issues = {}
       @user = User.current
       @issues[:data] = Issue.where(:assigned_to_id => @user)
       render :json =>  @issues
       respond_to do |format|
         format.html 
         format.api do 
           @issues
         end 
       end 
     end 
   
   end 
   
 
 
    # Get issues of all the group users in which current user is available 
   def project_issues 
     @user = User.current
     render :json =>  @user
     if User.current.groups.present?
       # @users_data = {}
       # @users =  User.current.groups.map(&:user_ids).flatten.uniq
       
       # @group_project_id  = @user.groups.givable
       # @group_users = User.where(:id => @users)
       # @issues = Issue.where(:assigned_to_id => @users)
       # @users = @group_users.map{|u| {:id=>u.id, :text=>u.firstname+" " + u.lastname, :row_height=>50, :bar_height=>40, :type=>"user", :user_id=>u.id, :created_on=>u.created_on,
       #   :estimated_hours=> Issue.where(:assigned_to_id=>u.id).sum(:estimated_hours)}} + @issues.map{|f| {:id =>"i"+f.id.to_s,:tracker_id => f.tracker_id,:project_id => f.project_id,:subject => f.subject,:description => f.description, :due_date => f.due_date, :category_id => f.category,:status_id => f.status, :assigned_to_id => f.assigned_to_id, :parent=> f.assigned_to_id, :priority_id => f.priority_id, :fixed_version_id => f.fixed_version_id, :author_id => f.author_id,:lock_version => f.lock_version, :row_height=>50, :bar_height=>40,  :text=>f.subject, :created_on => f.created_on,:updated_on => f.updated_on, :start_date => f.start_date,:done_ratio => f.done_ratio,:estimated_hours => f.estimated_hours, :parent_id => f.parent_id, :root_id => f.root_id, :lft => f.lft, :rgt => f.rgt, :type=>"issue", :is_private => f.is_private, :closed_on => f.closed_on}}
       # @users_data[:data] = @users
      
       # respond_to do |format|
       #   format.html 
       #   format.api do 
       #     @users_data
       #   end 
       # end 
     # else  
     #   # @issues = {}
     #   @user = User.current
     #   @group_users = User.where(:id => @user)
     #   @issues = Issue.where(:assigned_to_id=>@user)
     #   @users_data = @group_users.map{|u| {:id=>u.id, :text=>u.firstname+" " + u.lastname, :row_height=>50, :bar_height=>40, :type=>"user", :user_id=>u.id, :created_on=>u.created_on,
     #     :estimated_hours=> Issue.where(:assigned_to_id=>u.id).sum(:estimated_hours) }} + @issues.map{|f| {:id =>"i"+f.id.to_s,:tracker_id => f.tracker_id,:project_id => f.project_id,:subject => f.subject,:description => f.description, :due_date => f.due_date, :category_id => f.category,:status_id => f.status, :assigned_to_id => f.assigned_to_id, :parent=> f.assigned_to_id, :priority_id => f.priority_id, :fixed_version_id => f.fixed_version_id, :author_id => f.author_id,:lock_version => f.lock_version, :row_height=>50, :bar_height=>40,  :text=>f.subject, :created_on => f.created_on,:updated_on => f.updated_on, :start_date => f.start_date,:done_ratio => f.done_ratio,:estimated_hours => f.estimated_hours, :parent_id => f.parent_id, :root_id => f.root_id, :lft => f.lft, :rgt => f.rgt, :type=>"issue", :is_private => f.is_private, :closed_on => f.closed_on}}
     #   render :json => @users_data
     #   respond_to do |format|
     #     format.html 
     #     format.api do 
     #       @users_data
     #     end 
     #   end 
     end 
   end 
 
   
   
   def time
     if params[:user_id].present?
         @user = params[:user_id]
         @issues = Issue.where(:assigned_to_id => @user).limit(25)
         @issues = @issues.map{|e| {:id=>e.id, :subject=>e.subject, :description=>e.description, :updated_on=>e.updated_on, :start_date=>e.start_date, :estimated_hours=>e.estimated_hours, :parent_id=>e.parent_id, :done_ratio=>e.done_ratio, :due_date=>e.due_date, :created_on=>e.created_on, :end_date=>f.due_date, :assigned_to_id=>e.assigned_to_id,  :spent_hours =>TimeEntry.where(:issue_id=>e.id).sum(:hours)}}
         render :json => @issues
          respond_to do |format|
          format.html
          format.api do
          @issues
          end
         end
       end
   end
 
   def calendar_settings
     @start_week = Date.today.beginning_of_week
     @end_week = Date.today.end_of_week
   end 
 
   def resource_settings
   end 
 
   def get_dates
     current_day = Date.today
     @period_start = current_day.beginning_of_month
     @period_end = current_day.end_of_month
   end 
   
   def filter_by_group
     if params[:group_name].present?
       @user_id = User.current.id
       @group_id = TeamMember.where(member_id: @user_id).map(&:group_id).flatten.uniq
       @members = TeamMember.where(group_id: @group_id).map(&:member_id).flatten.uniq
       if @group_id.present?
        
       
 
         @group_users_plan =  User.where(:id => @members, :status=>1, :type=>"User")
       @parameter =   params[:group_name].downcase
       @group = WorkloadTeam.all.where("lower(name) LIKE ?","%#{@parameter}%").pluck(:id)
       @groups_data = {}
       @users = TeamMember.where(:group_id => @group).map(&:member_id).flatten.uniq
       @group_users =  User.where(:id => @users, :status=>1, :type=>"User")
       @all_issues = Issue.where(assigned_to_id: @users).limit(25)
       @group_issues=@all_issues.map{|f| { :id=>f.id , :subject=>f.subject , :estimated_hours=>f.estimated_hours.present? ? f.estimated_hours.round(2) : 0, :project_name=>f.project.name , :project_id=>f.project.id}}
       @issues = Issue.where(assigned_to_id: @users).where("(#{Issue.table_name}.start_date BETWEEN ? AND ?) AND (#{Issue.table_name}.due_date BETWEEN ? AND ?)", @period_start,@period_end,@period_start,@period_end).limit(25)
       @data = @group_users.map{|f| {:wk_scheme => user_workload_scheme(f.id), :holiday=> user_holiday_scheme(f.id), :id => f.id,  :parent=>0,  :color=>f.color, :skills=> TeamMember.where(:member_id => f.id).pluck(:skills),  :text=> f.firstname + " " + f.lastname, :row_height=>50, :bar_height=>40, :type=>"user", :user_id=>f.id, :login => f.login ,  :firstname => f.firstname, :lastname => f.lastname, :admin => f.admin,:created_on => f.created_on , :start_date=>"2022-08-11",  :updated_on => f.updated_on, :issues=>@issues.where(:assigned_to_id=>f.id), :estimated_hours => @issues.where(:assigned_to_id=>f.id).sum(:estimated_hours).round(2)}} + @issues.map{|f| {:id =>"i"+f.id.to_s, :holiday=> user_holiday_scheme(f.assigned_to_id),:tracker => f.tracker,:project => f.project,:subject => f.subject,:description => f.description, :due_date => f.due_date, :category_id => f.category,:status_id => f.status, :assigned_to_id => f.assigned_to_id,:wk_scheme => user_workload_scheme(f.assigned_to_id), :assigned_to => User.find_by_id(f.assigned_to_id).firstname + " " + User.find_by_id(f.assigned_to_id).lastname, s_date: f.start_date, :parent=> f.assigned_to_id, :priority_id => f.priority_id, :fixed_version_id => f.fixed_version_id, :author_id => f.author_id,:lock_version => f.lock_version, :row_height=>50, :bar_height=>40,  :text=>f.subject, :created_on => f.created_on,:updated_on => f.updated_on, :start_date => f.start_date,:done_ratio => f.done_ratio, :end_date=>f.due_date, :estimated_hours =>f.estimated_hours.present? ? f.estimated_hours.round(2) : 0 , :parent_id => f.parent_id, :root_id => f.root_id, :lft => f.lft, :rgt => f.rgt, :type=>"issue", :is_private => f.is_private, :closed_on => f.closed_on}}
       @groups_data[:data] = @data  
       @groups_data[:users] =  @group_users_plan
  
       @groups_data[:issues] = @group_issues  
     render :json =>  {data: @groups_data[:data],  users:  @groups_data[:users], issues: @groups_data[:issues] }
     respond_to do |format|
     format.html
     format.api do
       @groups_data
     end
   end
 else
   @workload_data = {}
    
   @workload_data[:data] = []
   render :json => @workload_data
   respond_to do |format|
   format.html
   format.api do
     @workload_data
   end
 end
 end
 end
    end
    def get_dates
     current_day = Date.today
     @period_start = current_day.beginning_of_month
     @period_end = current_day.end_of_month
   end
 
   def filter_by_users
     if params[:user_name].present?
       @user_id = User.current.id
       @group_id = TeamMember.where(member_id: @user_id).map(&:group_id).flatten.uniq
       @members = TeamMember.where(group_id: @group_id).map(&:member_id).flatten.uniq
       if @group_id.present?
         @group_users_plan =  User.where(:id => @members, :status=>1, :type=>"User")
       @parameter =   params[:user_name].downcase
       @users_data = {}
       scope =  User.where(:id => @members ).select("*,CONCAT(firstname, ' ', lastname) AS name")
       @users = scope.like(@parameter).pluck(:id)
       @group_users =  User.where(:id => @users, :status=>1, :type=>"User")
       @all_issues = Issue.where(assigned_to_id: @users).limit(25)
       @group_issues = @all_issues.map{|f| { :id=>f.id , :subject=>f.subject , :estimated_hours=>f.estimated_hours.present? ? f.estimated_hours.round(2) : 0, :project_name=>f.project.name , :project_id=>f.project.id}}
       @issues = Issue.where(assigned_to_id: @users).where("(#{Issue.table_name}.start_date BETWEEN ? AND ?) AND (#{Issue.table_name}.due_date BETWEEN ? AND ?)", @period_start,@period_end,@period_start,@period_end).limit(25)
       @data = @group_users.map{|f| {:wk_scheme => user_workload_scheme(f.id), :holiday=> user_holiday_scheme(f.id),:id => f.id,  :parent=>0,  :color=>f.color,  :skills=> TeamMember.where(:member_id => f.id).pluck(:skills),  :text=> f.firstname + " " + f.lastname, :row_height=>50, :bar_height=>40, :type=>"user", :user_id=>f.id, :login => f.login ,  :firstname => f.firstname, :lastname => f.lastname, :admin => f.admin,:created_on => f.created_on , :start_date=>"2022-08-11",  :updated_on => f.updated_on,  :issues=>@issues.where(:assigned_to_id=>f.id), :estimated_hours => @issues.where(:assigned_to_id=>f.id).sum(:estimated_hours).round(2)}} + @issues.map{|f| {:id =>"i"+f.id.to_s, :holiday=> user_holiday_scheme(f.assigned_to_id),:tracker => f.tracker,:project => f.project,:subject => f.subject,:description => f.description, :due_date => f.due_date, :category_id => f.category,:status_id => f.status, :assigned_to_id => f.assigned_to_id,:wk_scheme => user_workload_scheme(f.assigned_to_id), :assigned_to => User.find_by_id(f.assigned_to_id).firstname + " " + User.find_by_id(f.assigned_to_id).lastname, s_date: f.start_date, :parent=> f.assigned_to_id, :priority_id => f.priority_id, :fixed_version_id => f.fixed_version_id, :author_id => f.author_id,:lock_version => f.lock_version, :row_height=>50, :bar_height=>40,  :text=>f.subject, :created_on => f.created_on,:updated_on => f.updated_on, :start_date => f.start_date,:done_ratio => f.done_ratio, :end_date=>f.due_date, :estimated_hours =>f.estimated_hours.present? ? f.estimated_hours.round(2) : 0 , :parent_id => f.parent_id, :root_id => f.root_id, :lft => f.lft, :rgt => f.rgt, :type=>"issue", :is_private => f.is_private, :closed_on => f.closed_on}}
       @users_data[:data] = @data  
       @users_data[:users] = @group_users_plan
       @users_data[:issues] = @group_issues   
     render :json =>  {data: @users_data[:data],  users:  @users_data[:users], issues: @users_data[:issues] }
     respond_to do |format|
     format.html
     format.api do
       @users_data
     end
   end
 else
   @workload_data = {}
    
   @workload_data[:data] = []
   render :json => @workload_data
   respond_to do |format|
   format.html
   format.api do
     @workload_data
   end
 end
 end
 end
    end
    def get_dates
     current_day = Date.today
     @period_start = current_day.beginning_of_month
     @period_end = current_day.end_of_month
   end
   def user_workload_scheme(user)
     if user.present? 
       wk_scheme = WorkloadScheme.where(:user_id => user).pluck(:user_workload_id).uniq
       users_scheme = UserWorkload.where(:id => wk_scheme)
 
       return users_scheme
       render :json => users_scheme
     end 
  
   end 
 
  #  def user_holiday_scheme(user)
  #    if user.present? 
  #      id = HolidayScheme.where(:user_id => user).pluck(:user_holiday_id).uniq
  #      @holiday = UserHoliday.where(:id => id)
  #      @holiday_scheme = @holiday.map{|h| {:id => h.id, :name => h.name, :description=> h.description, :created_at=>h.created_at, :updated_at =>h.updated_at, :dates => h.holiday_dates }}
  #    end 
  #  end 

  def user_holiday_scheme(user)
    if user.present?
      id = HolidayScheme.where(user_id: user).pluck(:user_holiday_id).uniq
      @holiday = UserHoliday.where(id: id)
      @holiday_scheme = @holiday.map do |h|
        dates = h.holiday_dates.map do |date|
          {
            id: date.id,
            name: date.name,
            description: date.description,
            created_at: date.created_at,
            updated_at: date.updated_at,
            start_date: date.start_date,
            end_date: date.end_date || date.start_date,
            date_range: (date.start_date..(date.end_date || date.start_date)).to_a.map(&:to_s),
            user_holiday_id: date.user_holiday_id
          }
        end
        {
          id: h.id,
          name: h.name,
          description: h.description,
          created_at: h.created_at,
          updated_at: h.updated_at,
          dates: dates
        }
      end
    end
  end

   def create_default_record
   
     default_name = "Default"
     default_description = "Default workload"
     
     UserWorkload.create(name: default_name, description: default_description, wd0: 0, wd1: 8.42, wd2: 8.42, wd3: 8.42, wd4: 8.42, wd5: 8.42, wd6: 0)
     default_user_workload = UserWorkload.find_by(name: "Default")
 
     User.where(:status =>1).each do |user|
       WorkloadScheme.find_or_create_by(user_id: user.id, user_workload_id: default_user_workload.id)
     end
  
 end
 
 def workload_permissions
   
   @permission = {}
   roles = User.current.roles.to_a
   @permission[:manage_workload] = roles.any? { |role| role.permissions.include?(:manage_workload) }  
   @permission[:admin] = User.current.admin?
   render :json => @permission
   respond_to do |format|
    format.html 
    format.api do
       @permission                     
    end
   end
 end
 
 def update_dropdown_preference
   selected_option = params[:selected_option]
   current_user = User.current
 
   preference = DropdownPreference.find_or_initialize_by(user_id: current_user.id)
   preference.selected_option = selected_option
   preference.save!
 
   render json: { success: true , selected_option: preference }
 end


 private

def set_permissions
  roles = User.current.roles.to_a
  { manage_workload: roles.any? { |role| role.permissions.include?(:manage_workload) } }
end

def fetch_team_data_and_users
  if User.current.admin?
    team_data = WorkloadTeam.all.select(:id, :name)
    team_ids = team_data.pluck(:id)
    active_users = User.active.order("firstname ASC, lastname ASC")
  elsif team_member_manage_workload_permission?
    team_ids = TeamMember.where(member_id: User.current.id).pluck(:group_id)
    team_data = WorkloadTeam.where(id: team_ids).select(:id, :name)
    team_member_ids = TeamMember.where(group_id: team_ids).pluck(:member_id).uniq
    active_users = User.where(id: team_member_ids).order("firstname ASC, lastname ASC")
  else
    team_data = []
    active_users = User.where(id: User.current.id).order("firstname ASC, lastname ASC")
  end

  [team_data, active_users]
end

def team_member_manage_workload_permission?
  TeamMember.where(member_id: User.current.id).exists? && @permission[:manage_workload]
end





end
