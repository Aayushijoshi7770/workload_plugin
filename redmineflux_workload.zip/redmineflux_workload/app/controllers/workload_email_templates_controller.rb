class WorkloadEmailTemplatesController < ApplicationController

  def index
  end

  def new
    @email_template = EmailTemplate.new
  end

  def create
    @email_template = EmailTemplate.new(email_template_params)
    if @email_template.save
      flash[:notice] = "Template created successfully"
      redirect_to plugin_settings_path(:redmineflux_workload, tab: 'Templates')
    else
      render :new
    end
  end

  def edit
    @email_template = EmailTemplate.find(params[:id])
    @body_html = RedCloth.new(@email_template.body).to_html
    @footer_html = RedCloth.new(@email_template.footer).to_html
  end
  
  def update
    @email_template = EmailTemplate.find(params[:id])
    if @email_template.update(email_template_params)
      flash[:notice] = "Template updated successfully"
      redirect_to plugin_settings_path(:redmineflux_workload, tab: 'Templates')
    else
      render :edit
    end
  end

  # def destroy
  #   @email_template = EmailTemplate.find(params[:id])
  #   if @email_template.destroy
  #     flash[:notice] = "Template deleted successfully"
  #   else
  #     flash[:alert] = "Failed to delete template"
  #   end
  #   redirect_to plugin_settings_path(:redmineflux_workload, tab: 'Templates')
  # end

  def destroy
    @email_template = EmailTemplate.find(params[:id])
    
    if @email_template.destroy
      respond_to do |format|
        format.html do
          flash[:notice] = "Template deleted successfully"
          # redirect_to plugin_settings_path(:redmineflux_workload, tab: 'Templates')
        end
        format.json { render json: { message: 'Template deleted successfully' }, status: :ok }
      end
    else
      respond_to do |format|
        format.html do
          flash[:alert] = "Failed to delete template"
          # redirect_to plugin_settings_path(:redmineflux_workload, tab: 'Templates')
        end
        format.json { render json: { error: 'Failed to delete template' }, status: :unprocessable_entity }
      end
    end
  end
  
  


  private

  def email_template_params
    params.require(:email_template).permit(:template_name, :subject, :body, :footer)
  end
end
