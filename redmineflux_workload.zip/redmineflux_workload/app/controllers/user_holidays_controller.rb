class UserHolidaysController < ApplicationController
  accept_api_auth :search_users, :index, :add_members_to_holiday, :add_members_to_holiday_scheme, :update, :holiday_bulk_delete, :bulk_hdd_user_delete , :search_holiday_scheme_users , :search_holiday_scheme_members
 

  def index
    @holidays = UserHoliday.where(id: params[:id])
    respond_to do |format|
      format.html
      format.api { render :json => @holidays }
      format.json { render :json => @holidays }
    end 
  end

  def new
    @holiday = UserHoliday.new
    @holidays = UserHoliday.all
    
  end
  
  def create
    @holiday = UserHoliday.new(params.require(:user_holiday).permit(:name, :description, created_by: User.current.id, holiday_dates: []))
    if @holiday.save
      flash[:notice] = "Holiday scheme added successfully."
      redirect_to :back
      # redirect_to user_holiday_path(@holiday)
    elsif @holiday.errors.any?
      @holiday.errors.full_messages.each do |message|
        flash[:error] = message
        redirect_to :back
      end
    else  
      # flash[:error] = "Can't create holiday"
      render :action => 'new'
    end 
  end 

  def edit
    @holiday = UserHoliday.find(params[:id])
  end

  def show
    @holiday = UserHoliday.find(params[:id])
    @user_ids = HolidayScheme.where(:user_holiday_id => @holiday).pluck(:user_id)
    @users = User.where(:id => @user_ids).select(:firstname,:lastname).join(", ")
    @dates = @holiday.holiday_dates
  end


  def update
    @holiday = UserHoliday.find(params[:id])
  
    if @holiday.update(
      name: params[:name],
      description: params[:description]
    )
      flash[:notice] = 'Successfully Updated'
    elsif @holiday.errors.any?
      render json: { error: @holiday.errors.full_messages }, status: :unprocessable_entity
    else
      flash[:error] = 'Something went wrong'
    end
  end
  
  def destroy
    if (User.current.allowed_to?(:manage_workload, User.current.projects.to_a)) || (User.current.admin?)
      @holiday = UserHoliday.find(params[:id])
      @holiday_scheme = HolidayScheme.where(:user_holiday_id => @holiday)
      @holiday_scheme.each do |s|
        s.destroy
      end 
      @holiday.destroy
      redirect_to :back
      flash[:notice] = "Successfully destroyed holiday."
    else  
      flash[:error] = "You are not authorized"
      redirect_to :back
    end 
  end 

  def user_delete
    if (User.current.allowed_to?(:manage_workload, User.current.projects.to_a)) || (User.current.admin?)
      @user = HolidayScheme.where(user_id: params[:id])
      @user.destroy_all 
      redirect_to :back
      flash[:notice] = "Holiday member has been deleted" 
    else
      flash[:error] = "You are not authorized"
      redirect_to :back  
    end 
  end

  def search_users
    if User.present?
      if params[:name].present?
        @parameter =   params[:name].downcase
        @users = User.logged.where("lower(firstname) LIKE ? OR lower(lastname) LIKE ?", "%#{@parameter}%","%#{@parameter}%")
        render :json => @users
        respond_to do |format|
          format.html
          format.api do
            @users
          end
        end        
      end
    end
  rescue ActiveRecord::RecordNotFound
    render 404
  end  

  def add_members_to_holiday
    @users = params[:user_id] 
    scheme_id = params[:scheme_id]
    if (@users.present? && scheme_id.present?)
      @users.each do |user|
        @scheme = HolidayScheme.new(:user_holiday_id => scheme_id, :user_id => user)
        if @scheme.save  
          flash[:notice] = "Member added successfully"
        else  
          flash[:error] = "Member already exist in other scheme"
        end 
      end 
    end 
  end 
  
  def search_holiday_scheme_users
    name = params[:name]
    if name.present?
      @parameter = params[:name].downcase
      @all_holiday_user_ids = HolidayScheme.pluck(:user_id)
      scope = User.select("id, firstname, lastname, (firstname || ' ' || lastname) AS name").where(:status =>1).where.not(id: @all_holiday_user_ids)
      @user = scope.like(@parameter)
      render :json => @user
      respond_to do |format|
        format.html
        format.api do 
          @user
        end 
      end 
    else  
      return nil
    end 
  rescue ActiveRecord::RecordNotFound
    render 404
  end 
  
  def search_holiday_scheme_members
    if params[:name].present?
      @parameter = "%#{params[:name].downcase}%"
      @all_holiday_user_ids = HolidayScheme.pluck(:user_id)
  
      @user = User.where(id: @all_holiday_user_ids, status: 1)
                  .where("LOWER(CONCAT(firstname, ' ', lastname)) LIKE ?", @parameter)
                  .select("id, firstname, lastname, CONCAT(firstname, ' ', lastname) AS name")
   
        render json: @user
    else
      render json: { error: "Name parameter is missing" }, status: :unprocessable_entity
    end
  rescue ActiveRecord::RecordNotFound
    render json: { error: "Record not found" }, status: :not_found
  end


  def add_members_to_holiday_scheme
    @all_holiday_user_ids = HolidayScheme.pluck(:user_id)
    @users = User.all.where(:status => 1).where.not(id: @all_holiday_user_ids)
    respond_to do |format|
      format.api {render :json => @users }
    end 
  end 
  def holiday_bulk_delete
    if (User.current.allowed_to?(:manage_workload, User.current.projects.to_a)) || (User.current.admin?)
      @holiday = UserHoliday.find(params[:id])
      @holiday_scheme = HolidayScheme.where(:user_holiday_id => @holiday)
      @holiday_scheme.each do |s|
        s.destroy
      end 

      @holiday_dates = HolidayDate.where(:user_holiday_id => @holiday)
      @holiday_dates.each do |hd|
        hd.destroy
      end
     
      @data = UserHoliday.where(id: params[:id].split(',').map(&:to_i))
      @data.destroy_all
    
      flash[:notice] = "Successfully destroyed holiday scheme."
      render :json =>  @data
      respond_to do |format|
        format.html 
        format.api do
          @data         
         end
      end
    else  
      flash[:error] = "You are not authorized"
      redirect_to :back
    end 
  end
  def bulk_hdd_user_delete
    if (User.current.allowed_to?(:manage_workload, User.current.projects.to_a)) || (User.current.admin?)
      @user = HolidayScheme.where(user_id: params[:id].split(',').map(&:to_i))
      @user.destroy_all 
      render :json =>  @user
      respond_to do |format|
        format.html 
        format.api do
          @user         
         end
      end
      # redirect_to :back
      flash[:notice] = "Holiday member has been deleted" 
    else
      flash[:error] = "You are not authorized"
      redirect_to :back  
    end 
  end
end
