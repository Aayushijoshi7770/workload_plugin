class WorkHoursController < ApplicationController
  skip_before_action :verify_authenticity_token
  accept_api_auth :create, :show 

  def create
    issue_id = workhour_params[:issue]
    work_hours_entries = workhour_params[:entries]
  
    if issue_id.blank?
      return render json: { error: 'Issue ID is missing' }, status: :unprocessable_entity
    end
  
    issue = Issue.find_by(id: issue_id)
    unless issue
      return render json: { error: 'Issue not found' }, status: :not_found
    end
  
    if work_hours_entries.blank? || !work_hours_entries.is_a?(Array)
      return render json: { error: 'No valid work hours entries provided' }, status: :unprocessable_entity
    end
  
    errors = []
  
    ActiveRecord::Base.transaction do
      work_hours_entries.each do |entry|
        date = entry[:date]
        hours = entry[:hours]
        next if date.blank? || hours.blank?
  
        work_hour = issue.workhours.find_or_initialize_by(date: date)
        work_hour.hours = hours
        work_hour.created_by = User.current.id
        work_hour.issue_id = issue_id
  
        unless work_hour.valid?
          errors << { date: date, errors: work_hour.errors.full_messages }
          next
        end
  
        unless work_hour.save
          errors << { date: date, errors: work_hour.errors.full_messages }
        end
      end
  
      if errors.any?
        raise ActiveRecord::Rollback
      end
    end
  
    if errors.any?
      return render json: { errors: errors }, status: :unprocessable_entity
    end
  
    render json: { status: 'Hours added or updated successfully' }, status: :created
  end

  def show
    issue_id = params[:issue_id]
    start_date = params[:startDate]
    end_date = params[:dueDate]

    errors = []
    errors << 'Issue ID is missing' if issue_id.blank?
    errors << 'Start date is missing' if start_date.blank?
    errors << 'End date is missing' if end_date.blank?

    if start_date.present? && end_date.present? && start_date > end_date
      errors << 'Start date cannot be greater than end date'
    end

    if errors.any?
      render json: { errors: errors }, status: :unprocessable_entity and return
    end

    @workhours = Workhour.where(issue_id: issue_id).where(date: start_date..end_date)

    if @workhours.empty?
      render json: { message: 'No work hours found for the given date range.' }, status: :ok
    else
      render json: @workhours, status: :ok
    end
  end
  
  private
  
  def workhour_params
    params.require(:workhour).permit(:issue, entries: [:date, :hours])
  end
  
end
