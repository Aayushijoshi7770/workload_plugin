class HolidayDate < ActiveRecord::Base
    belongs_to :user_holidays
    validates_uniqueness_of :name ,scope: :user_holiday_id
    validates :name,  presence: true, length: {maximum: 55} 
    validates :description, length: {maximum: 255} 
    validates :start_date, presence: true
    validates :end_date, presence: true 
    validates_uniqueness_of :start_date, scope: :user_holiday_id, allow_nil: true
    validates_uniqueness_of :end_date, scope: :user_holiday_id, allow_nil: true
    validate :end_date_after_start_date
    validate :no_overlapping_dates
    private

    def end_date_after_start_date
      return if end_date.blank? || start_date.blank?
      if end_date <  start_date
        errors.add(:end_date, "must be greater than start date")
      end
    end

    def no_overlapping_dates
      return if start_date.blank? || end_date.blank?
      overlapping_holidays = HolidayDate.where.not(id: self.id).where(user_holiday_id: self.user_holiday_id).where("start_date < ? AND end_date > ?", end_date, start_date)
      if overlapping_holidays.exists?
        errors.add(:base, "Holiday dates must be unique and cannot overlap with already scheduled holidays")
      end
    end
    public

    def dates_between
      return [] if start_date.blank? || end_date.blank?
      (start_date..end_date).map { |date| date.strftime("%Y-%m-%d") }
    end
  end
