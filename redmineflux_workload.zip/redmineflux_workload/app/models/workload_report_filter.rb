class WorkloadReportFilter < ActiveRecord::Base
end
