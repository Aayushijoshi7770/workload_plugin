class WorkloadTeam < ActiveRecord::Base
    validates_uniqueness_of :name
    validates :name, presence: true, length: {maximum: 55} 
    validates :name, presence: true, format: { with: /\A[^!@#%^,&*"]+\z/, message: "cannot contain symbols !@#%^,&*" }
    before_destroy :delete_team_preferences

    private

    def delete_team_preferences
      TeamPreferences.where(team_id: self.id).destroy_all
    end
end        
