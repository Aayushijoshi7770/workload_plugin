class CreateTeamMembers < ActiveRecord::Base
    validates :member_id, :presence => true, :uniqueness => true  
end
 