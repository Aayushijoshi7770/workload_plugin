class WorkloadReport < ActiveRecord::Base
end
