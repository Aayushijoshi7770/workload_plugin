class UserTeamMember < ActiveRecord::Base

end
