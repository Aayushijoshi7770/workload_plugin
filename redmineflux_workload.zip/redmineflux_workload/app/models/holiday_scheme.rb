class HolidayScheme < ActiveRecord::Base
    validates :user_id, uniqueness: { scope: :user_holiday_id }
    validates_uniqueness_of :user_id
    
end
