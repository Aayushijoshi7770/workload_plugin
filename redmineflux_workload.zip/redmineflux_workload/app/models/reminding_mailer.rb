class RemindingMailer < ActionMailer::Base
  default from: Setting.mail_from
 
  def remind_workload_planning(cc_user, to_user, planned_hours, available, required_workload_hours, user_available_percentage, workload_total_available_hours, earliest_start_date, latest_end_date, email_template)
    @cc_user = cc_user
    @to_user = to_user
    @planned = planned_hours
    @available = available
    @remaining_hours = required_workload_hours
    @user_available_percentage = user_available_percentage
    @workload_total_available_hours = workload_total_available_hours
    @date_from = earliest_start_date
    @date_to = latest_end_date
    @template = EmailTemplate.find_by(id: email_template)
 
    Rails.logger.info "Remind workload planning called with template: #{@template.inspect}"
 
    if @template
      email_subject = replace_macros(@template.subject, false)
      email_body = replace_macros(@template.body)
      email_footer = replace_macros(@template.footer)
      complete_email_body = "#{email_body}<br><br>#{email_footer}"
 
      mail(to: @to_user.mail, subject: email_subject) do |format|
        format.html { render inline: complete_email_body }
      end
    else
      Rails.logger.error "Email template with id #{email_template} not found"
      send_dummy_email
    end
  rescue => e
    Rails.logger.error "Error in remind_workload_planning: #{e.message}"
    Rails.logger.error e.backtrace.join("\n")
    send_dummy_email
  end
 
  private
 
  def replace_macros(content, convert_to_html = true)
    date_range = "#{@date_from.to_s} to #{@date_to.to_s}"
    content.gsub!("\r", "") # Remove carriage return characters
    content.gsub!("{user_first_name}", @to_user.firstname)
    content.gsub!("{user_last_name}", @to_user.lastname)
    content.gsub!("{user_email}", @to_user.mail)
    content.gsub!("{user_available_percentage}", "#{@user_available_percentage}%")
    content.gsub!("{user_minimum_percentage}", "#{@remaining_hours}%")
    content.gsub!("{date}", date_range)
    content.gsub!("{workload_planned_hours}", @planned.to_s)
    content.gsub!("{workload_total_available_hours}", @workload_total_available_hours.to_s)
 
    convert_to_html ? convert_textile_to_html(content) : content
  end
 
  def convert_textile_to_html(textile_content)
    # RedCloth for Textile to HTML conversion
    RedCloth.new(textile_content).to_html
  end
 
  def send_dummy_email
    subject = "Workload Planning Reminder"
    body = <<~EMAIL
      Hello #{@to_user.firstname} #{@to_user.lastname},
 
      We hope this message finds you well. This is a gentle reminder to plan your workload for the upcoming period.
      Here are your current workload details:
      Total Available Hours: #{@workload_total_available_hours}
      Planned Hours: #{@planned}
      Available Percentage: #{@user_available_percentage}
      Minimum Percentage: #{@remaining_hours}
 
      Thanks and Best Regards,
    EMAIL
 
    mail(to: @to_user.mail, subject: subject, body: body)
  end
end