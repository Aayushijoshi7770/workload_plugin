class UserWorkload < ActiveRecord::Base
    validates_presence_of :wd0, :wd1, :wd2, :wd3, :wd4, :wd5, :wd6, message: "value can't be blank"
    validates_uniqueness_of :name
    validates :name, presence: true, length: { maximum: 55 }
    validates :description, length: { maximum: 255 }
    validates :wd0, :wd1, :wd2, :wd3, :wd4, :wd5, :wd6, numericality: { allow_nil: true, greater_than_or_equal_to: 0, less_than_or_equal_to: 12, without_attribute_name: true }
  
    def wd0=(value)
      converted_value = convert_time(value)
      super(converted_value)
    end
  
    def wd1=(value)
      converted_value = convert_time(value)
      super(converted_value)
    end
  
    def wd2=(value)
      converted_value = convert_time(value)
      super(converted_value)
    end
  
    def wd3=(value)
      converted_value = convert_time(value)
      super(converted_value)
    end
  
    def wd4=(value)
      converted_value = convert_time(value)
      super(converted_value)
    end
  
    def wd5=(value)
      converted_value = convert_time(value)
      super(converted_value)
    end
  
    def wd6=(value)
      converted_value = convert_time(value)
      super(converted_value)
    end
  
    private
  
    def convert_time(value)
      if value.is_a?(String) && value.include?(":")
        hours, minutes = value.split(":").map(&:to_i)
        value = hours + (minutes.to_f / 60.0)
        value.round(2)
      else
        value.to_f.round(2)
      end
    end
  end
