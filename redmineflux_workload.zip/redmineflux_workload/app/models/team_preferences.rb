class TeamPreferences < ActiveRecord::Base
    # serialize :team_ids, Array
end
