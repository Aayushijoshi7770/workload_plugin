class UserHoliday < ActiveRecord::Base
    has_many :holiday_dates
    accepts_nested_attributes_for :holiday_dates
    # validates_presence_of :name, presence: true, length: {maximum: 55} 
    validates :name, presence: true, length: {maximum: 55} 
    validates :description, length: {maximum: 255}
    validates_uniqueness_of :name
end

