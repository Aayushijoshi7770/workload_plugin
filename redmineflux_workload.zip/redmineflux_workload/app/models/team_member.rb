class TeamMember < ActiveRecord::Base
    validates :member_id, uniqueness: { scope: :group_id }
    validate :joining_date_cannot_be_greater_than_leaving_date
    before_destroy :delete_team_preference
    private
  
    def joining_date_cannot_be_greater_than_leaving_date
      if joining_date.present? && leaving_date.present? && joining_date > leaving_date
        errors.add(:joining_date, "can't be greater than leaving date")
      end
    end

    def delete_team_preference
      TeamPreferences.where(team_id: self.group_id).destroy_all
    end
end
       