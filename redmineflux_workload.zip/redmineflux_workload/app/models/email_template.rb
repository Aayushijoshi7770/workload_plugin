class EmailTemplate < ActiveRecord::Base
  validates :template_name, presence: true, uniqueness: true, length: { maximum: 255 }
  validates :subject, presence: true, length: { maximum: 255 }
  end