class WorkloadScheme < ActiveRecord::Base
   # has_and_belongs_to_many :user_workload 
   validates :user_id, uniqueness: { scope: :user_workload_id }
   validates_uniqueness_of :user_id
   validates :user_workload_id, presence: true
   validates :user_id, presence: true 

   
end
  