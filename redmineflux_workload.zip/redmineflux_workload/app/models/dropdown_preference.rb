class DropdownPreference < ActiveRecord::Base
    belongs_to :user
end
