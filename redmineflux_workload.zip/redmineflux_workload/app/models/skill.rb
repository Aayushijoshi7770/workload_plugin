class Skill < ActiveRecord::Base
    has_many :users, class_name: "User", foreign_key: "reference_id"
    validates_uniqueness_of :skill
    validates :skill, presence: true, length: {maximum: 55} 
    validates :skill, presence: true, format: { with: /\A[^!@#%^,&*"]+\z/, message: "cannot contain symbols !@#%^,&*" }
end
