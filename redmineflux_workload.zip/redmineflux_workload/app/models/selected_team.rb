class SelectedTeam < ActiveRecord::Base
end
