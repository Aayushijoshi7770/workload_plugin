class People < ActiveRecord::Base
    
end
