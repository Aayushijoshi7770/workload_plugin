module WorkloadReportsHelper
end
