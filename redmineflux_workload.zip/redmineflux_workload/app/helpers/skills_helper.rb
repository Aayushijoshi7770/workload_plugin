module SkillsHelper
end
