module WorkloadEmailTemplatesHelper
end
