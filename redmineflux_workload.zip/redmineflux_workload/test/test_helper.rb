# Load the Redmine helper
require_relative '../../../test/test_helper'
